import {e164,PhoneError,text,type Owner} from './core'
export function reservationProfile(body:any){
 const fullName=body.fullName?text(body.fullName,'full reservation name',120):null,email=body.email?text(body.email,'reservation email',254):null,birthDate=body.birthDate||null
 if(email&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))throw new PhoneError('Enter a valid reservation email.')
 if(birthDate&&(!/^\d{4}-\d{2}-\d{2}$/.test(birthDate)||!Number.isFinite(Date.parse(birthDate+'T12:00:00Z'))||new Date(birthDate+'T12:00:00Z').toISOString().slice(0,10)!==birthDate||Date.parse(birthDate)>Date.now()||Number(birthDate.slice(0,4))<1900))throw new PhoneError('Enter your exact birth date privately using the date picker.')
 if(typeof body.allowBirthDateForDoctorTravel!=='boolean')throw new PhoneError('Choose whether doctors/travel may use your saved date of birth.')
 return{fullName,email,birthDate,allowBirthDateForDoctorTravel:body.allowBirthDateForDoctorTravel}
}
export function ownerContactStore(pool:any){
 let initialized:Promise<any>|null=null
 const owner=(value:Owner)=>{if(!['salvador','dayanna'].includes(value))throw new PhoneError('Owner not verified.',403);return value}
 async function ready(){if(!initialized)initialized=(async()=>{await pool.query("CREATE TABLE IF NOT EXISTS friday_owner_contacts (owner TEXT PRIMARY KEY CHECK (owner IN ('salvador','dayanna')), phone TEXT NOT NULL, updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW())");await pool.query("ALTER TABLE friday_owner_contacts ADD COLUMN IF NOT EXISTS reservation_profile JSONB NOT NULL DEFAULT '{}'::jsonb")})().catch(()=>{initialized=null;throw new PhoneError('Private contact database is unavailable. No contact details were saved.',503)});await initialized}
 const result=(key:Owner,row:any)=>({owner:key,phone:row?.phone||null,updatedAt:row?.updated_at||null,fullName:row?.reservation_profile?.fullName||null,email:row?.reservation_profile?.email||null,birthDate:row?.reservation_profile?.birthDate||null,allowBirthDateForDoctorTravel:row?.reservation_profile?.allowBirthDateForDoctorTravel===true})
 return{
  async get(value:Owner){const key=owner(value);await ready();try{const r=await pool.query('SELECT phone, reservation_profile, updated_at FROM friday_owner_contacts WHERE owner = $1',[key]);return result(key,r.rows[0])}catch{throw new PhoneError('Private contact database could not be read.',503)}},
  async save(value:Owner,phone:unknown){const key=owner(value),number=e164(phone);await ready();try{const r=await pool.query('INSERT INTO friday_owner_contacts (owner, phone) VALUES ($1, $2) ON CONFLICT (owner) DO UPDATE SET phone = EXCLUDED.phone, updated_at = NOW() RETURNING phone, reservation_profile, updated_at',[key,number]);return result(key,r.rows[0])}catch{throw new PhoneError('Phone number could not be saved. Entry retained; check the private database.',503)}},
  async saveProfile(value:Owner,body:any){const key=owner(value),number=body.phone?e164(body.phone):'',profile=reservationProfile(body);await ready();try{const r=await pool.query('INSERT INTO friday_owner_contacts (owner, phone, reservation_profile) VALUES ($1, $2, $3::jsonb) ON CONFLICT (owner) DO UPDATE SET phone = EXCLUDED.phone, reservation_profile = EXCLUDED.reservation_profile, updated_at = NOW() RETURNING phone, reservation_profile, updated_at',[key,number,JSON.stringify(profile)]);return result(key,r.rows[0])}catch{throw new PhoneError('Reservation profile could not be saved. Entry retained; check the private database.',503)}}
 }
}
