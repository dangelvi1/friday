import twilio from 'twilio'
import {resolveOwnerSession} from '../../auth/owner-session'
import {PhoneError} from '../appointments/core'
import {officeInstructions} from './service'
import {getGmailClient} from '../../gmail-auth.js'
export function registerOfficeInstructions(app:any,deps:any){
 const mailbox=deps.mailbox||(async()=>{const gmail=await getGmailClient(),r=await gmail.users.getProfile({userId:'me'});return r.data.emailAddress||''}),sendMail=deps.sendMail||(async(b:any)=>{const gmail=await getGmailClient(),raw=['From: '+b.from,'To: '+b.to,'Subject: =?UTF-8?B?'+Buffer.from(b.subject).toString('base64')+'?=','Message-ID: <'+b.messageId+'>','MIME-Version: 1.0','Content-Type: text/plain; charset=UTF-8','Content-Transfer-Encoding: base64','',Buffer.from(b.text).toString('base64')].join('\r\n'),r=await gmail.users.messages.send({userId:'me',requestBody:{raw:Buffer.from(raw).toString('base64url')}});if(!r.data.id)throw Error();return r.data.id}),service=officeInstructions({...deps,mailbox,sendMail})
 const endpoint=(fn:any)=>async(req:any,res:any)=>{res.set('Cache-Control','no-store');const s=resolveOwnerSession(req);if(!s)return res.status(401).json({success:false,error:'Sign in before using private office instructions.'});try{res.json(await fn(req,s.owner))}catch(e:any){res.status(e instanceof PhoneError?e.status:400).json({success:false,error:e instanceof PhoneError?e.message:'Office instruction request failed. Your draft was retained; no automatic retry.'})}}
 app.get('/phone/instructions/contacts',endpoint(async(req:any,owner:any)=>({success:true,contacts:await service.contacts.list(owner,req.query.businessScope)})))
 app.post('/phone/instructions/contacts',endpoint(async(req:any,owner:any)=>({success:true,contact:await service.contacts.save(owner,req.body),message:'Office contact saved privately for this owner and company.'})))
 app.get('/phone/instructions',endpoint((_req:any,owner:any)=>service.list(owner)))
 app.post('/phone/instructions/prepare',endpoint((req:any,owner:any)=>service.prepare(owner,req.body)))
 app.post('/phone/instructions/:id/approve',endpoint((req:any,owner:any)=>service.approve(owner,req.params.id,req.body?.approved)))
 app.post('/phone/instructions/:id/stop',endpoint((req:any,owner:any)=>service.stop(owner,req.params.id)))
 app.post('/phone/instructions/:id/receipt',endpoint(async(req:any,owner:any)=>({success:true,review:service.publicJob(await service.store.get(owner,req.params.id))})))
 app.post('/phone/instructions/hooks/:id/:step',async(req:any,res:any)=>{try{const c=service.config();if(req.originalUrl!==req.path||!twilio.validateRequest(c.authToken,String(req.headers['x-twilio-signature']||''),c.base+req.path,req.body))return res.sendStatus(403);const r=await service.hook(req.params.id,req.params.step,req.body);if(r.statusOnly)return res.sendStatus(204);res.type('text/xml').send(r.twiml)}catch{res.sendStatus(403)}})
 const timer=deps.scheduler===false?null:setInterval(()=>{void service.runDue().catch(()=>{})},15000);timer?.unref();return{service,close(){if(timer)clearInterval(timer)}}
}
