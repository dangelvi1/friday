# Validation — Crosslist Inspector v11

158 reported automated entries passed: 140 specific checks plus 18 parent tests, no failures/skips. Uses temporary synthetic owner keys and actual Chromium with intercepted Crosslist test pages. No real Crosslist, Vinted, Shopify, QuickBooks or Calendar accounts were contacted. The Companion Page supplied no live DOM, so actual account/form compatibility is not claimed.

```sh
FRIDAY_TEST_TOOLS=/workspace/scratch/friday-test-tools node --import tsx --test tests/crosslist.test.ts tests/vinted.test.ts tests/calendar-context.test.ts tests/calendar-event-actions.test.ts tests/calendar-cancel.test.ts tests/voice-approvals.test.ts tests/calendar.test.ts tests/invoice-fields.test.ts tests/live-bank-feed.test.ts tests/bank-workflows.test.ts tests/document-review.test.ts
```

New Chromium/route checks cover owner authentication before launching Chrome, dedicated exact-origin dashboard navigation, manual workspace confirmation, separate owner tab handles, observed labels/native select options/custom visible options, preservation of brand/condition/price/quantity, no form submission, credential/hidden/arbitrary-value exclusion, query-string stripping, rejection of unrelated origins, login-screen handling and actual panel verification/inspection/owner lock. Existing Vinted/voice/Calendar/invoice/bank/Document Analysis regression suites passed.

Frontend TypeScript and targeted backend TypeScript passed. Standalone Vite compilation passed with the existing >500KB chunk warning. Windows-specific HTTPS certificate config is unchanged; the cloud build does not load those PC paths. Package CRC, manifest/file/baseline hashes and private-data/secret-pattern exclusions are checked. Installer/restore PowerShell reviewed but not executed: Windows/PowerShell/S: drive are unavailable here.

Not tested live: PC Chrome profile/account, actual Crosslist workspace/editor/dropdowns/save semantics, physical microphone, desktop wrapper and Windows installation/rollback. This module does not contain editing/click/fill/save/publish endpoints, so no real bulk changes were performed or claimed. Only explicitly authenticated inspection can read listing metadata; it never reads cookies/tokens/password fields and does not interact with Vinted. Inspection output may include private product titles/amounts and should be reviewed before sharing. Existing private configuration, credentials, data, AGENTS.md and Chrome profile are not packaged or modified by installation.
