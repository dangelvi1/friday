# FRIDAY Crosslist Inspector v11 — 20261104-11

For Salvador/Dayanna's existing PC-hosted FRIDAY at S:\AI\friday-ai, over Vinted Browser Preparation v10. This is the read-only connection/inspection step needed before implementing real Crosslist bulk editing. The provided address https://app.crosslist.com/?tab=all is the dashboard containing Shopify-imported listings, not an individual editor. An item published on Shopify is not assumed to be published on Vinted or other marketplaces.

## Scope and current status

Adds “Crosslist dashboard setup” to the existing voice page and a natural voice inspection tool. It opens a dedicated app.crosslist.com Chrome tab using FRIDAY's established persistent browser profile. Existing bank-feed/Vinted tabs and the natural voice session/pointer are preserved. Type your existing owner key privately, sign in to Crosslist yourself and confirm the correct SALDANA SHOP workspace before reading its contents. That account/workspace identity is manually confirmed by the owner, not automatically proven by FRIDAY.

Inspection returns observed headings, field labels/types/IDs, approved listing-field values, native select options, currently visible custom dropdown options, same-origin link paths and basic photo counts. Login/password screens stop inspection; hidden/password/email inputs, cookies, tokens and arbitrary input values are excluded. Query strings are omitted from observed links. Product titles and selected listing values can still appear: review output before sharing it. It does not export a catalog or private file to GitHub.

This version does NOT edit, fill, save, list, delist, publish or bulk update Crosslist listings. There are no click/fill/submit endpoints. It does not touch Shopify products, Vinted pages, inventory quantities or marketplace connections. Screenshots are not sufficient to identify custom dropdown option IDs or validate save behavior, and the live Companion Page was empty. The actual DOM evidence from this inspector is needed to build and test a compatible editor without guessed controls.

Requested correction plan, not yet applied: confirmed Vans listings → Brand “Vans”, Condition “New without tags”. Color must be assessed per product photo. Blue/navy primary and white secondary apply only to the supplied example; do not apply them to all Vans. Preserve price, size, quantity and photos. Unknown colors stay for review. A later editing patch must preview the specific batch, accept one owner decision, validate current row/form revisions, verify each save and report partial/uncertain outcomes honestly.

## Install from any PowerShell directory

Stop FRIDAY's backend and Vite process. Extract this ZIP under S:\AI\Fixing-Files-Folder\FRIDAY-Crosslist-Inspector-v11, then run:

```powershell
$packageRoot = 'S:\AI\Fixing-Files-Folder\FRIDAY-Crosslist-Inspector-v11'
$installers = @(Get-ChildItem -LiteralPath $packageRoot -Filter 'Install-Crosslist-Inspector.ps1' -File -Recurse -ErrorAction Stop)
if ($installers.Count -ne 1) { throw 'Expected exactly one installer. Check the extracted folder.' }
$installer = $installers[0].FullName
Unblock-File -LiteralPath $installer
Unblock-File -LiteralPath (Join-Path (Split-Path $installer) 'Restore-Crosslist-Inspector.ps1')
& $installer -ProjectPath 'S:\AI\friday-ai'
if (-not $?) { throw 'Installation failed. Do not continue.' }
Set-Location -LiteralPath 'S:\AI\friday-ai'
npm run build
if ($LASTEXITCODE -ne 0) { throw 'Build failed. Do not continue.' }
npm run server
```

In a second terminal:

```powershell
Set-Location -LiteralPath 'S:\AI\friday-ai'
npm run dev
```

Press Ctrl+F5 at https://localhost:5173/ and reconnect voice. The installer validates package/installed/required hashes, creates a verified backup and copies only five app/test files. No dependencies, DB migration, OAuth reset, credential/session copying or Vite certificate changes. No AGENTS.md replacement. If a baseline differs it stops before copying. PowerShell was reviewed, not executed in this Linux environment; enforced signed-script policy is not overridden.

## First live inspection

1. Open **Crosslist dashboard setup** in FRIDAY and verify your existing owner key.
2. Click **Open Crosslist dashboard**. In the dedicated Chrome window, sign in manually if needed. Confirm your SALDANA SHOP Shopify inventory is present. Return to FRIDAY and check the workspace confirmation box.
3. Click **Inspect current dashboard / editor** to inspect the dashboard. Use **Copy inspection result** and send the output so listing selection/batch controls can be implemented from observed identifiers.
4. In the same dedicated Crosslist tab, manually open the pictured Vans item. Inspect again to capture its editor.
5. For custom dropdowns, open Brand and filter/select nothing yet. While the dropdown remains open, say **“Inspect Crosslist”**. Voice inspection avoids switching windows and potentially closing the dropdown on blur. Repeat for Condition and Primary/Secondary color, capturing the actual visible option labels. If switching back to FRIDAY closes a dropdown, use voice while the Crosslist tab is frontmost.

The owner key, login passwords, cookies and tokens must never be shared. Read the inspection output before sending it; it may contain product names, amounts and observed listing values. If the site blocks this browser, stop and report the block rather than bypassing it. This module does not attempt to hide automation or interact with the Vinted session that was blocked earlier.

Useful voice commands: “Open Crosslist setup”, “Open the Crosslist dashboard”, “Inspect Crosslist”. Edits are deliberately not available until the real form is validated. The connection is code-tested against synthetic pages, not against the owner's authenticated Crosslist session.

## Restore

Stop FRIDAY. Run Restore-Crosslist-Inspector.ps1 from the printed backups\crosslist-inspector-v11-[timestamp] directory, rebuild/restart backend/dev, hard-refresh and reconnect voice. Restore checks file hashes and refuses later source edits. All private data/configuration/Chrome profile remains. No listing changes are made by this module or its rollback.
