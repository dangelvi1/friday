# FRIDAY Immediate Voice Commands v8 — 20261020-8

For Salvador and Dayanna's working PC-hosted FRIDAY at S:\AI\friday-ai. Install over Voice Approvals v7. Corrects the repeated review/fresh-confirmation loop reported during the owner's live microphone test and adds cancellation of saved Calendar events by spoken title. Existing owner authentication, company isolation, revision checks and duplicate protection remain.

## Corrected behavior

- “Please cancel that event,” “Cancel it,” and courtesy variants cancel a pending review immediately, including during FRIDAY's explanation. There is no readback-completion requirement or second cancellation approval. An expired/changed pending dialog can still be dismissed safely.
- An explicit “Approve that event” applies once to the current unchanged displayed review in the verified owner session, including during speech. Re-inspecting the same review no longer erases the spoken command. Simultaneous automatic microphone dispatch and model tool calls share one result instead of submitting twice or asking again.
- Repeated tool calls receive the cached outcome. Closing a review does not create another approval notification. FRIDAY is instructed not to restart cancelled reviews or ask for another decision on the same action.
- A new/different or changed action still requires its own decision. Multiple open actions require identifying which one. Production QuickBooks retains the full company confirmation. Unknown workflows remain manual. A bare yes or quoted instructions in documents/email still do not approve a write.

Voice commands are confirmation inside the manually verified owner session. This does not enable biometric speaker recognition; the existing recognition switch remains off. Owner keys remain typed privately in the relevant panel. No Google/Gmail reconnect is needed.

## Cancel a saved Calendar event

Say “Friday, cancel [the event title],” optionally specifying Personal/Nationwide and the occurrence date/time. FRIDAY looks up real events only in your configured owner calendars. A unique normalized exact title match is identified with its calendar, date and time, then cancelled without asking for another approval. There is no fuzzy automatic deletion.

If a title matches more than one event, FRIDAY asks which date/time or calendar. That selection continues the existing cancellation request; it is not another approval question. It never chooses a duplicate title by guessing. A recurring series requires an occurrence date; only the selected instance is cancelled, not the series. Special Google event types such as contact birthdays require their dedicated native controls.

“Cancel that event” with a pending draft dismisses that draft; it does not also delete an older saved event. If no pending draft exists, the current newly created Calendar receipt can identify the saved event. Otherwise name its title. One speech item cannot authorize both a pending cancellation and a saved-event deletion.

Saved-event cancellation is a real Google Calendar change. The backend rechecks owner, connection, destination mapping and event ETag and sends an If-Match conditional delete. Meetings with guests use Google's normal cancellation updates to attendees; no unrelated emails are sent. A shared Nationwide event is removed from that actual calendar, so office users see its cancellation. Merely finding/reading an event never cancels it.

Receipts and duplicate claims are private under credentials/calendar/cancellations/. Uncertain cancellations must be checked with Check last receipt or Load recent event receipts; never resubmit automatically or delete the claim to retry. If account/mapping changes, inspect the original Google calendar. A saved event is never recreated as a retry. No real events were cancelled during cloud testing.

## Install from any PowerShell location

Stop only FRIDAY's backend. Extract under S:\AI\Fixing-Files-Folder\FRIDAY-Immediate-Voice-Commands-v8 and run:

```powershell
$packageRoot = 'S:\AI\Fixing-Files-Folder\FRIDAY-Immediate-Voice-Commands-v8'
$installers = @(Get-ChildItem -LiteralPath $packageRoot -Filter 'Install-Immediate-Voice.ps1' -File -Recurse -ErrorAction Stop)
if ($installers.Count -ne 1) { throw 'Expected exactly one Install-Immediate-Voice.ps1. Check the extracted folder.' }
$installer = $installers[0].FullName
Unblock-File -LiteralPath $installer
Unblock-File -LiteralPath (Join-Path (Split-Path $installer) 'Restore-Immediate-Voice.ps1')
& $installer -ProjectPath 'S:\AI\friday-ai'
if (-not $?) { throw 'Installation failed. Do not continue.' }
Set-Location -LiteralPath 'S:\AI\friday-ai'
npm run build
if ($LASTEXITCODE -ne 0) { throw 'Build failed. Do not restart with an incomplete build.' }
npm run server
```

Restart the existing npm run dev process in its separate terminal too. Hard-refresh https://localhost:5173/ with Ctrl+F5; disconnect/reconnect the voice session. Close old dashboard/full-review tabs and reopen them through the refreshed conversational voice link.

The installer verifies package and installed-source hashes, creates a verified timestamped backup, then copies only 12 listed files. If a baseline differs, stop and obtain a compatible patch; do not force copying. It does not override an enforced Windows signed-script policy. Existing .env, Calendar client/tokens/mappings, Gmail files, localhost callback, databases and private uploads are unchanged. No dependency installation or OAuth reset.

## Owner-PC test

1. Verify owner in Calendar and connect the natural voice session.
2. Prepare a disposable draft. While FRIDAY explains it, say “Please cancel that event.” The pending dialog should close, the draft remain, and nothing be created. No repeated readback should follow.
3. Prepare an event you intend to save. Say “Approve that event” once, including during speech. Verify one created event and its native link; do not repeat the command while a save is in flight.
4. Say “Cancel [that exact title].” Confirm the actual saved event is cancelled, with no extra approval question. For duplicate titles expect only a date/calendar selection. Test guest notification behavior only on a meeting whose cancellation you actually intend to send.

Live microphone recognition/latency and actual Google behavior remain PC tests. Automated suites use synthetic records/clients and actual Chromium; see VALIDATION.md.

## Restore

Stop FRIDAY. Run Restore-Immediate-Voice.ps1 from the printed backups\immediate-voice-v8-[timestamp] directory, rebuild and restart backend/dev, then hard-refresh and reopen paired tabs. Restore verifies hashes and refuses later edits. It restores app files only; private credentials/receipts/DB/files remain. Code rollback does not undo an event already created or cancelled in Google Calendar. AGENTS-MERGE-PROPOSAL.md is a proposal only; AGENTS.md is not overwritten.
