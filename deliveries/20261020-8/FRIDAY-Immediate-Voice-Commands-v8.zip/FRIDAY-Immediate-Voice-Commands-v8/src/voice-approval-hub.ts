import {VoiceApprovalGate} from './voice-approval-gate'
const registry=()=> (window as any).FridayOwnerApprovals
export function createVoiceApprovalHub(room:string,onRemoteChange:()=>void){
 const gate=new VoiceApprovalGate(),channel=new BroadcastChannel('friday-approvals-'+room),queries=new Map<string,any[]>(),pending=new Map<string,{resolve:(v:any)=>void;timer:ReturnType<typeof setTimeout>}>()
 const dispatched=new Map<string,Promise<any>>(),announced=new Set<string>()
 let current:any=null
 channel.onmessage=({data:m})=>{
  if(m?.kind==='changed'){void announceNew();return}
  if(m?.kind==='pending'&&queries.has(m.query)&&Array.isArray(m.reviews))queries.get(m.query)!.push(...m.reviews.map((r:any)=>({...r,peer:m.peer})))
  if(m?.kind==='decision-result'){const waiter=pending.get(m.request);if(waiter){clearTimeout(waiter.timer);pending.delete(m.request);waiter.resolve(m.result)}}
 }
 async function reviews(){const id=crypto.randomUUID(),rows=registry().list().map((r:any)=>({...r,peer:null}));queries.set(id,rows);channel.postMessage({kind:'query',query:id});await new Promise(r=>setTimeout(r,220));queries.delete(id);return rows}
 async function announceNew(){try{const rows=await reviews();let fresh=false;for(const r of rows)if(!announced.has(r.id)){announced.add(r.id);fresh=true}if(fresh)onRemoteChange()}catch{}}
 function reset(){gate.reset();current=null}
 async function dispatch(r:any,action:string){
  const confirmation=await gate.waitAndConsume(r.id,action)
  const actual=(await reviews()).find((v:any)=>v.id===r.id&&v.version===r.version&&v.peer===r.peer)
  if(!actual)throw Error('The pending action changed or closed; it was not submitted. Do not restart the same review automatically.')
  let result:any
  if(!r.peer)result=await registry().act(r.id,r.version,action,confirmation.spokenCompany)
  else{const request=crypto.randomUUID();result=await new Promise(resolve=>{const timer=setTimeout(()=>{pending.delete(request);resolve({success:false,error:'Approval response timed out. Inspect the action/receipt; do not resubmit it.'})},25000);pending.set(request,{resolve,timer});channel.postMessage({kind:'decision',request,peer:r.peer,id:r.id,version:r.version,decision:action,spokenCompany:confirmation.spokenCompany})})}
  if(current?.id===r.id)current=null
  return{...result,reviewId:r.id,decision:action}
 }
 async function execute(action:string,id?:string){
  if(action==='stop'){reset();return{success:true,message:'Voice approval stopped. A submitted action cannot be undone here.'}}
  if(action==='review'){
   const rows=await reviews();if(!rows.length){current=null;return{success:false,error:'No supported approval is currently open. Do not repeat a cancelled or completed review.'}}
   const selected=id?rows.find((r:any)=>r.id===id):rows.length===1?rows[0]:null
   if(!selected)return{success:false,error:'More than one action is pending. Identify the intended one.',reviews:rows}
   const same=current?.id===selected.id&&current?.version===selected.version;current=selected;gate.begin(selected)
   return{success:true,review:selected,alreadyReviewed:same,message:same?'This is the same unchanged review. Do not read it or ask again; act on the explicit current voice command.':'Show and briefly explain this action once. An explicit approve/cancel command acts on it immediately, including during speech; do not request another confirmation.'}
  }
  if(!['approve','reject'].includes(action))throw Error('Use review, approve or reject.')
  if(id&&dispatched.has(id))return await dispatched.get(id)
  const rows=await reviews(),r=id?rows.find((v:any)=>v.id===id):rows.length===1?rows[0]:null
  if(!r)return{success:false,error:rows.length?'More than one action is pending; name the intended review.':'No pending action remains. Do not reopen it or ask for confirmation again.'}
  current=r;gate.begin(r)
  if(dispatched.has(r.id))return await dispatched.get(r.id)
  const task=dispatch(r,action);dispatched.set(r.id,task)
  try{return await task}catch(e){dispatched.delete(r.id);throw e}
 }
 async function onSpeechCommand(){
  // The command comes only from the live microphone transcript, never model arguments or document text.
  const command=gate.command(),decision=command?.decision
  if(!decision)return null
  const rows=await reviews()
  const candidates=rows.filter((r:any)=>decision==='reject'||(command?.speechAt||0)>=r.createdAt)
  if(candidates.length!==1)return null
  try{return await execute(decision,candidates[0].id)}catch(e:any){return{success:false,error:e.message}}
 }
 document.querySelectorAll('.profile').forEach(e=>e.addEventListener('click',()=>{reset();registry().clear()}))
 return{execute,reset,gate,onSpeechCommand,authorizeCancellation:(title:string,reference=false,selection=false)=>gate.waitNamedCancellation(title,reference,selection)}
}
