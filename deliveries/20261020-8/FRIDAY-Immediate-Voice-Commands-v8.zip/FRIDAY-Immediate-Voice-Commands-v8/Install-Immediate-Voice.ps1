param([string]$ProjectPath = 'S:\AI\friday-ai')
$ErrorActionPreference = 'Stop'
$manifest = Get-Content (Join-Path $PSScriptRoot 'immediate-voice-manifest.json') -Raw | ConvertFrom-Json
if (!(Test-Path (Join-Path $ProjectPath 'server.ts'))) { throw "FRIDAY project not found at $ProjectPath" }
# Preconditions only: these unchanged files are never copied.
foreach ($entry in $manifest.requiredSHA256.PSObject.Properties) {
  $target = Join-Path $ProjectPath $entry.Name
  if (!(Test-Path $target) -or (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash -ne $entry.Value) { throw "Compatibility check failed: $($entry.Name). No project files changed. Obtain a patch based on the current installed source." }
}
foreach ($relative in $manifest.files) {
  if ($relative -match '(^[\\/]|\.\.|:)') { throw "Unsafe manifest path: $relative" }
  $source = Join-Path $PSScriptRoot $relative
  $target = Join-Path $ProjectPath $relative
  $packageHash = $manifest.packageSHA256.PSObject.Properties[$relative].Value
  if (!(Test-Path $source) -or (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash -ne $packageHash) { throw "Package validation failed: $relative" }
  $baseline = $manifest.baselineSHA256.PSObject.Properties[$relative].Value
  if ($null -ne $baseline) {
    if (!(Test-Path $target) -or (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash -ne $baseline) { throw "Installed file differs from installed Voice Approvals version 20261020-7: $relative. No files changed. Keep this package separate and obtain a compatible update." }
  } elseif (Test-Path $target) { throw "New file already exists: $relative. No files changed." }
}
# Stop only the FRIDAY backend before running this installer; preserve other services.
$backup = Join-Path $ProjectPath ('backups\immediate-voice-v8-' + (Get-Date -Format 'yyyyMMdd-HHmmss-fff'))
New-Item -ItemType Directory -Path $backup -Force | Out-Null
foreach ($relative in $manifest.files) {
  $target = Join-Path $ProjectPath $relative
  if (Test-Path $target) {
    $saved = Join-Path $backup $relative
    New-Item -ItemType Directory -Path (Split-Path $saved) -Force | Out-Null
    Copy-Item -LiteralPath $target -Destination $saved
    $baseline = $manifest.baselineSHA256.PSObject.Properties[$relative].Value
    if ((Get-FileHash -LiteralPath $saved -Algorithm SHA256).Hash -ne $baseline) { throw "Backup verification failed: $relative. No project files changed." }
  }
}
$record = @{projectPath=$ProjectPath; files=$manifest.files; baselineSHA256=$manifest.baselineSHA256; packageSHA256=$manifest.packageSHA256}
$record | ConvertTo-Json -Depth 8 | Set-Content (Join-Path $backup 'restore-manifest.json') -Encoding UTF8
Copy-Item (Join-Path $PSScriptRoot 'Restore-Immediate-Voice.ps1') (Join-Path $backup 'Restore-Immediate-Voice.ps1')
try {
  # Recheck targets after backup to avoid overwriting an edit made during staging.
  foreach ($relative in $manifest.files) {
    $target = Join-Path $ProjectPath $relative
    $baseline = $manifest.baselineSHA256.PSObject.Properties[$relative].Value
    if ($null -ne $baseline) {
      if ((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash -ne $baseline) { throw "Target changed after backup: $relative" }
    } elseif (Test-Path $target) { throw "Target appeared after backup: $relative" }
  }
  $copied = @()
  foreach ($relative in $manifest.files) {
    $target = Join-Path $ProjectPath $relative
    New-Item -ItemType Directory -Path (Split-Path $target) -Force | Out-Null
    $copied += $relative
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot $relative) -Destination $target -Force
    if ((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash -ne $manifest.packageSHA256.PSObject.Properties[$relative].Value) { throw "Installed file verification failed: $relative" }
  }
} catch {
  # Roll back only files this installation attempted to copy.
  foreach ($relative in $copied) {
    $saved = Join-Path $backup $relative; $target = Join-Path $ProjectPath $relative
    if (Test-Path $saved) { Copy-Item -LiteralPath $saved -Destination $target -Force }
    elseif (Test-Path $target) { Remove-Item -LiteralPath $target }
  }
  throw
}
Write-Host 'Immediate Voice Commands version 8 installed. No events, QuickBooks records or private reviews were changed.'
Write-Host "Verified backup: $backup"
Write-Host 'Restart npm run server, then hard-refresh the dashboard and close old review tabs.'
Write-Host 'Rebuild and restart backend/dev. Hard-refresh voice; reopen QuickBooks/full review through the new voice link. Existing Google connections and callback configuration are unchanged. Disconnect/reconnect voice before testing immediate commands.'
