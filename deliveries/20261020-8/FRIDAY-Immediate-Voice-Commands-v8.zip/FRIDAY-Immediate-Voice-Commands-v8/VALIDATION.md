# Validation

121 Node-reported entries passed, zero failures/skips (108 specific cases plus 13 parent entries). Includes updated immediate voice behavior, saved Calendar cancellation, existing Calendar authorization/creation, invoice fields/owner workflows, bank review/feed and private Document Analysis regressions.

```
FRIDAY_TEST_TOOLS=/workspace/scratch/friday-test-tools node --import tsx --test tests/calendar-cancel.test.ts tests/voice-approvals.test.ts tests/calendar.test.ts tests/invoice-fields.test.ts tests/live-bank-feed.test.ts tests/bank-workflows.test.ts tests/document-review.test.ts
```

The previous assertions requiring completed readback were changed to assert the user's newly requested immediate behavior. Authentication, stale forms, company confirmation, quoted/negative commands, item replay and ambiguity assertions remain. Actual Chromium exercises cancellation without a prior review tool, cancellation during speech, automatic dispatch versus duplicate model calls, stale/expired dialog dismissal, invoice owner fields, Calendar creation and saved-event cancellation without opening another approval dialog.

Registered backend tests cover exact title lookup across configured calendars, duplicate-title selection, instance-only recurring cancellation, owner isolation, ETag/account/mapping/expiry guards, conditional one-time deletion, uncertain outcomes and receipt recovery, guest cancellation updates, incomplete pages and not-found results. All Google/QuickBooks clients are synthetic; no real event, invoice, guest notification or private uploaded file is changed or sent in cloud tests.

Frontend/backend TypeScript and standalone Vite compilation pass; existing large-bundle warning remains. Standalone compilation uses configFile:false without altering Windows TLS settings. JS runtime is exercised in Chromium. Windows installer/restore, actual microphone/OpenAI transcription latency, live OAuth/Google event deletion and guest notifications remain owner-PC testing. The owner's reported v7 live failure is the trigger for this correction, not a claimed live test of v8.

The test helper path/browser path are cloud facilities, not new app dependencies. Package contains no private credentials, recordings, customer documents, runtime receipts or databases. Existing owner key, Google connection and localhost configuration are preserved.
