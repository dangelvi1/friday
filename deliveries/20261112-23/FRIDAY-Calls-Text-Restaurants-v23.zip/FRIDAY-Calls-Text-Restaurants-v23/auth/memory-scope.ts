import {resolveOwnerSession} from './owner-session'
export function registerMemoryOwnerGuard(app:any){
 app.use('/memory',(req:any,res:any,next:any)=>{res.set('Cache-Control','no-store');const session=resolveOwnerSession(req);if(!session)return res.status(401).json({success:false,error:'Sign in to FRIDAY before using saved memory.'});const read=req.path.match(/^\/search\/([^/]+)\/?$/)?.[1],write=req.method==='POST'&&req.path==='/'?req.body?.scope:null,scope=read||write;if(scope&&scope!=='shared'&&scope!==session.owner)return res.status(403).json({success:false,error:'This memory scope belongs to another owner.'});next()})
}
