import test from 'node:test'
import assert from 'node:assert/strict'
import express from 'express'
import {mkdtemp,mkdir,writeFile,rm} from 'node:fs/promises'
import {join} from 'node:path'
import {tmpdir} from 'node:os'
import {registerMemoryOwnerGuard} from '../auth/memory-scope'
import {registerOwnerSessionRoutes} from '../auth/owner-session'
test('Saved memory requires the existing owner session and allows only own/shared reads or writes',async()=>{
 const cwd=process.cwd(),dir=await mkdtemp(join(tmpdir(),'friday-memory-scope-')),key='a'.repeat(64);let server:any,reads=0,writes=0
 try{process.chdir(dir);await mkdir('credentials');await writeFile('credentials/sandra-owner-access.json',JSON.stringify({salvador:key,dayanna:'b'.repeat(64)}));const app=express();app.use(express.json());server=app.listen(0,'127.0.0.1');await new Promise<void>(r=>server.once('listening',r));const base='http://127.0.0.1:'+server.address().port;registerOwnerSessionRoutes(app,{allowedOrigins:[base]});registerMemoryOwnerGuard(app);app.get('/memory/search/:scope',(_req,res)=>{reads++;res.json([])});app.post('/memory',(_req,res)=>{writes++;res.json({success:true})});assert.equal((await fetch(base+'/memory/search/salvador')).status,401);const login=await fetch(base+'/session/owner/login',{method:'POST',headers:{origin:base,'x-friday-session':'1','content-type':'application/json'},body:JSON.stringify({owner:'salvador',password:key})}),headers={origin:base,'x-friday-session':'1',cookie:login.headers.get('set-cookie')!.split(';')[0],'content-type':'application/json'};for(const scope of ['salvador','shared'])assert.equal((await fetch(base+'/memory/search/'+scope,{headers})).status,200);assert.equal((await fetch(base+'/memory/search/dayanna',{headers})).status,403);assert.equal((await fetch(base+'/memory',{method:'POST',headers,body:JSON.stringify({scope:'dayanna',content:'No cross-owner writes'})})).status,403);assert.equal((await fetch(base+'/memory',{method:'POST',headers,body:JSON.stringify({scope:'salvador',content:'Owner-authorized preference'})})).status,200);assert.equal(reads,2);assert.equal(writes,1)
 }finally{await new Promise<void>(r=>server?server.close(()=>r()):r());process.chdir(cwd);await rm(dir,{recursive:true,force:true})}
})
