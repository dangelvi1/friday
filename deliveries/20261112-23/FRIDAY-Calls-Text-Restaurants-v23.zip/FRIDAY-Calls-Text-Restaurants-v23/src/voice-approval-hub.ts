import {VoiceApprovalGate,approvalCommand,normalizeApproval} from './voice-approval-gate'
const registry=()=> (window as any).FridayOwnerApprovals
export function createVoiceApprovalHub(room:string,onRemoteChange:()=>void){
 const gate=new VoiceApprovalGate(),channel=new BroadcastChannel('friday-approvals-'+room),queries=new Map<string,any[]>(),pending=new Map<string,{resolve:(v:any)=>void;timer:ReturnType<typeof setTimeout>}>()
 const speechDispatches=new Map<string,{action:string;task:Promise<any>}>(),dispatched=new Map<string,Promise<any>>(),announced=new Set<string>()
 let current:any=null,ownerEpoch=0
 channel.onmessage=({data:m})=>{
  if(m?.kind==='changed'){void announceNew();return}
  if(m?.kind==='pending'&&queries.has(m.query)&&Array.isArray(m.reviews))queries.get(m.query)!.push(...m.reviews.map((r:any)=>({...r,peer:m.peer})))
  if(m?.kind==='decision-result'){const waiter=pending.get(m.request);if(waiter){clearTimeout(waiter.timer);pending.delete(m.request);waiter.resolve(m.result)}}
 }
 async function reviews(){const id=crypto.randomUUID(),rows=registry().list().map((r:any)=>({...r,peer:null}));queries.set(id,rows);channel.postMessage({kind:'query',query:id});await new Promise(r=>setTimeout(r,220));queries.delete(id);return rows}
 async function announceNew(){try{const rows=await reviews();let fresh=false;for(const r of rows)if(!announced.has(r.id)){announced.add(r.id);fresh=true}if(fresh){if(rows.length===1){current=rows[0];gate.begin(current)}onRemoteChange()}}catch{}}
 function reset(){ownerEpoch++;gate.reset();current=null;speechDispatches.clear();dispatched.clear();announced.clear();queries.clear();for(const p of pending.values()){clearTimeout(p.timer);p.resolve({success:false,error:'Owner changed. Inspect receipts for any submitted action.'})}pending.clear()}
 async function dispatch(r:any,action:string){
  const confirmation=await gate.waitAndConsume(r.id,action)
  const actual=(await reviews()).find((v:any)=>v.id===r.id&&v.version===r.version&&v.peer===r.peer)
  if(!actual)throw Error('The pending action changed or closed; it was not submitted. Do not restart the same review automatically.')
  let result:any
  if(!r.peer)result=await registry().act(r.id,r.version,action,confirmation.spokenCompany)
  else{const request=crypto.randomUUID();result=await new Promise(resolve=>{const timer=setTimeout(()=>{pending.delete(request);resolve({success:false,error:'Approval response timed out. Inspect the action/receipt; do not resubmit it.'})},25000);pending.set(request,{resolve,timer});channel.postMessage({kind:'decision',request,peer:r.peer,id:r.id,version:r.version,decision:action,spokenCompany:confirmation.spokenCompany})})}
  if(current?.id===r.id)current=null
  return{...result,reviewId:r.id,decision:action}
 }
 async function execute(action:string,id?:string){
  if(action==='stop'){reset();return{success:true,message:'Voice approval stopped. A submitted action cannot be undone here.'}}
  if(action==='review'){
   const rows=await reviews();if(!rows.length){current=null;return{success:false,error:'No supported approval is currently open. Do not repeat a cancelled or completed review.'}}
   const selected=id?rows.find((r:any)=>r.id===id):rows.length===1?rows[0]:null
   if(!selected)return{success:false,error:'More than one action is pending. Identify the intended one.',reviews:rows}
   const same=current?.id===selected.id&&current?.version===selected.version;current=selected;gate.begin(selected)
   return{success:true,review:selected,alreadyReviewed:same,message:same?'This is the same unchanged review. Do not read it or ask again; act on the explicit current voice command.':'Show and briefly explain this action once. An explicit approve/cancel command acts on it immediately, including during speech; do not request another confirmation.'}
  }
  if(!['approve','reject'].includes(action))throw Error('Use review, approve or reject.')
  const item=gate.speechItemId(),prior=item?speechDispatches.get(item):null
  if(id&&dispatched.has(id))return await dispatched.get(id)
  const rows=await reviews(),r=id?rows.find((v:any)=>v.id===id):rows.length===1?rows[0]:null
  if(!r&&!rows.length&&!id&&prior?.action===action)return await prior.task
  if(!r)return{success:false,error:rows.length?'More than one action is pending; name the intended review.':'No pending action remains. Do not reopen it or ask for confirmation again.'}
  current=r;gate.begin(r)
  if(dispatched.has(r.id))return await dispatched.get(r.id)
  const task=dispatch(r,action);dispatched.set(r.id,task);if(item){speechDispatches.set(item,{action,task});if(speechDispatches.size>100)speechDispatches.delete(speechDispatches.keys().next().value!)}
  try{return await task}catch(e){dispatched.delete(r.id);if(item)speechDispatches.delete(item);throw e}
 }
 async function onSpeechCommand(){
  // The command comes only from the live microphone transcript, never model arguments or document text.
  const command=gate.command(),decision=command?.decision
  if(!decision)return null
  const rows=await reviews()
  const candidates=rows.filter((r:any)=>(!command?.target||r.kind===command.target)&&(!command?.contextual||command.reviewId===r.id)&&(decision==='reject'||(command?.speechAt||0)>=r.createdAt))
  if(candidates.length!==1)return null
  try{return await execute(decision,candidates[0].id)}catch(e:any){return{success:false,error:e.message}}
 }
 async function onTypedCommand(text:string){
  const inputEpoch=ownerEpoch,submittedAt=Date.now(),id='typed-'+crypto.randomUUID();gate.typedInput(text,id);const command=approvalCommand(text);if(!command)return null;const all=await reviews(),rows=command?.target?all.filter((r:any)=>r.kind===command.target):all;if(inputEpoch!==ownerEpoch)throw Error('Owner changed; typed command discarded.');if(!rows.length)return null;if(rows.length!==1)return{success:false,error:'More than one review is open. Select the intended action before approving.'};const r=rows[0];if(r.kind==='phone'&&/\b(event|invoice|file|document)\b/i.test(text))throw Error('This review is a phone call; your command names another action. Identify the intended action.');if(r.createdAt>submittedAt)throw Error('The review appeared after your command. Review it before approving.');const actual=(await reviews()).find((v:any)=>v.id===r.id&&v.version===r.version&&v.peer===r.peer);if(!actual)throw Error('The displayed review changed. Nothing was submitted.');
  if(command.decision==='approve'&&r.requiredSpokenCompany&&normalizeApproval(command.company)!==normalizeApproval(r.requiredSpokenCompany))throw Error('Include the full company name displayed in the production review: approve it for '+r.requiredSpokenCompany+'.');
  if(dispatched.has(r.id))return await dispatched.get(r.id);let task:Promise<any>;
  if(!r.peer)task=registry().act(r.id,r.version,command.decision,command.company);else{const request=crypto.randomUUID();task=new Promise(resolve=>{const timer=setTimeout(()=>{pending.delete(request);resolve({success:false,error:'Approval result timed out. Inspect the receipt; do not resubmit.'})},25000);pending.set(request,{resolve,timer});channel.postMessage({kind:'decision',request,peer:r.peer,id:r.id,version:r.version,decision:command.decision,spokenCompany:command.company})})}
  dispatched.set(r.id,task);const result=await task;if(inputEpoch!==ownerEpoch)throw Error('Owner changed. Inspect receipts for an already submitted action.');if(current?.id===r.id)current=null;return{...result,reviewId:r.id,decision:command.decision,message:command.decision==='reject'?'Displayed review cancelled. No new request was submitted.':'Approval sent once. Inspect the workflow result before claiming success.'}
 }
 document.querySelectorAll('.profile').forEach(e=>e.addEventListener('click',()=>{reset();registry().clear()}))
 return{execute,reset,gate,onSpeechCommand,onTypedCommand,hasPending:async()=>(await reviews()).length>0,authorizeModification:(id:string,hasChanges:boolean)=>gate.authorizeModification(id,hasChanges),authorizeCancellation:(title:string,reference=false,selection=false)=>gate.waitNamedCancellation(title,reference,selection)}
}
