const credential=/(?:sk-(?:proj-)?[A-Za-z0-9_-]{24,}|shpat_[a-f0-9]{20,}|ya29\.[A-Za-z0-9_-]{20,}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----)/
export const containsCommandCredential=(text:string)=>credential.test(text)
export const commandCredentialMessage='That looks like a secret key. Enter credentials only in the private owner/provider fields; the command was not sent.'
