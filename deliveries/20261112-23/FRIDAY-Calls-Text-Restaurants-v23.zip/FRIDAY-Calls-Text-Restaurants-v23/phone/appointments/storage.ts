import {mkdir,readFile,writeFile,rename,readdir} from 'node:fs/promises'
import {resolve,dirname,join} from 'node:path'
import {randomBytes} from 'node:crypto'
import {PhoneError,type Owner} from './core'
const queues=new Map<string,Promise<any>>()
export async function serial<T>(key:string,fn:()=>Promise<T>):Promise<T>{const previous=queues.get(key)||Promise.resolve(),work=previous.catch(()=>{}).then(fn);queues.set(key,work);try{return await work}finally{if(queues.get(key)===work)queues.delete(key)}}
export function phoneStore(base=resolve('credentials/phone-appointments')){
 const ownerPath=(owner:Owner)=>{if(!['salvador','dayanna'].includes(owner))throw new PhoneError('Owner not verified.',403);return join(base,owner)}
 const path=(owner:Owner,id:string)=>{if(!/^[a-f0-9-]{36}$/.test(id))throw new PhoneError('Invalid call review ID.');return join(ownerPath(owner),id+'.json')}
 async function atomic(file:string,data:any){await mkdir(dirname(file),{recursive:true,mode:0o700});const tmp=file+'.'+randomBytes(8).toString('hex')+'.tmp';await writeFile(tmp,JSON.stringify(data),{flag:'wx',mode:0o600});await rename(tmp,file)}
 async function get(owner:Owner,id:string){try{const job=JSON.parse(await readFile(path(owner,id),'utf8'));if(job.owner!==owner||job.id!==id)throw Error();return job}catch{throw new PhoneError('Call review not found for this owner.',404)}}
 async function find(id:string){for(const owner of ['salvador','dayanna'] as Owner[])try{return await get(owner,id)}catch{}throw new PhoneError('Call not found.',404)}
 async function claim(owner:Owner,fingerprint:string,id:string){const file=join(ownerPath(owner),'claims',fingerprint+'.json');await mkdir(dirname(file),{recursive:true,mode:0o700});try{await writeFile(file,JSON.stringify({id,createdAt:new Date().toISOString()}),{flag:'wx',mode:0o600})}catch(e:any){if(e.code==='EEXIST')throw new PhoneError('A call for this number/date/window was already submitted. Inspect its receipt; do not redial through a new review.',409);throw e}}
 async function list(owner:Owner){let names:string[]=[];try{names=await readdir(ownerPath(owner))}catch(e:any){if(e.code!=='ENOENT')throw e}const rows=[];for(const n of names.filter(n=>/^[a-f0-9-]{36}\.json$/.test(n)))rows.push(await get(owner,n.slice(0,-5)));return rows.sort((a,b)=>b.createdAt-a.createdAt).slice(0,40)}
 return{get,find,claim,list,save:(job:any)=>atomic(path(job.owner,job.id),job)}
}
