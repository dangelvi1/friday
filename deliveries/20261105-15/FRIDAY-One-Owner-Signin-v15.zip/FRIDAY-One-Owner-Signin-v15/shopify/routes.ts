import {registerDailyCommerceRoutes} from '../commerce/daily/routes'
import {registerCrosslistInspectionRoutes} from '../marketplaces/crosslist/routes'
import {registerVintedPreparationRoutes} from '../marketplaces/vinted/routes'
// ============================================================
// FRIDAY SHOPIFY ROUTE REGISTRY
// FILE: S:\AI\friday-ai\shopify\routes.ts
// COMPANY: Saldana Corp
// PURPOSE: Shopify route registration only.
// ============================================================

import type {
  Express,
} from 'express'

import {
  registerShopifyProductRoutes,
} from './products'

import {
  registerShopifyAiProductRoutes,
} from './ai-product-builder'

import {
  registerShopifyDashboardCommandRoutes,
} from './dashboard-commands'


export function registerShopifyRoutes(
  app:
    Express,
  options: {getBrowser?:()=>Promise<any>} = {}
) {
  registerDailyCommerceRoutes(app)
  registerCrosslistInspectionRoutes(app,options)
  registerVintedPreparationRoutes(app,options)

  registerShopifyProductRoutes(
    app
  )

  registerShopifyAiProductRoutes(
    app
  )

  registerShopifyDashboardCommandRoutes(
    app
  )
}
