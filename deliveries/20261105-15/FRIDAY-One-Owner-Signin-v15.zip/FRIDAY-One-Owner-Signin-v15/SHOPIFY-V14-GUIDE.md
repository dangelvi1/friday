# FRIDAY Shopify Daily + Voice + Photo Drafts v14

For installed v12 OR v13. FRIDAY stays on your PC at S:\AI\friday-ai. The installer selects the matching additive voice source by SHA256; it does not require the discontinued Crosslist analysis update. Existing app/company/voice/Calendar/QuickBooks modules remain. No AGENTS, credentials, package/configuration or private data are replaced.

## Install

Stop only FRIDAY backend (Ctrl+C in its terminal); close old review tabs. Extract this ZIP into a new folder. Run the full installer path, not a relative .\ path from C:\Users\Salvador:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File 'S:\AI\Fixing-Files-Folder\FRIDAY-Shopify-Daily-v14\Install-Shopify-Daily.ps1' -ProjectPath 'S:\AI\friday-ai'
if ($LASTEXITCODE -ne 0) { throw 'Installer failed. Do not continue.' }
Set-Location 'S:\AI\friday-ai'
npm run build
if ($LASTEXITCODE -ne 0) { throw 'Build failed. Do not continue.' }
npm run server
```

Use the actual extracted path if different. ExecutionPolicy Bypass applies only to this PowerShell process, not the system policy. Existing large-bundle Vite warning is informational. In another terminal run `Set-Location 'S:\AI\friday-ai'; npm run dev`. Ctrl+F5 https://localhost:5173/, disconnect/reconnect voice. Open **Daily ecommerce dashboard** and type the existing Salvador/Dayanna owner key privately (never say or upload it).

## First test: sell existing stock

Say “Set my inventory research budget to 500 dollars, ZIP 08822, compare ten and twenty percent either way, and enable reports at 7:30pm Eastern.” This saves private settings, not spending consent. Review the settings shown. Backend must remain running and connected. One nightly run per owner/local day after the saved time; if started late it catches up that day, not all missed days. Reports remain in FRIDAY; no email is sent. Existing OpenAI API key/web-search usage is billed normally. No new worker terminal is needed.

Say “Audit my Shopify inventory and research how to sell it.” All active Shopify product/variant/image pages are audited (bounded completeness guards). Public-market detailed research samples up to six rotating owned products plus two new/restock leads per run. Progress shows real stage/search queries/source links. Historical reports compare changing quotes. Existing inventory is the first priority; all sales speed, supplier quotes, eligibility and fees remain evidence-linked estimates unless independently known. Actual visitor/conversion analytics are not connected. Existing Shopify permissions may omit inventory cost or aggregate orders; missing data stays unknown.

Budget comparisons at 400/450/500/550/600 dollars use quoted whole-lot tiers only. Reports separate merchandise, inbound shipping/tax/other, outbound shipping, fees, packaging, ad allowance, returns, estimated unit/lot profit, margin and ad break-even. Missing costs make net profit unknown. Customer-direct dropshipping uses its own supplier quote without a second warehouse-to-customer shipment. It is research, not fulfillment or inventory synchronization.

Say “Show my inventory”, “Read tonight’s report”, “What are the supplier and shipping comparisons?”, “Set this variant’s private shipping assumption to five dollars” or “Show suggested changes.” Use actual product/variant IDs returned by FRIDAY. Private cost notes do not change Shopify.

## Approved changes actually saved to Shopify

Currently supported existing-product writes are **SEO title and meta description only**, from factual current product text. Each proposal shows before/after/reason. Select individually or all supported displayed proposals, then say “Approve it” or “Cancel it” once. No second confirmation for the unchanged review. Fresh Shopify source identity/metadata checks and durable revision claims prevent stale/replayed writes; verify the receipt. “Stop” stops remaining writes; a request already sent may finish. Price, stock, descriptions, ads, theme changes and additional channel ideas in the report are recommendations, not automatically executable actions in this version.

## Product photos, by conversation

Say “Create a product from my pictures” to open the photo picker. You still select local files; if the browser blocks the picker, click the upload field. Choose 1–3 JPEG/PNG/WebP photographs, each up to 8 MiB. Say “Save these pictures”, then “Analyse them.” Photos are stored privately on your PC; analysis sends them to the configured OpenAI service. FRIDAY researches possible matching pages, suggests original copy and asks missing questions. Photos do not establish authenticity, quantity, condition, size, price or taxability. Web pictures are references; this version uses your uploaded photos for Shopify and does not reuse third-party images automatically.

Say “Use the suggested description”, answer the questions and edit title/brand/type/description/condition/size (or N/A)/SKU/price/quantity/taxability/SEO by voice. “Read my Shopify locations” returns actual locations; choose one, particularly when more than one exists. One draft represents one variant/size; create separate drafts for different sizes. FRIDAY never invents identifiers or a warehouse.

Say “Review this product draft.” The visible review includes exact confirmed fields, actual location, photo count and DRAFT status. “Approve it” creates a **new Shopify DRAFT**, uploads only your own photos, sets its new variant price/SKU/stock and verifies them. It does not modify existing products or publish to sales channels. Open the native Shopify URL to inspect processing photos/publication. Publishing is not installed by this update. Stop/cancel can halt remaining steps; inspect the receipt if a request was already submitted. Lost responses produce needs_review with a unique friday-draft-UUID tag; search that tag in Shopify and never automatically recreate an uncertain draft.

## Boundaries and rollback

This is a working research/review foundation, not unattended complete sales operations. Ads/spend, theme redesign/publishing, third-party channel publication, checkout validation, supplier purchasing, shipping labels, fulfillment, refunds and visitor analytics still need their actual integrations. No QuickBooks invoices are changed. Windows installation, live microphone, real OpenAI research quality, Shopify native scopes/schema/media processing, actual storefront and OAuth require PC tests; cloud checks are mocked API/Chromium checks only.

Installer verifies supported baseline/package hashes, backs up all changed existing files, records hashes, rechecks before copying and rolls back attempted files on copy failure. If compatibility differs, it stops before any project changes. Keep the printed backup path. Stop backend, run its backup-folder Restore-Shopify-Daily.ps1 by full path with process-scoped ExecutionPolicy Bypass. Restore refuses subsequent source edits and removes only this update’s new source files. Private commerce data remains, and already approved Shopify writes are not undone. No secrets, private photos/catalog/reports or environment configuration are in this package.
