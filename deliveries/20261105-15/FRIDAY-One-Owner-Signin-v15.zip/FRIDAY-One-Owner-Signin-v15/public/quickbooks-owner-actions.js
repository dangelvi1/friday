// Owner credentials stay in memory/input fields and are never placed in URLs or browser storage.
(() => {
  const $=id=>document.getElementById(id)
  let ownerKey=''
  async function credential(){
    if(window.FridayOwnerSession)return await window.FridayOwnerSession.credential()
    if(location.protocol!=='https:'&&!['localhost','127.0.0.1','[::1]'].includes(location.hostname))throw Error('Use HTTPS or localhost for owner credentials.')
    const existing=$('sandraOwnerKey')?.value.trim()||ownerKey
    if(/^[a-f0-9]{64}$/.test(existing))return existing
    const dialog=document.createElement('dialog');dialog.innerHTML='<form method="dialog"><h3>Verify owner</h3><p>Enter your existing FRIDAY owner key. It stays in this tab.</p><input type="password" autocomplete="off" aria-label="FRIDAY owner key" required pattern="[a-f0-9]{64}" maxlength="64"><p><button value="cancel" formnovalidate>Cancel</button> <button value="verify">Verify owner</button></p></form>';document.body.appendChild(dialog);dialog.showModal()
    return new Promise((resolve,reject)=>dialog.addEventListener('close',()=>{const v=dialog.querySelector('input').value;dialog.remove();if(dialog.returnValue==='verify'&&/^[a-f0-9]{64}$/.test(v)){ownerKey=v;if($('sandraOwnerKey')){$('sandraOwnerKey').value=v;$('sandraOwnerKey').dispatchEvent(new Event('input'))}resolve(v)}else reject(Error('Owner verification cancelled; your form was kept.'))},{once:true}))
  }
  async function ownerScope(companyKey,key){const r=await fetch('/quickbooks/invoice-owner-scope/'+encodeURIComponent(companyKey),{headers:{'X-Sandra-Owner-Key':key}}),d=await r.json();if(!r.ok||!d.success)throw Error(d.error||'Owner verification failed.');if(companyKey!==fridayQuickBooksState.companyKey)throw Error('Selected company changed.');return d}
  window.fridayVerifyExistingOwner=async()=>{const key=await credential();return await ownerScope(fridayQuickBooksState.companyKey,key)}
  window.fridayOwnerReview=async(title,summary,snapshot=()=>null)=>{
    const key=await credential(),selected=fridayQuickBooksState.companyKey,scope=await ownerScope(selected,key),initial=JSON.stringify(snapshot())
    if(!window.FridayOwnerApprovals)throw Error('Owner approval interface did not load. Refresh; nothing was submitted.')
    return await window.FridayOwnerApprovals.confirm({title,summary:`Owner ${scope.actor}. Company ${scope.companyName||selected} (${scope.environment}).\n${summary}`,scope:selected,owner:scope.actor,requiredSpokenCompany:scope.environment==='production'?scope.companyName:null,snapshot:()=>({selected:fridayQuickBooksState.companyKey,environment:fridayQuickBooksState.environment,value:snapshot()}),current:()=>selected===fridayQuickBooksState.companyKey&&JSON.stringify(snapshot())===initial,verify:async()=>{const current=await ownerScope(selected,key);if(current.realmId!==scope.realmId||current.environment!==scope.environment||current.actor!==scope.actor)throw Error('Owner or QuickBooks connection changed.');}})
  }
  window.fridayOwnerInvoiceRequest=async(url,options)=>{
    const key=await credential(),companyKey=fridayQuickBooksState.companyKey,scope=await ownerScope(companyKey,key)
    const body=JSON.parse(options.body)
    if(url!=='/quickbooks/invoice-action/'+encodeURIComponent(companyKey)&&!new RegExp('^/quickbooks/invoice-update/'+encodeURIComponent(companyKey)+'/[0-9]{1,20}$').test(url))throw Error('Invoice request scope differs from the selected company.')
    const original=JSON.stringify(body)
    const details=JSON.stringify({action:body.action||'update',invoiceId:body.invoiceId,docNumber:body.docNumber,customer:body.customerId,invoiceDate:body.txnDate,dueDate:body.dueDate,email:body.billEmail,customerMemo:body.customerMemo,privateNote:body.privateNote,lines:body.lines},null,2)
    if(!await window.fridayOwnerReview(body.action==='create-and-send'?'Create and EMAIL invoice':'Save QuickBooks invoice',`Review the exact customer, dates, line amounts, services, taxes and notes below. ${body.action==='create-and-send'?'This also emails the customer.':'This writes to QuickBooks.'}\n${details}`,()=>({body:JSON.parse(original),companyKey:fridayQuickBooksState.companyKey})))throw Error('Cancelled; your form was kept.')
    const fresh=await ownerScope(companyKey,key);if(fresh.realmId!==scope.realmId||fresh.environment!==scope.environment)throw Error('QuickBooks connection changed after review.')

    return fetch(url,{...options,headers:{...options.headers,'X-Sandra-Owner-Key':key},body:JSON.stringify({...body,approved:true,approvedBy:scope.actor,realmId:scope.realmId,environment:scope.environment})})
  }
  window.fridayInvoiceFieldRequest=async(url,options={})=>{
    const companyKey=fridayQuickBooksState.companyKey,parsed=new URL(url,location.origin),prefix='/quickbooks/invoice-fields/'+encodeURIComponent(companyKey)+'/'
    const read=parsed.pathname==='/quickbooks/invoice-field-search/'+encodeURIComponent(companyKey)&&(!options.method||options.method==='GET')
    const write=parsed.pathname.startsWith(prefix)&&/^\d{1,20}\/(preview|execute|receipt)$/.test(parsed.pathname.slice(prefix.length))&&options.method==='POST'
    if(parsed.origin!==location.origin||!read&&!write)throw Error('Invoice field request differs from the selected company.')
    if(!window.FridayOwnerSession&&read&&!/^[a-f0-9]{64}$/.test($('sandraOwnerKey')?.value.trim()||ownerKey))throw Error('Click Verify owner once before searching current QuickBooks fields.')
    const key=await credential(),scope=await ownerScope(companyKey,key)
    parsed.searchParams.set('realmId',scope.realmId);parsed.searchParams.set('environment',scope.environment)
    if(write)options={...options,body:JSON.stringify({...JSON.parse(options.body),realmId:scope.realmId,environment:scope.environment})}
    if(companyKey!==fridayQuickBooksState.companyKey)throw Error('Company changed; request cancelled.')
    return fetch(parsed.pathname+parsed.search,{...options,headers:{...options.headers,'X-Sandra-Owner-Key':key}})
  }
  window.fridayStatementRequest=async(url,options={})=>{if(!window.FridayOwnerSession&&!options.method&&!/^[a-f0-9]{64}$/.test($('sandraOwnerKey')?.value.trim()||ownerKey))throw Error('Verify owner using the dashboard button or enter your existing key in Sandra teaching before opening private statements.');const key=await credential(),companyKey=fridayQuickBooksState.companyKey;if(!url.startsWith('/quickbooks/statements/'+encodeURIComponent(companyKey)+'/'))throw Error('Statement company differs from current selection.');if(['POST','PATCH'].includes(options.method)){const scope=await ownerScope(companyKey,key);options={...options,body:JSON.stringify({...JSON.parse(options.body),realmId:scope.realmId,environment:scope.environment})}}return fetch(url,{...options,headers:{...options.headers,'X-Sandra-Owner-Key':key}})}
  function link(kind,id){
    const button=document.createElement('button');button.type='button';button.className='secondary-button';button.textContent='Open in QuickBooks ↗';button.dataset.qboLink=kind+':'+id
    const selected={companyKey:fridayQuickBooksState.companyKey,environment:fridayQuickBooksState.environment}
    button.disabled=!/^\d{1,20}$/.test(String(id))||selected.environment!=='production'
    button.title=button.disabled?'Direct production link requires a production company and actual QuickBooks ID.':`${kind} ID ${id}`
    button.addEventListener('click',e=>{e.stopPropagation();if(selected.companyKey!==fridayQuickBooksState.companyKey) return fridayLog('Company changed. Reload this view.');if(confirm(`Open this ${kind} in ${selected.companyKey}? Verify that same company is selected in your signed-in QuickBooks browser.`)){const a=document.createElement('a');a.href=`https://app.qbo.intuit.com/app/${kind==='invoice'?'invoice?txnId=':'customerdetail?nameId='}${encodeURIComponent(id)}`;a.target='_blank';a.rel='noopener noreferrer';a.click()}})
    return button
  }
  const verify=document.createElement('button');verify.type='button';verify.id='fridayVerifyOwner';verify.textContent='Verify owner';$('companyEnvironmentBadge')?.after(verify);verify.addEventListener('click',()=>credential().then(key=>ownerScope(fridayQuickBooksState.companyKey,key)).then(d=>fridayLog('Verified owner: '+d.actor)).catch(e=>fridayLog(e.message)))
  window.fridayQuickBooksLinkButton=link
  function attach(cell,kind,id){if(cell&&!cell.querySelector(`[data-qbo-link="${kind}:${id}"]`))cell.append(' ',link(kind,id))}
  const sales=renderInvoices
  renderInvoices=function(data){const result=sales(data);const rows=Array.from($('invoiceTableBody').rows);const byId=new Map((data.invoices||[]).map(i=>[String(i.id),i]));for(const row of rows){const i=byId.get(row.dataset.fridayVoiceInvoiceId);if(i){attach(row.cells[0],'invoice',i.id);attach(row.cells[1],'customer',i.customerId)}}return result}
  const customerInvoices=fridayRenderCustomer360Invoices
  fridayRenderCustomer360Invoices=function(){const r=customerInvoices();const invoices=new Map((fridayCustomer360State.invoices||[]).map(i=>[String(i.id),i]));for(const row of $('customer360InvoiceBody')?.rows||[]){const i=invoices.get(row.dataset.fridayVoiceInvoiceId);if(i){attach(row.cells[2],'invoice',i.id);attach(row.cells[3],'customer',i.customerId||fridayCustomer360State.customer?.id)}}return r}
  let visibleCustomers=[],visibleCustomerCompany=null
  window.fridayOpenVisibleCustomer=async id=>{if(visibleCustomerCompany!==fridayQuickBooksState.companyKey)throw Error('Company changed; search customers again.');const c=visibleCustomers.find(c=>String(c.id)===id);if(!c)throw Error('Search and inspect visible customer IDs first.');return showCustomerDetail(c)}
  const customers=renderCustomerResults
  renderCustomerResults=function(data){visibleCustomers=data;visibleCustomerCompany=fridayQuickBooksState.companyKey;const r=customers(data);Array.from($('customerTableBody').rows).forEach((row,i)=>{if(data[i]){row.dataset.fridayVoiceCustomerId=String(data[i].id);attach(row.cells[0],'customer',data[i].id)}});return r}
  const topDebtors=renderTopDebtors
  renderTopDebtors=function(data){const r=topDebtors(data);const sorted=[...data].sort((a,b)=>Number(b.totalOpen||0)-Number(a.totalOpen||0)).slice(0,10);Array.from($('topDebtorsTableBody').rows).forEach((row,i)=>{if(sorted[i]?.customerId)attach(row.cells[0],'customer',sorted[i].customerId)});return r}
  const reportCustomers=renderReportTopCustomers
  renderReportTopCustomers=function(data){const r=reportCustomers(data);Array.from($('reportTopCustomersBody').rows).forEach((row,i)=>{if(data[i]?.customerId)attach(row.cells[0],'customer',data[i].customerId)});return r}
  const detail=showCustomerDetail
  showCustomerDetail=async function(customer,...rest){const selected=fridayQuickBooksState.companyKey;const r=await detail(customer,...rest);if(selected===fridayQuickBooksState.companyKey)attach($('customerDetail')?.querySelector('.customer-360-title'),'customer',customer.id);return r}
  const editor=fridayOpenInvoiceEditor
  fridayOpenInvoiceEditor=async function(id){const selected=fridayQuickBooksState.companyKey,r=await editor(id);if(selected!==fridayQuickBooksState.companyKey||!fridayInvoiceEditState.invoice||String(fridayInvoiceEditState.invoice.id)!==String(id))return r;const invoice=fridayInvoiceEditState.invoice;attach($('fridayEditInvoiceTitle'),'invoice',invoice.id);attach($('fridayEditInvoiceSubtitle'),'customer',invoice.customerId);const title=$('fridayEditInvoiceTitle');if(title&&!title.querySelector('[data-delete-invoice]')){const b=document.createElement('button');b.type='button';b.textContent='Review invoice deletion';b.dataset.deleteInvoice=id;b.addEventListener('click',()=>deleteInvoice(id).catch(e=>fridayLog(e.message)));title.append(' ',b)}return r}
  fridayOpenInvoiceDetail=fridayOpenInvoiceEditor
  window.fridayOpenInvoiceDetail=fridayOpenInvoiceDetail
  async function deleteInvoice(id){
    const key=await credential(),selected=fridayQuickBooksState.companyKey,scope=await ownerScope(selected,key),url=`/quickbooks/invoice-delete/${encodeURIComponent(selected)}/${encodeURIComponent(id)}`
    const request=async(action,body)=>{const r=await fetch(url+'/'+action,{method:'POST',headers:{'Content-Type':'application/json','X-Sandra-Owner-Key':key},body:JSON.stringify({...body,realmId:scope.realmId,environment:scope.environment})}),d=await r.json();if(!r.ok||!d.success)throw Error(d.error||'Invoice action failed.');return d}
    const p=await request('preview',{})
    if(selected!==fridayQuickBooksState.companyKey)throw Error('Company changed; preview discarded.')
    const dependencies=p.dependenciesRequireReview?` This invoice has payments/credits or a balance different from its total. Linked references: ${p.linkedTransactions.map(x=>x.type+' #'+x.id).join(', ')||'Review the balance'}. Deletion may leave payments unapplied or affect reports. Approving confirms you reviewed these dependencies in QuickBooks.`:''
    if(!await window.fridayOwnerReview('DELETE QuickBooks invoice',`DELETE invoice #${p.docNumber||id} for ${p.customerName}, total $${Number(p.total).toFixed(2)}, balance $${Number(p.balance).toFixed(2)}. This changes QuickBooks.${dependencies}`,()=>({id,proposalId:p.proposalId,scope,company:fridayQuickBooksState.companyKey})))return

    const button=document.querySelector('[data-delete-invoice="'+id+'"]');if(button)button.disabled=true
    const receiptButton=document.createElement('button');receiptButton.type='button';receiptButton.textContent='Check deletion receipt';receiptButton.addEventListener('click',()=>request('receipt',{proposalId:p.proposalId}).then(d=>fridayLog('Deletion receipt: '+d.receipt.status)).catch(e=>fridayLog(e.message)));button?.after(receiptButton)
    const d=await request('execute',{proposalId:p.proposalId,snapshotHash:p.snapshotHash,approved:true,dependenciesReviewed:p.dependenciesRequireReview})
    fridayLog('Invoice deleted in QuickBooks; durable receipt: '+d.receipt.status);$('fridayCloseInvoiceEditButton')?.click();if(selected===fridayQuickBooksState.companyKey)await loadInvoices()
  }
  const statements=fridayLoadStatements
  fridayLoadStatements=async function(){const r=await statements();for(const row of $('statementLibraryBody')?.rows||[]){const a=row.querySelector('a[href*="/quickbooks/statements/"]');if(!a||!row.cells[1]?.textContent.trim().toLowerCase().endsWith('.csv')||row.querySelector('[data-review-statement]'))continue;const b=document.createElement('button');b.type='button';b.dataset.reviewStatement='true';b.textContent='Review statement rows';const companyKey=fridayQuickBooksState.companyKey,accountId=$('statementAccountSelector').value,url=a.getAttribute('href'),name=row.cells[1].textContent.trim();b.addEventListener('click',async()=>{try{const response=await fridayStatementRequest(url);if(!response.ok)throw Error('Could not read the saved statement.');const blob=await response.blob();if(companyKey!==fridayQuickBooksState.companyKey)throw Error('Company changed.');await fridayOpenDashboardPage('banking');if(companyKey!==fridayQuickBooksState.companyKey)throw Error('Company changed.');$('bankingAccountSelector').value=accountId;if($('bankingAccountSelector').value!==accountId)throw Error('Selected bank account is unavailable.');$('bankingAccountSelector').dispatchEvent(new Event('change'));$('sandraCsvTab').click();const files=new DataTransfer();files.items.add(new File([blob],name,{type:'text/csv'}));$('sandraBankFile').files=files.files;$('sandraBankFile').dispatchEvent(new Event('change'));$('sandraScopeConfirmed').scrollIntoView({block:'center'});await fridayPointTo($('sandraScopeConfirmed'),350);fridayLog('Saved statement rows loaded. Confirm this company/account and click Analyze.');}catch(e){fridayLog(e.message)}});a.parentElement.append(b)}return r}
  document.addEventListener('click',async e=>{const a=e.target.closest('a[href*="/quickbooks/statements/"]');if(!a)return;e.preventDefault();try{const r=await fridayStatementRequest(a.getAttribute('href'));if(!r.ok)throw Error('Owner statement access failed.');const url=URL.createObjectURL(await r.blob());window.open(url,'_blank','noopener');setTimeout(()=>URL.revokeObjectURL(url),60000)}catch(err){fridayLog(err.message)}})
  const clearOwner=()=>{ownerKey='';$('reconciliationResult').style.display='none'};document.addEventListener('sandra-company-changed',clearOwner);document.addEventListener('friday-owner-session-changed',clearOwner)
})()
