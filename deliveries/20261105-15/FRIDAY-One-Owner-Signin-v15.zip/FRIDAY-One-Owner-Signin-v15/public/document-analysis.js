// Reuse dashboard navigation and the existing conversational pointer.
(() => {
 document.addEventListener('DOMContentLoaded',async()=>{
  const section=document.createElement('section');section.id='documentAnalysisWorkspace';section.className='workspace-view';
  document.getElementById('genericWorkspace').parentElement.appendChild(section);
  const link=document.createElement('link');link.rel='stylesheet';link.href='/document-review.css?v=20261014-2';document.head.appendChild(link);
  if(!window.FridayDocumentReview){const script=document.createElement('script');script.type='module';script.src='/document-review-ui.js?v=20261105-15';document.head.appendChild(script);try{await new Promise((resolve,reject)=>{script.onload=resolve;script.onerror=()=>reject(Error('Document Analysis interface could not load. Refresh and check the update files.'));});}catch(e){section.textContent=e.message;return;}}
  const ui=window.FridayDocumentReview.mount(section,{company:()=>fridayQuickBooksState.companyKey});
  function show(){document.querySelectorAll('.workspace-view').forEach(v=>v.classList.remove('active'));section.classList.add('active');fridayQuickBooksState.currentPage='document-analysis';section.scrollIntoView({block:'start'});}
  const button=document.createElement('button');button.type='button';button.className='nav-item';button.dataset.page='document-analysis';button.textContent='Document Analysis';button.addEventListener('click',show);document.querySelector('.nav-item')?.parentElement.appendChild(button);
  const original=fridayOpenDashboardPage;fridayOpenDashboardPage=async function(page,...args){if(page==='document-analysis'){show();return true;}return await original(page,...args);};
  window.fridayDocumentAnalysis={show,clear:ui.invalidate};
  document.addEventListener('sandra-company-changed',ui.invalidate);document.getElementById('companySelector')?.addEventListener('change',ui.invalidate);
 });
})();
