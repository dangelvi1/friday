// START [QUICKBOOKS-DASH-23A] Verified-owner teaching and exact expense approval controller
(() => {
 const $=id=>document.getElementById(id)
 let loaded=null,proposal=null,busy=false,serial=0,pendingExample=null
 const selection=()=>window.sandraBankingApi.getSelection()
 const same=s=>s && s.companyKey===selection().companyKey && s.accountId===selection().accountId
 const status=text=>{$('sandraTeachingStatus').textContent=text}
 function invalidate(){serial++;loaded=null;proposal=null;$('sandraExecuteCategory').disabled=true;$('sandraCategoryReceipt').disabled=true;$('sandraPostedChangePreview').textContent='Selection changed. Load teaching and prepare a new preview.';$('sandraTeachCategory').innerHTML='<option value="">Load categories first</option>';for(const id of ['sandraTeachUse','sandraTeachNot','sandraTeachAsk','sandraTeachExamples','sandraTeachingHistoryText']) $(id).value='',$(id).textContent='';status('Load teaching for the selected company/account.')}
 document.addEventListener('friday-owner-session-changed',invalidate)
 function resetProposal(){serial++;proposal=null;$('sandraExecuteCategory').disabled=true;$('sandraCategoryReceipt').disabled=true;$('sandraPurposeApproved').checked=false;$('sandraReconciliationApproved').checked=false;$('sandraPostedChangePreview').textContent='Prepare a fresh preview for this category and posted Purchase ID.'}
 async function request(path,body){
  if(location.protocol!=='https:'&&!['localhost','127.0.0.1','[::1]'].includes(location.hostname))throw Error('Use HTTPS or localhost before entering an owner credential.')
  if(!window.FridayOwnerSession&&!/^[a-f0-9]{64}$/.test($('sandraOwnerKey').value.trim()))throw Error('Enter your owner credential from the server setup.')
  const selected=selection(),revision=serial
  const credential=window.FridayOwnerSession?await window.FridayOwnerSession.credential():$('sandraOwnerKey').value.trim();const options={headers:{'X-Sandra-Owner-Key':credential}}
  if(body){if(!same(loaded))throw Error('Load teaching for this company/account first.');options.method='POST';options.headers['Content-Type']='application/json';options.body=JSON.stringify({...body,realmId:loaded.realmId,environment:loaded.environment})}
  const response=await fetch(`/quickbooks/sandra-teaching/${encodeURIComponent(selected.companyKey)}/${encodeURIComponent(selected.accountId)}${path}`,options)
  let data;try{data=await response.json()}catch{throw Error(`Unreadable server response (${response.status}).`)}
  if(revision!==serial||!same(selected))throw Error('Selected company/account changed; response discarded.')
  if(!response.ok||!data.success)throw Error(data.error||'Operation failed.')
  if(data.companyKey && (data.companyKey!==selected.companyKey||String(data.accountId)!==selected.accountId))throw Error('Response scope mismatch.')
  return data
 }
 async function run(fn){if(busy)return;busy=true;try{await fn()}catch(e){status(e.message)}finally{busy=false}}
 function fill(){
  resetProposal();const lesson=loaded?.lessons.find(l=>l.category_id===$('sandraTeachCategory').value)
  $('sandraTeachUse').value=lesson?.definition.useFor||'';$('sandraTeachNot').value=lesson?.definition.notFor||'';$('sandraTeachAsk').value=lesson?.definition.askWhen||''
  $('sandraTeachExamples').value=(lesson?.definition.examples||[]).map(e=>`${e.merchant} | ${e.direction==='in'?'received':'spent'}`).join('\n');$('sandraTeachApproved').checked=lesson?.approved||false
  $('sandraTeachingHistoryText').textContent=''
  if(pendingExample){const lines=$('sandraTeachExamples').value.split('\n').filter(Boolean);if(!lines.includes(pendingExample))lines.push(pendingExample);$('sandraTeachExamples').value=lines.join('\n')}
 }
 async function load(){const d=await request('');loaded=d;resetProposal();$('sandraTeachCategory').innerHTML='<option value="">Select category</option>';for(const c of d.categories){const o=document.createElement('option');o.value=c.id;o.textContent=`${c.name} (${c.type})`;$('sandraTeachCategory').appendChild(o)}status(`Verified owner: ${d.actor}. ${d.lessons.length} saved categories. Posted accounting writes ${d.writesEnabled?'enabled':'disabled'}.`)}
 document.addEventListener('DOMContentLoaded',()=>{
  $('sandraLoadTeaching').addEventListener('click',()=>run(load))
  $('sandraTeachCategory').addEventListener('change',fill)
  $('sandraPostedPurchaseId').addEventListener('input',resetProposal)
  $('sandraOwnerKey').addEventListener('input',()=>{resetProposal();loaded=null})
  $('sandraSaveTeaching').addEventListener('click',()=>run(async()=>{
   const id=$('sandraTeachCategory').value;if(!id)throw Error('Select a category.')
   const examples=$('sandraTeachExamples').value.split('\n').filter(l=>l.trim()).map(l=>{const parts=l.split('|').map(x=>x.trim());if(parts.length!==2||!['spent','received'].includes(parts[1].toLowerCase()))throw Error('Example format: merchant | spent or merchant | received');return{merchant:parts[0],direction:parts[1].toLowerCase()==='received'?'in':'out'}})
   const old=loaded.lessons.find(l=>l.category_id===id)
   const d=await request('/category/'+id,{useFor:$('sandraTeachUse').value,notFor:$('sandraTeachNot').value,askWhen:$('sandraTeachAsk').value,examples,approve:$('sandraTeachApproved').checked,expectedRevision:old?.revision||0})
   loaded.lessons=loaded.lessons.filter(l=>l.category_id!==id);loaded.lessons.push(d.lesson);pendingExample=null;$('sandraTeachCategory').value='';fill();status(`Teaching revision ${d.lesson.revision} saved to PostgreSQL (${d.lesson.approved?'approved for drafts':'unapproved draft'}). Reanalyze the CSV to apply it. QuickBooks unchanged.`)
  }))
  $('sandraTeachingHistory').addEventListener('click',()=>run(async()=>{const id=$('sandraTeachCategory').value;if(!id)throw Error('Select a category.');const d=await request('/history/'+id);$('sandraTeachingHistoryText').textContent=JSON.stringify(d.history,null,2)}))
  $('sandraPreviewCategory').addEventListener('click',()=>run(async()=>{
   resetProposal();const d=await request('/preview',{categoryId:$('sandraTeachCategory').value,purchaseId:$('sandraPostedPurchaseId').value.trim()});proposal=d
   const p=d.preview;$('sandraPostedChangePreview').textContent=`${d.companyKey} / bank ${d.accountId} · Purchase #${p.purchaseId} · ${p.date} · ${p.payee} · $${p.amount.toFixed(2)}\nFROM: ${p.oldCategory} (#${p.oldCategoryId})\nTO: ${p.newCategory} (#${p.newCategoryId})\nTeaching purpose: ${d.teaching?.useFor||'Review required'}\nExclusions: ${d.teaching?.notFor||'None recorded'}\nAsk when: ${d.teaching?.askWhen||'None recorded'}\nConfirm these teaching conditions for this specific purchase. Only the category account changes. Expires in 15 minutes. ${d.writesEnabled?'Owner approval required.':'Accounting writes disabled on server.'}`
   $('sandraExecuteCategory').disabled=!d.writesEnabled;$('sandraCategoryReceipt').disabled=false
  }))
  $('sandraExecuteCategory').addEventListener('click',()=>run(async()=>{
   if(!proposal||!same(proposal)||!$('sandraPurposeApproved').checked||!$('sandraReconciliationApproved').checked)throw Error('Review the exact preview and confirm both checks.')
   // Disable before submission: never retry an uncertain financial request automatically.
   $('sandraExecuteCategory').disabled=true
   const d=await request('/execute/'+proposal.proposalId,{digest:proposal.digest,approved:true,businessPurposeConfirmed:true,reconciliationReviewed:true});status(`Posted Purchase #${d.result.purchaseId} category updated and verified. Receipt retained in PostgreSQL.`)
  }))
  $('sandraCategoryReceipt').addEventListener('click',()=>run(async()=>{if(!proposal)throw Error('Prepare a preview first.');const d=await request('/receipt/'+proposal.proposalId);$('sandraPostedChangePreview').textContent=JSON.stringify(d.receipt,null,2);status(`Receipt status: ${d.receipt.status}. Submitted/uncertain outcomes need manual verification before any new proposal.`)}))
  $('bankingAccountSelector').addEventListener('change',invalidate);document.addEventListener('sandra-company-changed',invalidate)
  document.addEventListener('sandra-category-candidate',e=>{if(!same(loaded)||!same(e.detail.scope)){status('Load teaching for this company/account with your owner credential first.');$('sandraTeachPanel').open=true;return}resetProposal();$('sandraPostedPurchaseId').value=e.detail.purchaseId;$('sandraTeachPanel').open=true;status('Posted Purchase selected. Choose the category, prepare a preview, then review purpose and reconciliation before approving.');$('sandraPostedPurchaseId').scrollIntoView({block:'center'});fridayPointTo($('sandraPostedPurchaseId'),350)});
  document.addEventListener('sandra-teach-row',e=>{if(!same(loaded)||!same(e.detail.scope)){status('Load teaching with your owner credential first, then choose Teach this merchant again.');$('sandraTeachPanel').open=true;return}const r=e.detail.row;$('sandraTeachPanel').open=true;pendingExample=`${r.fromTo||r.description} | ${r.direction==='in'?'received':'spent'}`;const suggested=loaded.categories.find(c=>c.name===r.suggestedCategory);if(suggested)$('sandraTeachCategory').value=suggested.id;fill();status('Choose the actual category and explain its purpose. Saving teaching does not approve or update this bank row.')})
 })
})()
// END [QUICKBOOKS-DASH-23A] Verified-owner teaching and exact expense approval controller
