import {authenticateSandraOwner} from '../../quickbooks/sandra-learning-core'
import {shopifyGraphQL} from '../../shopify/connection'
import {DailyError} from './core'
import {createDailyService} from './service'
import {seoService} from './seo'
import {photoService} from './photo'
export function registerDailyCommerceRoutes(app:any,deps:any={}){const graphql=deps.graphql||shopifyGraphQL,service=createDailyService({...deps,graphql}),seo=seoService(graphql),photos=photoService(graphql,deps.analysePhotos,deps.uploadImage)
 const endpoint=(fn:any)=>async(req:any,res:any)=>{res.set('Cache-Control','no-store');try{const owner=authenticateSandraOwner(req);await fn(req,res,owner)}catch(e:any){res.status(/^OWNER_/.test(e.message)?401:e instanceof DailyError?e.status:500).json({success:false,error:/^OWNER_/.test(e.message)?'Verify the existing owner key privately.':e instanceof DailyError?e.message:'Commerce operation failed. Existing inputs/data retained; inspect the report or receipt before retrying a write.'})}}
 app.get('/shopify/daily/settings',endpoint(async(_req:any,res:any,owner:any)=>res.json({success:true,owner,config:await service.config(owner)})))
 app.post('/shopify/daily/settings',endpoint(async(req:any,res:any,owner:any)=>res.json(await service.update(owner,req.body))))
 app.post('/shopify/daily/run',endpoint(async(_req:any,res:any,owner:any)=>res.json(await service.start(owner,false))))
 app.get('/shopify/daily/reports',endpoint(async(_req:any,res:any,owner:any)=>res.json(await service.list(owner))))
 app.get('/shopify/daily/reports/:id',endpoint(async(req:any,res:any,owner:any)=>res.json(await service.progress(owner,req.params.id))))
 app.post('/shopify/daily/reports/:id/stop',endpoint(async(req:any,res:any,owner:any)=>res.json(await service.stop(owner,req.params.id))))
 app.get('/shopify/daily/costs',endpoint(async(_req:any,res:any,owner:any)=>res.json({success:true,notes:await service.notes(owner)})))
 app.post('/shopify/daily/costs',endpoint(async(req:any,res:any,owner:any)=>res.json(await service.costUpdate(owner,req.body))))
 app.get('/shopify/daily/seo-reviews',endpoint(async(_req:any,res:any,owner:any)=>res.json(await seo.list(owner))))
 app.post('/shopify/daily/seo/preview',endpoint(async(req:any,res:any,owner:any)=>res.json(await seo.preview(owner,req.body))))
 app.post('/shopify/daily/seo/:id/apply',endpoint(async(req:any,res:any,owner:any)=>res.json(await seo.execute(owner,req.params.id,req.body.approved===true))))
 app.post('/shopify/daily/seo/:id/stop',endpoint(async(req:any,res:any,owner:any)=>res.json(await seo.stop(owner,req.params.id))))
 app.get('/shopify/daily/seo/:id/receipt',endpoint(async(req:any,res:any,owner:any)=>res.json(await seo.receipt(owner,req.params.id))))
 app.get('/shopify/daily/photos',endpoint(async(_req:any,res:any,owner:any)=>res.json(await photos.list(owner))))
 app.get('/shopify/daily/photo-locations',endpoint(async(_req:any,res:any)=>res.json(await photos.locations())))
 app.post('/shopify/daily/photos',endpoint(async(req:any,res:any,owner:any)=>res.json(await photos.create(owner,req.body))))
 app.get('/shopify/daily/photos/:id/images',endpoint(async(req:any,res:any,owner:any)=>res.json(await photos.images(owner,req.params.id))))
 app.get('/shopify/daily/photos/:id',endpoint(async(req:any,res:any,owner:any)=>res.json(await photos.get(owner,req.params.id))))
 for(const action of ['research','update','preview','execute','stop'] as const)app.post('/shopify/daily/photos/:id/'+action,endpoint(async(req:any,res:any,owner:any)=>res.json(await photos[action](owner,req.params.id,req.body))))
 let timer:any;if(deps.scheduler!==false){timer=setInterval(()=>{void service.tick().catch(()=>{})},60000);timer.unref?.();void service.tick().catch(()=>{});app.on?.('close',()=>clearInterval(timer))}
 return{service,seo,photos,close:()=>clearInterval(timer)}
}
