import {resolveOwnerSession,SESSION_MARKER} from '../auth/owner-session'
// START [SANDRA-LEARN-23A] Validated teaching and exact posted-expense preview
import {createHash, timingSafeEqual} from 'node:crypto'
import {readFileSync} from 'node:fs'
import {resolve} from 'node:path'
export function authenticateSandraOwner(req: any): 'salvador' | 'dayanna' {
  let keys: any
  try {keys = JSON.parse(readFileSync(resolve(process.cwd(),'credentials/sandra-owner-access.json'),'utf8'))}
  catch {throw new Error('OWNER_SETUP_REQUIRED')}
  const provided = String(req.headers['x-sandra-owner-key'] || '')
  if (!provided || provided===SESSION_MARKER) {const session=resolveOwnerSession(req);if(session)return session.owner;throw new Error('OWNER_UNAUTHORIZED')}
  if (!/^[a-f0-9]{64}$/.test(provided)) throw new Error('OWNER_UNAUTHORIZED')
  for (const actor of ['salvador','dayanna'] as const) {
    const expected = String(keys[actor] || '')
    if (/^[a-f0-9]{64}$/.test(expected) && timingSafeEqual(Buffer.from(expected),Buffer.from(provided))) return actor
  }
  throw new Error('OWNER_UNAUTHORIZED')
}
export function validateLesson(body: any) {
  const text = (k: string, max: number, required = false) => {
    if (typeof body?.[k] !== 'string' || body[k].length > max || (required && !body[k].trim())) throw new Error(`Invalid ${k}.`)
    return body[k].trim()
  }
  const revision = Number(body?.expectedRevision)
  if (!Number.isSafeInteger(revision) || revision < 0 || typeof body?.approve !== 'boolean') throw new Error('Invalid revision or approval.')
  if (!Array.isArray(body?.examples) || body.examples.length > 30) throw new Error('Maximum 30 merchant examples.')
  const examples = body.examples.map((r: any) => {
    if (typeof r?.merchant !== 'string' || r.merchant.trim().length < 4 || r.merchant.length > 100 || !['in','out'].includes(r.direction)) throw new Error('Each example needs an exact merchant and direction.')
    return {merchant:r.merchant.trim(),direction:r.direction}
  })
  return {useFor:text('useFor',2000,true),notFor:text('notFor',2000),askWhen:text('askWhen',2000),examples,expectedRevision:revision,approve:body.approve}
}
const digest = (x: unknown) => createHash('sha256').update(JSON.stringify(x)).digest('hex')
export function purchasePreview(purchase: any, bankAccountId: string, category: any) {
  if (!purchase || !/^\d+$/.test(String(purchase.Id)) || !/^\d+$/.test(String(purchase.SyncToken)) || String(purchase.AccountRef?.value) !== bankAccountId) throw new Error('Purchase does not belong to the selected bank account.')
  if (!category?.Active || !['Expense','Other Expense','Cost of Goods Sold'].includes(category.AccountType)) throw new Error('Select an active expense or cost-of-goods-sold category.')
  if (purchase.Credit || purchase.CurrencyRef && purchase.CurrencyRef.value !== 'USD' || purchase.TxnTaxDetail && (Number(purchase.TxnTaxDetail.TotalTax || 0) !== 0 || purchase.TxnTaxDetail.TaxLine?.length) || purchase.LinkedTxn?.length) throw new Error('Refunds, foreign currency, tax and linked transactions require manual review.')
  const lines = purchase.Line
  if (!Array.isArray(lines) || lines.length !== 1 || lines[0].DetailType !== 'AccountBasedExpenseLineDetail' || !lines[0].Id || lines[0].LinkedTxn?.length) throw new Error('Only a single account-based expense line is supported. Split/item transactions require manual review.')
  const detail = lines[0].AccountBasedExpenseLineDetail
  if (!detail?.AccountRef?.value || detail.TaxCodeRef && !['NON','NON-TAX'].includes(detail.TaxCodeRef.value)) throw new Error('Taxed or incomplete expense details require manual review.')
  if (String(detail.AccountRef.value) === String(category.Id)) throw new Error('This purchase already uses the selected category.')
  if (!Number.isFinite(Number(purchase.TotalAmt)) || Number(purchase.TotalAmt) <= 0 || Math.abs(Number(lines[0].Amount)-Number(purchase.TotalAmt)) > 0.001) throw new Error('Expense amounts do not agree.')
  const line = JSON.parse(JSON.stringify(lines[0]))
  line.AccountBasedExpenseLineDetail.AccountRef = {value:String(category.Id)}
  const payload = {Id:String(purchase.Id),SyncToken:String(purchase.SyncToken),sparse:true,Line:[line]}
  return {purchaseId:String(purchase.Id),syncToken:String(purchase.SyncToken),date:purchase.TxnDate,payee:purchase.EntityRef?.name || '',amount:Number(purchase.TotalAmt),bankAccountId,oldCategoryId:String(detail.AccountRef.value),oldCategory:detail.AccountRef.name || '',newCategoryId:String(category.Id),newCategory:category.FullyQualifiedName || category.Name,payload,snapshotHash:digest(purchase)}
}
export function applyTaughtCategories(rows: any[], lessons: any[]) {
  const normalize = (v: string) => v.toLowerCase().replace(/[^a-z0-9]+/g,' ').trim()
  return rows.map(original => {
    const row = {...original}
    if (row.candidates.length || row.amount >= 5000 || row.possibleDuplicate && !row.repeatConfirmed || /\b(zelle|transfer|payroll|irs|tax|loan|mortgage)\b/i.test(row.description + ' ' + (row.fromTo || ''))) return row
    const desc=normalize(row.description),payee=normalize(row.fromTo || '')
    const found = lessons.filter(l => l.approved && l.definition.examples.some((e: any) => {
      const merchant=normalize(e.merchant)
      return e.direction===row.direction && (desc===merchant || desc.startsWith(merchant+' ')) && (!payee || payee===merchant)
    }))
    if (found.length > 1) {row.reviewStatus='exception';row.reason+=' Multiple taught categories apply; resolve the conflict.';return row}
    if (found.length !== 1) return row
    const lesson=found[0]
    // Free-text exceptions cannot safely be inferred from merchant name alone.
    if (lesson.definition.askWhen || lesson.definition.notFor) {
      row.reviewStatus='exception';row.taughtCategoryId=lesson.category_id;row.taughtCategory=lesson.category_name
      row.reason+=` Teaching proposes ${lesson.category_name}. Check exclusions: ${lesson.definition.notFor || 'none'}. Ask when: ${lesson.definition.askWhen || 'none'}.`
      return row
    }
    if (row.suggestedCategory && normalize(row.suggestedCategory)!==normalize(lesson.category_name)) {row.reviewStatus='exception';row.reason+=' Taught category conflicts with existing evidence.';return row}
    row.reviewStatus='prepared';row.confidence='YELLOW';row.suggestedCategory=lesson.category_name;row.suggestedCategoryId=lesson.category_id;row.suggestion='Owner-approved teaching — draft recommendation';row.lessonRevision=lesson.revision;row.reason=lesson.definition.useFor
    return row
  })
}
// END [SANDRA-LEARN-23A] Validated teaching and exact posted-expense preview
