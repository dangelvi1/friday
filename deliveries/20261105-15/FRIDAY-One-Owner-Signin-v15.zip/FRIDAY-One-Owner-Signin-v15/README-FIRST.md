# FRIDAY One Owner Sign-in v15

FRIDAY stays on your PC at S:\AI\friday-ai. One FRIDAY password unlocks authorized modules in the same browser profile and origin; new dashboard/review tabs reuse the session. Salvador and Dayanna retain separate identities. This is sign-in, not approval for edits/deletions/sends. Existing Google, QuickBooks, Shopify and marketplace logins/scopes remain separate provider connections and may still need authorization when expired.

## Installation

This cumulative package supports installed v12, v13, and both v14 voice variants. It preserves the matching Crosslist source family and does not start or require the discontinued Crosslist analysis work. It includes the prior v14 ecommerce functionality, so v14 does not need to be installed first. The installer selects the exact baseline by source hash before any project writes; unknown source stops safely.

Stop only FRIDAY's backend with Ctrl+C; close old review tabs. Extract the ZIP into a new folder. Use the actual absolute installer path:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File 'S:\AI\Fixing-Files-Folder\FRIDAY-One-Owner-Signin-v15\Install-One-Owner-Signin.ps1' -ProjectPath 'S:\AI\friday-ai'
if ($LASTEXITCODE -ne 0) { throw 'Installer failed. Do not continue.' }
Set-Location 'S:\AI\friday-ai'
npm run build
if ($LASTEXITCODE -ne 0) { throw 'Build failed. Do not continue.' }
npm run server
```

Keep `npm run dev` running in another terminal. Ctrl+F5 https://localhost:5173/; close/reopen old paired dashboard tabs. Process-scoped ExecutionPolicy Bypass does not change the system policy. No provider credentials, TLS/Vite settings, package files, existing AGENTS or private data are replaced. See the printed verified backup path.

## Sign in once

Choose Salvador or Dayanna and click Connect. The private sign-in screen appears before microphone/AI connection. Use your existing owner's key in the Password field. To choose an easier personal password, expand **First time: set or reset a personal password**, enter that existing owner key above, and enter/repeat your chosen 12–128-character password below. Only do this on FRIDAY's own screen; never send it to chat or speak it. A later sign-in uses the personal password. Existing owner keys remain available for recovery/reset and legacy API clients; no keys are regenerated or printed.

Calendar, Sandra teaching/private bank review, invoices/custom fields/statements, Document Analysis and ecommerce use the shared sign-in. Module password inputs/Verify owner buttons are hidden; existing connection checks/company/calendar/workspace selections still apply. Same-browser/same-origin paired tabs inherit an opaque HttpOnly cookie, not your key. Another browser/device/profile signs in separately. The installed desktop app shares a session only if it uses the same browser profile/origin; its native runtime was not available for verification. Current working https://localhost:5173 is the supported default. HTTPS LAN IP origins on the app ports are also supported; named/custom deployments require explicit FRIDAY_OWNER_ALLOWED_ORIGINS configuration, never invented by this update.

The session lasts at most eight hours, ends when FRIDAY is explicitly disconnected/locked, and is invalidated by backend restart, key rotation or password reset. After rotating an existing owner key, reset the personal password privately using the new key. Save unsaved notes/forms before disconnecting or switching owners; locking clears owner-private review state. Refresh/new tabs reuse an active session. Switching to the other owner's profile locks the old session and requires that owner's password. Say **Lock FRIDAY** or use the shared Lock button. Locking propagates to paired tabs and clears pending reviews/owner-private module state. A request already submitted may finish; check its receipt. No write is automatically replayed after login/expiry.

One sign-in does not approve accounting/calendar/product/file actions. FRIDAY still displays each specific review and accepts **yes / approve it / cancel it** by the existing voice gate. Production-company confirmation and all company/owner scopes remain. Passwords/keys are never voice inputs. The helper stores only salted scrypt password hashes in private credentials/friday-owner-passwords.json; session IDs stay server-side in memory and only an opaque HttpOnly/SameSite cookie reaches the browser. Passwords/keys/tokens are not put in browser storage, URLs or paired-tab messages. Failed logins are rate-limited. Provider/employee OAuth/webhooks are not intercepted by the new realtime sign-in gate; the separated Nationwide/Sara employee system is preserved.

## Quick test

1. Connect and sign in once. Open Calendar, Daily ecommerce, and the paired QuickBooks dashboard from FRIDAY's conversational link. No second owner-password prompt should appear. Calendar/provider permission errors are connection errors rather than a demand for another FRIDAY password.
2. Open a full Document Analysis review from that dashboard. Same browser/origin reuses the sign-in. Read-only work and private notes retain company/owner scope.
3. Prepare one small authorized change; inspect it and say cancel it. Prepare it again and approve it once. Only the specific approved action may execute.
4. Lock FRIDAY. The paired tab clears its pending review. Reconnect: one password prompt returns. Choosing Dayanna requires Dayanna's sign-in.

The included ecommerce foundation prioritizes current inventory, offers private editable budgets, nightly 19:30 Eastern reporting while the PC/backend runs, quote/source/cost comparisons, supported reviewed SEO writes and photo-assisted Shopify DRAFT creation. Local photos still require a file-picker selection. No purchases, ad spending, theme publishing, live product publication or fulfillment are installed. Scheduled read-only jobs continue according to explicitly saved settings; disconnecting a microphone does not disable an approved nightly schedule. See SHOPIFY-V14-GUIDE.md for the detailed ecommerce boundaries; its old per-panel key steps are superseded by this shared sign-in.

## Backup / restore

Installer validates hashes, verifies backups, records the actual selected profile/source hashes and rolls back attempted copies on failure. Restore from the printed backup folder after stopping the backend, using its Restore-One-Owner-Signin.ps1 by absolute path with process-scoped ExecutionPolicy Bypass. It refuses subsequent source edits and removes only new application/test files from this package. Private passwords/provider credentials/reports/photos/receipts remain. Restart revokes session cookies server-side. Restoring source does not undo approved external changes. No private credentials, passwords, cookies, real catalog/photos/reports or browser profiles are included in the ZIP.
