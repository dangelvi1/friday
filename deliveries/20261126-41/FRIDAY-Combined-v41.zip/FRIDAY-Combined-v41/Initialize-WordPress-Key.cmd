@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Initialize-WordPress-Key.ps1" -ProjectPath "S:\AI\friday-ai"
if errorlevel 1 (
  echo Key setup did not finish. Read the error above; do not force it.
  pause
  exit /b 1
)
echo Restart the two FRIDAY servers once to load the new key.
pause
