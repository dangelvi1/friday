param([string]$ProjectPath='S:\AI\friday-ai')
$ErrorActionPreference='Stop'
$envPath=Join-Path $ProjectPath '.env'
if(!(Test-Path -LiteralPath (Join-Path $ProjectPath 'server.ts'))){throw 'FRIDAY project not found. No configuration changed.'}
$content=if(Test-Path -LiteralPath $envPath){[IO.File]::ReadAllText($envPath)}else{''}
function Pattern([string]$Name) { return '(?m)^[ \t]*(?:export[ \t]+)?' + [regex]::Escape($Name) + '[ \t]*=([^\r\n]*)' }
function Existing([string]$Name) {
  $matches = [regex]::Matches($script:content, (Pattern $Name))
  if ($matches.Count -gt 1) { throw "Duplicate $Name entries exist. Resolve those privately first; no configuration changed." }
  if (!$matches.Count) { return '' }
  $value = $matches[0].Groups[1].Value.Trim()
  if ($value.StartsWith("'")) { $m=[regex]::Match($value,"^'([^']*)'(?:\s*#.*)?$"); if (!$m.Success) { throw "Unsupported quoting for $Name. No configuration changed." }; return $m.Groups[1].Value }
  if ($value.StartsWith('"')) { $m=[regex]::Match($value,'^"([^"]*)"(?:\s*#.*)?$'); if (!$m.Success) { throw "Unsupported quoting for $Name. No configuration changed." }; return $m.Groups[1].Value }
  return ($value -split '#',2)[0].Trim()
}
function Set-Value([string]$Name,[string]$Value) {
  if (!$Value -or $Value -match "['\r\n\x00]") { throw "Invalid or empty value for $Name. No configuration changed." }
  $assignment = $Name + "='" + $Value + "'"
  $pattern = Pattern $Name
  if ([regex]::IsMatch($script:content,$pattern)) { $script:content=[regex]::Replace($script:content,$pattern,[System.Text.RegularExpressions.MatchEvaluator]{param($m) $assignment}) }
  else { if ($script:content.Length -gt 0 -and !$script:content.EndsWith("`n")) { $script:content += "`r`n" }; $script:content += $assignment + "`r`n" }
}

$key=Existing 'FRIDAY_WORDPRESS_CREDENTIAL_KEY'
if($key){
 if($key -notmatch '^[A-Za-z0-9+/]{43}=$' -or [Convert]::FromBase64String($key).Length -ne 32){throw 'Existing WordPress key is invalid and was NOT replaced. Preserve the original key and resolve it privately.'}
 Write-Host 'Existing WordPress key preserved. Nothing changed.'
 exit 0
}
$bytes=New-Object byte[] 32
$rng=[Security.Cryptography.RandomNumberGenerator]::Create()
try{$rng.GetBytes($bytes)}finally{$rng.Dispose()}
Set-Value 'FRIDAY_WORDPRESS_CREDENTIAL_KEY' ([Convert]::ToBase64String($bytes))
$backup=$null
if (Test-Path -LiteralPath $envPath) {
  $backup=Join-Path $ProjectPath ('backups\wordpress-key-' + (Get-Date -Format 'yyyyMMdd-HHmmss-fff') + '-' + [guid]::NewGuid().ToString('N').Substring(0,6))
  New-Item -ItemType Directory -Force -Path $backup | Out-Null
  $saved=Join-Path $backup '.env'
  Copy-Item -LiteralPath $envPath -Destination $saved
  if ((Get-FileHash -LiteralPath $envPath -Algorithm SHA256).Hash -ne (Get-FileHash -LiteralPath $saved -Algorithm SHA256).Hash) { throw 'Private backup verification failed. Existing configuration unchanged.' }
  if ($env:OS -eq 'Windows_NT') { Get-Acl -LiteralPath $envPath | Set-Acl -LiteralPath $saved }
}
$temp=$envPath+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
try {
  [IO.File]::WriteAllText($temp,$content,(New-Object Text.UTF8Encoding($false)))
  if (Test-Path -LiteralPath $envPath) {
    if ($env:OS -eq 'Windows_NT') { Get-Acl -LiteralPath $envPath | Set-Acl -LiteralPath $temp }
    [IO.File]::Replace($temp,$envPath,[System.Management.Automation.Language.NullString]::Value)
  } else { [IO.File]::Move($temp,$envPath) }
} finally { if (Test-Path -LiteralPath $temp) { Remove-Item -LiteralPath $temp -Force } }
Write-Host 'Private WordPress key configured. Google Ads and unrelated settings were preserved.'
if ($backup) { Write-Host "Verified PRIVATE .env backup: $backup" }
Write-Host 'Keep .env and its backup private. Restart FRIDAY and use AITAN Website Manager.'
Write-Host 'No WordPress or Google request, website change or ad spending was performed.'
