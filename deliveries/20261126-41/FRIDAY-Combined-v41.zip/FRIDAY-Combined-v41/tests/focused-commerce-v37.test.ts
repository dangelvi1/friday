import test from 'node:test'
import assert from 'node:assert/strict'
import {mkdtemp,mkdir,writeFile,rm} from 'node:fs/promises'
import {tmpdir} from 'node:os'
import {join,resolve} from 'node:path'
import {build} from 'vite'
import {chromium} from 'playwright'
import express from 'express'
import {selectCommerceProduct,savedProductPricing} from '../src/commerce-pricing'
import {registerDailyCommerceRoutes} from '../commerce/daily/routes'
import {DEFAULTS,STORE} from '../commerce/daily/core'
import {readJob} from '../commerce/daily/storage'
import {pricingIdeas} from '../commerce/daily/catalog'
import {buildResearch} from '../commerce/daily/research'
import {imageData} from '../commerce/daily/photo'

test('Saved pricing resolves real products beyond first ten without punctuation-based misses or online claims',()=>{
 const products=Array.from({length:15},(_,n)=>({id:'gid://shopify/Product/'+n,title:n===14?'Vans Old Skool -Bitter Chocolate':'Other product '+n}))
 const report={audit:{products},pricing:[{productId:products[14].id,title:products[14].title}],owned:[{id:products[14].id,variants:[{sku:'0009',merchandiseUSD:'20.00'}]}],research:{evidenceVersion:2,products:[]}}
 const r=savedProductPricing(report,{query:'VANS Old Skool Bitter Chocolate'})
 assert.equal(r.status,'selected');assert.equal(r.pricing[0].productId,products[14].id);assert.equal(r.liveWebSearchPerformed,false);assert.equal(r.owned.variants[0].sku,'0009');assert.equal(r.hasQualifiedMarketLeads,false);assert.equal(selectCommerceProduct(report,{}).candidates.length,10);assert.equal(selectCommerceProduct(report,{productId:''}).status,'not_found');assert.equal(selectCommerceProduct(report,{query:'---'}).status,'not_found')
 assert.equal(selectCommerceProduct(report,{query:'Other product'}).status,'selection_required')
 assert.equal(selectCommerceProduct(report,{productId:'unrelated',query:'Vans Old Skool Bitter Chocolate'}).status,'not_found')
 assert.match(selectCommerceProduct(report,{query:'No such name'}).message,/does not establish/)
})

test('Legacy/general-price leads never enter saved pricing experiments',()=>{
 const product={id:'p',title:'Fixture',variants:[]},lead={existingProductId:'p',channels:[{sourceLinked:true,priceUSD:'97.50'}]}
 assert.equal(pricingIdeas({audit:{products:[product]},research:{products:[lead]}})[0].marketMedianUSD,null)
 assert.equal(pricingIdeas({audit:{products:[product]},research:{evidenceVersion:2,products:[lead]}})[0].marketMedianUSD,null)
 const r=buildResearch({products:[{kind:'new_opportunity',title:'Not the requested product'}]},[],{...DEFAULTS,selectedOwnedOnly:true},new Set(['p']))
 assert.equal(r.products.length,0);assert.deepEqual(pricingIdeas({audit:{products:[{id:'legacy',title:'Partial legacy'}]}})[0].variants,[])
})

test('Owned comparison leads bind to actual variant IDs and distinguish competitor shipping',()=>{
 const url='https://example.com/products/fixture-shoe',productId='gid://shopify/Product/1',variantId='gid://shopify/ProductVariant/1'
 const item={kind:'owned_inventory',existingProductId:productId,title:'Fixture',offers:[],channels:[{name:'Fixture merchant',url,currency:'USD',priceUSD:'49.00',priceBasis:'asking',variantMatch:'exact',matchedVariantId:variantId,itemSize:'9',itemCondition:'New without tags',listedShippingUSD:'5.00',quote:'$49.00 for size 9, new without tags. Shipping $5.00.'}]}
 const build=(variants:any[])=>buildResearch({products:[item]},[{url}],DEFAULTS,new Set([productId]),[{id:productId,variants}]).products[0].channels[0]
 assert.equal(build([]).priceUSD,null)
 const c=build([{id:variantId,title:'Men size 9'}]);assert.equal(c.priceUSD,'49.00');assert.equal(c.listedShippingUSD,'5.00');assert.equal(c.matchedVariantId,variantId);assert.equal(c.itemCondition,'New without tags')
})

test('Focused owner API research uses selected live product only and refreshes saved costs without native writes',async t=>{
 const root=resolve(import.meta.dirname,'..'),cwd=process.cwd(),dir=await mkdtemp(join(tmpdir(),'friday-focus-v37-')),key='a'.repeat(64),other='b'.repeat(64)
 let server:any,browser:any,page:any,wrong=false,mutations=0,imageEdits=0,pauseImage:Promise<void>|null=null,finishImage:(()=>void)|undefined
 const calls:any[]=[],png='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aY1sAAAAASUVORK5CYII=',prepared='data:image/png;base64,'+Buffer.concat([imageData(png).bytes,Buffer.from('synthetic-photo-copy')]).toString('base64')
 try{
  process.chdir(dir);await mkdir('credentials');await writeFile('credentials/sandra-owner-access.json',JSON.stringify({salvador:key,dayanna:other}))
  const target='gid://shopify/Product/14',vid='gid://shopify/ProductVariant/14',pi={hasNextPage:false,endCursor:null}
  const products=[1,14].map(n=>({id:'gid://shopify/Product/'+n,title:n===14?'Vans Old Skool -Bitter Chocolate':'Other fixture',handle:'fixture-'+n,status:'ACTIVE',vendor:'Vans',descriptionHtml:'<p>Existing fixture description.</p>',onlineStoreUrl:'https://saldana.shop/products/fixture-'+n,seo:{title:'Fixture SEO',description:'A sufficiently detailed fixture SEO description.'},variants:{nodes:[{id:'gid://shopify/ProductVariant/'+n,title:'Men size 9',sku:'000'+n,price:'49.00',inventoryQuantity:2,selectedOptions:[{name:'Size',value:'9'}],inventoryItem:{id:'gid://shopify/InventoryItem/'+n,tracked:true}}],pageInfo:pi},images:{nodes:[{id:'img-'+n,url:'https://cdn.shopify.com/fixture.jpg',altText:'Fixture shoes'}],pageInfo:pi},tags:[],category:null,metafields:{nodes:[],pageInfo:pi}}))
  const graphql=async(q:string,v:any={})=>{
   if(q.startsWith('mutation')){mutations++;throw Error('No mutation allowed')}
   if(q.includes('Identity'))return{data:{shop:{id:wrong?'other':STORE.id,myshopifyDomain:STORE.domain,currencyCode:'USD'}}}
   if(q.includes('DailyStoreProducts'))return{data:{products:{nodes:structuredClone(products),pageInfo:pi}}}
   if(q.includes('DailyUnitCosts'))return{data:{nodes:v.ids.map((id:string)=>({id,unitCost:{amount:'20.00',currencyCode:'USD'}}))}}
   if(q.includes('CatalogDefinitions'))return{data:{metafieldDefinitions:{nodes:[],pageInfo:pi}}}
   if(q.includes('CatalogConstraintSchema'))return{data:{__type:{fields:[]}}}
   if(q.includes('CatalogListing'))return{data:{product:structuredClone(products.find(p=>p.id===v.id))}}
   if(q.includes('CatalogTaxonomy'))return{data:{taxonomy:{categories:{nodes:[],pageInfo:pi}}}}
   return{errors:[{message:'Unsupported optional fixture read'}]}
  }
  const app=express();app.use(express.json())
  const routes=registerDailyCommerceRoutes(app,{graphql,scheduler:false,prepareProductImage:async()=>{imageEdits++;if(pauseImage)await pauseImage;return prepared},analysePhotos:async()=>({lookupStatus:'matches_found',suggestions:{title:'Fixture owned shoe',description:'Original factual fixture description from the owner photo.',vendor:'Vans',productType:'Shoes',seoTitle:'Fixture owned shoe',seoDescription:'Original factual fixture snippet for the owner product.'},questions:['Confirm the actual size, condition and measured shipping weight.'],matches:[{title:'Possible fixture model',url:'https://example.com/products/fixture',priceUSD:'49.00',match:'possible',quote:'$49.00 fixture source',priceBasis:'Synthetic asking price fixture'}],references:[],imagePolicy:'Owner originals and selected prepared copies only'}),homepage:async()=>({available:true,issues:[]}),research:async(config:any,owned:any[])=>{calls.push({config,ids:owned.map(p=>p.id)});return{raw:{products:[{kind:'owned_inventory',existingProductId:owned[0].id,title:owned[0].title,offers:[],channels:[]}],storeIdeas:[],adIdeas:[],limitations:[]},sources:[]}}})
  server=app.listen(0,'127.0.0.1');await new Promise<void>(resolve=>server.once('listening',resolve));const base='http://127.0.0.1:'+server.address().port+'/shopify/daily'
  const req=async(path:string,body?:any,ownerKey=key)=>{const r=await fetch(base+path,{method:body===undefined?'GET':'POST',headers:{'content-type':'application/json','x-sandra-owner-key':ownerKey},...(body===undefined?{}:{body:JSON.stringify(body)})});return{status:r.status,data:await r.json()}}
  const finish=async(id:string)=>{for(let n=0;n<300;n++){const r=await routes.service.progress('salvador',id);if(r.job.status!=='running'&&(await routes.service.list('salvador')).activeId!==id)return r.job;await new Promise(resolve=>setTimeout(resolve,10))}throw Error('Fixture worker timeout')}
  await req('/settings',{...DEFAULTS,enabled:false,includeSales:false,expectedRevision:0})
  let reportId=''
  await t.test('focused request is authenticated, stays on actual target and uses one research call',async()=>{
   assert.equal((await req('/run',{productId:target},'bad')).status,401)
   const r=await req('/run',{productId:target});assert.equal(r.status,200);reportId=r.data.job.id
   const j=await finish(reportId);assert.equal(j.focusProductId,target);assert.equal(j.counts.marketResearchTarget,1);assert.equal(calls.length,1);assert.deepEqual(calls[0].ids,[target]);assert.equal(calls[0].config.selectedOwnedOnly,true);assert.equal(mutations,0)
   assert.equal((await req('/reports/'+reportId,undefined,other)).status,404)
  })
  await t.test('invalid/missing live targets and wrong stores cannot trigger paid research',async()=>{
   assert.equal((await req('/run',{productId:'invalid'})).status,400)
   const missing=await req('/run',{productId:'gid://shopify/Product/999'});const j=await finish(missing.data.job.id);assert.match(j.error,/No paid research/);assert.equal(calls.length,1)
   wrong=true;const r=await req('/run',{productId:target});await finish(r.data.job.id);wrong=false;assert.equal(calls.length,1);assert.equal(mutations,0)
  })
  await t.test('saving complete actual costs refreshes persisted and returned pricing; stale writes fail',async()=>{
   const values={merchandiseUSD:'20.00',inboundShippingUSD:'0.00',inboundTaxUSD:'0.00',otherInboundUSD:'0.00',outboundShippingUSD:'5.00',packagingUSD:'1.00',sellingFeeUSD:'2.00',paymentFeeUSD:'1.00',adsUSD:'0.00',returnsUSD:'0.00'}
   const r=await req('/costs',{reportId,variantId:vid,expectedRevision:0,values});assert.equal(r.status,200)
   assert.equal(r.data.owned.find((p:any)=>p.id===target).variants[0].estimatedContributionUSD,'20.00')
   const pricing=r.data.pricing.find((p:any)=>p.productId===target).variants[0];assert.deepEqual(pricing.costGaps,[]);assert.equal(pricing.experiments.find((x:any)=>x.percent===10).estimatedContributionUSD,'15.10')
   const saved=await readJob('salvador',reportId);assert.deepEqual(saved.report.pricing,r.data.pricing)
   assert.equal((await req('/costs',{reportId,variantId:vid,expectedRevision:0,values})).status,409);assert.equal(mutations,0)
  })
  await t.test('actual dashboard resolves a named product and starts focused research with the new button',async()=>{
   const out=join(dir,'frontend')
   await build({root,configFile:false,logLevel:'silent',build:{outDir:out,lib:{entry:join(root,'src/daily-commerce-panel.ts'),formats:['es'],fileName:()=> 'panel.js'},emptyOutDir:true}})
   app.use('/bundled',express.static(out));app.get('/test',(_req,res)=>res.type('html').send('<html><body><div class="panel"></div><script type="module">import {createDailyCommercePanel} from "/bundled/panel.js";window.panel=createDailyCommercePanel();</script></body></html>'))
   browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']})
   page=await browser.newPage();await page.addInitScript('window.__name=(fn)=>fn');await page.goto(base.replace('/shopify/daily','')+'/test')
   await page.waitForFunction(()=>(window as any).panel);await page.locator('#openDailyCommerce').click();await page.locator('#dcKey').fill(key);await page.locator('#dcVerify').click();await page.waitForFunction(()=>document.getElementById('dcStatus')?.textContent?.includes('verified'))
   await page.evaluate(id=>(window as any).panel.execute('report',{reportId:id}),reportId)
   const pricing=await page.evaluate(()=>(window as any).panel.execute('pricing',{query:'Vans Old Skool Bitter Chocolate'}))
   assert.equal(pricing.product.id,target);assert.equal(pricing.liveWebSearchPerformed,false);assert.equal(pricing.owned.variants[0].estimatedContributionUSD,'20.00')
   const noMatch=await page.evaluate(()=>(window as any).panel.execute('research_product',{query:'No matching product'}));assert.equal(noMatch.success,false);assert.equal(calls.length,1)
   await page.locator('[data-commerce-section=research]').click();await page.getByRole('button',{name:'Research this product · normal API usage'}).click()
   for(let n=0;n<300&&calls.length<2;n++)await new Promise(resolve=>setTimeout(resolve,10))
   assert.equal(calls.length,2);assert.deepEqual(calls[1].ids,[target]);assert.equal(calls[1].config.selectedOwnedOnly,true);assert.equal(mutations,0)
   const current=(await routes.service.list('salvador')).activeId;if(current)await finish(current)
  })

  await t.test('photo plus name lookup builds local copy; picture preview/select/restore never publishes automatically',async()=>{
   await page.evaluate(()=>(window as any).panel.execute('section',{section:'photos'}))
   await page.locator('#dpNotes').fill('Fixture owned shoe')
   await page.locator('#dpFiles').setInputFiles({name:'owner-photo.png',mimeType:'image/png',buffer:imageData(png).bytes})
   await page.locator('#dpUpload').click();await page.waitForFunction(()=>document.getElementById('dpStatus')?.textContent?.includes('uploaded'))
   await page.locator('#dpAnalyse').click();await page.waitForFunction(()=>document.getElementById('dpMatches')?.textContent?.includes('Possible fixture model'))
   await page.locator('#dpUse').click();await page.waitForFunction(()=>document.querySelector<HTMLInputElement>('#dp_title')?.value==='Fixture owned shoe')
   await page.locator('#dpPrepareImage').click();await page.getByRole('button',{name:'Use this prepared copy'}).waitFor()
   assert.equal(imageEdits,1);assert.equal(await page.locator('#dpPictures img').getAttribute('src'),png);assert.equal(await page.locator('#dp_title').inputValue(),'Fixture owned shoe')
   await page.getByRole('button',{name:'Use this prepared copy'}).click();await page.waitForFunction(()=>document.querySelector('#dpPictures img')?.getAttribute('src')!==document.querySelector('#dpPreparedImages img')?.getAttribute('src'))
   assert.equal(await page.locator('#dpPictures img').getAttribute('src'),prepared)
   await page.getByRole('button',{name:'Restore original 1'}).click();await page.waitForFunction(()=>document.querySelector('#dpPreparedImages button')?.textContent?.includes('selected'))
   assert.equal(await page.locator('#dpPictures img').getAttribute('src'),png)
   pauseImage=new Promise<void>(resolve=>{finishImage=resolve});const preparing=page.evaluate(()=>(window as any).panel.execute('photo_prepare_image',{photoNumber:1,imageStyle:'soft_studio'}));for(let n=0;n<100&&imageEdits<2;n++)await new Promise(resolve=>setTimeout(resolve,10));await page.locator('#dp_size').fill('9');finishImage!();const copy=await preparing;pauseImage=null;assert.equal(copy.success,true);assert.ok(copy.preparedId);assert.equal(imageEdits,2);assert.equal(await page.locator('#dp_size').inputValue(),'9');await page.evaluate(()=>(window as any).panel.execute('photo_save'))
   const selected=await page.evaluate(id=>(window as any).panel.execute('photo_select_image',{imageAssetId:id}),copy.preparedId);assert.equal(selected.success,true)
   const incomplete=await page.evaluate(()=>(window as any).panel.execute('photo_preview',{publish:true}));assert.equal(incomplete.success,false);assert.equal(mutations,0)
  })

  await t.test('focused research does not consume the enabled nightly full-report slot',async()=>{
   const c=await routes.service.config('salvador');await routes.service.update('salvador',{...c,enabled:true,reportTime:'00:00',expectedRevision:c.revision})
   const before=calls.length,targeted=await routes.service.start('salvador',false,target);await finish(targeted.job.id);assert.equal(calls.length,before+1)
   await routes.service.tick();const active=(await routes.service.list('salvador')).activeId;if(active)await finish(active)
   assert.equal(calls.length,before+2);assert.equal(calls.at(-1).config.selectedOwnedOnly,false);assert.equal(calls.at(-1).ids.length,2)
   await routes.service.tick();assert.equal(calls.length,before+2)
  })

 }finally{if(browser)await browser.close();if(server)await new Promise<void>(resolve=>server.close(()=>resolve()));process.chdir(cwd);await rm(dir,{recursive:true,force:true})}
})
