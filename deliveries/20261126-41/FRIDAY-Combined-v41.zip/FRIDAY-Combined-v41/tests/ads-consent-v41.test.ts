import test from 'node:test'
import assert from 'node:assert/strict'
import {readFile,mkdtemp,writeFile,rm} from 'node:fs/promises'
import {join,resolve} from 'node:path'
import {tmpdir} from 'node:os'
import express from 'express'
import {build} from 'vite'
import {chromium} from 'playwright'

test('actual SDK tools in every delivered voice family gate Ads disclosure without changing manual dashboard behavior',async t=>{
 const root=resolve(import.meta.dirname,'..'),dir=await mkdtemp(join(tmpdir(),'friday-ads-consent-v41-'));let browser:any,server:any
 try{
  const codes=await Promise.all(['src/main.ts','variants/v12/src/main.ts','variants/v13/src/main.ts'].map(async f=>(await readFile(join(root,f),'utf8')).split('const googleAdsStudioTool=')[1].split('\nconst ')[0]))
  const entry=join(dir,'entry.ts');await writeFile(entry,`import{runGoogleAdsWithConsent}from${JSON.stringify(join(root,'src/google-ads-consent.ts'))};import{tool}from'@openai/agents';import{z}from'zod';window.privateCalls=0;window.manualCalls=0;window.held=false;window.release=null;window.lastResult=null;const privateResult={success:true,account:{id:'1234567890',name:'PRIVATE-ACCOUNT-FIXTURE'},ideas:[{text:'PRIVATE-KEYWORD-FIXTURE',averageMonthlySearches:123}]};const marketingPanel={execute:async(action,args)=>{window.privateCalls++;if(window.held)await new Promise(r=>window.release=r);return privateResult}};const fridayDashboard={state:()=>({section:'marketing'}),notify:()=>{}};window.tools=${JSON.stringify(codes)}.map(code=>new Function('tool','z','marketingPanel','fridayDashboard','runGoogleAdsWithConsent','return '+code)(tool,z,marketingPanel,fridayDashboard,runGoogleAdsWithConsent));window.invoke=(family=0,action='test',companyId='company-a')=>{window.lastResult=null;window.task=window.tools[family].invoke({context:{}},JSON.stringify({action,companyId})).then(r=>window.lastResult=r);};document.getElementById('manual').onclick=()=>{window.manualCalls++;document.getElementById('results').textContent=JSON.stringify(privateResult)};window.ready=true;`)
  const out=join(dir,'bundle');await build({root,configFile:false,logLevel:'silent',resolve:{alias:[{find:/^@openai\/agents$/,replacement:join(root,'node_modules/@openai/agents/dist/index.mjs')},{find:/^zod$/,replacement:join(root,'node_modules/zod/index.js')}]},build:{outDir:out,lib:{entry,formats:['es'],fileName:'consent'}}})
  const app=express();app.use('/bundle',express.static(out));app.get('/',(_q,r)=>r.type('html').send(`<html><head><meta name=viewport content="width=device-width,initial-scale=1"></head><body><select id=mkCompany><option value=company-a>Company A</option><option value=company-b>Company B</option></select><button id=manual>Read in dashboard</button><pre id=results></pre><script>window.__name=f=>f;window.owner={id:'session-a',owner:'salvador'};window.FridayOwnerSession={ensure:async()=>window.owner,current:()=>window.owner};</script><script type=module src=/bundle/consent.js></script></body></html>`));server=app.listen(0,'127.0.0.1');await new Promise<void>(r=>server.once('listening',r));browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});const page=await browser.newPage({viewport:{width:390,height:844}});const errors:string[]=[];page.on('pageerror',(e:any)=>errors.push(e.message));await page.goto('http://127.0.0.1:'+server.address().port);await page.waitForFunction(()=>(window as any).ready)
  const invoke=async(family=0,action='test')=>{await page.evaluate(({family,action})=>(window as any).invoke(family,action),{family,action});await page.locator('#fridayAdsAiConsent').waitFor()}
  const result=async()=>{await page.waitForFunction(()=>(window as any).lastResult!==null);return page.evaluate(()=>(window as any).lastResult)}
  const allow=async()=>{await page.locator('#adsConsentCheck').check();await page.locator('#adsConsentAllow').click()}
  for(let family=0;family<3;family++)await t.test('voice family '+family+' requires real local consent for each request; decline never invokes the data operation',async()=>{
   const before=await page.evaluate(()=>(window as any).privateCalls)
   await invoke(family);assert.equal(await page.locator('#adsConsentAllow').isDisabled(),true);assert.match(await page.locator('dialog').innerText(),/OpenAI/);assert.match(await page.locator('dialog').innerText(),/competition and bid/)
   await page.evaluate(()=>{document.getElementById('adsConsentAllow')!.dispatchEvent(new MouseEvent('click',{bubbles:true}))});assert.equal(await page.locator('dialog[open]').count(),1)
   await page.locator('#adsConsentDecline').click();const denied=await result();assert.equal(denied.status,'ai_sharing_declined');assert.ok(!JSON.stringify(denied).includes('PRIVATE-'));assert.equal(await page.evaluate(()=>(window as any).privateCalls),before)
   await page.locator('#manual').click();assert.match(await page.locator('#results').innerText(),/PRIVATE-ACCOUNT-FIXTURE/)
   await invoke(family);await allow();const accepted=await result();assert.equal(accepted.account.name,'PRIVATE-ACCOUNT-FIXTURE');assert.equal(await page.evaluate(()=>(window as any).privateCalls),before+1)
   await invoke(family);await page.keyboard.press('Escape');assert.equal((await result()).status,'ai_sharing_declined');assert.equal(await page.evaluate(()=>(window as any).privateCalls),before+1)
  })
  await t.test('model fields cannot grant consent or launch campaigns; ordinary approve events cannot accept the disclosure',async()=>{
   await invoke();await page.evaluate(()=>{document.dispatchEvent(new CustomEvent('friday-owner-approval',{detail:{approved:true}}));document.getElementById('adsConsentCheck')!.dispatchEvent(new Event('change'))});assert.equal(await page.locator('#adsConsentAllow').isDisabled(),true);await page.locator('#adsConsentDecline').click();await result()
   const invalid=await page.evaluate(()=>(window as any).tools[0].invoke({context:{}},JSON.stringify({action:'launch',approved:true,consent:true})));assert.match(String(invalid),/error|invalid|enum/i)
  })
  await t.test('another request cannot reuse a pending disclosure or consent',async()=>{
   await invoke();const other=await page.evaluate(()=>(window as any).tools[1].invoke({context:{}},JSON.stringify({action:'test',companyId:'company-a'})));assert.equal(other.status,'ai_sharing_busy');await page.locator('#adsConsentDecline').click();await result()
  })
  await t.test('owner changes cancel pending consent and suppress a previously allowed in-flight result',async()=>{
   const before=await page.evaluate(()=>(window as any).privateCalls);await invoke();await page.evaluate(()=>{(window as any).owner={id:'session-b',owner:'dayanna'};document.dispatchEvent(new CustomEvent('friday-owner-session-changed'))});assert.equal((await result()).status,'ai_sharing_declined');assert.equal(await page.locator('dialog').count(),0);assert.equal(await page.evaluate(()=>(window as any).privateCalls),before)
   await page.evaluate(()=>(window as any).held=true);await invoke();await allow();await page.waitForFunction(()=>(window as any).release!==null);await page.evaluate(()=>{(window as any).owner={id:'session-c',owner:'salvador'};document.dispatchEvent(new CustomEvent('friday-owner-session-changed'));(window as any).release();(window as any).release=null;(window as any).held=false});const changed=await result();assert.equal(changed.status,'context_changed');assert.ok(!JSON.stringify(changed).includes('PRIVATE-'))
  })
  await t.test('business changes invalidate consent before data access and suppress changed-context results',async()=>{
   const before=await page.evaluate(()=>(window as any).privateCalls);await invoke();await page.evaluate(()=>(document.getElementById('mkCompany') as HTMLSelectElement).value='company-b');await allow();assert.equal((await result()).status,'ai_sharing_declined');assert.equal(await page.evaluate(()=>(window as any).privateCalls),before)
   await page.selectOption('#mkCompany','company-a');await page.evaluate(()=>(window as any).held=true);await invoke();await allow();await page.waitForFunction(()=>(window as any).release!==null);await page.evaluate(()=>{(document.getElementById('mkCompany') as HTMLSelectElement).value='company-b';(window as any).release();(window as any).release=null;(window as any).held=false});assert.equal((await result()).status,'context_changed');await page.selectOption('#mkCompany','company-a')
  })
  await t.test('disclosure fits mobile, grants no persistent permission and needs a signed-in owner',async()=>{
   await invoke();assert.ok(await page.evaluate(()=>document.querySelector('dialog')!.getBoundingClientRect().width<=innerWidth));assert.equal(await page.evaluate(()=>localStorage.length),0);await page.locator('#adsConsentDecline').click();await result();await page.evaluate(()=>(window as any).owner=null);const denied=await page.evaluate(()=>(window as any).tools[0].invoke({context:{}},JSON.stringify({action:'test',companyId:'company-a'})));assert.equal(denied.status,'owner_required');assert.equal(await page.locator('dialog').count(),0);assert.deepEqual(errors,[])
  })
 }finally{await browser?.close();await new Promise<void>(r=>server?server.close(()=>r()):r());await rm(dir,{recursive:true,force:true})}
})
