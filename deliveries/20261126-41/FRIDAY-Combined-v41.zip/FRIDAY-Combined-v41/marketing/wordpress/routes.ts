import {wordpressService} from './service'
export function registerWordPressRoutes(app:any,pool:any,endpoint:any,deps:any={}){const service=wordpressService(pool,deps),base='/marketing/companies/:companyId/wordpress'
 app.get('/marketing/wordpress/status',endpoint(async(_q:any,r:any)=>r.json(await service.status())))
 app.post('/marketing/wordpress/initialize',endpoint(async(_q:any,r:any)=>r.json(await service.initialize())))
 app.get(base,endpoint(async(q:any,r:any)=>r.json(await service.list(q.params.companyId))))
 app.post(base,endpoint(async(q:any,r:any,o:string)=>r.json(await service.connect(o,q.params.companyId,q.body))))
 app.post(base+'/:siteId/test',endpoint(async(q:any,r:any)=>r.json(await service.test(q.params.companyId,q.params.siteId))))
 app.post(base+'/:siteId/disconnect',endpoint(async(q:any,r:any,o:string)=>r.json(await service.disconnect(o,q.params.companyId,q.params.siteId,q.body))))
 app.get(base+'/:siteId/content',endpoint(async(q:any,r:any)=>r.json(await service.contents(q.params.companyId,q.params.siteId,String(q.query.type||'pages'),Number(q.query.page||1),String(q.query.search||'')))))
 app.get(base+'/:siteId/item',endpoint(async(q:any,r:any)=>r.json(await service.item(q.params.companyId,q.params.siteId,String(q.query.type||'pages'),Number(q.query.id)))))
 app.post(base+'/:siteId/preview',endpoint(async(q:any,r:any,o:string)=>r.json(await service.preview(o,q.params.companyId,q.params.siteId,q.body))))
 app.get(base+'/:siteId/receipts',endpoint(async(q:any,r:any)=>r.json(await service.receipts(q.params.companyId,q.params.siteId))))
 const review='/marketing/companies/:companyId/wordpress-reviews/:id'
 app.get(review,endpoint(async(q:any,r:any)=>r.json(await service.receipt(q.params.companyId,q.params.id))))
 for(const action of ['execute','cancel','resolve'] as const)app.post(review+'/'+action,endpoint(async(q:any,r:any,o:string)=>r.json(await service[action](o,q.params.companyId,q.params.id,q.body))))
 app.post(review+'/verify',endpoint(async(q:any,r:any)=>r.json(await service.verify(q.params.companyId,q.params.id))))
 app.post(review+'/rollback',endpoint(async(q:any,r:any,o:string)=>r.json(await service.rollback(o,q.params.companyId,q.params.id))))
 return service
}
