import {z} from 'zod'
const text=(max=1000)=>z.string().trim().max(max)
const url=text(1000).refine(s=>{if(!s)return true;try{const u=new URL(s);return u.protocol==='https:'&&!u.username&&!u.password&&!u.search&&!u.hash}catch{return false}},'Use an HTTPS address without credentials, query or fragment.')
const money=z.string().regex(/^(0|[1-9]\d{0,7})\.\d{2}$/,'Use USD with two decimals, for example 500.00.')
export const profileSchema=z.object({
 name:text(160).min(1),relationship:z.enum(['internal','external']),industry:text(250),website:url,
 logoURL:url,colors:z.array(z.string().regex(/^#[a-fA-F0-9]{6}$/)).max(8),fonts:text(400),guidelines:text(4000),
 contactName:text(160),email:text(254).refine(v=>!v||/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v),'Enter an email address.'),phone:text(40),address:text(500),
 audience:text(2000),serviceArea:text(1000),services:text(3000),strategy:text(4000),brandVoice:text(2000),aiInstructions:text(4000),
 instagram:text(160),facebook:url,languages:z.array(z.enum(['en','es'])).min(1).max(2),timeZone:text(80).refine(s=>{try{new Intl.DateTimeFormat('en-US',{timeZone:s});return true}catch{return false}},'Choose a valid IANA time zone.'),
 monthlyAdBudgetUSD:money.nullable(),monthlyAIBudgetUSD:money.nullable(),automationMode:z.enum(['manual','semi_automatic']),publishingPaused:z.boolean(),
 postsPerWeek:z.number().int().min(0).max(35),reelsPerWeek:z.number().int().min(0).max(35),planningDays:z.number().int().min(7).max(14),
 customerStatus:z.enum(['lead','active','inactive']),marketingNotes:text(4000)
}).strict()
export type Profile=z.infer<typeof profileSchema>
export const blankProfile:Profile={name:'',relationship:'external',industry:'',website:'',logoURL:'',colors:[],fonts:'',guidelines:'',contactName:'',email:'',phone:'',address:'',audience:'',serviceArea:'',services:'',strategy:'',brandVoice:'',aiInstructions:'',instagram:'',facebook:'',languages:['en'],timeZone:'America/New_York',monthlyAdBudgetUSD:null,monthlyAIBudgetUSD:null,automationMode:'manual',publishingPaused:true,postsPerWeek:3,reelsPerWeek:2,planningDays:14,customerStatus:'active',marketingNotes:''}
export const newCompanySchema=z.object({requestId:z.uuid(),profile:profileSchema}).strict()
export const updateSchema=z.object({expectedRevision:z.number().int().nonnegative(),profile:profileSchema,active:z.boolean()}).strict()
export class MarketingError extends Error{constructor(message:string,public status=400){super(message)}}
export const companyId=(v:unknown)=>z.uuid().parse(v)
export const defaults:Profile[]=[
 {...blankProfile,name:'Nationwide Cleaning & Restoration Services Inc.',relationship:'internal',website:'https://www.nationwiderestore.com',instagram:'@nationwiderestore',phone:'1-800-914-0135',industry:'Cleaning and restoration',services:'Water damage, fire and smoke restoration, mold remediation, construction and emergency services',guidelines:'Protect homeowner identities, addresses, claim numbers and confidential project details. Generated footage must be labeled illustrative.'},
 {...blankProfile,name:'SaldanaShop',relationship:'internal',website:'https://www.saldana.shop',industry:'E-commerce and retail',colors:['#FF7F7F','#FFFFFF'],guidelines:'Coral pink and white; coral shade is a starting suggestion to confirm. Advertise only verified inventory and owner-approved promotions.'},
 {...blankProfile,name:'Carba Exotics',relationship:'internal',industry:'Vehicle rentals',services:'SUV and Ford Transit 15-passenger van rentals',serviceArea:'New York, New Jersey, Pennsylvania and Connecticut',guidelines:'Confirm vehicle availability and rates. Do not present generated vehicles as actual rental inventory.'},
 {...blankProfile,name:'AITAN Services Corp',relationship:'internal',industry:'Printing, design, marketing and advertising',services:'Commercial printing, business cards, flyers, brochures, graphic design, branding, digital marketing, social media management, advertising, websites, SEO, custom packaging and promotional products'}
]
export const capabilities={phase:1,customerLogin:false,externalPublishing:false,paidAds:false,aiGeneration:false,mediaLibrary:false,contentCalendar:false,integrations:['Meta','WordPress','Google Ads','Search Console','Analytics','Wheelbase Pro','4over'].map(provider=>({provider,status:provider==='Google Ads'?'read_only_connection_available':provider==='WordPress'?'connection_and_reviewed_content_available':'awaiting_integration',connected:false})),note:'Company/customer profiles and planning preferences only. Budgets do not authorize spending. Read-only Google Ads connection and private advertising drafts are available after explicit setup. No publishing worker is enabled.'}
