// A local, per-request disclosure gate. Never accept consent from model/tool arguments.
let busy=false,epoch=0
let dismiss:(()=>void)|null=null
if(typeof document!=='undefined')document.addEventListener('friday-owner-session-changed',()=>{epoch++;dismiss?.()})
const owner=()=>{const s=(window as any).FridayOwnerSession?.current();return s?.id&&s?.owner?String(s.id)+'\n'+String(s.owner):null}
const selectedCompany=()=>document.querySelector<HTMLSelectElement>('#mkCompany')?.value??''
const blocked=(status='ai_sharing_declined')=>({success:false,status,message:'No Google Ads tool results were shared by this request. Use Google Ads Manager directly in the dashboard. Do not automatically repeat this request or seek the same data through another tool.'})
export async function runGoogleAdsWithConsent(action:string,args:any,operation:()=>Promise<any>){
 if(busy)return blocked('ai_sharing_busy')
 busy=true
 try{
  await (window as any).FridayOwnerSession?.ensure()
  const session=owner(),generation=epoch,beforeCompany=selectedCompany(),company=args.companyId||beforeCompany
  if(!session)return blocked('owner_required')
  if(document.querySelector('dialog[open],[role=dialog][aria-modal=true]'))return blocked('finish_current_review')
  const allowed=await new Promise<boolean>(resolve=>{
   const dialog=document.createElement('dialog');dialog.id='fridayAdsAiConsent';dialog.setAttribute('aria-labelledby','adsConsentTitle');dialog.style.cssText='width:min(540px,calc(100vw - 40px));box-sizing:border-box;max-height:85dvh;overflow:auto;border:1px solid #b8cdc3;border-radius:14px;padding:24px;color:#23463c;background:white;font:15px/1.6 system-ui';
   dialog.innerHTML='<h2 id="adsConsentTitle">Share Ads information with OpenAI?</h2><p>FRIDAY uses OpenAI to understand and answer your advertising request. If you allow this request, its tool results may include Google Ads account IDs and names, currency and time zone, campaign plans, keywords, ad copy, proposed budgets and targeting, and Keyword Planner search-volume, competition and bid estimates.</p><p>Authorization tokens, developer tokens and client secrets are excluded from these tool results. This permission applies to this request only. It does not launch ads or authorize spending.</p><p id="adsConsentContext"></p><p>Decline to keep using Google Ads Manager directly in the dashboard. Declining does not disconnect Google or remove saved data. Information shared previously cannot be recalled by this choice.</p><label style="display:block;margin:16px 0"><input id="adsConsentCheck" type="checkbox"> I agree to send these results to OpenAI for this request.</label><div style="display:flex;flex-wrap:wrap;gap:12px"><button id="adsConsentDecline" type="button">Decline — use dashboard</button><button id="adsConsentAllow" type="button" disabled>Allow this request</button></div>'
   dialog.querySelector('#adsConsentContext')!.textContent='Requested action: '+action+' · Business workspace: '+(company||'select in dashboard')
   const check=dialog.querySelector<HTMLInputElement>('#adsConsentCheck')!,allow=dialog.querySelector<HTMLButtonElement>('#adsConsentAllow')!
   let settled=false
   const finish=(yes:boolean)=>{if(settled)return;settled=true;clearTimeout(timer);dismiss=null;dialog.remove();resolve(yes)}
   const timer=setTimeout(()=>finish(false),300000)
   dismiss=()=>finish(false)
   check.onchange=()=>{allow.disabled=!check.checked}
   allow.onclick=(event)=>{if(event.isTrusted&&check.checked)finish(true)}
   dialog.querySelector<HTMLButtonElement>('#adsConsentDecline')!.onclick=()=>finish(false)
   dialog.addEventListener('cancel',event=>{event.preventDefault();finish(false)})
   dialog.addEventListener('close',()=>finish(false))
   document.body.append(dialog)
   try{dialog.showModal();dialog.querySelector<HTMLButtonElement>('#adsConsentDecline')!.focus()}catch{finish(false)}
  })
  if(!allowed||epoch!==generation||owner()!==session||selectedCompany()!==beforeCompany)return blocked()
  const result=await operation()
  if(epoch!==generation||owner()!==session||(document.querySelector('#mkCompany')&&selectedCompany()!==company))return blocked('context_changed')
  return result
 }catch{return blocked('ai_sharing_failed')}finally{busy=false}
}
