import {e164,PhoneError,type Owner} from './core'
// Structured owner contact data stays in the existing private PostgreSQL database.
export function ownerContactStore(pool:any){
 let initialized:Promise<any>|null=null
 const owner=(value:Owner)=>{if(!['salvador','dayanna'].includes(value))throw new PhoneError('Owner not verified.',403);return value}
 async function ready(){if(!initialized)initialized=pool.query("CREATE TABLE IF NOT EXISTS friday_owner_contacts (owner TEXT PRIMARY KEY CHECK (owner IN ('salvador','dayanna')), phone TEXT NOT NULL, updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW())").catch(()=>{initialized=null;throw new PhoneError('Private contact database is unavailable. No phone number was saved.',503)});await initialized}
 return{
  async get(value:Owner){const key=owner(value);await ready();try{const r=await pool.query('SELECT phone, updated_at FROM friday_owner_contacts WHERE owner = $1',[key]);return{owner:key,phone:r.rows[0]?.phone||null,updatedAt:r.rows[0]?.updated_at||null}}catch{throw new PhoneError('Private contact database could not be read.',503)}},
  async save(value:Owner,phone:unknown){const key=owner(value),number=e164(phone);await ready();try{const r=await pool.query('INSERT INTO friday_owner_contacts (owner, phone) VALUES ($1, $2) ON CONFLICT (owner) DO UPDATE SET phone = EXCLUDED.phone, updated_at = NOW() RETURNING phone, updated_at',[key,number]);return{owner:key,phone:r.rows[0].phone,updatedAt:r.rows[0].updated_at}}catch{throw new PhoneError('Phone number could not be saved. Entry retained; check the private database.',503)}}
 }
}
