import twilio from 'twilio'
import {restaurantResearch} from './research'
import {resolveOwnerSession} from '../../auth/owner-session'
import {PhoneError} from './core'
import {appointmentService} from './service'
import {registerAppointmentMedia} from './realtime'
import {ownerContactStore} from './contacts'
export function registerAppointmentPhone(app:any,server:any,deps:any){
 const contacts=deps.contacts||(deps.pool?ownerContactStore(deps.pool):null),service=deps.service||appointmentService({...deps,contacts}),endpoint=(fn:any)=>async(req:any,res:any)=>{res.set('Cache-Control','no-store');const session=resolveOwnerSession(req);if(!session)return res.status(401).json({success:false,error:'Sign in to FRIDAY before using phone controls.'});try{res.json(await fn(req,session.owner))}catch(e:any){res.status(e instanceof PhoneError?e.status:400).json({success:false,error:e instanceof PhoneError?e.message:'Phone request could not be verified. No automatic dialing retry.'})}}
 app.get('/phone/appointments/contact',endpoint(async(_req:any,owner:any)=>{if(!contacts)throw new PhoneError('Private contact storage is not configured.',503);return{success:true,contact:await contacts.get(owner)}}))
 app.post('/phone/appointments/contact',endpoint(async(req:any,owner:any)=>{if(!contacts)throw new PhoneError('Private contact storage is not configured.',503);return{success:true,contact:await contacts.save(owner,req.body?.phone),message:'Your phone number was saved privately for this signed-in owner. No call was placed.'}}))
 app.get('/phone/appointments/status',endpoint(async()=>{try{const c=service.config();return{success:true,configured:true,callerNumber:c.from,liveConnectionTested:false,message:'Configuration present. No call or provider login test was performed.'}}catch(e:any){return{success:true,configured:false,liveConnectionTested:false,message:e.message}}}))
 app.get('/phone/appointments',endpoint((_req:any,owner:any)=>service.list(owner)))
 app.post('/phone/appointments/research',endpoint((req:any,owner:any)=>restaurantResearch(owner,req.body,deps)))
 app.post('/phone/appointments/prepare',endpoint((req:any,owner:any)=>service.prepare(owner,req.body)))
 app.post('/phone/appointments/:id/retry-review',endpoint((req:any,owner:any)=>service.prepareRetry(owner,req.params.id)))
 app.post('/phone/appointments/:id/approve',endpoint((req:any,owner:any)=>service.approve(owner,req.params.id,req.body?.approved)))
 app.post('/phone/appointments/:id/reject',endpoint((req:any,owner:any)=>service.reject(owner,req.params.id)))
 app.post('/phone/appointments/:id/receipt',endpoint((req:any,owner:any)=>service.receipt(owner,req.params.id)))
 app.post('/phone/appointments/:id/connect-owner',endpoint((req:any,owner:any)=>service.transfer(owner,req.params.id)))
 app.post('/phone/appointments/:id/stop',endpoint((req:any,owner:any)=>service.stop(owner,req.params.id)))
 app.post('/phone/appointments/:id/transcript',endpoint((req:any,owner:any)=>service.transcript(owner,req.params.id)))
 app.post('/phone/appointments/:id/transcript-enabled',endpoint((req:any,owner:any)=>service.setTranscriptEnabled(owner,req.params.id,req.body?.enabled)))
 app.post('/phone/appointments/:id/calendar-draft',endpoint((req:any,owner:any)=>service.calendarDraft(owner,req.params.id)))
 app.post('/phone/appointments/:id/calendar-link',endpoint((req:any,owner:any)=>service.linkCalendar(owner,req.params.id,req.body?.reviewId)))
 app.post('/phone/appointments/hooks/:id/:kind',async(req:any,res:any)=>{try{const c=service.config(),kind=req.params.kind;if(!['status','twiml','transfer-result','transfer-status'].includes(kind)||req.originalUrl!==req.path||!twilio.validateRequest(c.authToken,String(req.headers['x-twilio-signature']||''),c.base+req.path,req.body))return res.sendStatus(403);if(kind.startsWith('transfer-')){const j=await service.transferHook(req.params.id,req.body,kind);if(kind==='transfer-status')return res.sendStatus(204);const final=new twilio.twiml.VoiceResponse();final.say(j.transferStatus==='completed'?'Thank you. Goodbye.':'The person I am assisting is unavailable. They will need to follow up. Thank you.');final.hangup();return res.type('text/xml').send(final.toString())}const j=await service.hook(req.params.id,req.body,kind);if(kind==='status')return res.sendStatus(204);const response=new twilio.twiml.VoiceResponse();if(!j.stopRequestedAt&&!['ended','cancelled'].includes(j.status)){const stream=response.connect().stream({url:c.base.replace('https:','wss:')+'/phone/appointments/media/'+j.id});stream.parameter({name:'jobToken',value:j.mediaToken});await service.diagnose(j.id,'twiml_ready')}res.type('text/xml').send(response.toString())}catch{res.sendStatus(403)}})
 const media=registerAppointmentMedia(server,service,deps.media||{})
 return{service,media}
}
