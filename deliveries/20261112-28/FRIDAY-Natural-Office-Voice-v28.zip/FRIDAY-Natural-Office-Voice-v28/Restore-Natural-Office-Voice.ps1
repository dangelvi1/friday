$ErrorActionPreference = 'Stop'
$recordPath = Join-Path $PSScriptRoot 'restore-manifest.json'
if (!(Test-Path $recordPath)) { throw 'Run the backup-folder copy of this script with FRIDAY backend stopped.' }
$record = Get-Content $recordPath -Raw | ConvertFrom-Json
foreach ($relative in $record.files) {
  $target = Join-Path $record.projectPath $relative
  if (!(Test-Path $target) -or (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash -ne $record.packageSHA256.PSObject.Properties[$relative].Value) { throw "Installed file changed after update: $relative. Restore stopped before changing files." }
  $saved = Join-Path $PSScriptRoot $relative
  $baseline = $record.baselineSHA256.PSObject.Properties[$relative].Value
  if ($null -ne $baseline -and (!(Test-Path $saved) -or (Get-FileHash -LiteralPath $saved -Algorithm SHA256).Hash -ne $baseline)) { throw "Backup failed verification: $relative. No files changed." }
}
foreach ($relative in $record.files) {
  $target = Join-Path $record.projectPath $relative; $saved = Join-Path $PSScriptRoot $relative
  if (Test-Path $saved) { Copy-Item -LiteralPath $saved -Destination $target -Force }
  else { Remove-Item -LiteralPath $target }
}
Write-Host 'Verified application source restored. Build/restart both servers and hard-refresh.'
Write-Host 'Private calls, contacts, schedules, claims and chat/archive history remain. Returning to v27 restores the previous system voice for office calls. Rollback does not undo calls or restore deleted private data.'
Write-Host 'After ending all calls, generated voice cache files can be removed locally from credentials\friday-office-voice. v27 does not serve or clean that v28-only cache. It contains generated prompts, not recorded call audio.'
