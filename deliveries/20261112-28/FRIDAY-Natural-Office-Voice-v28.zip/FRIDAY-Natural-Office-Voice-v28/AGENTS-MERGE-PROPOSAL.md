# Proposed additions only — do not replace AGENTS.md

- Office reminders use the natural OpenAI Marin voice, preserving explicit Spanish/English selection and the exact approved message. Keep the original dashboard Realtime session and existing appointment voice intact.
- Prepare the greeting/message/repeat/goodbye audio before dialing. Generation failure must not silently fall back to the old system voice or redial. Preserve stop during generation, durable call/email claims, owner/company scope and the two-repeat cap.
- Generated speech is not a call recording. Keep it private, job-bound, unguessable, active-call-only and short-lived; clean it on completion/expiry while retaining call receipts. Never expose voice keys, provider keys, raw error bodies, generated URLs or private audio in public receipts/packages.
- The existing narrow office callback path also serves temporary audio using an expiring opaque token. POST webhooks still require verified Twilio signatures/call identity. Do not broaden Cloudflare bypass or weaken owner/device gates.
- Keep seven-day Chat retention and Archive behavior, private contacts/preferences, employee isolation and backups. Prove voice/routing behavior with mocked providers and disclose that actual phone sound quality still needs an own-phone test.
