// ============================================================
// SANDRA LIVE QUICKBOOKS BANK FEED — PHASE 1 (READ ONLY)
// FILE: S:\AI\friday-ai\quickbooks\live-bank-feed.ts
// PURPOSE:
// - Open QuickBooks Banking in a dedicated Chrome profile
// - Read live bank-feed balance, posted balance and Pending transactions
// - Never click Post / Match / Categorize / Exclude
// ============================================================

import type {
  Express,
} from 'express'

import {
  chromium,
  type BrowserContext,
  type Page,
} from 'playwright'


let qboContext:
  BrowserContext |
  null =
  null


const QBO_PROFILE =
  process.env
    .FRIDAY_QBO_BROWSER_PROFILE ||
  'S:\\AI\\friday-qbo-browser-profile'


async function getQboContext() {
  if (
    qboContext
  ) {
    try {
      qboContext.pages()
      return qboContext
    } catch {
      qboContext =
        null
    }
  }

  qboContext =
    await chromium
      .launchPersistentContext(
        QBO_PROFILE,
        {
          channel:
            'chrome',

          headless:
            false,

          viewport:
            null,
        }
      )

  qboContext.on(
    'close',
    () => {
      qboContext =
        null
    }
  )

  return qboContext
}


async function getQboPage() {
  const context =
    await getQboContext()

  const pages =
    context.pages()

  let page:
    Page

  if (
    pages.length
  ) {
    page =
      pages[
        pages.length -
        1
      ]
  } else {
    page =
      await context.newPage()
  }

  await page.bringToFront()
  return page
}


function parseMoney(
  value:
    string |
    null |
    undefined
) {
  const text =
    String(
      value ||
      ''
    )
      .replace(
        /,/g,
        ''
      )

  const match =
    text.match(
      /-?\$?\s*([0-9]+(?:\.[0-9]{1,2})?)/
    )

  if (
    !match
  ) {
    return null
  }

  const sign =
    text.includes(
      '-'
    )
      ? -1
      : 1

  const amount =
    Number(
      match[1]
    )

  if (
    !Number.isFinite(
      amount
    )
  ) {
    return null
  }

  return Number(
    (
      sign *
      amount
    )
      .toFixed(
        2
      )
  )
}


function normalizeText(
  value:
    string |
    null |
    undefined
) {
  return String(
    value ||
    ''
  )
    .replace(
      /\s+/g,
      ' '
    )
    .trim()
}


export async function ensureBankingPage(
  page:
    Page
) {
  const currentUrl =
    page.url()

  let bankingPage = false
  try {const url=new URL(currentUrl);bankingPage=['qbo.intuit.com','app.qbo.intuit.com'].includes(url.hostname) && ['/app/banking','/app/banktransactions'].includes(url.pathname.toLowerCase().replace(/\/$/,''))} catch {}
  if (!bankingPage) {
    await page.goto(
      'https://qbo.intuit.com/app/banking',
      {
        waitUntil:
          'domcontentloaded',

        timeout:
          45000,
      }
    )
  }

  await page.waitForTimeout(
    1500
  )
}


async function detectLoginRequired(
  page:
    Page
) {
  const url =
    page.url()
      .toLowerCase()

  if (
    url.includes(
      'accounts.intuit.com'
    ) ||
    url.includes(
      'signin'
    ) ||
    url.includes(
      'login'
    )
  ) {
    return true
  }

  const bodyText =
    normalizeText(
      await page
        .locator(
          'body'
        )
        .innerText()
        .catch(
          () =>
            ''
        )
    )
      .toLowerCase()

  return (
    bodyText.includes(
      'sign in to quickbooks'
    ) ||
    bodyText.includes(
      'sign in with'
    )
  )
}


async function findTopAccountCard(
  page:
    Page,
  accountName:
    string
) {
  const wanted =
    normalizeText(
      accountName
    )

  const wantedLower =
    wanted.toLowerCase()

  const candidates =
    page.locator(
      'div, section, article, li'
    )

  const count =
    await candidates.count()

  let best:
    any =
    null

  let bestText =
    ''

  let bestScore =
    -1

  for (
    let index =
      0;
    index <
      count;
    index +=
      1
  ) {
    const candidate =
      candidates.nth(
        index
      )

    if (
      !await candidate
        .isVisible()
        .catch(
          () =>
            false
        )
    ) {
      continue
    }

    const text =
      normalizeText(
        await candidate
          .innerText()
          .catch(
            () =>
              ''
          )
      )

    const lower =
      text.toLowerCase()

    if (
      !lower.includes(
        wantedLower
      )
    ) {
      continue
    }

    if (
      !lower.includes(
        'bank:'
      ) ||
      !lower.includes(
        'posted:'
      )
    ) {
      continue
    }

    const box =
      await candidate
        .boundingBox()
        .catch(
          () =>
            null
        )

    if (
      !box ||
      box.y >
        900
    ) {
      continue
    }

    let score =
      0

    if (
      lower.startsWith(
        wantedLower
      )
    ) {
      score +=
        60
    }

    if (
      text.length <
      220
    ) {
      score +=
        30
    }

    if (
      box.y <
      500
    ) {
      score +=
        30
    }

    if (
      score >
      bestScore
    ) {
      best =
        candidate

      bestText =
        text

      bestScore =
        score
    }
  }

  return {
    card:
      best,

    text:
      bestText ||
      null,
  }
}


async function getCurrentAccountButton(
  page:
    Page
) {
  const candidates = [
    page.locator(
      'button[aria-haspopup="listbox"]'
    ),

    page.locator(
      'button[aria-haspopup="menu"]'
    ),

    page.locator(
      '[role="combobox"]'
    ),

    page.locator(
      'button'
    ),
  ]

  const knownAccountPattern =
    /(BOFA|Chase|CHASE|TD Bank|CHECKING|CHK|QuickBooks).*(\d{3,4})/i

  let best:
    any =
    null

  let bestText:
    string |
    null =
    null

  let bestScore =
    -1

  for (
    const group
    of candidates
  ) {
    const count =
      await group.count()

    for (
      let index =
        0;
      index <
        count;
      index +=
        1
    ) {
      const control =
        group.nth(
          index
        )

      if (
        !await control
          .isVisible()
          .catch(
            () =>
              false
          )
      ) {
        continue
      }

      const box =
        await control
          .boundingBox()
          .catch(
            () =>
              null
          )

      if (
        !box ||
        box.y >
          900
      ) {
        continue
      }

      const controlText =
        normalizeText(
          await control
            .innerText()
            .catch(
              () =>
                ''
            )
        )

      const ariaLabel =
        normalizeText(
          await control
            .getAttribute(
              'aria-label'
            )
            .catch(
              () =>
                ''
            )
        )

      const title =
        normalizeText(
          await control
            .getAttribute(
              'title'
            )
            .catch(
              () =>
                ''
            )
        )

      const combined =
        normalizeText(
          `${controlText} ${ariaLabel} ${title}`
        )

      if (
        !combined ||
        /\b(Match|Categorize|Post|Exclude|Review)\b/i.test(
          combined
        )
      ) {
        continue
      }

      let score =
        0

      if (
        knownAccountPattern.test(
          combined
        )
      ) {
        score +=
          100
      }

      if (
        /bank account/i.test(
          combined
        )
      ) {
        score +=
          60
      }

      if (
        /select account/i.test(
          combined
        )
      ) {
        score +=
          50
      }

      if (
        box.y <
        500
      ) {
        score +=
          30
      }

      if (
        score >
      bestScore
      ) {
        best =
          control

        bestText =
          controlText ||
          ariaLabel ||
          title ||
          null

        bestScore =
          score
      }
    }
  }

  return {
    button:
      best,

    text:
      bestText,
  }
}


async function getActiveAccountName(
  page:
    Page
) {
  const current =
    await getCurrentAccountButton(
      page
    )

  if (
    current.text
  ) {
    return normalizeText(
      current.text
    )
  }

  return null
}


async function findAccountChoice(
  page:
    Page,
  accountName:
    string
) {
  const wanted =
    normalizeText(
      accountName
    )

  const escaped =
    wanted.replace(
      /[.*+?^${}()|[\]\\]/g,
      '\\$&'
    )

  const pattern =
    new RegExp(
      escaped,
      'i'
    )

  const roleCandidates = [
    page.getByRole(
      'option',
      {
        name:
          wanted,
        exact:
          true,
      }
    ),

    page.getByRole(
      'menuitem',
      {
        name:
          wanted,
        exact:
          true,
      }
    ),

    page.getByRole(
      'option',
      {
        name:
          pattern,
      }
    ),

    page.getByRole(
      'menuitem',
      {
        name:
          pattern,
      }
    ),

    page.locator(
      '[role="listbox"] button, [role="menu"] button, [role="dialog"] button'
    )
      .filter({
        hasText:
          wanted,
      }),
  ]

  for (
    const candidate
    of roleCandidates
  ) {
    const count =
      await candidate.count()

    for (
      let index =
        0;
      index <
        count;
      index +=
        1
    ) {
      const option =
        candidate.nth(
          index
        )

      if (
        await option
          .isVisible()
          .catch(
            () =>
              false
          )
      ) {
        return option
      }
    }
  }

  return null
}


async function verifyAccountByPageText(
  page:
    Page,
  accountName:
    string
) {
  const wanted =
    normalizeText(
      accountName
    )
      .toLowerCase()

  const bodyText =
    normalizeText(
      await page
        .locator(
          'body'
        )
        .innerText()
        .catch(
          () =>
            ''
        )
    )
      .toLowerCase()

  if (
    !wanted ||
    !bodyText.includes(
      wanted
    )
  ) {
    return false
  }

  // Require Banking context too, so matching text elsewhere on the page
  // does not count as account verification.
  const hasBankingContext =
    bodyText.includes(
      'bank:'
    ) &&
    bodyText.includes(
      'posted:'
    ) &&
    (
      bodyText.includes(
        'pending'
      ) ||
      bodyText.includes(
        'bank transactions'
      )
    )

  return hasBankingContext
}


async function selectAccountByName(
  page:
    Page,
  accountName:
    string
) {
  const wanted =
    normalizeText(
      accountName
    )

  if (
    !wanted
  ) {
    return {
      selected:
        false,

      matchedText:
        null,

      method:
        'manual-account-lock',
    }
  }

  const verifiedCard =
    await findTopAccountCard(
      page,
      wanted
    )

  if (
    verifiedCard.card
  ) {
    return {
      selected:
        true,

      matchedText:
        verifiedCard.text,

      method:
        'manual-account-lock-verified',
    }
  }

  const activeAccountName =
    await getActiveAccountName(
      page
    )

  if (
    activeAccountName &&
    normalizeText(
      activeAccountName
    )
      .toLowerCase()
      .includes(
        wanted.toLowerCase()
      )
  ) {
    return {
      selected:
        true,

      matchedText:
        activeAccountName,

      method:
        'manual-account-lock-selector-verified',
    }
  }

  const pageTextVerified =
    await verifyAccountByPageText(
      page,
      wanted
    )

  if (
    pageTextVerified
  ) {
    return {
      selected:
        true,

      matchedText:
        wanted,

      method:
        'manual-account-lock-page-text-verified',
    }
  }

  return {
    selected:
      false,

    matchedText:
      activeAccountName ||
      null,

    method:
      'manual-account-lock-mismatch',
  }
}



async function openPendingTab(
  page:
    Page
) {
  const selectedCandidates = [
    page.locator(
      '[role="tab"][aria-selected="true"]'
    ),

    page.locator(
      '[aria-current="page"]'
    ),
  ]

  for (
    const group
    of selectedCandidates
  ) {
    const count =
      await group.count()

    for (
      let index =
        0;
      index <
        count;
      index +=
        1
    ) {
      const item =
        group.nth(
          index
        )

      const text =
        normalizeText(
          await item
            .innerText()
            .catch(
              () =>
                ''
            )
        )

      if (
        /^Pending\b/i.test(
          text
        )
      ) {
        return true
      }
    }
  }

  // QuickBooks sometimes doesn't expose the selected Pending tab
  // through aria-selected. In strict read-only mode, accept visible
  // Pending text when the Banking transaction table is present.
  const bodyText =
    normalizeText(
      await page
        .locator(
          'body'
        )
        .innerText()
        .catch(
          () =>
            ''
        )
    )

  if (
    /Pending\s*\(\d+\)/i.test(
      bodyText
    ) &&
    /Bank description/i.test(
      bodyText
    )
  ) {
    return true
  }

  // Strict safety mode:
  // Sandra never clicks Pending, Match, Categorize, Post,
  // account cards, transaction rows, or transaction controls.
  // The user manually selects the account + Pending tab in QuickBooks.
  return false
}



async function extractAccountSummary(
  page:
    Page,
  accountName:
    string
) {
  const wanted =
    normalizeText(
      accountName
    )
      .toLowerCase()

  const candidates =
    page.locator(
      'div, section, article, li'
    )

  const count =
    await candidates.count()

  let bestText =
    ''

  let bestLength =
    Number.MAX_SAFE_INTEGER

  for (
    let index =
      0;
    index <
      count;
    index +=
      1
  ) {
    const candidate =
      candidates.nth(
        index
      )

    const text =
      normalizeText(
        await candidate
          .innerText()
          .catch(
            () =>
              ''
          )
      )

    if (
      !text
    ) {
      continue
    }

    const lower =
      text.toLowerCase()

    if (
      !lower.includes(
        wanted
      )
    ) {
      continue
    }

    if (
      !lower.includes(
        'bank:'
      ) ||
      !lower.includes(
        'posted:'
      )
    ) {
      continue
    }

    if (
      text.length <
      bestLength
    ) {
      bestText =
        text

      bestLength =
        text.length
    }
  }

  const bank =
    bestText.match(
      /Bank:\s*(-?\$[\d,]+(?:\.\d{2})?)/i
    )

  const posted =
    bestText.match(
      /Posted:\s*(-?\$[\d,]+(?:\.\d{2})?)/i
    )

  return {
    rawText:
      bestText,

    bankText:
      bank?.[1] ||
      null,

    postedText:
      posted?.[1] ||
      null,
  }
}



async function extractPendingCount(
  page:
    Page
) {
  const candidates = [
    /Pending\s*\((\d+)\)/i,
    /Pending\s+(\d+)/i,
  ]

  const body =
    normalizeText(
      await page
        .locator(
          'body'
        )
        .innerText()
        .catch(
          () =>
            ''
        )
    )

  for (
    const pattern
    of candidates
  ) {
    const match =
      body.match(
        pattern
      )

    if (
      match
    ) {
      return Number(
        match[1]
      )
    }
  }

  return null
}


async function getTableHeaders(
  page:
    Page
) {
  const headers =
    page.locator(
      'table thead th, [role="columnheader"]'
    )

  const count =
    await headers.count()

  const values:
    string[] =
    []

  for (
    let index =
      0;
    index <
      count;
    index +=
      1
  ) {
    const text =
      normalizeText(
        await headers
          .nth(
            index
          )
          .innerText()
          .catch(
            () =>
              ''
          )
      )

    values.push(
      text
    )
  }

  return values
}


function headerIndex(
  headers:
    string[],
  patterns:
    RegExp[]
) {
  return headers.findIndex(
    header =>
      patterns.some(
        pattern =>
          pattern.test(
            header
          )
      )
  )
}


async function extractVisibleRows(
  page:
    Page
) {
  const headers =
    await getTableHeaders(
      page
    )

  const dateIndex =
    headerIndex(
      headers,
      [
        /^Date$/i,
      ]
    )

  const descriptionIndex =
    headerIndex(
      headers,
      [
        /Bank description/i,
        /^Description$/i,
      ]
    )

  const spentIndex =
    headerIndex(
      headers,
      [
        /^Spent$/i,
        /Money out/i,
      ]
    )

  const receivedIndex =
    headerIndex(
      headers,
      [
        /^Received$/i,
        /Money in/i,
      ]
    )

  const fromToIndex =
    headerIndex(
      headers,
      [
        /From\s*\/\s*To/i,
        /^Payee$/i,
        /^Vendor$/i,
      ]
    )

  const categoryIndex =
    headerIndex(
      headers,
      [
        /Match\s*\/\s*Categorize/i,
        /Category/i,
      ]
    )

  const actionIndex =
    headerIndex(
      headers,
      [
        /^Action$/i,
        /^Status$/i,
      ]
    )

  const rowsLocator =
    page.locator(
      'table tbody tr, [role="row"]'
    )

  const count =
    await rowsLocator.count()

  const results:
    any[] =
    []

  const datePattern =
    /\b\d{1,2}\/\d{1,2}\/\d{4}\b/

  let bankingRowIndex =
    0

  for (
    let index =
      0;
    index <
      count;
    index +=
      1
  ) {
    const row =
      rowsLocator.nth(
        index
      )

    const rawText =
      normalizeText(
        await row
          .innerText()
          .catch(
            () =>
              ''
          )
      )

    if (
      !rawText ||
      !datePattern.test(
        rawText
      )
    ) {
      continue
    }

    const cellsLocator =
      row.locator(
        'td, [role="cell"], [role="gridcell"]'
      )

    const cellCount =
      await cellsLocator.count()

    const cells:
      string[] =
      []

    for (
      let cellIndex =
        0;
      cellIndex <
        cellCount;
      cellIndex +=
        1
    ) {
      cells.push(
        normalizeText(
          await cellsLocator
            .nth(
              cellIndex
            )
            .innerText()
            .catch(
              () =>
                ''
            )
        )
      )
    }

    const getCell =
      (
        columnIndex:
          number
      ) =>
        columnIndex >=
            0 &&
        columnIndex <
          cells.length
          ? cells[
              columnIndex
            ]
          : ''

    const date =
      getCell(
        dateIndex
      ) ||
      rawText.match(
        datePattern
      )?.[0] ||
      null

    const description =
      getCell(
        descriptionIndex
      ) ||
      null

    const spent =
      parseMoney(
        getCell(
          spentIndex
        )
      )

    const received =
      parseMoney(
        getCell(
          receivedIndex
        )
      )

    const fromTo =
      getCell(
        fromToIndex
      ) ||
      null

    let recommendation =
      getCell(
        categoryIndex
      ) ||
      null

    if (
      recommendation
    ) {
      recommendation =
        normalizeText(
          recommendation
            .replace(
              /\bMatch\b/gi,
              ''
            )
            .replace(
              /\bCategorize\b/gi,
              ''
            )
            .replace(
              /\bPost\b/gi,
              ''
            )
        ) ||
        null
    }

    const status =
      getCell(
        actionIndex
      ) ||
      (
        rawText.match(
          /\b(Post|Match|Categorize|Review|Excluded|Posted)\b/gi
        )
          ?.join(
            ' · '
          ) ||
        null
      )

    results.push({
      pageRowIndex:
        bankingRowIndex,

      date,
      description,
      spent,
      received,
      fromTo,
      recommendation,
      status,
      rawText,
      rawCells:
        cells,
    })

    bankingRowIndex +=
      1
  }

  return results
}



function parseTransactionDate(
  value:
    string |
    null |
    undefined
) {
  const text =
    String(
      value ||
      ''
    )
      .trim()

  const match =
    text.match(
      /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/
    )

  if (
    !match
  ) {
    return 0
  }

  const month =
    Number(
      match[1]
    )

  const day =
    Number(
      match[2]
    )

  const year =
    Number(
      match[3]
    )

  return Date.UTC(
    year,
    month -
      1,
    day
  )
}


async function getPageIndicator(
  page:
    Page
) {
  const body =
    normalizeText(
      await page
        .locator(
          'body'
        )
        .innerText()
        .catch(
          () =>
            ''
        )
    )

  const range =
    body.match(
      /\b(\d+)\s*-\s*(\d+)\s+of\s+(\d+)\b/i
    )

  const pageCount =
    body.match(
      /\bPage\s+(\d+)\s+of\s+(\d+)\b/i
    )

  return {
    rangeStart:
      range
        ? Number(
            range[1]
          )
        : null,

    rangeEnd:
      range
        ? Number(
            range[2]
          )
        : null,

    total:
      range
        ? Number(
            range[3]
          )
        : null,

    page:
      pageCount
        ? Number(
            pageCount[1]
          )
        : null,

    pages:
      pageCount
        ? Number(
            pageCount[2]
          )
        : null,

    raw:
      range?.[0] ||
      pageCount?.[0] ||
      null,
  }
}


async function findPaginatorInput(
  page:
    Page
) {
  const inputs =
    page.locator(
      'input'
    )

  const count =
    await inputs.count()

  for (
    let index =
      0;
    index <
      count;
    index +=
      1
  ) {
    const input =
      inputs.nth(
        index
      )

    if (
      !await input
        .isVisible()
        .catch(
          () =>
            false
        )
    ) {
      continue
    }

    const box =
      await input
        .boundingBox()
        .catch(
          () =>
            null
        )

    if (
      !box
    ) {
      continue
    }

    const value =
      normalizeText(
        await input
          .inputValue()
          .catch(
            () =>
              ''
          )
      )

    const aria =
      normalizeText(
        await input
          .getAttribute(
            'aria-label'
          )
          .catch(
            () =>
              ''
          )
      )

    const title =
      normalizeText(
        await input
          .getAttribute(
            'title'
          )
          .catch(
            () =>
              ''
          )
      )

    const placeholder =
      normalizeText(
        await input
          .getAttribute(
            'placeholder'
          )
          .catch(
            () =>
              ''
          )
      )

    const nearbyText =
      normalizeText(
        await input
          .locator(
            'xpath=..'
          )
          .innerText()
          .catch(
            () =>
              ''
          )
      )

    const combined =
      normalizeText(
        `${aria} ${title} ${placeholder} ${nearbyText}`
      )

    if (
      /\bPage\b/i.test(
        combined
      ) &&
      /\bof\s+\d+\b/i.test(
        combined
      )
    ) {
      return input
    }

    if (
      /^\d+$/.test(
        value
      ) &&
      /\bpage\b/i.test(
        combined
      )
    ) {
      return input
    }
  }

  return null
}


async function goToPageNumber(
  page:
    Page,
  targetPage:
    number,
  beforeIndicator:
    string |
    null
) {
  const paginatorInput =
    await findPaginatorInput(
      page
    )

  if (
    !paginatorInput
  ) {
    return false
  }

  await paginatorInput.click({
    timeout:
      5000,
  })

  await paginatorInput.fill(
    String(
      targetPage
    )
  )

  await paginatorInput.press(
    'Enter'
  )

  const startedAt =
    Date.now()

  while (
    Date.now() -
      startedAt <
    12000
  ) {
    await page.waitForTimeout(
      400
    )

    const after =
      await getPageIndicator(
        page
      )

    if (
      (
        after.page ===
          targetPage
      ) ||
      (
        after.raw &&
        after.raw !==
          beforeIndicator
      )
    ) {
      await page.waitForTimeout(
        700
      )

      return true
    }
  }

  return false
}


async function clickNextPage(
  page:
    Page,
  beforeIndicator:
    string |
    null,
  nextPageNumber:
    number |
    null
) {
  // Preferred method: type the exact target page into QuickBooks'
  // pagination input ("Page X of Y"). This is scoped to the paginator
  // and cannot click Match/Categorize transaction controls.
  if (
    nextPageNumber !==
    null
  ) {
    const movedByInput =
      await goToPageNumber(
        page,
        nextPageNumber,
        beforeIndicator
      )

    if (
      movedByInput
    ) {
      return true
    }
  }

  // Safe fallback: exact pagination controls only.
  const nextCandidates = [
    page.locator(
      'button[aria-label="Next page"]'
    ),

    page.locator(
      'button[aria-label="Go to next page"]'
    ),

    page.locator(
      'button[title="Next page"]'
    ),

    page.getByRole(
      'button',
      {
        name:
          /^Next page$/i,
      }
    ),
  ]

  let nextButton:
    any =
    null

  for (
    const group
    of nextCandidates
  ) {
    const count =
      await group.count()

    for (
      let index =
        0;
      index <
        count;
      index +=
        1
    ) {
      const candidate =
        group.nth(
          index
        )

      if (
        await candidate
          .isVisible()
          .catch(
            () =>
              false
          )
      ) {
        nextButton =
          candidate

        break
      }
    }

    if (
      nextButton
    ) {
      break
    }
  }

  if (
    !nextButton
  ) {
    return false
  }

  if (
    await nextButton
      .isDisabled()
      .catch(
        () =>
          false
      )
  ) {
    return false
  }

  await nextButton.click({
    timeout:
      5000,
  })

  const startedAt =
    Date.now()

  while (
    Date.now() -
      startedAt <
    10000
  ) {
    await page.waitForTimeout(
      400
    )

    const after =
      await getPageIndicator(
        page
      )

    if (
      after.raw &&
      after.raw !==
        beforeIndicator
    ) {
      await page.waitForTimeout(
        600
      )

      return true
    }
  }

  return false
}



export async function extractAllPendingTransactions(
  page:
    Page,
  maxRows:
    number
) {
  const first = await getPageIndicator(page)
  if ((first.page !== null && first.page > 1) || (first.rangeStart !== null && first.rangeStart > 1)) {
    if (!await goToPageNumber(page,1,first.raw)) throw new Error('Could not return to page 1. In QuickBooks, select page 1 and read again; no partial feed was accepted.')
    const reset=await getPageIndicator(page)
    if (reset.page !== 1 && reset.rangeStart !== 1) throw new Error('Page 1 could not be verified. No partial feed was accepted.')
  }
  const seenPages=new Set<string>()
  const byOrdinal =
    new Map<
      number,
      any
    >()

  const pageDiagnostics:
    any[] =
    []

  const maxPages =
    100

  for (
    let pageLoop =
      0;
    pageLoop <
      maxPages;
    pageLoop +=
      1
  ) {
    const indicator =
      await getPageIndicator(
        page
      )

    await page.waitForTimeout(
      600
    )

    const rows =
      await extractVisibleRows(
        page
      )

    const signature=JSON.stringify([indicator.raw,rows.map((row:any)=>[row.date,row.description,row.spent,row.received,row.fromTo])])
    if(seenPages.has(signature))throw new Error('QuickBooks repeated a page. The feed is incomplete; no duplicate page was accepted.')
    seenPages.add(signature)
    const rangeStart =
      indicator.rangeStart ??
      (
        pageLoop *
        50 +
        1
      )

    for (
      const row
      of rows
    ) {
      const ordinal =
        rangeStart +
        Number(
          row.pageRowIndex ||
          0
        )

      byOrdinal.set(
        ordinal,
        {
          ...row,
          sourceOrdinal:
            ordinal,
        }
      )
    }

    pageDiagnostics.push({
      page:
        indicator.page ??
        pageLoop +
          1,

      pages:
        indicator.pages,

      rangeStart:
        indicator.rangeStart,

      rangeEnd:
        indicator.rangeEnd,

      total:
        indicator.total,

      rowsDetected:
        rows.length,

      collectedSoFar:
        byOrdinal.size,
    })

    if (
      byOrdinal.size >=
      maxRows
    ) {
      break
    }

    if (
      indicator.total !==
        null &&
      byOrdinal.size >=
        indicator.total
    ) {
      break
    }

    if (
      indicator.page !==
        null &&
      indicator.pages !==
        null &&
      indicator.page >=
        indicator.pages
    ) {
      break
    }

    const nextPageNumber =
      indicator.page !==
        null
        ? indicator.page +
          1
        : (
            pageLoop +
            2
          )

    const moved =
      await clickNextPage(
        page,
        indicator.raw,
        nextPageNumber
      )

    if (
      !moved
    ) {
      break
    }
  }

  const transactions =
    Array.from(
      byOrdinal.values()
    )
      .sort(
        (
          a,
          b
        ) => {
          const dateDiff =
            parseTransactionDate(
              b.date
            ) -
            parseTransactionDate(
              a.date
            )

          if (
            dateDiff !==
            0
          ) {
            return dateDiff
          }

          return (
            Number(
              a.sourceOrdinal ||
              0
            ) -
            Number(
              b.sourceOrdinal ||
              0
            )
          )
        }
      )
      .slice(
        0,
        maxRows
      )

  return {
    transactions,
    pageDiagnostics,
  }
}



export function registerQuickBooksLiveBankFeed(
  app:
    Express
) {

  app.get(
    '/quickbooks/live-bank-feed/:companyKey',
    async (
      req,
      res
    ) => {
      let stage =
        'start'

      try {
        stage =
          'validate-request'

        const companyKey =
          String(
            req.params.companyKey ||
            ''
          )
            .trim()
            .toLowerCase()

        const accountName =
          normalizeText(
            String(
              req.query.accountName ||
              ''
            )
          )

        const maxRows =
          Math.max(
            1,
            Math.min(
              5000,
              Number(
                req.query.maxRows ||
                1000
              ) ||
              1000
            )
          )

        if (
          companyKey !==
          'nationwide'
        ) {
          return res
            .status(400)
            .json({
              success:
                false,

              error:
                'Phase 1 live bank-feed bridge is limited to Nationwide while read-only testing is completed.',
            })
        }

        if (
          !accountName
        ) {
          return res
            .status(400)
            .json({
              success:
                false,

              error:
                'accountName is required.',
            })
        }

        stage =
          'open-browser'

        const page =
          await getQboPage()

        stage =
          'open-banking-page'

        await ensureBankingPage(
          page
        )

        if (
          await detectLoginRequired(
            page
          )
        ) {
          return res.json({
            success:
              false,

            loginRequired:
              true,

            readOnly:
              true,

            currentUrl:
              page.url(),

            message:
              'QuickBooks sign-in is required in the Sandra banking browser window. Sign in once, then run Live Feed again.',
          })
        }

        stage =
          'select-account'

        const selection =
          await selectAccountByName(
            page,
            accountName
          )

        stage =
          'verify-account'

        const activeAccountName =
          await getActiveAccountName(
            page
          )

        const normalizedWanted =
          normalizeText(
            accountName
          )
            .toLowerCase()

        const normalizedActive =
          normalizeText(
            activeAccountName
          )
            .toLowerCase()

        const verifiedCard =
          await findTopAccountCard(
            page,
            accountName
          )

        const selectorVerified =
          Boolean(
            normalizedActive &&
            normalizedActive.includes(
              normalizedWanted
            )
          )

        const cardVerified =
          Boolean(
            verifiedCard.card
          )

        if (
          !selection.selected ||
          (
            !selectorVerified &&
            !cardVerified
          )
        ) {
          return res
            .status(409)
            .json({
              success:
                false,

              readOnly:
                true,

              accountMismatch:
                true,

              requestedAccount:
                accountName,

              detectedActiveAccount:
                activeAccountName,

              matchedCardText:
                selection.matchedText,

              verifiedAccountCardText:
                verifiedCard.text,

              stage,

              message:
                `Sandra is in strict manual-account mode. In QuickBooks Banking, manually select "${accountName}" and make sure the Pending tab is open, then run Read Live Feed again. Sandra will not click account cards or transaction controls.`,
            })
        }

        stage =
          'verify-pending-tab'

        const pendingSelected =
          await openPendingTab(
            page
          )

        if (
          !pendingSelected
        ) {
          return res
            .status(409)
            .json({
              success:
                false,

              readOnly:
                true,

              manualActionRequired:
                true,

              stage,

              requestedAccount:
                accountName,

              message:
                'Sandra is in strict manual-account mode. In QuickBooks Banking, manually open the requested account and the Pending tab, then click Read Live Feed again.',
            })
        }

        stage =
          'read-balances'

        const summary =
          await extractAccountSummary(
            page,
            accountName
          )

        stage =
          'read-pending-count'

        const pendingCount =
          await extractPendingCount(
            page
          )

        stage =
          'read-transactions'

        const extraction =
          await extractAllPendingTransactions(
            page,
            maxRows
          )

        stage =
          'complete'

        const transactions =
          extraction.transactions

        const bankBalance =
          parseMoney(
            summary.bankText
          )

        const postedBalance =
          parseMoney(
            summary.postedText
          )

        const difference =
          (
            bankBalance !==
              null &&
            postedBalance !==
              null
          )
            ? Number(
                (
                  bankBalance -
                  postedBalance
                )
                  .toFixed(
                    2
                  )
              )
            : null

        res.json({
          success:
            true,

          readOnly:
            true,

          companyKey,

          accountName,

          selectedAccountByText:
            selection.selected,

          accountSelectionMethod:
            selection.method,

          activeAccountName,

          source:
            'quickbooks-live-bank-feed-browser',

          safetyMode:
            'strict-manual-account-read-only',

          currentUrl:
            page.url(),

          balances: {
            bankBalance,

            postedBalance,

            difference,
          },

          pendingCount,

          returnedTransactionCount:
            transactions.length,

          maxRows,

          transactions,

          diagnostics: {
            accountCardText:
              summary.rawText ||
              null,

            pageDiagnostics:
              extraction.pageDiagnostics,

            complete:
              pendingCount !==
                null
                ? transactions.length >=
                  pendingCount
                : null,
          },
        })
      } catch (
        error:
          any
      ) {
        console.error(
          'QUICKBOOKS LIVE BANK FEED ERROR:',
          error
        )

        res
          .status(500)
          .json({
            success:
              false,

            readOnly:
              true,

            stage,

            error:
              error?.message ||
              'Could not read the QuickBooks live bank feed.',
          })
      }
    }
  )
}
