# FRIDAY Live Bank Feed fix — 20261014-4

For the confirmed Bank Review v3 installation on Salvador's existing PC at `S:\AI\friday-ai`.

The earlier update made the Accounting API's posted activity the default Banking view and put the existing Chrome reader in a collapsed section. That changed the expected workflow. Zero posted API records does not prove that the bank statement or native bank feed has no transactions.

This fix restores a prominent **Read QuickBooks browser feed** button and an immediately visible **QuickBooks browser feed** tab. It uses the existing dedicated Sandra Chrome profile, brings its window forward and returns from invoice/other pages to the actual QuickBooks Banking page. The backend starts at page 1 even if the previous read left Chrome on the last page, reads available Pending pages and rejects a repeating page with unchanged evidence. The selected month is applied AFTER reading the available pages; repeated transactions and source ordinals are preserved. Unreadable dates are retained separately for manual review. Limits remain 5,000 rows / 100 pages; known incomplete counts stay explicitly incomplete.

The API view remains available under **Read Posted Activity** and **Posted activity (API)**. Month/account read-navigation no longer silently forces it as the default view. Account cards say **Not read yet**, rather than incorrectly declaring the bank disconnected; after a successful scoped browser read the selected card shows the actual current bank balance and read count. These are CURRENT balances, not the selected month's historical statement balances. Account/month changes clear old read results. The response company/account/count must match before rows are displayed; the existing browser profile is for Nationwide Production.

The native reader still reads the **Pending** view. Transactions already posted/categorized may not remain in Pending. This is not a statement import, PDF OCR, official reconciliation or a financial write. Native account/company/tab selection stays manual, and no Post, Match, Categorize, Exclude or Undo controls are clicked. Browser count/selector verification must succeed; do not infer a particular real August row exists from a synthetic test. The uploaded real statement and extracted private text are not in this package or GitHub.

## Install

Stop FRIDAY's backend. Extract the ZIP under `S:\AI\Fixing-Files-Folder\FRIDAY-Live-Bank-Feed-Fix-v4`. Run from any PowerShell directory:

```powershell
$packageRoot = 'S:\AI\Fixing-Files-Folder\FRIDAY-Live-Bank-Feed-Fix-v4'
$installers = @(Get-ChildItem -LiteralPath $packageRoot -Filter 'Install-Live-Bank-Feed.ps1' -File -Recurse -ErrorAction Stop)
if ($installers.Count -ne 1) { throw 'Expected exactly one v4 installer.' }
$installer = $installers[0].FullName
Unblock-File -LiteralPath $installer
Unblock-File -LiteralPath (Join-Path (Split-Path $installer) 'Restore-Live-Bank-Feed.ps1')
& $installer -ProjectPath 'S:\AI\friday-ai'
```

The installer verifies v3 baselines/package hashes, backs up and verifies each existing changed file, then copies only its listed files. It rejects local edits instead of overwriting them. No .env, credentials, OAuth connections, certificates, database, uploaded statement, biometric file or AGENTS.md is replaced. There are no new runtime dependencies or accounting writes.

Rebuild your normal frontend public-file output and restart:

```powershell
Set-Location -LiteralPath 'S:\AI\friday-ai'
npm run build
npm run server
```

Hard-refresh the dashboard with Ctrl+F5 and reopen the conversational dashboard tab if it was already open.

## August test

1. Select Nationwide Production, BOFA CONSTRUCTION - 7015 and August 2026.
2. Click **Read QuickBooks browser feed**. Your existing Sandra Chrome window should open/come forward.
3. If prompted, sign in yourself. In that Chrome window verify Nationwide, select BOFA CONSTRUCTION - 7015 and the Pending tab, then click Read again in FRIDAY. Existing account mismatch or login messages must be resolved there; this fix does not invent private configuration or switch unrelated accounts.
4. Watch pagination, then check the total read count and the count shown for `2026-08`. Known incomplete results must say incomplete. The source reads all available Pending months before displaying August; it does not write or change transaction dates.
5. If the Pending read is complete but shows no August rows, verify whether those August rows are already categorized/posted in native QuickBooks. Pending availability and statement history are different. The real API zero-row cause cannot be proven from the FRIDAY screenshot alone.

## Validation and restore

Synthetic tests exercise actual Chromium pagination starting from the last page, page-one failure, repeated-page rejection, partial limits, preservation of repeated transactions, exact month/date validation, invoice-to-Banking navigation, restored button/default tab, company/account/count binding, August-only display, current balance cards, stale-account clearing and login feedback. The prior banking, invoice, owner approval, voice and Document Analysis regressions are also run. TypeScript and JavaScript syntax checks pass. Actual Windows installation, saved Chrome profile/login, current native QuickBooks selectors, OAuth and real August rows remain owner-PC checks; no live account was contacted here.

For rollback, stop FRIDAY and run Restore-Live-Bank-Feed.ps1 from the exact printed `backups\live-bank-feed-v4-...` directory. Restore verifies backup/installed hashes and refuses later edits. Private data and all v3 financial approval features remain; rollback restores the previous hidden/default-view behavior.
