// START [QUICKBOOKS-DASH-25] Paired conversational voice navigation with existing visible cursor
(() => {
 const room=new URLSearchParams(location.hash.slice(1)).get('friday-voice')
 if(!room||!/^[a-f0-9-]{36}$/.test(room))return
 history.replaceState(null,'',location.pathname+location.search)
 const channel=new BroadcastChannel('friday-qb-'+room),peer=crypto.randomUUID()
 let busy=false,epoch=0
 const done=new Map(),seen=new Set()
 const visible=e=>!!e && !!(e.offsetWidth||e.offsetHeight||e.getClientRects().length) && getComputedStyle(e).visibility!=='hidden'
 const company=()=>fridayQuickBooksState.companyKey
 const clean=t=>String(t||'').replace(/\s+/g,' ').trim()
 function state(){
  const root=document.querySelector('.workspace-view.active'),text=clean(root?.innerText||'')
  const elements=Array.from(document.querySelectorAll('[id]')).filter(e=>visible(e)&&e.type!=='password'&&!/ownerkey|credential|secret/i.test(e.id)).slice(0,100).map(e=>({id:e.id,tag:e.tagName,label:clean(e.innerText||e.getAttribute('aria-label')||'').slice(0,100)}))
  const rows=Array.from(document.querySelectorAll('#invoiceTableBody tr, #customer360InvoiceBody tr')).filter(visible).slice(0,100).map(e=>({text:clean(e.innerText).slice(0,400),invoiceId:e.dataset.fridayVoiceInvoiceId || (e.getAttribute('onclick')||e.querySelector('[onclick]')?.getAttribute('onclick')||'').match(/fridayOpenInvoiceDetail\(\s*['"]?(\d+)/)?.[1]||null}))
  return {companyKey:company(),companyName:fridayQuickBooksState.companyName,environment:fridayQuickBooksState.environment,page:fridayQuickBooksState.currentPage,visibleText:text.slice(0,12000),truncated:text.length>12000||document.querySelectorAll('#invoiceTableBody tr, #customer360InvoiceBody tr').length>100,elements,invoiceRows:rows,customerRows:Array.from(document.querySelectorAll('#customerTableBody [data-friday-voice-customer-id]')).filter(visible).slice(0,100).map(e=>({customerId:e.dataset.fridayVoiceCustomerId,text:clean(e.innerText).slice(0,300)})),bankAccounts:Array.from(document.getElementById('bankingAccountSelector')?.options||[]).filter(e=>e.value).map(e=>({id:e.value,name:e.textContent})),readOnly:true,executable:false}
 }
 // Preserve existing row handlers; expose their actual IDs for read-only voice selection.
 if(typeof renderInvoices==='function'){
  const original=renderInvoices
  renderInvoices=function(data){const result=original(data);const rows=document.querySelectorAll('#invoiceTableBody tr, #customer360InvoiceBody tr');(data?.invoices||[]).forEach((invoice,index)=>{if(rows[index]&&/^\d+$/.test(String(invoice.id)))rows[index].dataset.fridayVoiceInvoiceId=String(invoice.id)});return result}
 }
 function ready(){channel.postMessage({kind:'ready',peer})}
 async function point(e){if(!visible(e))throw Error('Element is not visible. Inspect the current page first.');e.scrollIntoView({block:'center',behavior:'instant'});await fridayPointTo(e,350)}
 async function execute(m){
  if(m.action==='get_state')return{success:true,...state()}
  if(m.companyKey!==company()||!m.companyKey)throw Error('Selected company differs from the request. Inspect and confirm the selected company first.')
  const value=String(m.value||'');if(value.length>200)throw Error('Value too long.')
  const before=company(),ticket=epoch
  if(m.action==='navigate'){
   if(!['dashboard','transactions','customers','sales','expenses','collections','banking','statements','reports','chart-of-accounts','reconciliation','document-analysis'].includes(value))throw Error('Only read-only dashboard sections are allowed.')
   const e=Array.from(document.querySelectorAll('[data-page]')).find(e=>e.dataset.page===value&&visible(e));if(e)await point(e)
   if(ticket!==epoch)throw Error('Stopped.')
   await fridayOpenDashboardPage(value)
  }else if(m.action==='search_invoices'){
   await fridayOpenDashboardPage('sales');if(ticket!==epoch)throw Error('Stopped.')
   const field=document.getElementById('invoiceCustomerSearch');await point(field);if(ticket!==epoch)throw Error('Stopped.')
   field.value=value;const ok=await loadInvoices();if(ok===false)throw Error('Invoice search did not complete.')
  }else if(m.action==='search_customers'){
   await fridayOpenDashboardPage('customers');if(ticket!==epoch)throw Error('Stopped.')
   const field=document.getElementById('customerSearchInput');await point(field);if(ticket!==epoch)throw Error('Stopped.');field.value=value;await searchCustomers()
  }else if(m.action==='open_customer'){
   const row=Array.from(document.querySelectorAll('#customerTableBody [data-friday-voice-customer-id]')).find(e=>visible(e)&&e.dataset.fridayVoiceCustomerId===value)
   if(!row)throw Error('Use a customer ID from the visible search results.');await point(row);if(ticket!==epoch)throw Error('Stopped.');await window.fridayOpenVisibleCustomer(value)
  }else if(m.action==='search_accounts'){
   await fridayOpenDashboardPage('chart-of-accounts');if(ticket!==epoch)throw Error('Stopped.');const field=document.getElementById('chartAccountSearch');await point(field);if(ticket!==epoch)throw Error('Stopped.');field.value=value;fridayRenderChartOfAccounts()
  }else if(m.action==='select_bank_account'){
   await fridayOpenDashboardPage('banking');if(ticket!==epoch)throw Error('Stopped.');const field=document.getElementById('bankingAccountSelector');await point(field);if(ticket!==epoch)throw Error('Stopped.')
   const choices=Array.from(field.options).filter(o=>o.value&&(o.value===value||clean(o.textContent).toLowerCase().includes(value.toLowerCase())))
   if(!value||choices.length!==1)throw Error('Account is missing or ambiguous. Inspect bankAccounts and use its actual ID.')
   field.value=choices[0].value;field.dispatchEvent(new Event('change'));await window.sandraBankingApi.openReview()
  }else if(m.action==='set_month'){
   if(!/^\d{4}-(0[1-9]|1[0-2])$/.test(value))throw Error('Month must be YYYY-MM.')
   const ids={dashboard:'dashboardMonth',expenses:'expenseMonth',banking:'bankingMonth',reports:'reportMonth'},field=document.getElementById(ids[fridayQuickBooksState.currentPage])
   await point(field);if(ticket!==epoch)throw Error('Stopped.');field.value=value;field.dispatchEvent(new Event('change'))
   if(fridayQuickBooksState.currentPage==='banking')await window.sandraBankingApi.openReview()
   else if(fridayQuickBooksState.currentPage==='expenses')await loadExpenses()
   else if(fridayQuickBooksState.currentPage==='reports')await loadMonthlyReport()
  }else if(['search_claim','search_job','search_carrier'].includes(m.action)){
   const result=window.fridaySearchInvoiceDetails(value,m.action==='search_claim'?'claim':m.action==='search_job'?'job':'carrier');return{success:true,...state(),detailSearch:result}
  }else if(m.action==='open_invoice'){
   if(!/^\d{1,20}$/.test(value))throw Error('Use the internal invoice ID from dashboard data.')
   if(!state().invoiceRows.some(r=>r.invoiceId===value))throw Error('That invoice ID is not among the visible invoice rows. Inspect/search first; do not guess an ID.')
   await point(document.querySelector('[data-friday-voice-invoice-id="'+value+'"]') || document.getElementById('invoiceTableBody'));if(ticket!==epoch)throw Error('Stopped.')
   const ok=await window.fridayOpenInvoiceDetail(value);if(ok===false)throw Error('Invoice detail did not open.')
   await point(document.getElementById('invoiceDetailPanel'))
  }else if(m.action==='point'){
   if(/ownerkey|credential|secret/i.test(value))throw Error('Credential fields are not available to voice tools.')
   const e=document.getElementById(value);if(e?.type==='password')throw Error('Credential fields are unavailable.');await point(e)
  }else if(m.action==='scroll'){
   if(!['up','down','top','bottom'].includes(value))throw Error('Scroll must be up, down, top or bottom.')
   const candidates=Array.from(document.querySelectorAll('.workspace-view.active .data-table-wrap')).filter(visible)
   const target=candidates.find(e=>e.scrollHeight>e.clientHeight+10)
   if(target)target.scrollTo({top:value==='top'?0:value==='bottom'?target.scrollHeight:target.scrollTop+(value==='up'?-1:1)*target.clientHeight*.8,behavior:'instant'})
   else window.scrollTo({top:value==='top'?0:value==='bottom'?document.documentElement.scrollHeight:scrollY+(value==='up'?-1:1)*innerHeight*.8,behavior:'instant'})
  }else throw Error('Unsupported action. Voice navigation cannot change QuickBooks data.')
  if(ticket!==epoch)throw Error('Stopped; inspect current state before continuing.')
  if(before!==company())throw Error('Company changed; result discarded. Inspect again.')
  return{success:true,...state()}
 }
 channel.onmessage=async event=>{
  const m=event.data;if(m?.kind==='hello'){ready();return}
  if(m?.kind!=='command'||m.peer!==peer||typeof m.id!=='string')return
  const reply=result=>channel.postMessage({kind:'result',peer,id:m.id,result})
  if(done.has(m.id)){reply(done.get(m.id));return}
  if(seen.has(m.id)){reply({success:false,error:'This request is already in progress. Inspect state rather than retry.'});return}
  seen.add(m.id);if(seen.size>500){const oldest=seen.values().next().value;seen.delete(oldest);done.delete(oldest)}
  if(m.action==='stop'){epoch++;const cursor=document.getElementById('fridayCursor');if(cursor)cursor.style.opacity='0';const result={success:true,message:'Stopped. Any read already in flight may finish; no writes are available.'};done.set(m.id,result);reply(result);return}
  if(busy){reply({success:false,error:'Dashboard is busy. Wait for the current action.'});return}
  busy=true;const selector=document.getElementById('companySelector'),wasDisabled=selector?.disabled;if(selector)selector.disabled=true
  try{const result=await execute(m);done.set(m.id,result);reply(result)}catch(e){const result={success:false,error:e.message,readOnly:true};done.set(m.id,result);reply(result)}finally{busy=false;if(selector)selector.disabled=wasDisabled}
 }
 document.getElementById('companySelector')?.addEventListener('change',()=>{epoch++})
 window.addEventListener('pagehide',()=>{epoch++;channel.close()})
 ready()
})()
// END [QUICKBOOKS-DASH-25] Paired conversational voice navigation with existing visible cursor
