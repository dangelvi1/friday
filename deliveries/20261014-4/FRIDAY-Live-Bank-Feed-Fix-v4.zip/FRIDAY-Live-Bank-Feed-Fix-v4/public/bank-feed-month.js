// Read every available Pending page first; month filtering never drives browser pagination.
(() => {
  function isoDate(value) {
    const text=String(value||'').trim()
    const match=/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec(text)
    const iso=match?`${match[3]}-${match[1].padStart(2,'0')}-${match[2].padStart(2,'0')}`:text
    if(!/^\d{4}-\d{2}-\d{2}$/.test(iso))return null
    const date=new Date(iso+'T00:00:00Z')
    return Number.isFinite(date.getTime())&&date.toISOString().slice(0,10)===iso?iso:null
  }
  function selectMonth(rows,month) {
    if(!/^\d{4}-(0[1-9]|1[0-2])$/.test(month))throw Error('Select a valid bank month first.')
    const selected=[],unreadable=[]
    for(const row of rows){const date=isoDate(row.date);if(!date)unreadable.push(row);else if(date.slice(0,7)===month)selected.push(row)}
    return {rows:selected,unreadable,outsideMonth:rows.length-selected.length-unreadable.length}
  }
  window.FridayBankFeedMonth={isoDate,selectMonth}
})()
