import {recordBudget,waitBudget} from './catalog'
import {DailyError} from './core'

// Use the categories connection already used by the live catalog audit.
// A search label narrows reads only; exact returned IDs decide eligibility.
export async function verifyTaxonomyCategory(graphql:any,id:unknown,label?:unknown):Promise<{id:string;name?:string}>{
 if(typeof id!=='string'||!/^gid:\/\/shopify\/TaxonomyCategory\/[a-zA-Z0-9-]+$/.test(id))throw new DailyError('Invalid Shopify category ID.')
 const search=typeof label==='string'?label.split('>').at(-1)!.trim().slice(0,200):''
 let after:string|null=null
 const seen=new Set<string>()
 for(let page=0;page<100;page++){
  await waitBudget(graphql)
  const response:any=await graphql('query CatalogCategoryVerify($search:String!,$after:String){taxonomy{categories(first:30,search:$search,after:$after){nodes{id name} pageInfo{hasNextPage endCursor}}}}',{search,after})
  recordBudget(graphql,response)
  if(response?.errors?.length){const error:any=new DailyError('Shopify category verification failed. No category change submitted.',502);error.details=response.errors;throw error}
  const connection:any=response?.data?.taxonomy?.categories
  if(!Array.isArray(connection?.nodes)||typeof connection?.pageInfo?.hasNextPage!=='boolean')throw new DailyError('Category verification read was incomplete. No category change submitted.',502)
  const exact=connection.nodes.find((node:any)=>node?.id===id)
  if(exact)return exact
  if(!connection.pageInfo.hasNextPage)throw new DailyError('Selected category ID was not found in the current Shopify taxonomy results. Refresh the audit and choose a current category.',409)
  const next:unknown=connection.pageInfo.endCursor
  if(typeof next!=='string'||!next||seen.has(next))throw new DailyError('Category verification paging did not advance. No category change submitted.',502)
  seen.add(next);after=next
 }
 throw new DailyError('Category verification reached its read limit. Narrow the category selection and review again.',409)
}
