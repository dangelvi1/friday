import test from 'node:test'
import assert from 'node:assert/strict'
import {mkdtemp,rm,readFile} from 'node:fs/promises'
import {tmpdir} from 'node:os'
import {join} from 'node:path'
import {randomUUID} from 'node:crypto'
import {seoPlainText} from '../commerce/daily/seo-text'
import {savedFieldComparison} from '../commerce/daily/saved-field-comparison'
import {seoService,proposals} from '../commerce/daily/seo'
import {STORE} from '../commerce/daily/core'
import {atomic,folder,jobFile,readJob} from '../commerce/daily/storage'

test('Default-title evidence preserves the missing raw override and requires the exact live product title',()=>{
 const c=savedFieldComparison('seoTitle',null,'Long product title','Long product title')
 assert.equal(c.matchesApproved,true);assert.equal(c.current,null);assert.equal(c.effectiveCurrent,'Long product title');assert.equal(c.comparisonBasis,'shopify_default_product_title')
 for(const [field,current,approved,title] of [
  ['seoTitle',null,'Different title','Product title'],['seoTitle',null,'Product title',undefined],
  ['seoTitle','','Product title','Product title'],['seoDescription',null,'Product title','Product title'],
  ['seoTitle','Old custom title','Product title','Product title']
 ] as const)assert.equal(savedFieldComparison(field,current,approved,title).matchesApproved,false)
})

test('Plain SEO entity corrections are one-layer proposals with exact before values',()=>{
 assert.equal(seoPlainText('Worklight &amp; Spotlight &#39;A&#39; &#x26; &quot;B&quot;'),'Worklight & Spotlight \'A\' & "B"')
 assert.equal(seoPlainText('&amp;amp;'),'&amp;')
 assert.equal(seoPlainText('Keep &unknown; &#0; &#xD800; &#1114112;'),'Keep &unknown; &#0; &#xD800; &#1114112;')
 const title='Fixture rechargeable worklight and spotlight with an extra long name'
 const old='Rechargeable worklight &amp; spotlight with two USB charging ports.'
 const p={id:'gid://shopify/Product/123',title,description:'',seo:{title:null,description:old}}
 const rows=proposals({products:[p]});assert.equal(rows.length,1);assert.equal(rows[0].field,'seoDescription');assert.equal(rows[0].before,old);assert.equal(rows[0].after,'Rechargeable worklight & spotlight with two USB charging ports.')
 const short=proposals({products:[{...p,title:'Fixture shoe',seo:{title:null,description:null},description:'A shoe &amp; a second shoe for the fixture.'}]})
 assert.ok(short.some(c=>c.field==='seoTitle'));assert.ok(short.some(c=>c.field==='seoDescription'&&c.after.includes('& a second')))
 assert.equal(proposals({products:[{...p,seo:{title:null,description:'A normal description with sufficient plain text.'}}]}).length,0)
})

test('Owner-scoped default verification and native-review diagnostics',async t=>{
 const cwd=process.cwd(),dir=await mkdtemp(join(tmpdir(),'friday-v33-'))
 try {
  process.chdir(dir)
  const product={id:'gid://shopify/Product/123',title:'Fixture long product name for the default SEO title verification',handle:'fixture',vendor:'Fixture',status:'ACTIVE',descriptionHtml:'',seo:{title:null,description:null as string|null}}
  let writes=0,categoryError:boolean|'provider'=false
  const service=seoService(async(q:string,v:any={})=>{
   if(q.includes('Identity'))return{data:{shop:{id:STORE.id,myshopifyDomain:STORE.domain,currencyCode:'USD'}}}
   if(q.includes('CatalogReviewBases'))return{data:{nodes:[structuredClone(product)]}}
   if(q.includes('DailySeoProduct'))return{data:{product:structuredClone(product)}}
   if(q.includes('CatalogListing'))return{data:{product:{id:product.id,tags:[],category:null,metafields:{nodes:[],pageInfo:{hasNextPage:false}}}}}
   if(q.includes('CatalogCategoryVerify')){if(categoryError==='provider')return{errors:[{message:'CATEGORY_PROVIDER_FIXTURE',extensions:{code:'FIELD_UNAVAILABLE'}}]};if(categoryError)throw Error('CATEGORY_SCHEMA_FIXTURE Bearer private-fixture-token');throw Error('Unexpected category test')}
   if(q.includes('DailySeoUpdate')){writes++;product.seo={...product.seo,...v.product.seo};return{data:{productUpdate:{product:{id:product.id},userErrors:[]}}}}
   throw Error('Unexpected query')
  })
  async function report(change:any){const id=randomUUID();await atomic(jobFile('salvador',id),{id,owner:'salvador',companyKey:STORE.companyKey,status:'completed',activity:[],report:{catalogRevision:0,audit:{products:[{id:product.id,sourceSEO:structuredClone(product)}]},changes:[change]}});return id}
  await t.test('an old exact default-title receipt verifies locally with no repeat write and no guard deletion',async()=>{
   const c={id:'123:seoTitle',productId:product.id,field:'seoTitle',before:null,after:product.title,supported:true},reportId=await report(c),id=randomUUID(),guard=join(folder('salvador'),'catalog-claims','retained.json')
   await atomic(guard,{reviewId:id});const original=await readFile(guard,'utf8')
   await atomic(join(folder('salvador'),'seo-reviews',id+'.json'),{id,owner:'salvador',format:'catalog-v16',companyKey:STORE.companyKey,status:'needs_review',reportId,changes:[c],snapshots:{[product.id]:{base:structuredClone(product)}},results:[{status:'uncertain',productId:product.id,writeAttempted:true}]})
   const r=await service.verifyCurrent('salvador',id);assert.equal(writes,0);assert.equal(r.verification.checks[0].fields[0].current,null);assert.equal(r.verification.checks[0].fields[0].comparisonBasis,'shopify_default_product_title');assert.equal(r.review.status,'needs_review');assert.ok((await readJob('salvador',reportId)).report.changes[0].appliedAt);assert.equal(await readFile(guard,'utf8'),original)
   await assert.rejects(()=>service.verifyCurrent('dayanna',id),/not found/)
  })
  await t.test('entity correction does not mutate Shopify until exact fresh review and approval',async()=>{
   product.seo.description='A useful fixture worklight &amp; spotlight with rechargeable battery.'
   const c=proposals({products:[{...product,description:'',seo:product.seo}]})[0],id=await report(c)
   const p=await service.preview('salvador',{reportId:id,changeIds:[c.id]});assert.equal(writes,0);assert.equal(p.review.status,'prepared')
   const r=await service.execute('salvador',p.review.id,true);assert.equal(writes,1);assert.equal(r.review.status,'completed');assert.equal(product.seo.description,c.after);assert.ok(!product.seo.description?.includes('&amp;'))
  })
  await t.test('native category exception is visible and sanitized without a category write',async()=>{
   categoryError=true
   const c={id:'123:category',productId:product.id,field:'category',displayAfter:'Shoes > Sneakers',before:null,after:'gid://shopify/TaxonomyCategory/fixture',supported:true},id=await report(c)
   const r=await service.preview('salvador',{reportId:id,changeIds:[c.id]});assert.equal(writes,1);assert.equal(r.review.status,'no_changes');assert.match(r.review.excluded[0].reason,/CATEGORY_SCHEMA_FIXTURE/);assert.ok(!JSON.stringify(r.review.excluded).includes('private-fixture-token'));assert.equal(r.review.excluded[0].diagnostics.phase,'review_listing_field')
  })
  await t.test('returned category provider errors retain diagnostic code and message',async()=>{
   categoryError='provider'
   const c={id:'123:category',productId:product.id,field:'category',displayAfter:'Shoes > Sneakers',before:null,after:'gid://shopify/TaxonomyCategory/fixture',supported:true},id=await report(c)
   const r=await service.preview('salvador',{reportId:id,changeIds:[c.id]});assert.equal(writes,1);assert.equal(r.review.excluded[0].diagnostics.messages[0].code,'FIELD_UNAVAILABLE');assert.match(r.review.excluded[0].diagnostics.messages[0].message,/CATEGORY_PROVIDER_FIXTURE/)
  })

 }finally{process.chdir(cwd);await rm(dir,{recursive:true,force:true})}
})
