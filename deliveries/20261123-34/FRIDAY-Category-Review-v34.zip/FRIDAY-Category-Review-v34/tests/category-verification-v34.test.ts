import test from 'node:test'
import assert from 'node:assert/strict'
import {mkdtemp,rm} from 'node:fs/promises'
import {tmpdir} from 'node:os'
import {join} from 'node:path'
import {randomUUID} from 'node:crypto'
import {verifyTaxonomyCategory} from '../commerce/daily/category-verification'
import {seoService} from '../commerce/daily/seo'
import {STORE} from '../commerce/daily/core'
import {atomic,jobFile} from '../commerce/daily/storage'
const id='gid://shopify/TaxonomyCategory/aa-8-8'
const page=(nodes:any[],more=false,cursor:string|null=null)=>({data:{taxonomy:{categories:{nodes,pageInfo:{hasNextPage:more,endCursor:cursor}}}}})

test('Category connection verifies exact ID and paginates; matching names alone never qualify',async()=>{
 const calls:any[]=[]
 const g=async(q:string,v:any)=>{
  assert.ok(q.includes('categories(first:30'));assert.ok(!q.includes('category(id:'));assert.ok(!q.includes('$id:'));calls.push(v)
  return v.after?page([{id,name:'Sneakers'}]):page([{id:'gid://shopify/TaxonomyCategory/other',name:'Sneakers'}],true,'second')
 }
 assert.equal((await verifyTaxonomyCategory(g,id,'Apparel & Accessories > Shoes > Sneakers')).id,id)
 assert.deepEqual(calls,[{search:'Sneakers',after:null},{search:'Sneakers',after:'second'}])
 await assert.rejects(()=>verifyTaxonomyCategory(async()=>page([{id:'gid://shopify/TaxonomyCategory/other',name:'Sneakers'}]),id,'Sneakers'),/not found/)
})

test('Missing/malformed/looping taxonomy responses and invalid IDs fail closed',async()=>{
 await assert.rejects(()=>verifyTaxonomyCategory(async()=>({data:{taxonomy:{}}}),id,'Sneakers'),/incomplete/)
 await assert.rejects(()=>verifyTaxonomyCategory(async()=>page([],true,null),id,'Sneakers'),/did not advance/)
 let count=0;await assert.rejects(()=>verifyTaxonomyCategory(async()=>{count++;return page([],true,'same')},id),/did not advance/);assert.equal(count,2)
 let called=false;await assert.rejects(()=>verifyTaxonomyCategory(async()=>{called=true},'unrelated-object','Sneakers'),/Invalid/);assert.equal(called,false)
 await assert.rejects(()=>verifyTaxonomyCategory(async()=>({errors:[{message:'schema fixture',extensions:{code:'undefinedField'}}]}),id),e=>{assert.equal((e as any).details[0].extensions.code,'undefinedField');return true})
})

test('Actual category preview is read-only, approval writes and verifies, dependencies/owner/changed fields remain protected',async t=>{
 const cwd=process.cwd(),dir=await mkdtemp(join(tmpdir(),'friday-v34-'))
 try{
  process.chdir(dir)
  const before='gid://shopify/TaxonomyCategory/aa-8',pid='gid://shopify/Product/123'
  let wrong=false,missing=false,metadata=false,writes=0
  const product:any={id:pid,title:'Fixture skate shoes',handle:'fixture',status:'ACTIVE',vendor:'Vans',descriptionHtml:'',seo:{title:null,description:null},category:{id:before},tags:[]}
  const service=seoService(async(q:string,v:any={})=>{
   if(q.includes('Identity'))return{data:{shop:{id:wrong?'other':STORE.id,myshopifyDomain:STORE.domain,currencyCode:'USD'}}}
   if(q.includes('CatalogReviewBases'))return{data:{nodes:[structuredClone(product)]}}
   if(q.includes('DailySeoProduct'))return{data:{product:structuredClone(product)}}
   if(q.includes('CatalogListing'))return{data:{product:{...structuredClone(product),metafields:{nodes:metadata?[{namespace:'shopify',key:'color',value:'owned attribute'}]:[],pageInfo:{hasNextPage:false}}}}}
   if(q.includes('CatalogCategoryVerify')){assert.ok(!q.includes('category(id:'));return page(missing?[]:[{id,name:'Sneakers'}])}
   if(q.includes('DailySeoUpdate')){writes++;assert.equal(v.product.category,id);product.category={id};return{data:{productUpdate:{product:{id:pid},userErrors:[]}}}}
   throw Error('Unexpected fixture query')
  })
  async function preview(){
   const reportId=randomUUID(),c={id:'123:category',productId:pid,field:'category',before:product.category.id,after:id,displayAfter:'Apparel & Accessories > Shoes > Sneakers',supported:true}
   await atomic(jobFile('salvador',reportId),{id:reportId,owner:'salvador',companyKey:STORE.companyKey,status:'completed',activity:[],report:{catalogRevision:0,audit:{products:[{id:pid,sourceSEO:structuredClone(product)}]},changes:[c]}})
   return service.preview('salvador',{reportId,changeIds:[c.id]})
  }
  await t.test('missing exact category excludes without native mutation',async()=>{missing=true;const r=await preview();assert.equal(r.review.status,'no_changes');assert.match(r.review.excluded[0].reason,/not found/);assert.equal(writes,0);missing=false})
  await t.test('existing category attributes require dependency review',async()=>{metadata=true;const r=await preview();assert.equal(r.review.status,'no_changes');assert.match(r.review.excluded[0].reason,/dependency review/);assert.equal(writes,0);metadata=false})
  await t.test('wrong store and a changed category cannot be overwritten',async()=>{
   wrong=true;await assert.rejects(()=>preview(),/identity/);wrong=false
   const r=await preview();product.category={id:'gid://shopify/TaxonomyCategory/other'}
   const result=await service.execute('salvador',r.review.id,true);assert.equal(result.review.results[0].status,'conflict');assert.equal(writes,0);product.category={id:before}
  })
  await t.test('one exact approval submits category and fresh readback verifies it',async()=>{
   const r=await preview();assert.equal(r.review.status,'prepared');assert.equal(writes,0)
   await assert.rejects(()=>service.execute('salvador',r.review.id,false),/Approve/)
   await assert.rejects(()=>service.execute('dayanna',r.review.id,true),/not found/)
   const result=await service.execute('salvador',r.review.id,true);assert.equal(result.review.status,'completed');assert.equal(result.review.results[0].status,'saved');assert.equal(writes,1);assert.equal(product.category.id,id)
   await service.execute('salvador',r.review.id,true);assert.equal(writes,1)
  })
 }finally{process.chdir(cwd);await rm(dir,{recursive:true,force:true})}
})
