import {registerInvoiceFieldRoutes} from './invoice-field-routes'
import {invoiceReviewFields} from './invoice-review-fields'
// ============================================================
// FRIDAY QUICKBOOKS FEATURE MODULE
// FILE: S:\AI\friday-ai\quickbooks\invoice-search.ts
// PURPOSE: Small, focused QuickBooks route module.
// ============================================================

import type {
  Express,
} from 'express'

import {
  getValidQuickBooksConnection,
} from './connection'

import {
  getQuickBooksApiBaseUrl,
} from './quickbooks-auth'

export function registerQuickBooksInvoiceSearch(
  app:
    Express
) {

registerInvoiceFieldRoutes(app)

// START [QUICKBOOKS-14] Invoice search + payment terms + newest-first sorting
// ACTION: REPLACE ENTIRE QUICKBOOKS-14 BLOCK
// FILE: S:\AI\friday-ai\quickbooks\routes.ts
// PLACE: Below [QUICKBOOKS-13] Customer Search
// PURPOSE:
// - Search QuickBooks invoices
// - Return customer, totals, balances and status
// - Return invoice SalesTermRef / payment terms
// - Support customer-specific invoice views
// - Default invoices to newest → oldest
// - Prepare payment-term filtering for Sales and Customer Details
// USERS: Salvador and Dayanna
// ============================================================

app.get(
  '/quickbooks/invoices/:companyKey',
  async (
    req,
    res
  ) => {
    try {

      const companyKey =
        String(
          req.params.companyKey ||
          ''
        )
          .trim()
          .toLowerCase()


      const customerId =
        String(
          req.query.customerId ||
          ''
        )
          .trim()


      const customerName =
        String(
          req.query.customerName ||
          ''
        )
          .trim()


      const status =
        String(
          req.query.status ||
          'all'
        )
          .trim()
          .toLowerCase()


      const termId =
        String(
          req.query.termId ||
          ''
        )
          .trim()


      const minBalanceRaw =
        String(
          req.query.minBalance ||
          ''
        )
          .trim()


      const minBalance =
        minBalanceRaw
          ? Number(
              minBalanceRaw
            )
          : null


      const maxResultsRaw =
        Number(
          req.query.maxResults ||
          100
        )


      const maxResults =
        Number.isFinite(
          maxResultsRaw
        )
          ? Math.min(
              Math.max(
                Math.floor(
                  maxResultsRaw
                ),
                1
              ),
              1000
            )
          : 100


      const connection =
        await getValidQuickBooksConnection(
          companyKey
        )


      const baseUrl =
        getQuickBooksApiBaseUrl(
          connection.environment
        )


      // ------------------------------------------------------------
      // BUILD QUICKBOOKS QUERY
      // ------------------------------------------------------------

      let query =
        `SELECT * FROM Invoice`


      const conditions:
        string[] =
        []


      if (customerId) {

        const safeCustomerId =
          customerId
            .replace(
              /\\/g,
              '\\\\'
            )
            .replace(
              /'/g,
              "\\'"
            )


        conditions.push(
          `CustomerRef = '${safeCustomerId}'`
        )
      }


      if (customerName) {

        const safeCustomerName =
          customerName
            .replace(
              /\\/g,
              '\\\\'
            )
            .replace(
              /'/g,
              "\\'"
            )


        conditions.push(
          `CustomerRef.name LIKE '%${safeCustomerName}%'`
        )
      }


      if (
        status ===
        'open'
      ) {

        conditions.push(
          `Balance > '0'`
        )
      }


      if (
        status ===
        'paid'
      ) {

        conditions.push(
          `Balance = '0'`
        )
      }


      if (
        minBalance !==
          null &&
        Number.isFinite(
          minBalance
        )
      ) {

        conditions.push(
          `Balance >= '${minBalance}'`
        )
      }


      if (
        conditions.length >
        0
      ) {

        query +=
          ` WHERE ` +
          conditions.join(
            ' AND '
          )
      }


      query +=
        ` MAXRESULTS ${maxResults}`


      const url =
        `${baseUrl}` +
        `/v3/company/` +
        `${encodeURIComponent(
          connection.realm_id
        )}` +
        `/query?query=` +
        `${encodeURIComponent(
          query
        )}`


      const response =
        await fetch(
          url,
          {
            method:
              'GET',

            headers: {

              Authorization:
                `Bearer ${connection.access_token}`,

              Accept:
                'application/json',
            },
          }
        )


      const data =
        await response.json()


      if (!response.ok) {

        console.error(
          'QUICKBOOKS INVOICE SEARCH ERROR:',
          data
        )


        return res
          .status(
            response.status
          )
          .json({
            success:
              false,

            error:
              'QuickBooks invoice search failed.',

            details:
              data,
          })
      }


      const invoices =
        data
          ?.QueryResponse
          ?.Invoice ||
        []


      const now =
        new Date()


      // ------------------------------------------------------------
      // NORMALIZE INVOICES
      // ------------------------------------------------------------

      let results =
        invoices.map(
          (
            invoice:
              any
          ) => {

            const dueDate =
              invoice.DueDate
                ? new Date(
                    `${invoice.DueDate}T00:00:00`
                  )
                : null


            const balance =
              Number(
                invoice.Balance ||
                0
              )


            const total =
              Number(
                invoice.TotalAmt ||
                0
              )


            const isPaid =
              balance <=
              0


            const isOverdue =
              !isPaid &&
              dueDate !==
                null &&
              dueDate.getTime() <
                now.getTime()


            const daysOverdue =
              isOverdue &&
              dueDate
                ? Math.floor(
                    (
                      now.getTime() -
                      dueDate.getTime()
                    ) /
                    (
                      1000 *
                      60 *
                      60 *
                      24
                    )
                  )
                : 0


            const salesTermId =
              String(
                invoice
                  ?.SalesTermRef
                  ?.value ||
                ''
              )
                .trim()


            const salesTermName =
              String(
                invoice
                  ?.SalesTermRef
                  ?.name ||
                ''
              )
                .trim()


            return {

              id:
                invoice.Id ||
                null,


              ...invoiceReviewFields(invoice),

              docNumber:
                invoice.DocNumber ||
                null,


              customerId:
                invoice
                  .CustomerRef
                  ?.value ||
                null,


              customerName:
                invoice
                  .CustomerRef
                  ?.name ||
                null,


              txnDate:
                invoice.TxnDate ||
                null,


              dueDate:
                invoice.DueDate ||
                null,


              // ----------------------------------------------------
              // PAYMENT TERMS
              // ----------------------------------------------------

              salesTermId:
                salesTermId ||
                null,


              salesTermName:
                salesTermName ||
                null,


              paymentTerm: {

                id:
                  salesTermId ||
                  null,

                name:
                  salesTermName ||
                  null,
              },


              totalAmount:
                total,


              balance:
                balance,


              isPaid,


              isOpen:
                !isPaid,


              isOverdue,


              daysOverdue,


              currency:
                invoice
                  .CurrencyRef
                  ?.value ||
                null,


              emailStatus:
                invoice.EmailStatus ||
                null,


              printStatus:
                invoice.PrintStatus ||
                null,


              privateNote:
                invoice.PrivateNote ||
                null,


              customerMemo:
                invoice
                  .CustomerMemo
                  ?.value ||
                null,


              linkedTransactions:
                invoice.LinkedTxn ||
                [],


              billEmail:
                invoice
                  .BillEmail
                  ?.Address ||
                null,
            }
          }
        )


      // ------------------------------------------------------------
      // PAYMENT TERM FILTER
      // We filter locally because this keeps the QuickBooks query
      // compatible even when SalesTermRef filtering is limited.
      // ------------------------------------------------------------

      if (termId) {

        results =
          results.filter(
            (
              invoice:
                any
            ) =>
              String(
                invoice.salesTermId ||
                ''
              ) ===
              termId
          )
      }


      // ------------------------------------------------------------
      // DEFAULT SORT:
      // NEWEST INVOICE → OLDEST INVOICE
      // ------------------------------------------------------------

      const sortedResults =
        results.sort(
          (
            a:
              any,
            b:
              any
          ) => {

            const dateCompare =
              String(
                b.txnDate ||
                ''
              )
                .localeCompare(
                  String(
                    a.txnDate ||
                    ''
                  )
                )


            if (
              dateCompare !==
              0
            ) {

              return dateCompare
            }


            // Same date:
            // larger numeric invoice number first when possible.

            const aNumber =
              Number(
                a.docNumber
              )


            const bNumber =
              Number(
                b.docNumber
              )


            if (
              Number.isFinite(
                aNumber
              ) &&
              Number.isFinite(
                bNumber
              )
            ) {

              return (
                bNumber -
                aNumber
              )
            }


            return String(
              b.docNumber ||
              ''
            )
              .localeCompare(
                String(
                  a.docNumber ||
                  ''
                )
              )
          }
        )


      // ------------------------------------------------------------
      // RESPONSE
      // ------------------------------------------------------------

      res.json({

        success:
          true,


        companyKey,


        companyName:
          connection.company_name,


        filters: {

          customerId:
            customerId ||
            null,


          customerName:
            customerName ||
            null,


          status,


          termId:
            termId ||
            null,


          minBalance,
        },


        count:
          sortedResults.length,


        totals: {

          invoiceAmount:
            sortedResults.reduce(
              (
                sum:
                  number,
                invoice:
                  any
              ) =>
                sum +
                invoice.totalAmount,
              0
            ),


          openBalance:
            sortedResults.reduce(
              (
                sum:
                  number,
                invoice:
                  any
              ) =>
                sum +
                invoice.balance,
              0
            ),


          overdueBalance:
            sortedResults.reduce(
              (
                sum:
                  number,
                invoice:
                  any
              ) =>
                sum +
                (
                  invoice.isOverdue
                    ? invoice.balance
                    : 0
                ),
              0
            ),
        },


        invoices:
          sortedResults,
      })

    } catch (
      error:
        any
    ) {

      console.error(
        'QUICKBOOKS INVOICE SEARCH ERROR:',
        error
      )


      res
        .status(500)
        .json({

          success:
            false,


          error:
            error?.message ||
            'Could not search QuickBooks invoices.',
        })
    }
  }
)

// ============================================================
// END [QUICKBOOKS-14] Invoice search + payment terms + newest-first sorting

}
