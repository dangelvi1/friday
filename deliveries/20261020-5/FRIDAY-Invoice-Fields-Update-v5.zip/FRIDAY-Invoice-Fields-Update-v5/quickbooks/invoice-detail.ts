import {invoiceReviewFields} from './invoice-review-fields'
// ============================================================
// FRIDAY QUICKBOOKS FEATURE MODULE
// FILE: S:\AI\friday-ai\quickbooks\invoice-detail.ts
// PURPOSE: Small, focused QuickBooks route module.
// ============================================================

import type {
  Express,
} from 'express'

import {
  getValidQuickBooksConnection,
} from './connection'

import {
  getQuickBooksApiBaseUrl,
} from './quickbooks-auth'

export function registerQuickBooksInvoiceDetail(
  app:
    Express
) {

// START [QUICKBOOKS-14B] Invoice detail + line items
// ACTION: ADD
// FILE: S:\AI\friday-ai\quickbooks\routes.ts
// PURPOSE: Load one complete QuickBooks invoice for dashboard detail view
// USERS: Salvador and Dayanna
// ============================================================

app.get(
  '/quickbooks/invoice/:companyKey/:invoiceId',
  async (
    req,
    res
  ) => {
    try {
      const companyKey =
        String(
          req.params.companyKey ||
          ''
        )
          .trim()
          .toLowerCase()

      const invoiceId =
        String(
          req.params.invoiceId ||
          ''
        )
          .trim()

      if (!invoiceId) {
        return res
          .status(400)
          .json({
            success: false,
            error: 'invoiceId is required.',
          })
      }

      const connection =
        await getValidQuickBooksConnection(
          companyKey
        )

      const baseUrl =
        getQuickBooksApiBaseUrl(
          connection.environment
        )

      const response =
        await fetch(
          `${baseUrl}/v3/company/${encodeURIComponent(
            connection.realm_id
          )}/invoice/${encodeURIComponent(
            invoiceId
          )}`,
          {
            headers: {
              Authorization:
                `Bearer ${connection.access_token}`,
              Accept:
                'application/json',
            },
          }
        )

      const data =
        await response.json()

      if (!response.ok) {
        return res
          .status(response.status)
          .json({
            success: false,
            error:
              'QuickBooks invoice detail lookup failed.',
            details: data,
          })
      }

      const invoice =
        data?.Invoice ||
        null

      if (!invoice) {
        return res
          .status(404)
          .json({
            success: false,
            error: 'Invoice not found.',
          })
      }

      const lines =
        (invoice.Line || [])
          .filter(
            (line: any) =>
              line.DetailType ===
              'SalesItemLineDetail'
          )
          .map(
            (line: any) => ({
              id:
                line.Id ||
                null,
              description:
                line.Description ||
                null,
              amount:
                Number(
                  line.Amount ||
                  0
                ),
              itemId:
                line
                  ?.SalesItemLineDetail
                  ?.ItemRef
                  ?.value ||
                null,
              itemName:
                line
                  ?.SalesItemLineDetail
                  ?.ItemRef
                  ?.name ||
                null,
              serviceDate:
                line
                  ?.SalesItemLineDetail
                  ?.ServiceDate ||
                null,
              quantity:
                Number(
                  line
                    ?.SalesItemLineDetail
                    ?.Qty ||
                  0
                ),
              unitPrice:
                Number(
                  line
                    ?.SalesItemLineDetail
                    ?.UnitPrice ||
                  0
                ),
              taxCode:
                line
                  ?.SalesItemLineDetail
                  ?.TaxCodeRef
                  ?.value ||
                null,
            })
          )

      res.json({
        success: true,
        companyKey,
        companyName:
          connection.company_name,
        environment:
          connection.environment,
        invoice: {
          ...invoiceReviewFields(invoice),
          readScope:{companyKey,realmId:String(connection.realm_id),environment:String(connection.environment)},
          id:
            invoice.Id ||
            null,
          syncToken:
            invoice.SyncToken ||
            null,
          docNumber:
            invoice.DocNumber ||
            null,
          customerId:
            invoice
              ?.CustomerRef
              ?.value ||
            null,
          customerName:
            invoice
              ?.CustomerRef
              ?.name ||
            null,
          txnDate:
            invoice.TxnDate ||
            null,
          dueDate:
            invoice.DueDate ||
            null,
          salesTermId:
            invoice
              ?.SalesTermRef
              ?.value ||
            null,
          salesTermName:
            invoice
              ?.SalesTermRef
              ?.name ||
            null,
          totalAmount:
            Number(
              invoice.TotalAmt ||
              0
            ),
          balance:
            Number(
              invoice.Balance ||
              0
            ),
          billEmail:
            invoice
              ?.BillEmail
              ?.Address ||
            null,
          emailStatus:
            invoice.EmailStatus ||
            null,
          printStatus:
            invoice.PrintStatus ||
            null,
          customerMemo:
            invoice
              ?.CustomerMemo
              ?.value ||
            null,
          privateNote:
            invoice.PrivateNote ||
            null,
          linkedTransactions:
            invoice.LinkedTxn ||
            [],
          lines,
        },
      })
    } catch (
      error:
        any
    ) {
      console.error(
        'QUICKBOOKS INVOICE DETAIL ERROR:',
        error
      )

      res
        .status(500)
        .json({
          success: false,
          error:
            error?.message ||
            'Could not load invoice detail.',
        })
    }
  }
)

// ============================================================
// END [QUICKBOOKS-14B] Invoice detail + line items

}
