import type {Express} from 'express'
import {createHash,randomUUID} from 'node:crypto'
import {mkdir,readFile,writeFile,unlink} from 'node:fs/promises'
import {resolve} from 'node:path'
import {authenticateSandraOwner} from './sandra-learning-core'
import {getValidQuickBooksConnection} from './connection'
import {getQuickBooksApiBaseUrl} from './quickbooks-auth'
import {runQuickBooksQuery,QuickBooksThrottleError} from './query'
import {invoiceReviewFields,invoiceHeaderPatch,invoiceFieldLabels} from './invoice-review-fields'

function canonical(v:any):any{return Array.isArray(v)?v.map(canonical):v&&typeof v==='object'?Object.fromEntries(Object.keys(v).sort().map(k=>[k,canonical(v[k])])):v}
const hash=(v:any)=>createHash('sha256').update(JSON.stringify(canonical(v))).digest('hex')
const directory=()=>resolve(process.cwd(),'data','invoice-field-actions')
const path=(id:string)=>resolve(directory(),id+'.json')
async function invoice(c:any,id:string){
 const r=await fetch(`${getQuickBooksApiBaseUrl(c.environment)}/v3/company/${encodeURIComponent(c.realm_id)}/invoice/${id}`,{headers:{Authorization:`Bearer ${c.access_token}`,Accept:'application/json'},signal:AbortSignal.timeout(30000)}),d=await r.json()
 if(!r.ok||!d.Invoice||String(d.Invoice.Id)!==id)throw Error('Could not read the selected invoice.')
 return d.Invoice
}
function financialSnapshot(v:any){const {CustomField,MetaData,SyncToken,...rest}=v;return hash(rest)}
async function selected(req:any){
 const actor=authenticateSandraOwner(req),companyKey=String(req.params.companyKey)
 if(!/^[a-z0-9-]{1,80}$/.test(companyKey))throw Error('Invalid company.')
 const c=await getValidQuickBooksConnection(companyKey),scope={actor,companyKey,realmId:String(c.realm_id),environment:String(c.environment)}
 if(req.method==='POST'&&(req.body?.realmId!==scope.realmId||req.body?.environment!==scope.environment))throw Error('Company connection changed. Refresh first.')
 if(req.query.realmId&&String(req.query.realmId)!==scope.realmId||req.query.environment&&String(req.query.environment)!==scope.environment)throw Error('Company connection changed. Refresh first.')
 return {c,scope}
}
export async function readInvoiceFieldSnapshot(query:(sql:string)=>Promise<any>,customerId=''){
 if(customerId&&!/^\d{1,20}$/.test(customerId))throw Error('Invalid customer.')
 const where=customerId?` WHERE CustomerRef = '${customerId}'`:''
 const count=await query('SELECT COUNT(*) FROM Invoice'+where),expected=count?.QueryResponse?.totalCount
 if(!Number.isSafeInteger(expected)||expected<0||expected>200000)throw Error('Invoice count unavailable or above the supported read limit. Narrow to a customer.')
 const rows:any[]=[],seen=new Set<string>()
 for(let page=0;page<=200;page++){
  const d=await query(`SELECT * FROM Invoice${where} ORDERBY TxnDate STARTPOSITION ${page*1000+1} MAXRESULTS 1000`),batch=d?.QueryResponse?.Invoice??[]
  if(!d?.QueryResponse||!Array.isArray(batch))throw Error('Invalid invoice page.')
  for(const row of batch){const id=String(row.Id||'');if(!/^\d{1,20}$/.test(id)||seen.has(id))throw Error('Repeated or invalid invoice ID. No partial results accepted.');if(customerId&&String(row.CustomerRef?.value)!==customerId)throw Error('Customer scope mismatch.');seen.add(id);rows.push(row)}
  if(batch.length<1000){if(rows.length!==expected)throw Error('Invoice count changed or pagination was incomplete. Refresh and search again.');return rows}
 }
 throw Error('Invoice pagination exceeded the read limit. Narrow to a customer.')
}
const searchText=(v:any)=>String(v??'').normalize('NFKD').replace(/\p{M}/gu,'').replace(/\s+/g,' ').trim().toLowerCase()
export function matchInvoiceFields(row:any,q:string,field:string){
 const fields=invoiceReviewFields(row),needle=searchText(q)
 const keys=field==='all'?[...Object.keys(invoiceFieldLabels),'lineService','customer','invoice']: [field]
 return keys.filter(k=>{const value=k==='lineService'?fields.lineServices.join(' '):k==='customer'?row.CustomerRef?.name:k==='invoice'?row.DocNumber:(fields as any)[k];return searchText(value).includes(needle)})
}
export function registerInvoiceFieldRoutes(app:Express){
 app.get('/quickbooks/invoice-field-search/:companyKey',async(req,res)=>{
  res.setHeader('Cache-Control','no-store')
  try{
   const {c,scope}=await selected(req),q=String(req.query.q||'').trim(),field=String(req.query.field||'all'),customerId=String(req.query.customerId||'')
   if(!q||q.length>200||!['all','lineService','customer','invoice',...Object.keys(invoiceFieldLabels)].includes(field))return res.status(400).json({success:false,error:'Choose a supported field and search text (1–200 characters).'})
   const rows=await readInvoiceFieldSnapshot(sql=>runQuickBooksQuery(c,sql),customerId),matches:any[]=[],unavailable:any={}
   for(const row of rows){const f=invoiceReviewFields(row);for(const k of Object.keys(invoiceFieldLabels)){if(['unavailable','ambiguous'].includes(f.fieldInfo[k].status))unavailable[k]=(unavailable[k]||0)+1}const matchedFields=matchInvoiceFields(row,q,field);if(matchedFields.length)matches.push({id:String(row.Id),docNumber:row.DocNumber||'',customerId:String(row.CustomerRef?.value||''),customerName:row.CustomerRef?.name||'',txnDate:row.TxnDate||'',totalAmount:row.TotalAmt??null,balance:row.Balance??null,currency:row.CurrencyRef?.value||null,...f,matchedFields})}
   return res.json({success:true,...scope,q,field,customerId:customerId||null,readOnly:true,completeRead:true,scannedCount:rows.length,totalMatches:matches.length,returnedCount:Math.min(matches.length,5000),truncated:matches.length>5000,unavailableCounts:unavailable,invoices:matches.slice(0,5000),readAt:new Date().toISOString(),limitations:['Fields not exposed by the QuickBooks invoice API cannot be searched or edited by guessing.','QuickBooks can change during a read. Refresh the invoice before editing.']})
  }catch(e:any){if(e instanceof QuickBooksThrottleError){res.setHeader('Retry-After',String(e.retryAfterSeconds));return res.status(429).json({success:false,error:e.message})}return res.status(400).json({success:false,error:'Could not complete the scoped invoice search. Verify owner/company and retry; no partial results were accepted.'})}
 })
 app.post('/quickbooks/invoice-fields/:companyKey/:invoiceId/:action',async(req,res)=>{
  res.setHeader('Cache-Control','no-store')
  let submitted=false,proposal:any=null
  try{
   const {c,scope}=await selected(req),id=String(req.params.invoiceId),action=String(req.params.action)
   if(!/^\d{1,20}$/.test(id)||!['preview','execute','receipt'].includes(action))throw Error('Invalid invoice field action.')
   await mkdir(directory(),{recursive:true})
   const active=path(hash({companyKey:scope.companyKey,realmId:scope.realmId,environment:scope.environment,id}))+'.active'
   if(action==='preview'){
    if(req.body?.sourceScope?.companyKey!==scope.companyKey||req.body?.sourceScope?.realmId!==scope.realmId||req.body?.sourceScope?.environment!==scope.environment)return res.status(409).json({success:false,error:'The QuickBooks connection differs from the opened invoice. Reopen it before editing.'})
    try{const pending=JSON.parse(await readFile(path((await readFile(active,'utf8')).trim()),'utf8'));return res.status(409).json({success:false,proposalId:pending.actor===scope.actor?pending.proposalId:undefined,error:'A header update is submitted or uncertain. Check its receipt and QuickBooks before creating another preview.'})}catch(e:any){if(e.code!=='ENOENT')throw e}
    const current=await invoice(c,id)
    if(String(current.SyncToken)!==String(req.body?.expectedSyncToken))return res.status(409).json({success:false,error:'Invoice changed. Reopen it before editing; your current fields were kept.'})
    if(!/^\d+$/.test(String(current.SyncToken)))throw Error('Header invoice revision unavailable.')
    const patch=invoiceHeaderPatch(current,req.body?.changes)
    proposal={...scope,invoiceId:id,proposalId:randomUUID(),docNumber:current.DocNumber||id,syncToken:String(current.SyncToken),snapshotHash:hash(current),financialHash:financialSnapshot(current),customFields:patch.customFields,review:patch.review,status:'prepared',expiresAt:Date.now()+900000}
    await writeFile(path(proposal.proposalId),JSON.stringify(proposal),{flag:'wx'})
    const {customFields,financialHash,...display}=proposal
    return res.json({success:true,...display})
   }
   const proposalId=req.body?.proposalId
   if(typeof proposalId!=='string'||! /^[a-f0-9-]{36}$/.test(proposalId))throw Error('Invalid proposal.')
   proposal=JSON.parse(await readFile(path(proposalId),'utf8'))
   if(proposal.invoiceId!==id||Object.entries(scope).some(([k,v])=>proposal[k]!==v))return res.status(403).json({success:false,error:'Preview belongs to another owner or company.'})
   if(action==='receipt'){const {customFields,financialHash,...receipt}=proposal;return res.json({success:true,receipt})}
   if(proposal.status!=='prepared'||proposal.expiresAt<Date.now()||req.body?.approved!==true||req.body?.snapshotHash!==proposal.snapshotHash)return res.status(409).json({success:false,error:'Preview expired, changed or already submitted. Inspect the receipt; do not automatically retry.'})
   const current=await invoice(c,id)
   if(hash(current)!==proposal.snapshotHash)return res.status(409).json({success:false,error:'Invoice changed after preview. Nothing was submitted; prepare a fresh preview.'})
   try{await writeFile(active,proposalId,{flag:'wx'})}catch{return res.status(409).json({success:false,error:'Another header update is submitted or uncertain.'})}
   // One durable claim per preview, including after successful active-lock removal.
   try{await writeFile(path(proposalId)+'.submitted',new Date().toISOString(),{flag:'wx'})}catch{return res.status(409).json({success:false,error:'Preview was already submitted. Check its receipt.'})}
   proposal.status='uncertain';await writeFile(path(proposalId),JSON.stringify(proposal));submitted=true
   const r=await fetch(`${getQuickBooksApiBaseUrl(c.environment)}/v3/company/${encodeURIComponent(c.realm_id)}/invoice?requestid=${proposalId}`,{method:'POST',headers:{Authorization:`Bearer ${c.access_token}`,'Content-Type':'application/json',Accept:'application/json'},body:JSON.stringify({Id:id,SyncToken:proposal.syncToken,sparse:true,CustomField:proposal.customFields}),signal:AbortSignal.timeout(30000)}),d=await r.json()
   if(!r.ok&&!d.Invoice&&[400,401,403,404,409,422].includes(r.status)&&['ValidationFault','AuthenticationFault','AuthorizationFault'].includes(d.Fault?.type)&&Array.isArray(d.Fault?.Error)){
    proposal.status='rejected';proposal.errors=d.Fault.Error.map((e:any)=>({code:String(e.code||'').slice(0,100),message:String(e.Detail||e.Message||'Rejected').slice(0,1000)}));await writeFile(path(proposalId),JSON.stringify(proposal));await unlink(active);submitted=false
    return res.status(422).json({success:false,status:'rejected',proposalId,error:'QuickBooks rejected the header update. Your draft was kept. Check the receipt, correct the fields and prepare a new preview.'})
   }
   if(!r.ok||String(d.Invoice?.Id)!==id)throw Error('Unverified update response.')
   const actual=await invoice(c,id),fields=invoiceReviewFields(actual)
   if(!/^\d+$/.test(String(actual.SyncToken))||String(actual.SyncToken)===proposal.syncToken)throw Error('Updated invoice revision could not be verified.')
   if(financialSnapshot(actual)!==proposal.financialHash||proposal.review.some((change:any)=>(fields as any)[change.field]!==change.after))throw Error('Header or unchanged accounting data could not be verified.')
   const expected=proposal.customFields.map((f:any)=>({id:String(f.DefinitionId),type:f.Type,value:f.StringValue??f.NumberValue??f.DateValue??f.BooleanValue})).sort((a:any,b:any)=>a.id.localeCompare(b.id))
   const observed=(actual.CustomField||[]).map((f:any)=>({id:String(f.DefinitionId),type:f.Type,value:f.StringValue??f.NumberValue??f.DateValue??f.BooleanValue})).sort((a:any,b:any)=>a.id.localeCompare(b.id))
   if(hash(expected)!==hash(observed))throw Error('Unchanged custom fields could not be verified.')
   proposal.status='applied';proposal.verifiedAt=new Date().toISOString();proposal.newSyncToken=String(actual.SyncToken)
   await writeFile(path(proposalId),JSON.stringify(proposal));await unlink(active)
   return res.json({success:true,status:'applied',invoiceId:id,syncToken:String(actual.SyncToken),fields,verifiedAt:proposal.verifiedAt})
  }catch(e:any){return res.status(submitted?502:400).json({success:false,proposalId:proposal?.proposalId,error:submitted?'Update outcome is uncertain. Keep your draft and inspect the receipt and QuickBooks before another submission.':/^(Provide|Unknown|Header|This header|No header|Company connection)/.test(String(e.message))?e.message:'Could not validate the header operation. Verify owner/company and refresh; your fields were kept.'})}
 })
}
