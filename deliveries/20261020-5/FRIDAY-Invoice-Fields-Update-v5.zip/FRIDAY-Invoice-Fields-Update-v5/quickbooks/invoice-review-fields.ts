import {moneyMinor,moneyText} from './document-review-money'
import {customerNameMatch,nameKey} from '../public/customer-name-match.js'
// START [QUICKBOOKS-26A] Raw custom invoice fields and exact claim comparison
const norm=(v:string)=>v.toLowerCase().replace(/[^a-z0-9]/g,'')
export const invoiceFieldLabels = {poReferenceNumber:'PO Reference no.',service:'SERVICE',monthClaim:'CLAIM / MONTH',jobLocationCarrier:'JOB LOCATION / CARRIER',jobName:'JOB NAME'} as const
export type InvoiceHeaderField = keyof typeof invoiceFieldLabels
const aliases:Record<InvoiceHeaderField,string[]> = {
 poReferenceNumber:['poreferenceno','poreferencenumber','poreference','pono','ponumber','purchaseordernumber','purchaseorderreference'],
 service:['service','services'],monthClaim:['month','claim','claimnumber','monthclaim','claimmonth','claimno','monthclaimnumber','claimmonthnumber'],
 jobLocationCarrier:['joblocation','carrier','joblocationcarrier','locationcarrier','carrierjoblocation'],jobName:['jobname']
}
export function invoiceReviewFields(invoice:any) {
 const raw=Array.isArray(invoice.CustomField)?invoice.CustomField:[]
 const customFields=raw.map((f:any)=>({id:String(f.DefinitionId||''),name:String(f.Name||''),type:String(f.Type||''),value:['StringValue','NumberValue','DateValue','BooleanValue'].map(k=>f[k]).find(v=>v!==undefined&&v!==null)})).map((f:any)=>({...f,value:f.value==null?null:String(f.value)}))
 const fields:any={},fieldInfo:any={}
 for(const key of Object.keys(invoiceFieldLabels) as InvoiceHeaderField[]){
  const matches=customFields.filter((f:any)=>aliases[key].includes(norm(f.name)))
  const field=matches.length===1?matches[0]:null
  const source=field?raw.find((f:any)=>String(f.DefinitionId||'')===field.id&&String(f.Name||'')===field.name):null
  const editable=!!field?.id&&!!source&&(!source.Type||source.Type==='StringType')&&(source.Type==='StringType'||typeof source.StringValue==='string')&&!['NumberValue','DateValue','BooleanValue'].some(k=>source[k]!==undefined&&source[k]!==null)&&customFields.filter((f:any)=>f.id===field.id).length===1
  fields[key]=field?.value??null
  fieldInfo[key]={label:invoiceFieldLabels[key],status:matches.length>1?'ambiguous':!field?'unavailable':field.value==null||field.value===''?'blank':'available',editable,definitionId:field?.id||null,name:field?.name||null,type:field?.type||null,
   message:matches.length>1?'Multiple QuickBooks fields match this label; resolve the definition in QuickBooks.':!field?'QuickBooks did not expose this header field in the invoice API response.':editable?'': 'QuickBooks did not return one editable text-field definition. Numeric claim values cannot recover leading zeros.'}
 }
 const lineServices=[...new Set((invoice.Line||[]).map((l:any)=>l.SalesItemLineDetail?.ItemRef?.name).filter((v:any)=>typeof v==='string'&&v.trim()))]
 return {customFields,...fields,lineServices,fieldInfo}
}
export function invoiceHeaderPatch(invoice:any,changes:unknown){
 if(!changes||typeof changes!=='object'||Array.isArray(changes))throw Error('Provide header field changes.')
 const keys=Object.keys(changes),current=invoiceReviewFields(invoice)
 if(!keys.length||keys.length>5)throw Error('Provide one to five changed header fields.')
 const customFields=structuredClone(invoice.CustomField||[]),review:any[]=[]
 for(const key of keys){
  if(!Object.hasOwn(invoiceFieldLabels,key))throw Error('Unknown invoice header field.')
  const value=(changes as any)[key],info=current.fieldInfo[key]
  if(typeof value!=='string'||value.length>500||/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(value))throw Error('Header values must be text up to 500 characters.')
  if(!info.editable)throw Error('This header has no unique editable QuickBooks text definition: '+invoiceFieldLabels[key as InvoiceHeaderField])
  const field=customFields.find((f:any)=>String(f.DefinitionId)===info.definitionId)
  if(value===String((current as any)[key]??''))continue
  field.StringValue=value;field.Type='StringType'
  review.push({field:key,label:invoiceFieldLabels[key as InvoiceHeaderField],definitionId:info.definitionId,before:(current as any)[key]??'',after:value})
 }
 if(!review.length)throw Error('No header values changed.')
 return {customFields,review}
}
export function amountCents(input:unknown):number|null {
 if(input===null||input===undefined||input==='')return null
 const value=String(input).trim().replace(/[$,\s]/g,'').replace(/^\((.+)\)$/,'-$1')
 if(!/^-?\d{1,10}(?:\.\d{1,2})?$/.test(value))throw new Error('Unreadable amount; correct the source row before comparison.')
 const negative=value.startsWith('-'),[whole,fraction='']=value.replace('-','').split('.')
 return (negative?-1:1)*(Number(whole)*100+Number(fraction.padEnd(2,'0')))
}
export function compareDocumentRow(row:any,invoices:any[],basis:'total'|'balance',customers:any[]=[]) {
 const name=nameKey
 const customer=name(row.customer),claim=String(row.claim||'').trim(),invoiceNo=String(row.invoiceNumber||'').trim()
 const contains=(hay:any,needle:any)=>!!name(needle)&&name(hay).includes(name(needle))
 const identities=new Map<string,any>()
 for(const c of customers){const matches=(c.names||[]).map((alias:any)=>({alias,match:customerNameMatch(row.customer,alias)})).filter((v:any)=>v.match).sort((a:any,b:any)=>b.match.score-a.match.score);if(matches.length)identities.set(String(c.id),matches[0])}
 const candidates=invoices.flatMap(invoice=>{
  const evidence:string[]=[]
  const identity=identities.get(String(invoice.customerId)),nameMatch=identity?.match || customerNameMatch(row.customer,invoice.customerName)
  if(nameMatch?.kind==='NORMALIZED')evidence.push('Same customer')
  else if(nameMatch)evidence.push('Possible customer name: '+nameMatch.kind.toLowerCase())
  const matchedName=identity?.alias || invoice.customerName
  if(claim && String(invoice.monthClaim||'').trim()===claim)evidence.push('Exact claim')
  if(invoiceNo && String(invoice.docNumber||'').trim()===invoiceNo)evidence.push('Exact invoice number')
  if(customer && (contains(invoice.jobName,customer)||customerNameMatch(row.customer,invoice.jobName)))evidence.push('Customer Name in invoice Job Name')
  if(contains(invoice.jobLocationCarrier,row.carrier))evidence.push('Carrier / office')
  if(contains(invoice.jobLocationCarrier,row.location))evidence.push('Location')
  if(contains(invoice.service,row.service)||contains(invoice.description,row.service))evidence.push('Service')
  if(!evidence.length)return []
  let difference=null,quickBooksAmount=null,sourceAmount=null,amountStatus='NEEDS_REVIEW',amountReason='Missing or unreadable amount / currency.'
  const currency=String(row.currency||'USD')
  try {
   const expected=moneyMinor(row.amount,currency),actual=moneyMinor(basis==='total'?invoice.totalAmount:invoice.balance,invoice.currency)
   if(expected!==null)sourceAmount=moneyText(expected,currency)
   if(actual!==null)quickBooksAmount=moneyText(actual,invoice.currency)
   if(currency!==invoice.currency)amountReason='Different or unknown currencies; no amount comparison.'
   else if(expected!==null && actual!==null){difference=moneyText(actual-expected,currency);amountStatus=actual===expected?'EQUAL':'DIFFERENT';amountReason=actual<expected?'Invoice amount is lower. A referral fee may explain this; owner review required.':'QuickBooks amount minus source COST.'}
  }catch{}
  return [{...invoice,evidence,sourceAmount,quickBooksAmount,difference,amountStatus,amountReason,
    identityStatus:evidence.includes('Same customer')||evidence.includes('Exact claim')?'RELATED':'POSSIBLE',nameScore:nameMatch?.score || 0,matchedCustomerName:matchedName,nameMatchKind:nameMatch?.kind || null,selected:false}]
 }).sort((a,b)=>Number(b.evidence.includes('Exact claim'))-Number(a.evidence.includes('Exact claim')) || Number(b.evidence.includes('Same customer'))-Number(a.evidence.includes('Same customer')) || b.nameScore-a.nameScore || b.evidence.length-a.evidence.length)
 return {status:candidates.length?'NEEDS_REVIEW':'NOT_FOUND',reason:candidates.length?'All related options shown. Select invoices and record your own review; amounts alone do not confirm identity.':'No related invoice found in the complete selected-company snapshot.',candidates}
}
