# Validation

Automated tests use synthetic owners, records and fake QuickBooks responses, temporary private storage, and actual Chromium. They do not use the uploaded statements, real credentials or live accounting.

Run from project root after installing existing locked dependencies:

```
node --import tsx --test tests/invoice-fields.test.ts
```

Invoice suite: 12 specific cases / 14 Node-reported entries, covering reversed labels and leading zeros, actual nonstandard field IDs, unavailable/blank/ambiguous/numeric values, full scoped pagination beyond 1000, incomplete reads, real registered route DTOs, owner/company/realm/source binding, stale revisions, cancelled/rejected/uncertain requests, durable no-replay receipts, header-only sparse save preserving negative referral fees and unrelated financial/custom fields. Chromium exercises Sales and Customer360, API-omitted fields, fresh reads, draft retention, approved saves, native links, paired natural voice actions and pointer, and company changes.

Combined regression command (pg-mem helper for the existing suites is cloud-local):

```
FRIDAY_TEST_TOOLS=/workspace/scratch/friday-test-tools node --import tsx --test tests/invoice-fields.test.ts tests/live-bank-feed.test.ts tests/bank-workflows.test.ts tests/document-review.test.ts
```

Combined result: 79 reported entries passed, zero failures/skips (71 specific cases plus eight parent entries).

Frontend TypeScript and backend TypeScript checks pass. Standalone Vite build with configFile:false passes with existing bundle-size warning. This validates frontend compilation without replacing the owner's Windows TLS config. The ordinary Windows build, PowerShell installer execution, live OAuth/custom-field exposure, native links/QuickBooks writes, saved Chrome bank-reader login/selectors and actual microphone require owner-PC validation. No claim of live QuickBooks synchronization or successful Windows installation is made.
