# FRIDAY Invoice Fields v5 — 20261020-5

For Salvador and Dayanna's existing PC-hosted FRIDAY at S:\AI\friday-ai. Install over Live Bank Feed v4. If the installer reports a baseline mismatch, stop and obtain a package based on the installed files; do not force replacement or manually copy files. No dependency/configuration/AGENTS/database replacement. No accounting writes happen during installation or read/search/preview.

## Changes

Fixes the reversed CLAIM / MONTH label missing from FRIDAY's MONTH / CLAIM mapping. Preserves leading zeros as text. Displays PO Reference no., SERVICE, CLAIM / MONTH, JOB LOCATION / CARRIER and JOB NAME in Sales, Customer360 and invoice view. SERVICE header remains separate from product/service lines. The dedicated Refresh button reads current QuickBooks invoice fields; this is an explicit read, not a background sync timer.

Filter loaded invoice details remains a local filter. Search QuickBooks reads all supported pages for the company or selected customer using verified owner scope, reports unavailable fields and capped results, and rejects incomplete/repeated pages. Visible results include actual invoice/customer QuickBooks links. Natural conversation supports PO, header SERVICE, claim/month, carrier/location, job name and separate line-service searches, with visible pointer. Voice cannot submit accounting changes.

The header editor uses real uniquely returned QuickBooks text custom-field DefinitionIds. API-omitted, duplicate/ambiguous or nontext fields are visibly disabled; no IDs, private configuration or missing values are invented. Native QBO can show advanced fields that its Accounting API does not return, including PO. Those require a separately verified integration approach if still unavailable. This fix cannot recover zeros already discarded by a numeric source field.

Review and save header changes opens a centered before/after owner confirmation. Only after approval does it submit a sparse header-only update with the actual SyncToken. It preserves negative referral lines, dates, tax and totals. It verifies a fresh QuickBooks receipt and unchanged financial data. Failed/cancelled edits remain in the form. Changing company/realm, stale data, or uncertain submission blocks reuse. Check header receipt and inspect native QuickBooks after an uncertain result; do not automatically retry. Existing full invoice editor remains separate; save or clear header edits before using its Save Invoice button. Existing unsaved financial edits are retained by header-only saves.

## Install from any PowerShell location

Stop only FRIDAY's backend. Extract this ZIP under S:\AI\Fixing-Files-Folder\FRIDAY-Invoice-Fields-Update-v5, then run:

```powershell
$packageRoot = 'S:\AI\Fixing-Files-Folder\FRIDAY-Invoice-Fields-Update-v5'
$installers = @(Get-ChildItem -LiteralPath $packageRoot -Filter 'Install-Invoice-Fields.ps1' -File -Recurse -ErrorAction Stop)
if ($installers.Count -ne 1) { throw 'Expected exactly one Install-Invoice-Fields.ps1. Check the extracted folder.' }
$installer = $installers[0].FullName
Unblock-File -LiteralPath $installer
Unblock-File -LiteralPath (Join-Path (Split-Path $installer) 'Restore-Invoice-Fields.ps1')
& $installer -ProjectPath 'S:\AI\friday-ai'
if (-not $?) { throw 'Installation failed. Do not continue.' }
Set-Location -LiteralPath 'S:\AI\friday-ai'
npm run build
if ($LASTEXITCODE -ne 0) { throw 'Build failed. Do not restart with an incomplete build.' }
npm run server
```

This command locates the extracted installer instead of relying on your current directory. Unblock-File removes the downloaded-file flag only from these two reviewed scripts. It does not change machine execution policy; an enforced signed-script policy still requires your approved signing procedure. Installer verifies package/baseline hashes and verified backup before copying only 12 listed files. It prints the backup path. No private configuration is added.

Hard-refresh dashboard and voice page (Ctrl+F5), close old invoice/review tabs. Verify owner using the existing owner verification dialog; never put keys in a URL or voice prompt.

## Owner-PC live check

1. Select Nationwide. Open a known invoice whose native QBO screen has CLAIM / MONTH beginning with zero. Use Refresh from QuickBooks and compare all five fields against the native screen; unavailable is not equivalent to blank.
2. Search QuickBooks for its claim, PO, SERVICE, carrier and job name from Sales and Customer360. Try the same read-only requests in the normal voice session. Confirm company/customer scope and visible pointer.
3. Open native invoice/customer links and confirm actual records.
4. Only on an invoice you intend to change, edit one API-exposed text header field, review before/after and approve. Verify receipt and native QuickBooks, including unchanged lines, total and balance. Cancel another preview and confirm no change. No live invoice was changed during cloud validation.
5. Recheck the existing Nationwide BOFA CONSTRUCTION – 7015 visible Chrome-feed button and Document Analysis private notes. These remain the existing modules.

## Restore

Stop FRIDAY. Run Restore-Invoice-Fields.ps1 from the backup path printed during install; then rebuild, restart and hard-refresh. Restore verifies backup/installed hashes and refuses to overwrite later edits. Private notes, invoice action receipts, databases and uploads remain. Do not delete receipts for uncertain requests.

Read VALIDATION.md for automated versus live coverage. AGENTS-MERGE-PROPOSAL.md is a proposal only and is never installed over AGENTS.md.
