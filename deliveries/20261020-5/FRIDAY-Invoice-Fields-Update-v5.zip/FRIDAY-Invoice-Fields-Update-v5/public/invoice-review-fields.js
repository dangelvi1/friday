// START [QUICKBOOKS-DASH-26A] Claim, carrier/location and job invoice columns/search
(() => {
 const escape=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))
 const match=(i,text,field)=>{const q=text.trim().toLowerCase();if(!q)return true;const values=field==='claim'?[i.monthClaim]:field==='carrier'?[i.jobLocationCarrier]:field==='job'?[i.jobName]:field==='po'?[i.poReferenceNumber]:field==='service'?[i.service]:field==='line_service'?(i.lineServices||[]):[i.docNumber,i.customerName,i.poReferenceNumber,i.service,i.monthClaim,i.jobLocationCarrier,i.jobName,...(i.lineServices||[])];return values.some(v=>String(v||'').toLowerCase().includes(q))}
 let currentCustomer='',search='',field='all',salesData=null
 function controls(body,scope){
  const id=scope==='customer'?'customerInvoiceDetailSearch':'salesInvoiceDetailSearch';let input=document.getElementById(id)
  if(!input){const wrap=document.createElement('div');wrap.className='sandra-toolbar';wrap.innerHTML=`<label>Filter loaded invoice details <input id="${id}" type="search" placeholder="PO, service, claim, carrier, location, job or invoice #" /></label><select id="${id}Field"><option value="all">All details</option><option value="po">PO Reference no.</option><option value="service">SERVICE header</option><option value="line_service">Product / service lines</option><option value="claim">CLAIM / MONTH</option><option value="carrier">JOB LOCATION / CARRIER</option><option value="job">JOB NAME</option></select><button type="button" data-search-quickbooks="${scope}">Search QuickBooks</button><span>Typing filters loaded invoices. Search QuickBooks reads the selected company/customer beyond loaded rows.</span>`;body.closest('.data-table-wrap').before(wrap);input=document.getElementById(id);const filter=document.getElementById(id+'Field');input.addEventListener('input',()=>{if(scope==='customer'){search=input.value;fridayRenderCustomer360Invoices()}else if(salesData)renderInvoices(salesData)});wrap.querySelector('[data-search-quickbooks]').addEventListener('click',()=>window.fridaySearchInvoiceDetails(input.value,filter.value,scope).catch(e=>fridayLog(e.message)));filter.addEventListener('change',()=>{if(scope==='customer'){field=filter.value;fridayRenderCustomer360Invoices()}else if(salesData)renderInvoices(salesData)})}
  return input
 }
 const oldCustomer=fridayRenderCustomer360Invoices
 fridayRenderCustomer360Invoices=function(){
  const body=document.getElementById('customer360InvoiceBody');if(!body)return oldCustomer()
  const id=String(fridayCustomer360State.customer?.id||''),input=controls(body,'customer')
  if(currentCustomer!==id){currentCustomer=id;search='';field='all';input.value='';document.getElementById('customerInvoiceDetailSearchField').value='all'}
  const rows=fridaySortCustomerInvoices(fridayCustomer360State.invoices.filter(i=>fridayCustomerInvoiceMatchesStatus(i,fridayCustomer360State.status)&&fridayCustomerInvoiceMatchesTerm(i,fridayCustomer360State.termId)&&match(i,search,field)),fridayCustomer360State.sort)
  body.closest('table').querySelector('thead').innerHTML='<tr>'+['Date','Type','No.','Customer','PO Reference no.','SERVICE','CLAIM / MONTH','JOB LOCATION / CARRIER','JOB NAME','Due date','Terms','Amount','Balance','Status','Email','Action'].map(v=>'<th>'+v+'</th>').join('')+'</tr>'
  body.innerHTML='';const count=document.getElementById('customer360FilteredCount');if(count)count.textContent=rows.length+' loaded invoice(s) shown'
  for(const i of rows){const tr=document.createElement('tr');tr.className='customer-invoice-row';tr.dataset.fridayVoiceInvoiceId=String(i.id);tr.innerHTML=[i.txnDate,'Invoice',i.docNumber||i.id,i.customerName,i.poReferenceNumber,i.service,i.monthClaim,i.jobLocationCarrier,i.jobName,i.dueDate,i.salesTermName,fridayMoney(i.totalAmount),fridayMoney(i.balance),i.isPaid?'Paid':i.isOverdue?'Overdue':'Open',i.billEmail].map(v=>'<td>'+escape(v??'—')+'</td>').join('')+'<td><button type="button">View</button></td>';tr.querySelector('button').addEventListener('click',()=>window.fridayOpenInvoiceDetail(i.id));body.appendChild(tr)}
  if(!rows.length)body.innerHTML='<tr><td colspan="16">No matching loaded invoices. A missing API custom field is not proof the claim is absent.</td></tr>'
 }
 const oldSales=renderInvoices
 renderInvoices=function(data){
  salesData=data;const body=document.getElementById('invoiceTableBody');if(!body)return oldSales(data)
  const input=controls(body,'sales'),filter=document.getElementById('salesInvoiceDetailSearchField'),rows=(data.invoices||[]).filter(i=>match(i,input.value,filter.value))
  oldSales({...data,invoices:rows});const header=body.closest('table').querySelector('thead tr');if(!header.dataset.reviewFields){for(const name of ['PO Reference no.','SERVICE','CLAIM / MONTH','JOB LOCATION / CARRIER','JOB NAME']){const th=document.createElement('th');th.textContent=name;header.appendChild(th)}header.dataset.reviewFields='true'}
  const rendered=Array.from(body.querySelectorAll('tr'));rows.forEach((invoice,index)=>{const tr=rendered[index];if(!tr)return;tr.dataset.fridayVoiceInvoiceId=String(invoice.id);for(const key of ['poReferenceNumber','service','monthClaim','jobLocationCarrier','jobName']){const td=document.createElement('td');td.textContent=invoice[key]??'—';tr.appendChild(td)}})
 }
 let searchTicket=0,remote=null
 const fieldsMap={all:'all',claim:'monthClaim',carrier:'jobLocationCarrier',job:'jobName',po:'poReferenceNumber',service:'service',line_service:'lineService'}
 function remotePanel(body){let panel=document.getElementById('invoiceFieldSearchResults');if(!panel){panel=document.createElement('section');panel.id='invoiceFieldSearchResults';panel.className='friday-invoice-field-results';panel.innerHTML='<h3>QuickBooks field search</h3><p data-field-search-status role="status"></p><div data-field-search-pages></div><div class="data-table-wrap"><table class="data-table"><thead><tr>'+['Invoice','Customer','PO Reference no.','SERVICE','CLAIM / MONTH','JOB LOCATION / CARRIER','JOB NAME','Total','Balance','Action'].map(n=>'<th>'+n+'</th>').join('')+'</tr></thead><tbody id="invoiceFieldSearchResultsBody"></tbody></table></div>';body.closest('.data-table-wrap').before(panel)}else body.closest('.data-table-wrap').before(panel);return panel}
 function renderRemote(){
  if(!remote)return
  const panel=document.getElementById('invoiceFieldSearchResults');if(!panel)return
  const rows=remote.invoices.slice(remote.page*100,remote.page*100+100),body=panel.querySelector('tbody');body.replaceChildren()
  for(const i of rows){const tr=document.createElement('tr');tr.className='friday-field-result-row';tr.dataset.fridayVoiceInvoiceId=i.id;tr.innerHTML=[i.docNumber||i.id,i.customerName,i.poReferenceNumber,i.service,i.monthClaim,i.jobLocationCarrier,i.jobName,fridayMoney(i.totalAmount),fridayMoney(i.balance)].map(v=>'<td>'+escape(v??'Not returned')+'</td>').join('')+'<td></td>';const view=document.createElement('button');view.type='button';view.textContent='View invoice';view.addEventListener('click',()=>window.fridayOpenInvoiceDetail(i.id));tr.cells[9].append(view);if(window.fridayQuickBooksLinkButton){tr.cells[0].append(window.fridayQuickBooksLinkButton('invoice',i.id));tr.cells[1].append(window.fridayQuickBooksLinkButton('customer',i.customerId))}body.append(tr)}
  if(!rows.length)body.innerHTML='<tr><td colspan="10">No matching exposed invoice fields. Review unavailable-field counts above.</td></tr>'
  const pages=panel.querySelector('[data-field-search-pages]');pages.replaceChildren();for(const [label,delta] of [['Previous',-1],['Next',1]]){const button=document.createElement('button');button.type='button';button.textContent=label;button.disabled=delta<0?remote.page===0:(remote.page+1)*100>=remote.invoices.length;button.addEventListener('click',()=>{remote.page+=delta;renderRemote()});pages.append(button)}pages.append(document.createTextNode(' Page '+(remote.page+1)+' of '+Math.max(1,Math.ceil(remote.invoices.length/100))))
 }
 window.fridaySearchInvoiceDetails=async function(value,which='all',preferredScope){
  if(typeof value!=='string'||!value.trim()||value.length>200||!Object.hasOwn(fieldsMap,which))throw Error('Choose a field and search text (1–200 characters).')
  let body=document.getElementById('customer360InvoiceBody'),customerId=''
  const customerVisible=body&&body.getClientRects().length&&fridayCustomer360State.customer
  if(preferredScope==='customer'||!preferredScope&&customerVisible){if(!customerVisible)throw Error('Open a customer first.');customerId=String(fridayCustomer360State.customer.id)}else{await fridayOpenDashboardPage('sales');body=document.getElementById('invoiceTableBody')}
  const companyKey=fridayQuickBooksState.companyKey,ticket=++searchTicket,panel=remotePanel(body),status=panel.querySelector('[data-field-search-status]')
  remote=null;panel.querySelector('tbody').replaceChildren();panel.querySelector('[data-field-search-pages]').replaceChildren();status.textContent='Reading current QuickBooks invoices for '+(customerId?'this customer':'this company')+'…';panel.hidden=false
  const filterScope=customerId?'customer':'sales',input=controls(body,filterScope);input.value=value;document.getElementById(input.id+'Field').value=which
  await fridayPointTo(input,250)
  try{
   if(ticket!==searchTicket||companyKey!==fridayQuickBooksState.companyKey)throw Error('Search stopped or company changed.')
   if(!window.fridayInvoiceFieldRequest)throw Error('Invoice field controls have not loaded. Refresh the page.')
   const params=new URLSearchParams({q:value.trim(),field:fieldsMap[which]});if(customerId)params.set('customerId',customerId)
   const response=await window.fridayInvoiceFieldRequest('/quickbooks/invoice-field-search/'+encodeURIComponent(companyKey)+'?'+params),data=await response.json()
   if(ticket!==searchTicket||companyKey!==fridayQuickBooksState.companyKey||customerId&&String(fridayCustomer360State.customer?.id)!==customerId)throw Error('Invoice search scope changed; response discarded.')
   if(!response.ok||!data.success||data.companyKey!==companyKey||String(data.customerId||'')!==customerId||data.completeRead!==true)throw Error(data.error||'Complete scoped search unavailable.')
   remote={...data,page:0};renderRemote();const unavailable=Object.entries(data.unavailableCounts||{}).map(([k,v])=>({poReferenceNumber:'PO Reference no.',service:'SERVICE',monthClaim:'CLAIM / MONTH',jobLocationCarrier:'JOB LOCATION / CARRIER',jobName:'JOB NAME'}[k]||k)+': '+v).join(' · ')
   status.textContent=`${data.totalMatches} match(es) from ${data.scannedCount} QuickBooks invoices in ${customerId?'this customer':'this company'} · refreshed ${new Date(data.readAt).toLocaleString()}. ${data.truncated?'First 5,000 matches shown; narrow the search.':''}${unavailable?' Fields not exposed or ambiguous: '+unavailable+'.':''} Line services are separate from the SERVICE header.`
   return {scope:customerId?'selected customer':'selected company',completeRead:true,scannedCount:data.scannedCount,totalMatches:data.totalMatches,truncated:data.truncated,unavailableCounts:data.unavailableCounts,rows:data.invoices.slice(0,100).map(i=>({id:i.id,docNumber:i.docNumber,customerName:i.customerName,poReferenceNumber:i.poReferenceNumber,service:i.service,monthClaim:i.monthClaim,jobLocationCarrier:i.jobLocationCarrier,jobName:i.jobName,lineServices:i.lineServices,matchedFields:i.matchedFields})),returnedVoiceRows:Math.min(100,data.invoices.length),limitedToLoadedInvoices:false,readOnly:true}
  }catch(e){if(ticket===searchTicket&&companyKey===fridayQuickBooksState.companyKey)status.textContent=e.message;throw e}
 }
 function updateLoadedFields(e){const d=e.detail;if(d.companyKey!==fridayQuickBooksState.companyKey)return;for(const collection of [salesData?.invoices,fridayCustomer360State.invoices]){for(const i of collection||[])if(String(i.id)===d.invoiceId)Object.assign(i,d.fields)}if(salesData)renderInvoices(salesData);if(fridayCustomer360State.customer)fridayRenderCustomer360Invoices();searchTicket++;remote=null;const panel=document.getElementById('invoiceFieldSearchResults');if(panel){panel.querySelector('tbody').replaceChildren();panel.querySelector('[data-field-search-status]').textContent=e.type==='friday-invoice-fields-refreshed'?'Invoice fields refreshed from QuickBooks. Search again to refresh current matches.':'Invoice fields saved and verified. Search again to refresh current matches.'}}
 document.addEventListener('friday-invoice-fields-saved',updateLoadedFields)
 document.addEventListener('friday-invoice-fields-refreshed',updateLoadedFields)
 document.addEventListener('friday-invoice-search-stop',()=>{searchTicket++;const status=document.querySelector('#invoiceFieldSearchResults [data-field-search-status]');if(status)status.textContent='Search stopped. A read already in flight may finish; no new results will be displayed.'})
 document.addEventListener('sandra-company-changed',()=>{searchTicket++;remote=null;document.getElementById('invoiceFieldSearchResults')?.remove();currentCustomer='';search='';field='all';salesData=null;for(const id of ['salesInvoiceDetailSearch','customerInvoiceDetailSearch']){const e=document.getElementById(id);if(e)e.value=''}})
})()
// END [QUICKBOOKS-DASH-26A] Claim, carrier/location and job invoice columns/search
