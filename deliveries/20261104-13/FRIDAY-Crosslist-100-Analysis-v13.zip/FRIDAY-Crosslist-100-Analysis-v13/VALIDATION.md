# Validation — Crosslist Analyse 100 v13

Full regression: all 175 reported entries passed with no failures/skips. Uses synthetic owner keys, intercepted Crosslist pages, mocked photo-AI results and actual Chromium. No real Crosslist/OpenAI/Shopify/Vinted/QuickBooks accounts or paid AI requests were used.

```sh
FRIDAY_TEST_TOOLS=/workspace/scratch/friday-test-tools node --import tsx --test tests/crosslist-analysis.test.ts tests/crosslist-edit.test.ts tests/crosslist.test.ts tests/vinted.test.ts tests/calendar-context.test.ts tests/calendar-event-actions.test.ts tests/calendar-cancel.test.ts tests/voice-approvals.test.ts tests/calendar.test.ts tests/invoice-fields.test.ts tests/live-bank-feed.test.ts tests/bank-workflows.test.ts tests/document-review.test.ts
```

After final Brand label-boundary/lazy-photo hardening, all 18 focused editor/analysis entries passed again. These tests reproduce the grouped Brand structure missed in v12, require unique label/control association, reject actual Brand ambiguity, distinguish an unrelated unsaved control from Brand detection failure, show precise missing-Vinted/color diagnostics and reveal a lazy product photo without changing fields.

The 100-item Chromium test starts from the middle of a real fixture sequence, rewinds through Previous, visits 100 unique UUIDs and analyses all 100 description/photo pairs with different per-item brands/colors. It verifies 100 ready proposals, source/session binding, a 100-item before/after review, original unsaved price retention and zero Save/Post requests from analysis. Additional cases cover stopped jobs, shorter-than-requested traversal, AI unavailability without invented colors, owner-private history and metadata redaction. Actual UI checks start/stop/progress/history/ready-queue/cancel behavior. Existing owner voice, Crosslist correction save/stop, Calendar, banking, invoices, Document Analysis and private-file regressions passed.

Frontend TypeScript, targeted backend TypeScript and standalone Vite compilation passed. Existing >500KB chunk warning remains. Windows TLS config, dependencies, private configuration and credentials are unchanged. Package CRC, source/baseline/package hashes and private-data/secret-pattern exclusions are checked. Installer/restore PowerShell reviewed, not executed: Windows/S: drive are unavailable in cloud.

Not verified live: actual Crosslist grouped DOM/pagination/lazy-loading/timing, real OpenAI model/account/structured-output responses or costs, physical microphone, native Save validation/connected-marketplace propagation, Windows installation/rollback and desktop wrapper. The provider request uses the existing private OPENAI_API_KEY at runtime; no key is invented or exposed. No website-block bypass or direct Vinted automation is added. Unknown fields/images/provider errors remain visible review items rather than fabricated results. Browser revision checks are optimistic, not an atomic external-edit lock.

Analysis does not Save/Post or synchronize stock/orders. Applying ready proposals is a separate immutable owner-reviewed correction queue, with preserved unrelated values and durable receipts/claims. Test one actual Save before a larger apply pass. Private analysis journals remain on the PC and are excluded from GitHub artifacts. Code rollback cannot undo external saves or provider usage already incurred.
