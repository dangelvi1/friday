# FRIDAY Crosslist Analyse 100 v13 — 20261104-13

For Salvador/Dayanna's existing FRIDAY at S:\AI\friday-ai, installed over Crosslist Corrections v12. Addresses the reported generic editor-reading failure and adds one background analysis run covering up to 100 unique Crosslist listings for the Vinted workflow. This does not use the blocked direct Vinted browser session.

## What changed

- Fixes Brand detection when its label/dropdown share a grouped layout with other fields, as opposed to the isolated wrapper used by the old fixture. It still requires the observed Brand label and one uniquely identifiable remaining editor combobox. Multiple possible controls stop reading rather than selecting the first one.
- Checks login, Vinted view and exact field/dropdown identities before waiting for photos. Names the failing field, unchecked Vinted view, ambiguous Brand or missing/loading photo, instead of returning the same generic error. Pending lazy-loaded product photos are brought into view without changing form values. Unknown DOM errors remain safely redacted; credentials/cookies/raw HTML are not exposed.
- Adds **Analyse 100 listings**, progress/stop/history and ready-proposal import to the Crosslist panel. Start from any actual listing editor; FRIDAY opens a separate scanning tab, rewinds with the observed Previous control and walks forward with Next. It does not use an unexamined dashboard row or invent listing IDs.
- Original tab/unsaved edits are retained. Selecting Vinted on the scanning/verification tab exposes its fields but no Save/Post is clicked there. Scanning is sequential to keep each actual description/photo paired; up to three AI requests may run concurrently. This is one 100-item job, not 100 parallel editable browser forms.
- Each item gets description-based brand evidence, the requested New without tags proposal, product-photo color suggestions and confidence/review flags. Never copy Navy/White across the catalog. AI colors must be exact observed palette choices. Ambiguous brands, low/medium confidence, invalid colors, unreadable fields/photos and unsupported clearing stay for review. No category, shipping, size, price, condition facts, stock or eligibility are invented.
- Progress distinguishes listing IDs visited, fields fully read, photos analysed, ready proposals and items needing review. If the sequence ends before 100, repeats or fails, the actual count is reported. If more listings exist after the requested 100, the limit/more-available flag is reported. A completed traversal with unresolved items is completed_with_review, not proof that all photos were analysed successfully.

## AI configuration and privacy

Photo analysis uses the PC's existing OPENAI_API_KEY through the OpenAI Responses API. No key is included, changed or requested in voice/chat. Default model is gpt-4.1-mini; the optional existing-environment setting FRIDAY_CROSSLIST_ANALYSIS_MODEL can select another compatible image/structured-output model, but no private configuration is invented or edited by installation.

The job sends each product description and a cropped product-photo JPEG to the configured OpenAI service. Normal API usage applies. It never sends owner keys, Crosslist passwords, cookies, full account screenshots or internal-note fields. Only one readable product photo is analysed per listing; review colors if other views show additional details. If API configuration/access fails, remaining text reads continue and unavailable colors are flagged rather than guessed. There is no automatic paid-request retry loop.

Owner-private analysis journals live under credentials\commerce\crosslist\[owner]\analyses. Product snapshots/receipts stay on the PC and are never included in GitHub deliveries. Recent analyses remain visible after page reload; a server-interrupted run is reported interrupted and is not automatically resumed or claimed complete.

## Start the 100-item analysis

1. Open Crosslist dashboard setup in the existing voice page and verify the private owner key/workspace.
2. Open any actual listing editor in the dedicated Crosslist Chrome tab. You do not need to manually open all 100 listings. Existing unsaved edits can remain; analysis works in a separate tab.
3. Click **Analyse 100 listings**, or say **“Analyse all 100 Crosslist listings for Vinted.”** Keep FRIDAY's backend running. The progress screen updates automatically. A connected voice session receives completion counts/status.
4. Stop analysis prevents remaining reads/AI requests where possible. A request already processed by the AI provider can still incur usage. No listing Save/Post is submitted by analysis.
5. Inspect the ready/review counts and individual reasons. Click **Add ready proposals to review queue** when the analysis finishes or stops. Existing manually queued choices are retained. Unknown items are not silently included as ready.

The reviewed correction queue now supports up to 100 individually captured/proposed records. Adding results does not save them. Review and save queue displays exact before/after and still requires one specific owner decision. Cancel retains queued notes. Source/session/protected-value/revision checks and durable receipts/claims remain. An active editor with unrelated unsaved changes is protected before navigation to other queued records. Save/discard those yourself before approving an apply pass; analysis does not discard them for you.

The Save workflow may enable the already-approved Vinted field view on freshly navigated editor pages. Other marketplace selections remain protected. It clicks Save only, never Post/Delist/Delete. Browser checks are optimistic, not an atomic lock against external edits. Do not edit the same queued records in other sessions while applying.

## Live-test boundary

The 100-item scanner and review UI were exercised with actual Chromium and synthetic pages/AI results. No live Crosslist/OpenAI/marketplace calls were used during cloud tests. Actual Crosslist pagination, grouped DOM, lazy-loading and Save propagation need owner-PC validation. The new detailed diagnostics identify unsupported live controls without guessing.

Test one real Save first before applying 100 changes. Missing native category/size/shipping validation is not bypassed. A direct Post is never clicked; no inventory/order synchronization or verified Vinted eligibility/publication is claimed. Native Crosslist Save may have downstream effects that only an owner-PC test can establish. Stop prevents remaining saves, not a write already submitted. Uncertain outcomes are checked by receipt, not automatically resubmitted.

## Install from any PowerShell directory

Stop FRIDAY's backend and Vite process. Extract under S:\AI\Fixing-Files-Folder\FRIDAY-Crosslist-100-Analysis-v13, then run:

```powershell
$packageRoot = 'S:\AI\Fixing-Files-Folder\FRIDAY-Crosslist-100-Analysis-v13'
$installers = @(Get-ChildItem -LiteralPath $packageRoot -Filter 'Install-Crosslist-100.ps1' -File -Recurse -ErrorAction Stop)
if ($installers.Count -ne 1) { throw 'Expected exactly one installer. Check the extracted folder.' }
$installer = $installers[0].FullName
Unblock-File -LiteralPath $installer
Unblock-File -LiteralPath (Join-Path (Split-Path $installer) 'Restore-Crosslist-100.ps1')
& $installer -ProjectPath 'S:\AI\friday-ai'
if (-not $?) { throw 'Installation failed. Do not continue.' }
Set-Location -LiteralPath 'S:\AI\friday-ai'
npm run build
if ($LASTEXITCODE -ne 0) { throw 'Build failed. Do not continue.' }
npm run server
```

In another terminal:

```powershell
Set-Location -LiteralPath 'S:\AI\friday-ai'
npm run dev
```

Ctrl+F5 at https://localhost:5173/ and reconnect voice. No dependency installation, migration, OAuth reset, credentials copying or certificate changes. Installer validates package/baseline/required file hashes and creates a verified backup before copying seven app/test files. It refuses incompatible installed source. Private data/config/Chrome profile and AGENTS.md are preserved. PowerShell reviewed, not executed in this Linux cloud. Enforced signed-script policy is not overridden.

## Restore

Stop FRIDAY. Run Restore-Crosslist-100.ps1 from the printed backups\crosslist-100-v13-[timestamp] directory, rebuild/restart both processes, hard-refresh and reconnect voice. Hash checks refuse later edits. Private journals/receipts/claims remain. Rollback does not undo saved Crosslist corrections or AI usage already incurred. A running read-only analysis interrupted by restart is reported incomplete/interrupted; it does not automatically save any result.
