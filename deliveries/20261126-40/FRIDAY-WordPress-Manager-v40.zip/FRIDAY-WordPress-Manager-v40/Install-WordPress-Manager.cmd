@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-WordPress-Manager.ps1" -ProjectPath "S:\AI\friday-ai"
if errorlevel 1 (
  echo Installation stopped. Read the error above; no force option is provided.
  pause
  exit /b 1
)
pushd "S:\AI\friday-ai"
if errorlevel 1 exit /b 1
call npm.cmd run build
if errorlevel 1 (
  echo Build failed. Stop here. Keep the verified backup.
  popd
  pause
  exit /b 1
)
popd
echo Source installation and build finished. Initialize the WordPress key if needed, then restart FRIDAY once.
echo No website changes or advertising requests were submitted by this installer.
pause
