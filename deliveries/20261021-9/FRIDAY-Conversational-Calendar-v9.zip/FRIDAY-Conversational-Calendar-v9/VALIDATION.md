# Validation — Conversational Calendar v9

Cloud checks used synthetic owners, credentials, calendars, events, invoices, statements and temporary storage. Actual Chromium exercised the real review registry, voice gate/hub, Calendar panel, paired dashboard and Document Analysis interfaces. Google/OpenAI/QuickBooks were not connected for these tests.

Full regression: 136 reported entries passed, comprising 121 specific checks and 15 parent tests, with no skips/failures:

```sh
FRIDAY_TEST_TOOLS=/workspace/scratch/friday-test-tools node --import tsx --test tests/calendar-context.test.ts tests/calendar-event-actions.test.ts tests/calendar-cancel.test.ts tests/voice-approvals.test.ts tests/calendar.test.ts tests/invoice-fields.test.ts tests/live-bank-feed.test.ts tests/bank-workflows.test.ts tests/document-review.test.ts
```

Covers actual-ID/numbered focus despite duplicate titles, no guessing from incomplete/empty/expired reads, contextual short answers only after a specific current question, company-bound questions, interruption-safe explicit commands, single consumption per microphone item, draft-versus-saved cancellation, sparse editing and DST/all-day duration, owner/mapping/ETag/recurring protections, preserved guests/private properties, lost-response verification, durable duplicate protection, existing financial/file/voice regressions. Actual browser read→focus→modify→one yes→cancel-it flow passed.

After final hardening to preserve the earliest approval-question timestamp during streaming, accept courtesy references, and return a cached dispatch even when a duplicate model call omits its review ID, the focused Calendar-context and actual voice/browser suites were rerun: all 28 reported entries passed. The final courtesy-reference change also passed all seven Calendar-context entries. See included tests for exact assertions. No global “yes” bypass was introduced.

Frontend TypeScript and targeted Calendar backend TypeScript passed. Standalone Vite compilation passed with the existing >500 KB chunk warning. Cloud build intentionally does not load the PC-specific HTTPS certificate paths from vite.config.ts; that file was preserved. Package ZIP CRC, package/baseline hashes and exclusions were checked. PowerShell scripts were reviewed, not executed: PowerShell/Windows and the owner's actual S: drive are unavailable here.

Not tested live: physical microphone/ASR timing, actual Google OAuth/account ACLs, real event creation/edit/deletion or guest updates, employee visibility on the actual shared calendar, QuickBooks mutations, Windows installer/rollback execution and the desktop wrapper. Installer changes code only, preserves private configuration/data and creates a verified backup. Existing Google connections do not need reconnecting. Source rollback does not undo live Calendar changes.
