// Explicit live speech confirms the current displayed review in the verified owner session.
export const normalizeApproval=(s:unknown)=>String(s||'').normalize('NFKD').replace(/\p{M}/gu,'').toLowerCase().replace(/&/g,' and ').replace(/[^\p{L}\p{N}]+/gu,' ').trim()
export function approvalCommand(text:string){
 let s=normalizeApproval(text)
 // Natural courtesy words and the assistant's name do not change an explicit command.
 s=s.replace(/^(?:(?:please|friday|por favor|can you|could you|would you|go ahead and) )+/,'').replace(/(?: (?:please|por favor|now))+$/,'')
 s=s.replace(/^(?:yes|okay|ok|sure) (?=(?:approve|confirm|cancel|delete|remove)\b)/,'')
 if(/^(?:yes|yeah|yep|okay|ok|sure|go ahead|do it|yes please|okay do it|si|claro|adelante)$/.test(s))return{decision:'approve',company:'',contextual:true}
 if(/^(?:no|no thanks|never mind|nevermind)$/.test(s))return{decision:'reject',company:'',contextual:true}
 if(/^(?:(?:no )?(?:cancel|delete|remove|reject|dismiss)(?: it| that| this| this action| that action| this event| that event| the event| this invoice| that invoice| this file| that file| the pending event| the pending approval| my event| the appointment| that appointment| this appointment)?|stop|cancela(?:lo| eso| ese evento| la aprobacion)?|rechaza(?:lo| eso)?)$/.test(s))return{decision:'reject',company:''}
 const match=s.match(/^(?:(?:yes )?(?:i )?(?:approve|confirm)(?: it| that| this| this action| that action| this event| that event| the event| this invoice| that invoice| this file| that file)?|(?:si )?(?:aprueba(?:lo| eso| ese evento| esa factura)?|confirma(?:lo| eso)?))(?: (?:for|para) (.+))?$/)
 return match?{decision:'approve',company:match[1]||''}:null
}
export class VoiceApprovalGate {
 private pending:any=null
 private speech:any=null
 private candidate:any=null
 private lastSpeech:any=null
 private cancellationItems=new Set<string>()
 private savedIntent:any=null
 private question:any=null
 private assistantText=''
 private assistantResponse=''
 private editIntent:any=null
 private seen=new Set<string>()
 private clock:()=>number
 constructor(clock=()=>Date.now()){this.clock=clock}
 // Re-inspecting a review must never erase the owner's command.
 begin(review:any){if(this.pending?.id!==review?.id||this.pending?.version!==review?.version){this.question=null;this.assistantText=''}this.pending=review}
 reset(){this.pending=null;this.speech=null;this.candidate=null;this.lastSpeech=null;this.savedIntent=null;this.question=null;this.editIntent=null;this.assistantText=''}
 // Retained for transport compatibility. Audible playback is not an approval/cancellation fence.
 audioStart(_id=''){}
 audioTranscript(_text:string,_id=''){}
 audioStopped(_id=''){}
 interrupted(){}
 speechStarted(id:string){if(!id)return;this.speech={id,at:this.clock()};this.candidate=null}
 userTranscript(id:string,text:string){
  if(this.seen.has(id)||this.speech?.id!==id)return
  this.seen.add(id);if(this.seen.size>500)this.seen.delete(this.seen.values().next().value!)
  this.lastSpeech={id,text,at:this.clock()}
  const command=approvalCommand(text)
  this.candidate=command?{...command,at:this.clock(),speechAt:this.speech.at,id}:null
 }
 async waitNamedCancellation(title:string,reference=false,selection=false){const deadline=Date.now()+2500;while(this.speech&&this.lastSpeech?.id!==this.speech.id&&Date.now()<deadline)await new Promise(r=>setTimeout(r,30));return this.consumeNamedCancellation(title,reference,selection)}
 consumeNamedCancellation(title:string,allowCurrentReference=false,allowSelection=false){
  const utterance=this.lastSpeech,spoken=normalizeApproval(utterance?.text).replace(/^(?:(?:please|friday|por favor|can you|could you|would you) )+/,'')
  const name=normalizeApproval(title)
  const explicit=/^(?:cancel|delete|remove|cancela|elimina|borra)\b/.test(spoken)
  const named=name.length>=2&&(' '+spoken+' ').includes(' '+name+' ')
  const reference=allowCurrentReference&&this.directSavedCancellation()&&approvalCommand(utterance?.text||'')?.decision==='reject'
  const selection=allowSelection&&this.savedIntent?.title===name&&this.savedIntent.until>this.clock()&&!/^(?:what|when|why|how|which|que|cuando)\b/.test(spoken)&&!/\b(?:no|not|don t|never|instead|keep|stop|change)\b/.test(spoken)&&/\b(?:one|first|second|third|morning|afternoon|evening|today|tomorrow|monday|tuesday|wednesday|thursday|friday|saturday|sunday|personal|nationwide|primero|segundo|lunes|martes|miercoles|jueves|viernes|sabado|domingo|\d+)\b/.test(spoken)
  if(!utterance||this.clock()-utterance.at>20000||this.cancellationItems.has(utterance.id)||!(selection||explicit&&(named||reference)))throw Error('The live command does not identify this saved event for cancellation. Do not ask for approval again; use the current selected event or the event actually spoken.')
  this.cancellationItems.add(utterance.id);this.savedIntent={title:name,until:this.clock()+90000};return{itemId:utterance.id}
 }
 speechItemId(){return this.lastSpeech?.id||null}
 directSavedCancellation(){return /^(?:(?:please|friday|can you|could you|would you|go ahead and|yes|okay|ok|sure) )*(?:cancel|delete|remove)(?: it| that| this| that event| this event| the event| my event| the appointment| that appointment| this appointment)?(?: please| now)*$/.test(normalizeApproval(this.lastSpeech?.text))&&!this.cancellationItems.has(this.lastSpeech?.id)}
 command(){return this.candidate?{decision:this.candidate.decision,speechAt:this.candidate.speechAt,contextual:!!this.candidate.contextual,reviewId:this.candidate.contextual?this.question?.id:null}:null}
 noteAssistant(text:string,response='',complete=false){
  if(response&&response!==this.assistantResponse){this.assistantResponse=response;this.assistantText='';this.question=null}
  this.assistantText=complete?text:(this.assistantText+text).slice(-8000)
  const spoken=normalizeApproval(this.assistantText),p=this.pending
  if(!p||!/(?:shall i|should i|do you want|would you like|can i|may i|ready to|do you approve|do you confirm|please confirm|is that okay|is that correct|does that look right|shall we|should we|quieres|deseas|debo|confirmas|apruebas)/.test(spoken)||!/(?:approve|confirm|save|create|update|reschedule|delete|cancel|proceed|go ahead|guardar|aprobar|confirmar|cancelar|actualizar)/.test(spoken))return
  if(p.requiredSpokenCompany&&!spoken.includes(normalizeApproval(p.requiredSpokenCompany)))return
  if(this.question?.id!==p.id||this.question?.version!==p.version)this.question={id:p.id,version:p.version,at:this.clock(),company:p.requiredSpokenCompany||''}
 }
 async authorizeModification(eventId:string,hasChanges:boolean){
  const deadline=Date.now()+2500;while(this.speech&&this.lastSpeech?.id!==this.speech.id&&Date.now()<deadline)await new Promise(r=>setTimeout(r,30))
  const u=this.lastSpeech,s=normalizeApproval(u?.text).replace(/^(?:(?:please|friday|can you|could you|would you) )+/,'')
  const explicit=/^(?:modify|change|move|reschedule|edit|update|rename|make|cambia|modifica|mueve)\b/.test(s)
  const continuation=this.editIntent?.eventId===eventId&&this.editIntent.until>this.clock()&&!/^(?:what|when|why|how|which)\b/.test(s)&&!/\b(?:no|not|don t|never|cancel|stop|keep)\b/.test(s)&&/\b(?:\d+|am|pm|morning|afternoon|tomorrow|monday|tuesday|wednesday|thursday|friday|saturday|sunday|title|location|notes)\b/.test(s)
  if(!u||this.clock()-u.at>20000||!explicit&&!continuation)throw Error('Use the actual spoken modification request for the event under discussion.')
  this.editIntent={eventId,until:this.clock()+90000};return{needsChanges:!hasChanges}
 }
 async waitAndConsume(id:string,decision:string){
  const deadline=Date.now()+2500
  while(this.pending?.id===id&&!this.candidate&&this.speech&&this.clock()-this.speech.at<20000&&Date.now()<deadline)await new Promise(r=>setTimeout(r,30))
  return this.consume(id,decision)
 }
 consume(id:string,decision:string){
  const p=this.pending,c=this.candidate
  if(!p||p.id!==id||!c||c.decision!==decision||this.clock()-c.at>20000||decision==='approve'&&this.clock()>p.expiresAt)throw Error('No explicit live voice command is available for this pending review. Do not repeat the review or approval question automatically.')
  if(decision==='approve'&&(!Number.isFinite(p.createdAt)||c.speechAt<p.createdAt))throw Error('This review was created after the spoken command. Show the new action before approving it.')
  const question=this.question?.id===p.id&&this.question?.version===p.version&&this.question.at<=c.speechAt&&c.speechAt-this.question.at<90000?this.question:null
  if(c.contextual&&!question)throw Error('A short yes/no needs a specific approval question about this current action; do not treat it as a global command.')
  if(question?.company&&!c.company)c.company=question.company
  if(decision==='approve'&&p.requiredSpokenCompany&&normalizeApproval(c.company)!==normalizeApproval(p.requiredSpokenCompany))throw Error('Include the full production company name shown in this review; the action has not been submitted.')
  if(this.cancellationItems.has(c.id))throw Error('This spoken command was already used. Inspect its result; do not perform a second action.')
  this.cancellationItems.add(c.id);this.candidate=null;return{review:p,spokenCompany:c.company}
 }
}
export function handleApprovalTransportEvent(gate:VoiceApprovalGate,event:any){
 if(event.type==='input_audio_buffer.speech_started')gate.speechStarted(event.item_id)
 if(event.type==='response.output_audio_transcript.delta')gate.noteAssistant(event.delta||'',event.response_id||'')
 if(event.type==='response.output_audio_transcript.done')gate.noteAssistant(event.transcript||'',event.response_id||'',true)
 if(event.type==='conversation.item.input_audio_transcription.completed')gate.userTranscript(event.item_id,event.transcript||'')
}
