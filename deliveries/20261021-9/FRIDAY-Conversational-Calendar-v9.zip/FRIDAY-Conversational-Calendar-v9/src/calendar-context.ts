// Actual IDs from the verified owner's read; titles are labels, never the authority for "it".
export class CalendarContext {
 private rows:any[]=[]
 private focused:any=null
 private scope:any=null
 private expiresAt=0
 private clock:()=>number
 constructor(clock=()=>Date.now()){this.clock=clock}
 clear(){this.rows=[];this.focused=null;this.scope=null;this.expiresAt=0}
 read(data:any){this.clear();if(!data.readScope||data.completeRead!==true)return;this.scope=data.readScope;this.rows=structuredClone(data.events||[]);this.expiresAt=this.clock()+600000;if(this.rows.length===1)this.focused=this.rows[0]}
 focus(id:string){if(this.clock()>this.expiresAt)throw Error('Calendar discussion expired. Read the relevant schedule again.');const event=this.rows.find(e=>e.id===id);if(!event)throw Error('Select an actual event from the current schedule, not a guessed title/ID.');this.focused=event;return this.current()}
 current(){if(!this.focused||this.clock()>this.expiresAt)return null;return{event:structuredClone(this.focused),sourceScope:structuredClone(this.scope),expiresAt:this.expiresAt}}
 idAt(index:number){if(!Number.isSafeInteger(index)||index<1||index>this.rows.length)throw Error('Choose a numbered event from the current schedule.');return this.rows[index-1].id}
 remember(event:any,sourceScope:any){if(JSON.stringify(this.scope)===JSON.stringify(sourceScope)){const index=this.rows.findIndex(e=>e.id===event.id);if(index>=0)this.rows[index]=structuredClone(event);else this.rows.push(structuredClone(event))}else this.rows=[structuredClone(event)];this.scope=sourceScope;this.focused=structuredClone(event);this.expiresAt=this.clock()+600000}
}
