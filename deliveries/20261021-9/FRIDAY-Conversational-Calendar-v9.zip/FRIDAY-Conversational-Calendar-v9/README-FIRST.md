# FRIDAY Conversational Calendar v9 — 20261021-9

For Salvador and Dayanna's working FRIDAY at S:\AI\friday-ai. Install over Immediate Voice Commands v8. Keeps the existing natural voice session, owner authentication, company isolation and visible pointer.

## What changes

- After a complete schedule read, a sole event becomes the event under discussion. With multiple events, FRIDAY focuses an actual event ID/number before discussing a specific one. The panel shows numbered events and “Discuss this event” buttons. Duplicate titles never choose a target automatically.
- “Cancel it”, “Please cancel the event”, “Delete it” and similar direct commands cancel the focused saved event without repeating its title or asking another approval. FRIDAY stops current audio when you start speaking. No pending approval may exist for this automatic saved-event command; pending draft cancellation takes precedence and cannot also delete a saved event.
- “Approve it” and “Confirm” remain direct current-review commands. “Yes”, “Okay”, “Sure”, “Go ahead”, “Do it” and short “No” answer only a specific current approval question. They are not global permissions. The question is tied to the exact review/version, bounded in time and cleared by a different assistant response or review. Production invoice approval still binds the exact full company; FRIDAY must include it in the actual question or the owner command must name it.
- “Modify it” asks only what should change. Provide date/time, title, location or notes. A centered before/after review opens; one “yes” to the save question submits it once. Cancelling that review leaves the saved event untouched. Existing guests receive Google's normal update/cancellation notices when the saved event changes.
- Context is private owner-page memory, expires after ten minutes, and clears on empty/incomplete reads, locking/profile changes and changed calendar mapping/account. A stale event revision requires a fresh read. It cannot switch from Personal to Nationwide by guessing. A genuinely ambiguous event needs selection by number/date/time/calendar; the title does not have to be repeated. Recurring masters are never modified/deleted by guessing a whole series.

Only requested edit fields are patched. Existing guests, private properties and unrelated fields are verified after saving. Owner, connection, mapping, event ID and ETag are checked again. Private one-time claims and receipts prevent automatic retries after uncertainty. No QuickBooks logic, financial records, credentials, Google authorizations, existing configuration, databases or private uploads are included or changed by installation. Speech confirms within the verified owner session; this does not enable biometric speaker identification.

## Install from any PowerShell directory

Stop FRIDAY's backend and Vite process. Extract the ZIP under S:\AI\Fixing-Files-Folder\FRIDAY-Conversational-Calendar-v9. Run:

```powershell
$packageRoot = 'S:\AI\Fixing-Files-Folder\FRIDAY-Conversational-Calendar-v9'
$installers = @(Get-ChildItem -LiteralPath $packageRoot -Filter 'Install-Conversational-Calendar.ps1' -File -Recurse -ErrorAction Stop)
if ($installers.Count -ne 1) { throw 'Expected exactly one installer. Check the extracted folder.' }
$installer = $installers[0].FullName
Unblock-File -LiteralPath $installer
Unblock-File -LiteralPath (Join-Path (Split-Path $installer) 'Restore-Conversational-Calendar.ps1')
& $installer -ProjectPath 'S:\AI\friday-ai'
if (-not $?) { throw 'Installation failed. Do not continue.' }
Set-Location -LiteralPath 'S:\AI\friday-ai'
npm run build
if ($LASTEXITCODE -ne 0) { throw 'Build failed. Do not continue.' }
npm run server
```

In a separate PowerShell terminal:

```powershell
Set-Location -LiteralPath 'S:\AI\friday-ai'
npm run dev
```

Ctrl+F5 at https://localhost:5173/, disconnect/reconnect voice, close old dashboard/review tabs and reopen through FRIDAY. No Google reconnect or dependency install is needed. Installer verifies all package/baseline/required hashes, creates a verified backup, copies only eleven listed files, and rolls back a failed copy. It refuses incompatible versions. It does not override an enforced signed-script policy.

## Live test on your PC

1. Verify the owner in Calendar. Ask “What events do I have tomorrow?” With one event, say “Please cancel it” only if you intend to delete it. Expect immediate interruption and one verified cancellation, without a title question.
2. With several events, select one by its number/time. Say “Modify it”, then “Move it to [time/date]” or “Change the location to [location]”. Review the before/after once. Answer “Yes” to its save question. Confirm exactly one update in Google Calendar.
3. Prepare a disposable new draft. Say “Cancel” while she speaks; the dialog closes without saving or deleting any older event. Prepare it again and say “Approve it” once, or answer “Yes” to her specific creation question.
4. If an outcome is uncertain, use Check last receipt or recent receipts and inspect the original Google event; do not issue another write or remove claim files. Shared Nationwide edits/cancellations affect the office calendar and may notify existing guests.

Live microphone timing/recognition, Google's real event/guest behavior and PowerShell execution are PC checks; cloud checks use synthetic data. See VALIDATION.md. Existing >500KB bundle warning remains informational.

## Restore

Stop FRIDAY and run Restore-Conversational-Calendar.ps1 from the printed backups\conversational-calendar-v9-[timestamp] folder. Rebuild, restart backend/dev, hard-refresh and reconnect voice. Restore validates hashes and refuses later source edits. It restores app code only; it does not undo a Calendar action already performed. Existing AGENTS.md is never overwritten; the merge proposal is separate.
