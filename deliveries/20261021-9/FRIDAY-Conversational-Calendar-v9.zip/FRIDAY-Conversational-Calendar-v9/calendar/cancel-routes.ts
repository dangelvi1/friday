import {checkSource} from './event-actions'
import {randomUUID} from 'node:crypto'
import {mkdir,writeFile,readdir} from 'node:fs/promises'
import {CalendarError,digest,privatePath,readPrivate,savePrivate,locked,text} from './core'
const options={timeout:20000,retry:false}
const normalize=(v:unknown)=>String(v||'').normalize('NFKD').replace(/\p{M}/gu,'').replace(/&/g,' and ').replace(/[^\p{L}\p{N}]+/gu,' ').trim().toLowerCase()
const recordPath=(owner:string,id:string)=>{if(!/^[a-f0-9-]{36}$/.test(id))throw new CalendarError('Invalid cancellation review.');return privatePath('cancellations',owner,id+'.json')}
const display=(p:any)=>({id:p.id,title:p.title,destination:p.destination,calendarName:p.calendarName,eventId:p.eventId,start:p.start,end:p.end,timeZone:p.timeZone,status:p.status,attendeeCount:p.attendeeCount||0,expiresAt:p.expiresAt})
function localDate(e:any,zone:string){if(e.start?.date)return e.start.date;try{const parts=new Intl.DateTimeFormat('en-CA',{timeZone:e.start?.timeZone||zone,year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(new Date(e.start.dateTime));const p=Object.fromEntries(parts.map(x=>[x.type,x.value]));return`${p.year}-${p.month}-${p.day}`}catch{return''}}
export function registerCalendarCancellation(app:any,{endpoint,selected,stillSelected}:any){
 app.get('/calendar/cancellations',endpoint(async(_req:any,res:any,owner:string)=>{let files:string[]=[];try{files=await readdir(privatePath('cancellations',owner))}catch(e:any){if(e.code!=='ENOENT')throw e}const rows=[];for(const f of files){if(!/^[a-f0-9-]{36}\.json$/.test(f))continue;const r=await readPrivate(privatePath('cancellations',owner,f));if(r.owner===owner)rows.push(r)}rows.sort((a,b)=>b.expiresAt-a.expiresAt);res.json({success:true,reviews:rows.slice(0,30).map(display),total:rows.length})}))
 app.post('/calendar/events/cancel/find',endpoint(async(req:any,res:any,owner:string)=>{
 const title=req.body.title?text(req.body.title,'event title',200,true):'',date=String(req.body.date||''),start=String(req.body.start||''),targetId=String(req.body.eventId||'')
 if(date&&(!/^\d{4}-\d{2}-\d{2}$/.test(date)||!Number.isFinite(Date.parse(date))||new Date(date).toISOString().slice(0,10)!==date))throw new CalendarError('Provide a real occurrence date.')
 if(start&&!Number.isFinite(Date.parse(start)))throw new CalendarError('Provide a valid exact occurrence start.')
 if(targetId&&!/^[a-zA-Z0-9_-]{1,300}$/.test(targetId))throw new CalendarError('Invalid current-event reference.')
 if(!title&&!targetId)throw new CalendarError('Identify the event by its current context or title.')
 const destinations=req.body.destination?[req.body.destination]:['personal','nationwide'],matches:any[]=[]
 for(const target of destinations){const s=await selected(owner,target);if(targetId&&req.body.sourceScope){checkSource(owner,s,req.body);const e=(await s.api.events.get({calendarId:s.calendar.id,eventId:targetId},options)).data;if(e.id!==targetId||e.status==='cancelled')continue;if(!req.body.expectedETag||req.body.expectedETag!==e.etag)throw new CalendarError('Event changed since the conversation. Read its current details first.',409);matches.push({s,e});await stillSelected(owner,s);continue}if(!title)throw new CalendarError('Current-event scope is required.');const tokens=new Set(),ids=new Set();let pageToken:string|undefined
 do{if(tokens.size>=100||pageToken&&tokens.has(pageToken))throw new CalendarError('Event lookup was incomplete or repeated. No cancellation submitted.');if(pageToken)tokens.add(pageToken)
 const around=date?Date.parse(date+'T00:00:00Z'):0
 const r=await s.api.events.list({calendarId:s.calendar.id,q:title,showDeleted:false,singleEvents:!!date,maxResults:250,...(date?{timeMin:new Date(around-36*3600000).toISOString(),timeMax:new Date(around+60*3600000).toISOString()}:{}),...(pageToken?{pageToken}:{})},options)
 if(!r.data||r.data.items!==undefined&&!Array.isArray(r.data.items))throw new CalendarError('Event lookup did not complete.')
 for(const e of r.data.items||[]){if(!e.id||ids.has(e.id))throw new CalendarError('Repeated/missing event ID. No cancellation submitted.');ids.add(e.id);if(e.status==='cancelled'||normalize(e.summary)!==normalize(title)||date&&localDate(e,s.calendar.timeZone||'America/New_York')!==date||start&&Date.parse(e.start?.dateTime)!==Date.parse(start)||targetId&&e.id!==targetId)continue
 matches.push({s,e})}
 pageToken=r.data.nextPageToken
 }while(pageToken);await stillSelected(owner,s)
 }
 const choices=matches.map(({s,e})=>({title:e.summary,destination:s.target,calendarName:s.calendar.name,start:e.start,end:e.end,timeZone:e.start?.timeZone||s.calendar.timeZone||null,recurringSeries:!!e.recurrence?.length}))
 if(matches.length!==1||matches[0].e.recurrence?.length)return res.json({success:true,status:matches.length?'needs_selection':'not_found',matches:choices,message:matches.length===1?'This is a recurring series. Specify the occurrence date; the whole series was not cancelled.':matches.length?'More than one event has this title. Identify the date/time or calendar; no second approval is needed for that selection.':'No exact event title matched. Nothing was cancelled.'})
 const {s,e}=matches[0];if(!e.etag)throw new CalendarError('Event revision unavailable. Nothing was cancelled.')
 const p={id:randomUUID(),owner,connectionId:s.c.id,mappingRevision:s.m.revision,calendarId:s.calendar.id,destination:s.target,calendarName:s.calendar.name,eventId:e.id,etag:e.etag,title:e.summary,start:e.start,end:e.end,timeZone:e.start?.timeZone||s.calendar.timeZone||null,eventType:e.eventType||'default',attendeeCount:e.attendees?.length||0,expiresAt:Date.now()+120000,status:'prepared'}
 // Non-default event kinds and attendee messages require their own explicit workflow.
 if(p.eventType!=='default')throw new CalendarError('This is a special Google event type. Use its dedicated Google Calendar controls; no changes were made.')
 await savePrivate(recordPath(owner,p.id),p);res.json({success:true,status:'matched',review:display(p)})
 }))
 app.post('/calendar/events/cancel/:id/:action',endpoint(async(req:any,res:any,owner:string)=>locked('owner:'+owner,async()=>{
 if(!['execute','receipt'].includes(req.params.action))throw new CalendarError('Unsupported cancellation action.')
 const file=recordPath(owner,req.params.id),p=await readPrivate(file);if(p.owner!==owner)throw new CalendarError('Cancellation belongs to another owner.',403)
 const s=await selected(owner,p.destination);if(s.c.id!==p.connectionId||s.m.revision!==p.mappingRevision||s.calendar.id!==p.calendarId)throw new CalendarError('Calendar selection/account changed. No new cancellation was submitted.',409)
 async function check(){try{const r=await s.api.events.get({calendarId:p.calendarId,eventId:p.eventId},options);if(r.data.id===p.eventId&&r.data.status==='cancelled'){p.status='cancelled';await savePrivate(file,p)}}catch(e:any){const code=Number(e.response?.status||e.code);if([404,410].includes(code)){p.status='cancelled';await savePrivate(file,p)}}}
 if(req.params.action==='receipt'){if(p.status==='uncertain')await check();return res.json({success:true,review:display(p)})}
 if(p.status==='cancelled')return res.json({success:true,status:'cancelled',review:display(p)})
 if(p.status!=='prepared'||p.expiresAt<Date.now()||req.body.approved!==true)throw new CalendarError('Cancellation expired or was already submitted. Check its receipt; no automatic retry.',409)
 const current=(await s.api.events.get({calendarId:p.calendarId,eventId:p.eventId},options)).data
 if(current.id!==p.eventId)throw new CalendarError('Event identity could not be verified. Nothing was cancelled.',409)
 if(current.status==='cancelled'){p.status='cancelled';await savePrivate(file,p);return res.json({success:true,status:'cancelled',review:display(p)})}
 if(current.etag!==p.etag||normalize(current.summary)!==normalize(p.title)||JSON.stringify(current.start)!==JSON.stringify(p.start)||JSON.stringify(current.end)!==JSON.stringify(p.end)||current.recurrence?.length)throw new CalendarError('Event changed since lookup. Nothing was cancelled. Identify the current event again.',409)
 await mkdir(privatePath('cancellations','claims'),{recursive:true,mode:0o700});const claim=privatePath('cancellations','claims',digest({owner,connectionId:p.connectionId,calendarId:p.calendarId,eventId:p.eventId})+'.json')
 try{await writeFile(claim,JSON.stringify({reviewId:p.id}),{flag:'wx',mode:0o600})}catch{throw new CalendarError('This event cancellation was already submitted. Check its original receipt and Google Calendar.',409)}
 p.status='uncertain';await savePrivate(file,p)
 try{await s.api.events.delete({calendarId:p.calendarId,eventId:p.eventId,sendUpdates:p.attendeeCount?'all':'none'},{...options,headers:{'If-Match':p.etag}});await check()}catch{}
 if(p.status!=='cancelled')throw new CalendarError('Cancellation outcome is uncertain. Inspect its receipt and Google Calendar; do not resubmit.',502)
 return res.json({success:true,status:'cancelled',review:display(p)})
 })))
}
