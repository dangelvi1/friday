# FRIDAY Document Analysis update — 20261014-1

This updates the existing PC-hosted modular app. It does not migrate hosting, reconnect OAuth, create/edit/send QuickBooks invoices, or change Nationwide/Sara services. All invoice access in this feature is read-only. Owner credentials remain in the owner PC configuration and are entered only in the current review tab.

## What changes

The dashboard and full-width page use the same redesigned interface: saved analyses, multiple-file uploads, adding finished documents to the current analysis, combining selected existing analyses, edit/delete/restore controls, 50/100/200/300 rows per page, related-row counts and links, same-name filtering, possible similar-name references, and original source viewing. Deleted rows stay recoverable and original row numbers do not change. Combined reviews retain source filenames, source ordinals and page references. Original saved analyses remain available.

Source extraction imports Claim, Date Created, Loss Date, INSURED (Customer/Job Name), TRADE (Service), City State Zipcode, Office (Carrier/Insurance), and COST. It retains repeats, leading zeros, exact amount strings, explicit currency, and USD for blank currency. Old reviews remain readable; re-extract original documents for new date/field extraction. Missing old fields remain unavailable.

Invoice options include every invoice for a resolved matching customer plus related job/claim/carrier/location/service options. Ambiguous identities are not automatically merged; each candidate shows customer ID, evidence, total/balance and exact per-candidate difference. A lower invoice can suggest a referral fee but does not prove one. No automatic fee subtraction, combined-row totals or payment assumptions. Selections and decisions are owner-reviewed.

Open in QuickBooks uses the production invoice URL and requires a company confirmation dialog. QuickBooks determines its current company from the signed-in browser session: verify Nationwide/Robal inside QuickBooks before viewing or manually editing. Sandbox direct links are deliberately unavailable. Live sign-in/deep-link behavior still needs your PC-side check. FRIDAY does not perform edits through these links.

Save progress persists private notes/selections while unresolved; Mark reviewed saves a final snapshot, then PDF is available. Source edits, row removals, combining, re-extraction, changed notes and new comparisons invalidate the final PDF. Existing notes remain visible for reconfirmation; stale selections are not automatically reapplied. Unresolved items stay Needs review in the report. PDF has clickable invoice links and a disclosed standard-font text approximation where characters cannot be represented; exact original text remains in JSON.

Expenses is added to the existing conversational navigation allowlist. The original Realtime session, pairing and visible pointer are retained. Audio interruption and deeper voice controls still require live testing; this package does not replace voice with a push-to-talk form or harden all older Gmail/QuickBooks write routes.

## Install on the owner PC

1. Extract into its own staging folder under `S:\AI\Fixing-Files-Folder`. Do not copy the entire package over the project manually.
2. Stop only the FRIDAY backend (`Ctrl+C` in its `npm run server` terminal). Keep PostgreSQL, the speaker service and Nationwide Operations running.
3. Open PowerShell in this package folder:

```powershell
& .\Install-Document-Analysis.ps1 -ProjectPath 'S:\AI\friday-ai'
```

The installer checks the audited source/dependency baselines before any replacement, verifies package/backup/copied file hashes, and records a timestamped backup. A changed/new-existing file stops installation: do not bypass it; use the current installed file for a compatible patch. The obsolete Sandra Phase1 manifest is not used or rewritten. No dependency declaration or lockfile is changed, and no npm install is needed if the supplied project's dependencies are already installed (including pdf-lib).

4. Restart `npm run server` from `S:\AI\friday-ai`. Close old full-review tabs and hard-refresh the dashboard (`Ctrl+Shift+R`). If using the frontend dev server, keep the existing `npm run dev` workflow.
5. Load Document Analysis with your existing owner credential and company. The first authenticated request creates **additive** private PostgreSQL columns: excluded rows, notes, notes revision, pending documents and reviewed snapshot. It does not touch accounting records. Preserve your normal private DB backup before accepting new review data. Application file rollback leaves these columns/data intact.

## Working with added documents

Upload one or multiple files with explicit AI consent. Each file is saved/extracted individually (5 MB per file, 1–50 PDF pages). After extraction completes, use **Add finished pending documents** to combine new attachments, or check saved analyses and **Combine selected documents**. Pending IDs are saved so a tab restart does not lose successfully uploaded documents. An incomplete source blocks combining rather than accepting partial rows. If some uploads fail, successful ones remain saved; retry only failed files to avoid uploading duplicates. The combined limit is 50 documents/10,000 rows.

Confirm all active source rows before Find invoice options. Review choices/notes, Save progress, then Mark reviewed and download PDF. Excluded unreadable rows remain retained as original source and do not block confirmation of the active rows. Restoring them invalidates comparison again. Notes/errors stay on screen after a failed save; successful upload/edit forms clear while retaining the owner credential.

## Rollback

Stop only FRIDAY backend. In the printed backup folder run `& .\Restore-Document-Analysis.ps1`, restart FRIDAY and hard-refresh. Restore checks installed and backup hashes and refuses to erase subsequent edits. It restores original files and removes new files; private DB columns/notes remain, rather than being destructively rolled back. Keep your backup until this update is accepted.

## Validation and limits

See VALIDATION.md. The delivered code was tested offline with synthetic customers/documents/invoices, an in-memory PostgreSQL emulator and real Chromium. No live OAuth, microphone, QuickBooks, Windows installation, or customer/employee service test was performed. The normal frontend build requires your PC TLS keys; a build-only override was used here without changing the runtime config or disabling TLS verification. The existing broader authorization issues from the audit remain separate work.

The test file uses existing project libraries plus a separate test-only pg-mem installation; it is not a runtime dependency. To reproduce on a suitable Node 24 machine, install pg-mem into a separate test-tools directory, set FRIDAY_TEST_TOOLS to its absolute path and FRIDAY_CHROMIUM to an existing Chromium executable, then run `node --import tsx --test tests/document-review.test.ts`. Tests create temporary synthetic owner credentials and intercept external API calls; do not point the harness at production services.
