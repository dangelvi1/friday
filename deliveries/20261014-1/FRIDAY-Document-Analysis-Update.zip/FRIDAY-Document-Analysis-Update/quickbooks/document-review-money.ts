export function currencyPrecision(currency:string) {
 if(!/^[A-Z]{3}$/.test(currency) || !Intl.supportedValuesOf('currency').includes(currency)) throw Error('Invalid currency. Choose a supported three-letter code.')
 const precision=new Intl.NumberFormat('en-US',{style:'currency',currency}).resolvedOptions().maximumFractionDigits
 if(precision===undefined)throw Error('Invalid currency precision.')
 return precision
}
export function moneyMinor(input:unknown,currency='USD'): bigint|null {
 if(input==null || String(input).trim()==='')return null
 const precision=currencyPrecision(currency)
 let value=String(input).trim().replace(/^\((.+)\)$/,'-$1').replace(/^(-?)\$/,'$1')
 if(!/^-?(?:\d+|\d{1,3}(?:,\d{3})+)(?:\.\d+)?$/.test(value))throw Error('Unreadable amount; correct the source row before comparison.')
 value=value.replace(/,/g,'')
 const negative=value.startsWith('-'),[whole,fraction='']=value.replace(/^-/,'').split('.')
 if(whole.length>15 || fraction.length>precision)throw Error('Unreadable amount precision for '+currency+'.')
 return (negative?-1n:1n)*(BigInt(whole)*10n**BigInt(precision)+BigInt(fraction.padEnd(precision,'0')||'0'))
}
export function moneyText(minor:bigint,currency='USD') {
 const precision=currencyPrecision(currency),negative=minor<0n,absolute=(negative?-minor:minor).toString().padStart(precision+1,'0')
 return (negative?'-':'')+(precision?absolute.slice(0,-precision)+'.'+absolute.slice(-precision):absolute)
}
export function quickBooksInvoiceLink(id:string,environment:string) {
 if(!/^\d{1,20}$/.test(id))throw Error('Invalid invoice ID.')
 // The company is the signed-in QBO session; require an explicit company check.
 if(environment!=='production')return null
 return 'https://app.qbo.intuit.com/app/invoice?txnId='+encodeURIComponent(id)
}
