// Pure private-review rules. No database, network or QuickBooks writes.
export const MAX_REVIEW_ROWS = 10000
export const sourceFields = ['customer','claim','createdDate','lossDate','service','location','carrier','jobName','invoiceNumber'] as const
export function nameKey(value: unknown) {
  return String(value ?? '').normalize('NFKC').toLocaleLowerCase('en-US').replace(/\s+/g,' ').trim()
}
export function reviewRows(review: any): any[] {
  return (review.extraction?.rows || []).map((raw: any,index: number) => {
    const edited = review.draft_rows?.[index] || review.confirmed_rows?.[index] || raw
    return {...raw,...edited,ordinal:index+1,documentId:raw.documentId || review.id,
      documentName:raw.documentName || review.filename,sourceOrdinal:raw.sourceOrdinal || index+1,
      amount:edited.amount ?? raw.amounts?.[0]?.value ?? null,
      currency:String(edited.currency ?? raw.amounts?.[0]?.currency ?? '').trim() || 'USD'}
  })
}
export function activeReviewRows(review: any) {
  const excluded=new Set(review.excluded_rows || [])
  return reviewRows(review).filter(row=>!excluded.has(row.ordinal))
}
export function mergeReviews(target: any,sources: any[]) {
  if (target.extraction?.coverage?.complete!==true) throw Error('Source extraction must be complete before combining.')
  const rows=reviewRows(target), documents=new Map<string,any>()
  const addDocuments=(review:any)=>{
    const list=review.extraction?.documents || [{id:review.id,filename:review.filename,coverage:review.extraction.coverage}]
    for (const doc of list) documents.set(doc.id,doc)
  }
  addDocuments(target)
  const notes={...(target.review_notes || {})}, excluded=[...(target.excluded_rows || [])]
  for (const source of sources) {
    if(source.id===target.id || source.extraction?.coverage?.complete!==true) throw Error('Source document is incomplete or is the current review.')
    const docs=source.extraction?.documents || [{id:source.id,filename:source.filename,coverage:source.extraction.coverage}]
    if(docs.some((d:any)=>documents.has(d.id))) throw Error('Source document is already part of this analysis. Repeated rows are retained, but the same document cannot be added twice.')
    const offset=rows.length
    for(const row of reviewRows(source)) rows.push({...row,ordinal:rows.length+1})
    for(const n of source.excluded_rows || []) excluded.push(n+offset)
    for(const [key,value] of Object.entries(source.review_notes || {})) notes[Number(key)+offset]={...(value as any),stale:true}
    addDocuments(source)
  }
  if(rows.length>MAX_REVIEW_ROWS || documents.size>50) throw Error('Source limit: 10,000 rows and 50 documents per analysis.')
  const list=[...documents.values()]
  return {rows,documents:list,excluded,notes,coverage:{complete:true,totalPages:list.reduce((n,d)=>n+(d.coverage?.totalPages || 0),0),processedPages:list.reduce((n,d)=>n+(d.coverage?.processedPages || 0),0),extractedRows:rows.length,documents:list}}
}
export function validateProgress(body:any,review:any) {
  if(Number(body.expectedRevision)!==review.revision || Number(body.expectedReviewRevision)!==(review.review_revision || 0)) throw Error('Source or notes changed. Reload before saving; your entries are retained.')
  if(!Array.isArray(body.rows)||body.rows.length>MAX_REVIEW_ROWS) throw Error('Invalid progress rows.')
  const valid=new Set(activeReviewRows(review).map(r=>r.ordinal)),seen=new Set<number>()
  const comparison=review.comparison, result={...(review.review_notes || {})}
  for(const row of body.rows) {
    if(!Number.isSafeInteger(row.ordinal)||!valid.has(row.ordinal)||seen.has(row.ordinal)) throw Error('Invalid or repeated progress row.')
    seen.add(row.ordinal)
    if(typeof row.notes!=='string'||row.notes.length>4000||!['needs_review','match','difference'].includes(row.decision)) throw Error('Invalid notes or review decision.')
    if(!Array.isArray(row.invoiceIds)||row.invoiceIds.length>20000||row.invoiceIds.some((id:any)=>typeof id!=='string'||!/^\d{1,20}$/.test(id))||new Set(row.invoiceIds).size!==row.invoiceIds.length) throw Error('Invalid selected invoices.')
    const candidates=comparison?.rows?.find((r:any)=>r.ordinal===row.ordinal)?.candidates || []
    if(row.invoiceIds.some((id:string)=>!candidates.some((c:any)=>c.id===id))) throw Error('Invoice selection is not in this row’s scoped comparison. Compare again before selecting.')
    if(row.decision!=='needs_review' && !comparison) throw Error('Source comparison required before completing a decision.')
    if(row.decision!=='needs_review' && !row.invoiceIds.length) throw Error('Invoice selection required for a reviewed match or difference. Use Needs review if unresolved.')
    result[row.ordinal]={notes:row.notes,decision:row.decision,invoiceIds:row.invoiceIds,comparisonId:comparison?.id || null,stale:false}
  }
  return result
}
