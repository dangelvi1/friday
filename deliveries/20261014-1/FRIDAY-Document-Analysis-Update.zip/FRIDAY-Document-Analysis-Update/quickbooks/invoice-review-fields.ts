import {moneyMinor,moneyText} from './document-review-money'
// START [QUICKBOOKS-26A] Raw custom invoice fields and exact claim comparison
const norm=(v:string)=>v.toLowerCase().replace(/[^a-z0-9]/g,'')
export function invoiceReviewFields(invoice:any) {
 const customFields=(Array.isArray(invoice.CustomField)?invoice.CustomField:[]).map((f:any)=>({id:String(f.DefinitionId||''),name:String(f.Name||''),value:['StringValue','NumberValue','DateValue','BooleanValue'].map(k=>f[k]).find(v=>v!==undefined&&v!==null)})).map((f:any)=>({...f,value:f.value==null?null:String(f.value)}))
 const value=(names:string[])=>{const found=customFields.filter((f:any)=>names.includes(norm(f.name)));return found.length===1?found[0].value:null}
 return {customFields,monthClaim:value(['month','claim','claimnumber','monthclaim']),jobLocationCarrier:value(['joblocation','carrier','joblocationcarrier']),jobName:value(['jobname'])}
}
export function amountCents(input:unknown):number|null {
 if(input===null||input===undefined||input==='')return null
 const value=String(input).trim().replace(/[$,\s]/g,'').replace(/^\((.+)\)$/,'-$1')
 if(!/^-?\d{1,10}(?:\.\d{1,2})?$/.test(value))throw new Error('Unreadable amount; correct the source row before comparison.')
 const negative=value.startsWith('-'),[whole,fraction='']=value.replace('-','').split('.')
 return (negative?-1:1)*(Number(whole)*100+Number(fraction.padEnd(2,'0')))
}
export function compareDocumentRow(row:any,invoices:any[],basis:'total'|'balance',customers:any[]=[]) {
 const name=(v:any)=>String(v??'').normalize('NFKC').toLowerCase().replace(/\s+/g,' ').trim()
 const customer=name(row.customer),job=name(row.jobName),claim=String(row.claim||'').trim(),invoiceNo=String(row.invoiceNumber||'').trim()
 const contains=(hay:any,needle:any)=>!!name(needle)&&name(hay).includes(name(needle))
 const customerIds=new Set(customers.filter(c=>(c.names||[]).some((v:any)=>customer && name(v)===customer)).map(c=>String(c.id)))
 const candidates=invoices.flatMap(invoice=>{
  const evidence:string[]=[]
  if(customer && (name(invoice.customerName)===customer || customerIds.has(String(invoice.customerId))))evidence.push('Same customer')
  if(claim && String(invoice.monthClaim||'').trim()===claim)evidence.push('Exact claim')
  if(invoiceNo && String(invoice.docNumber||'').trim()===invoiceNo)evidence.push('Exact invoice number')
  if((customer && contains(invoice.jobName,customer)) || (job && contains(invoice.jobName,job)))evidence.push('Job name')
  if(contains(invoice.jobLocationCarrier,row.carrier))evidence.push('Carrier / office')
  if(contains(invoice.jobLocationCarrier,row.location))evidence.push('Location')
  if(contains(invoice.description,row.service))evidence.push('Service')
  if(!evidence.length)return []
  let difference=null,quickBooksAmount=null,sourceAmount=null,amountStatus='NEEDS_REVIEW',amountReason='Missing or unreadable amount / currency.'
  const currency=String(row.currency||'USD')
  try {
   const expected=moneyMinor(row.amount,currency),actual=moneyMinor(basis==='total'?invoice.totalAmount:invoice.balance,invoice.currency)
   if(expected!==null)sourceAmount=moneyText(expected,currency)
   if(actual!==null)quickBooksAmount=moneyText(actual,invoice.currency)
   if(currency!==invoice.currency)amountReason='Different or unknown currencies; no amount comparison.'
   else if(expected!==null && actual!==null){difference=moneyText(actual-expected,currency);amountStatus=actual===expected?'EQUAL':'DIFFERENT';amountReason=actual<expected?'Invoice amount is lower. A referral fee may explain this; owner review required.':'QuickBooks amount minus source COST.'}
  }catch{}
  return [{...invoice,evidence,sourceAmount,quickBooksAmount,difference,amountStatus,amountReason,
    identityStatus:evidence.includes('Same customer')||evidence.includes('Exact claim')?'RELATED':'POSSIBLE',selected:false}]
 }).sort((a,b)=>Number(b.evidence.includes('Exact claim'))-Number(a.evidence.includes('Exact claim')) || Number(b.evidence.includes('Same customer'))-Number(a.evidence.includes('Same customer')) || b.evidence.length-a.evidence.length)
 return {status:candidates.length?'NEEDS_REVIEW':'NOT_FOUND',reason:candidates.length?'All related options shown. Select invoices and record your own review; amounts alone do not confirm identity.':'No related invoice found in the complete selected-company snapshot.',candidates}
}
