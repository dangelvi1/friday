(() => {
 const params=new URLSearchParams(location.search),company=params.get('company'),review=params.get('review');
 if(!company||!/^[a-z0-9-]{1,80}$/.test(company)||!review||!/^[a-f0-9-]{36}$/.test(review)){document.getElementById('documentReviewApp').textContent='Invalid private review link.';return;}
 window.FridayDocumentReview.mount(document.getElementById('documentReviewApp'),{company:()=>company,reviewId:review,full:true});
})();
