Historical report feature reference. Use README-FIRST.md and Install-Voice-Home-Calendars.ps1 for v19 installation.

Historical v17 reference; use README-FIRST.md and Install-Unified-Dashboard.ps1 for v18 installation.

# FRIDAY Commerce Reports v17 — 2026-11-09

Cumulative update supports v12/v13 and both source families of v14/v15/v16. FRIDAY stays on S:\AI\friday-ai. Existing personal owner password, natural voice/pointer, company isolation and Nationwide/Sara separation remain. No secrets/configuration, package files, TLS, existing AGENTS or private runtime data are replaced.

## Install

Stop the backend with Ctrl+C. Extract into a new folder and use the actual full path:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File 'S:\AI\Fixing-Files-Folder\FRIDAY-Commerce-Reports-v17\Install-Commerce-Reports.ps1' -ProjectPath 'S:\AI\friday-ai'
if ($LASTEXITCODE -ne 0) { throw 'Installer failed. Do not continue.' }
Set-Location 'S:\AI\friday-ai'
npm run build
if ($LASTEXITCODE -ne 0) { throw 'Build failed. Do not continue.' }
npm run server
```

Adjust only the installer path to its actual extracted location, or use the download/extract/install command provided with this release. Keep npm run dev in the other terminal, Ctrl+F5 https://localhost:5173/, reconnect voice and reopen old review tabs. ExecutionPolicy Bypass is confined to the child installer process. The existing bundle warning does not mean a build failed. No new module passwords; existing FRIDAY owner sign-in works.

## Results and report search

Open Daily ecommerce dashboard. Search by date, product, status or report ID, then press Enter/Search. A single match loads automatically; several matches offer separate Open buttons. Opening a report or Refresh current report replaces the whole displayed report together: progress, store findings, inventory, research, ideas, costs, proposals, metadata editor and pricing. An older background poll cannot overwrite a newly selected report. Selecting another report clears its old selections/edit draft and pending local review. A failed fetch leaves the current report available to refresh. A new nightly report notice does not replace an explicitly opened report.

Delete current report or Delete report prepares a private Trash review; say Approve it or Cancel it once, or click the displayed button. Show Trash to open or Restore a report. Search applies to the selected active/Trash list. Active research or a running listing batch must be stopped/inspected first. Trash changes only this owner's saved report and invalidates old metadata reviews. Shopify products, existing discounts, write receipts and product photos are retained. Restoring requires a fresh change review. This is recoverable deletion, not permanent disk erasure.

Voice examples: Show my report history; Find reports for Vans; Open report [ID]; Delete this report; Show my report Trash; Open the listing receipt; Check the listing receipt diagnostics. You can approve/cancel the one visible delete or change review with normal contextual voice commands. A receipt window itself needs no approval because it submits no write.

## Listing receipt now opens visibly

Open listing receipt and Saved listing receipts open a centered window, including after a dashboard reload. Select a saved batch to inspect its status, verified product count, results, exclusions and safe errors. Refresh is read-only. Read-only Shopify check reads store identity, app permission flags, ProductUpdateInput schema and one affected product when available; it sends no mutation and runs no paid research. Copy diagnostics copies the displayed details for troubleshooting.

For the previously reported needs_review / zero verified batch: opening a receipt does not reapply it. Zero verified does not prove that no write reached Shopify. Older saved failures may contain only the old generic message; the underlying cause cannot be recovered from data that was never saved. New failures retain the safe provider message/code/field and execution phase, including whether a write was attempted. Native rejected fields and uncertain requests remain reviewable without automatic write replay. Inspect the native product before preparing any further change for an uncertain batch.

The original receipt button wrote into a text section elsewhere on the page and lost its selected batch reference after reload. This release uses a saved-history window instead.

## Failed price research

The pasted generic incomplete/failed response means the public research request did not finish; it is not evidence of a price or a Shopify-write failure. New runs preserve actual safe OpenAI HTTP/error/incomplete codes (for example quota, model access, rate limit or output limit), show them in the displayed report, and keep the separate Shopify audit/proposals usable. Previous generic failures remain historical, not retroactively diagnosed.

The single existing Responses request is bounded to eight leads, two supplier offers/two channels each and short source excerpts; its output allowance is 12,000 tokens. This reduces oversized answers but does not guarantee completion or fix missing billing/scopes. Normal configured API usage applies. There is no automatic paid retry. No public price/demand/shipping figure is substituted when research fails. Choose Research / audit now explicitly if you want a new audit and research run after inspecting the error/account configuration privately.

## Combined fields, pricing and bulk approval

One fresh inventory audit analyses descriptions, category, tags, actual category/product metafields, SEO title and meta description together with pricing ideas. Existing old reports do not gain metadata that was never collected: run a fresh audit. Automatic proposals use actual product facts and actual native taxonomy/definitions/allowed reference entries. Unknown material, condition, fit or other facts remain questions; unavailable permissions/schema or complex types remain explicit exclusions. Select one product for friendly field editing, save its proposal privately, then review all supported proposals across products with Accept all supported changes → review. It supports up to 5,000 exact fields, bounded product reads, explicit conflicts/exclusions and durable verified receipts. Approve it once after the before/after review. A new category may require applying it and rerunning the audit before applicable attributes can be safely written.

Pricing is analysed in that same report: actual variant prices/stock, linked competitor evidence where available, exact 5/10/15% experiments and known/unknown contribution costs. Base variant prices are not silently changed by Accept all listing fields. The existing separate exact-variant/percentage/start/end review can create a one-off native scheduled checkout discount after approval; it does not add theme badges or renew weekly. See LISTING-FEATURES.md for supported native field types and scheduled-special limits. No live account write was performed during development.

## Backup / restore

The installer verifies supported source/package hashes before copying, verifies backups, rechecks targets and rolls back attempted copies on failure. Unknown edits stop before project changes. Keep its printed backup path. Stop backend, then run that backup folder's Restore-Commerce-Reports.ps1 by its full path with process-scoped ExecutionPolicy Bypass. Restore refuses later source edits and preserves private data. Restoring code does not undo Shopify changes, scheduled discounts or Trash flags. Existing AGENTS.md is untouched; AGENTS-MERGE-PROPOSAL.md is proposed merge text only.
