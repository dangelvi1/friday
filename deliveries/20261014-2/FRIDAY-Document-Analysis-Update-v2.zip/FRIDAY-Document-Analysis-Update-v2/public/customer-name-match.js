// Shared, deterministic name evidence. Never edits the original insured/customer text.
export function nameKey(value) {
 return String(value??'').normalize('NFKD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[’']/g,'').replace(/[^\p{L}\p{N}]+/gu,' ').trim().replace(/\s+/g,' ');
}
function oneEdit(a,b) {
 if(a===b)return true;
 if(Math.min(a.length,b.length)<4||Math.abs(a.length-b.length)>1)return false;
 let i=0,j=0,edits=0;
 while(i<a.length&&j<b.length){if(a[i]===b[j]){i++;j++;continue;}if(++edits>1)return false;if(a.length>=b.length)i++;if(b.length>=a.length)j++;}
 return edits+(i<a.length||j<b.length?1:0)<=1;
}
export function customerNameMatch(source,target) {
 const a=nameKey(source),b=nameKey(target);
 if(!a||!b)return null;
 if(a===b)return{kind:'NORMALIZED',score:100};
 const left=a.split(' '),right=b.split(' ');
 // Different numeric identifiers are not spelling variations.
 const digits=words=>words.filter(w=>/\d/.test(w)).sort().join('|');
 if(digits(left)!==digits(right))return null;
 if(left.length<2||right.length<2)return null;
 if([...left].sort().join(' ')===[...right].sort().join(' '))return{kind:'REORDERED',score:90};
 const used=new Set();let matched=0,typo=false;
 for(const token of left){let index=right.findIndex((other,i)=>!used.has(i)&&token===other);if(index<0){index=right.findIndex((other,i)=>!used.has(i)&&oneEdit(token,other));if(index>=0)typo=true;}if(index>=0){used.add(index);matched++;}}
 if(matched<2||matched/Math.min(left.length,right.length)<.66||matched/Math.max(left.length,right.length)<.5)return null;
 return{kind:typo?'SPELLING':'PARTIAL',score:typo?65:75};
}
