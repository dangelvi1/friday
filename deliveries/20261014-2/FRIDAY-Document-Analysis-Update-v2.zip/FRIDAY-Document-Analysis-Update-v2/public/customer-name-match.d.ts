export function nameKey(value: unknown): string;
export function customerNameMatch(source: unknown, target: unknown): {kind: 'NORMALIZED'|'REORDERED'|'SPELLING'|'PARTIAL';score: number}|null;
