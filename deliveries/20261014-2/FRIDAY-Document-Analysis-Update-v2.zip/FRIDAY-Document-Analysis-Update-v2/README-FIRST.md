# FRIDAY Document Analysis version 2 — 20261014-2

This update installs over **20261014-1**, which Salvador confirmed working. It changes only Document Analysis presentation, private deletion/restoration and customer-name evidence. The app stays on `S:\AI\friday-ai`; voice, employee services and QuickBooks accounting actions are not replaced or enabled.

## Requested changes

- **Delete saved analysis** in the review toolbar and **Delete** beside each saved analysis. Deletion moves the analysis to owner/company-scoped **Trash**. Use **Show deleted analyses (Trash)** and **Restore** to recover it. Unsaved notes must be saved first. Busy jobs, stale source revisions and stale note revisions are rejected. Original files and private notes remain recoverable; this is not permanent data erasure.
- **Delete document** and **Restore document** under **Extraction / attached documents**, including pending uploaded files. Removing a document excludes all its rows from that analysis, hides its source viewer, and clears confirmation/comparison/reviewed PDF. Original row numbers and notes remain. Restoring the document keeps any separately deleted rows deleted. Other analyses using that source remain available. If the original saved analysis is in Trash, its file remains accessible only through an active owner-scoped analysis that already references it. Trashed analyses cannot be modified, compared, exported or selected for a new combine operation.
- **Customer Name** is the only display meaning for INSURED. It is no longer displayed/grouped as Job Name. Separate columns: Customer Name, Claim, Date Created, Loss Date, Service, Location, Carrier and Cost, plus row provenance, invoice options and private notes. Date Created remains separate to preserve the earlier requested field. The table scrolls horizontally where needed. Both dashboard and full-width review use these controls.
- Extraction now explicitly copies the full INSURED name without guessing, abbreviating, autocorrecting or mixing neighboring claim/service/payment cells into it. Old source values are not automatically rewritten; edit a bad source row or re-extract an original document with consent if OCR needs correction.
- A shared name-evidence helper handles case, whitespace, accents and punctuation. Reversed name order, two-token partial names/extra labels (such as `Gregori Colimon Pay`), and small token spelling differences appear as **possible** matches. Different numeric name identifiers and single-word fuzzy matches are rejected. Original names stay unchanged. Customer API aliases and invoice Customer/Job Name fields provide evidence; similar customer IDs are never merged and amount equality never confirms identity automatically. All invoices belonging to each matching customer remain options, with the existing direct QuickBooks links and per-candidate amount comparisons. Use Find invoice options again to refresh older comparisons with improved matching.
- Existing repeated-row links now use Customer Name only. Possible similar names are separate references. PDF source labels also use Customer Name, Claim, dates, Service, Location, Carrier and Cost separately.

No changes are made to QuickBooks invoices/payments. Manual edits remain in QuickBooks after opening an invoice link and verifying the signed-in company.

## Install

1. Extract this ZIP into a new staging folder under `S:\AI\Fixing-Files-Folder`. Keep the working version-1 backup; do not merge the folder manually into FRIDAY.
2. Stop only FRIDAY backend. Keep PostgreSQL, the speaker service and Nationwide Operations running.
3. Open PowerShell **in this extracted package folder**. If Windows marked these downloaded scripts, unblock just these trusted package files; do not change system execution policy:

```powershell
Unblock-File -LiteralPath '.\Install-Document-Analysis.ps1'
Unblock-File -LiteralPath '.\Restore-Document-Analysis.ps1'
& .\Install-Document-Analysis.ps1 -ProjectPath 'S:\AI\friday-ai'
```

The installer verifies the installed version-1 baselines, package files, backups and copied hashes. If any compatibility check fails, stop and use the current installed file for a compatible patch; do not bypass the checks. New helper paths must not already exist. No dependency installation, OAuth reconnection or credential changes are required.

4. Restart:

```powershell
cd 'S:\AI\friday-ai'
npm run server
```

Close old review tabs and hard-refresh the dashboard (`Ctrl+Shift+R`). The first authenticated Document Analysis request creates two **additive** private DB columns: `deleted_at` and `removed_documents`. Keep the regular private DB backup. No accounting data is changed.

5. Check the separate columns, Delete saved analysis, Trash/Restore, and the document controls in both views. Delete/restoring a source requires reconfirmation and a new comparison before another reviewed PDF. Notes remain visible.

## Rollback

Stop FRIDAY. From the new printed `backups\document-analysis-v2-...` folder, run its `Restore-Document-Analysis.ps1`. Restart and hard-refresh. Restore refuses to erase later edits and restores version-1 files. Private columns/data are retained; older version 1 does not honor the new analysis Trash or document-removal flags, so deleted analyses/documents may reappear and comparisons may need refreshing. Restore the matching private DB backup only through your normal owner-controlled DB workflow if a full data-state rollback is needed. Do not delete or manually merge databases.

## Verification

36 reported offline tests passed, including the previous regression cases, new name evidence, scoped analysis Trash/restore, document removal/restoration, retention of separately deleted rows and private notes, retained references from active combined analyses, invalidation of reviewed PDFs, removed-document edit rejection, and browser controls/columns. No tests were skipped. Real Chromium exercised both layouts; AI/QBO requests used synthetic intercepted responses. TypeScript checks, JavaScript syntax checks and a build-only frontend bundle passed. Windows installation, real PostgreSQL lock contention, live microphone, OAuth and production QBO/deep-link behavior remain separate PC-side checks. This package preserves the existing broader authorization limitations documented in the initial audit.
