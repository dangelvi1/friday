import type {Express} from 'express'
import {pool} from '../db/pool'
import {activeReviewRows,mergeReviews,reviewRows,validateProgress} from './document-review-core'
import {reviewedPdf} from './document-analysis-report'
const busy=(row:any)=>['queued','extracting','comparing'].includes(row.status)
const validId=(id:any):id is string=>typeof id==='string'&&/^[a-f0-9-]{36}$/.test(id)
export function registerDocumentReviewExtensions(app:Express,d:any,db:any=pool){
 const root='/quickbooks/document-analysis/:companyKey/:id'
 async function context(req:any,res:any){
  res.setHeader('Cache-Control','no-store')
  if(!validId(req.params.id))throw Error('Invalid review ID.')
  const scope=await d.selected(req);await d.ensure();return scope
 }
 async function change(req:any,res:any,fn:any,allowBusy=false,allowDeleted=false){
  let client:any
  try{
   const s=await context(req,res);client=await db.connect();await client.query('BEGIN')
   const args=[...d.vals(s),req.params.id]
   const result=await client.query(`SELECT * FROM friday_document_reviews WHERE ${d.scopeWhere} AND id=$5 FOR UPDATE`,args)
   const row=result.rows[0];if(!row)throw Error('Review not found in your private company scope.')
   if(row.deleted_at&&!allowDeleted)throw Error('Source analysis is in Trash. Restore it before changing it.')
   if(Number(req.body.expectedRevision)!==row.revision)throw Error('Source changed. Reload before saving; your entries are retained.')
   if(busy(row)&&!allowBusy)throw Error('Source busy. Wait for extraction or comparison to finish.')
   const response=await fn(client,s,row,args)
   await client.query('COMMIT');return res.json({success:true,quickBooksChanged:false,...response})
  }catch(e){if(client)await client.query('ROLLBACK');return d.fail(res,e)}finally{client?.release()}
 }
 app.post(root+'/visibility',(req,res)=>change(req,res,async(client:any,_s:any,row:any,args:any[])=>{
  if(typeof req.body.deleted!=='boolean')throw Error('Invalid analysis deletion/restoration.')
  if(Number(req.body.expectedReviewRevision)!==(row.review_revision || 0))throw Error('Source notes changed. Reload before deleting or restoring.')
  await client.query(`UPDATE friday_document_reviews SET deleted_at=$6,confirmed_rows=NULL,comparison=NULL,reviewed_snapshot=NULL,status='source_draft',revision=revision+1,updated_at=now() WHERE ${d.scopeWhere} AND id=$5`,[...args,req.body.deleted?new Date():null])
  await history(client,{...row,revision:row.revision+1},req.body.deleted?'analysis_trashed':'analysis_restored',{})
  return{revision:row.revision+1,deleted:req.body.deleted}
 },false,true))
 app.post(root+'/document/:documentId/visibility',(req,res)=>change(req,res,async(client:any,_s:any,row:any,args:any[])=>{
  const id=req.params.documentId,docs=row.extraction?.documents || [{id:row.id}]
  if(!validId(id)||(!docs.some((doc:any)=>doc.id===id)&&!(row.pending_documents || []).includes(id)&&!(row.removed_documents || []).includes(id))||typeof req.body.removed!=='boolean')throw Error('Invalid document deletion/restoration.')
  if(Number(req.body.expectedReviewRevision)!==(row.review_revision || 0))throw Error('Source notes changed. Reload before removing or restoring a document.')
  const removed=new Set<string>(row.removed_documents || [])
  if(req.body.removed)removed.add(id);else removed.delete(id)
  await client.query(`UPDATE friday_document_reviews SET removed_documents=$6,draft_rows=$7,confirmed_rows=NULL,comparison=NULL,reviewed_snapshot=NULL,status='source_draft',revision=revision+1,updated_at=now() WHERE ${d.scopeWhere} AND id=$5`,[...args,JSON.stringify([...removed]),JSON.stringify(reviewRows(row))])
  await history(client,{...row,revision:row.revision+1},req.body.removed?'document_removed':'document_restored',{documentId:id})
  return{revision:row.revision+1,removed:req.body.removed}
 }))
 async function history(client:any,row:any,event:string,data:any){
  await client.query('INSERT INTO friday_document_review_history(review_id,owner,revision,event,data) VALUES($1,$2,$3,$4,$5)',[row.id,row.owner,row.revision,event,JSON.stringify(data)])
 }
 app.post(root+'/combine',(req,res)=>change(req,res,async(client:any,s:any,row:any,args:any[])=>{
  const ids=req.body.sourceIds
  if(!Array.isArray(ids)||!ids.length||ids.length>49||ids.some((id:any)=>!validId(id))||new Set(ids).size!==ids.length)throw Error('Invalid documents to combine.')
  const sources=[]
  // Use a stable lock order. Originals remain available; merging copies the reviewed source snapshot.
  for(const id of [...ids].sort()){
   const result=await client.query(`SELECT * FROM friday_document_reviews WHERE ${d.scopeWhere} AND id=$5 AND deleted_at IS NULL FOR SHARE`,[...d.vals(s),id])
   const source=result.rows[0]
   if(!source)throw Error('Review not found in this owner/company scope.')
   if(busy(source)||Number(req.body.sourceRevisions?.[id])!==source.revision)throw Error('Source document busy or changed. Reload the document list.')
   sources.push(source)
  }
  const merged=mergeReviews(row,sources),extraction={...row.extraction,rows:merged.rows,documents:merged.documents,coverage:merged.coverage}
  await client.query(`UPDATE friday_document_reviews SET extraction=$6,draft_rows=$7,excluded_rows=$8,review_notes=$9,pending_documents=$10,removed_documents=$11,confirmed_rows=NULL,comparison=NULL,reviewed_snapshot=NULL,status='source_draft',revision=revision+1,error=NULL,updated_at=now() WHERE ${d.scopeWhere} AND id=$5`,[...args,JSON.stringify(extraction),JSON.stringify(merged.rows),JSON.stringify(merged.excluded),JSON.stringify(merged.notes),JSON.stringify((row.pending_documents||[]).filter((id:string)=>!ids.includes(id))),JSON.stringify(merged.removed)])
  await history(client,{...row,revision:row.revision+1},'documents_combined',{sourceIds:ids,rowCount:merged.rows.length})
  return{revision:row.revision+1,rowCount:merged.rows.length}
 }))
 app.post(root+'/pending-documents',(req,res)=>change(req,res,async(client:any,s:any,row:any,args:any[])=>{
  const ids=req.body.sourceIds
  if(!Array.isArray(ids)||ids.length>49||ids.some((id:any)=>!validId(id)||id===row.id))throw Error('Invalid pending documents.')
  for(const id of ids){const source=await client.query(`SELECT id FROM friday_document_reviews WHERE ${d.scopeWhere} AND id=$5 AND deleted_at IS NULL`,[...d.vals(s),id]);if(!source.rows.length)throw Error('Source document not found in this owner/company scope.')}
  const pending=[...new Set([...(row.pending_documents||[]),...ids])]
  if(pending.length>49)throw Error('Source limit: 50 documents per review.')
  await client.query(`UPDATE friday_document_reviews SET pending_documents=$6 WHERE ${d.scopeWhere} AND id=$5`,[...args,JSON.stringify(pending)])
  await history(client,row,'documents_pending',{sourceIds:ids})
  return{pendingDocuments:pending}
 },true))
 app.post(root+'/row/:ordinal/visibility',(req,res)=>change(req,res,async(client:any,_s:any,row:any,args:any[])=>{
  const ordinal=Number(req.params.ordinal)
  if(!Number.isSafeInteger(ordinal)||ordinal<1||ordinal>reviewRows(row).length||typeof req.body.excluded!=='boolean')throw Error('Invalid row deletion/restoration.')
  if((row.removed_documents || []).includes(reviewRows(row)[ordinal-1].documentId))throw Error('Source document is removed. Restore the document before changing its rows.')
  const excluded=new Set<number>(row.excluded_rows || [])
  if(req.body.excluded)excluded.add(ordinal);else excluded.delete(ordinal)
  await client.query(`UPDATE friday_document_reviews SET excluded_rows=$6,draft_rows=$7,confirmed_rows=NULL,comparison=NULL,reviewed_snapshot=NULL,status='source_draft',revision=revision+1,error=NULL,updated_at=now() WHERE ${d.scopeWhere} AND id=$5`,[...args,JSON.stringify([...excluded].sort((a,b)=>a-b)),JSON.stringify(reviewRows(row))])
  await history(client,{...row,revision:row.revision+1},req.body.excluded?'row_removed':'row_restored',{ordinal})
  return{revision:row.revision+1,ordinal}
 }))
 app.post(root+'/progress',(req,res)=>change(req,res,async(client:any,_s:any,row:any,args:any[])=>{
  const notes=validateProgress(req.body,row),version=(row.review_revision || 0)+1
  await client.query(`UPDATE friday_document_reviews SET review_notes=$6,review_revision=$7,reviewed_snapshot=NULL,updated_at=now() WHERE ${d.scopeWhere} AND id=$5`,[...args,JSON.stringify(notes),version])
  await history(client,row,'progress_saved',{reviewRevision:version,ordinals:req.body.rows.map((r:any)=>r.ordinal)})
  return{reviewRevision:version}
 }))
 app.post(root+'/reviewed',(req,res)=>change(req,res,async(client:any,s:any,row:any,args:any[])=>{
  if(req.body.reviewed!==true || Number(req.body.expectedReviewRevision)!==(row.review_revision || 0))throw Error('Confirm the saved review and reload changed notes.')
  if(!row.comparison?.id || row.comparison.revision!==row.revision || !row.confirmed_rows)throw Error('Source comparison is missing or stale. Confirm and compare again.')
  const rows=activeReviewRows(row)
  if(!rows.length)throw Error('Source review has no active rows.')
  for(const r of rows){const note=row.review_notes?.[r.ordinal];if(!note || note.stale || note.comparisonId!==row.comparison.id)throw Error('Source row '+r.ordinal+': save a current decision or Needs review before marking reviewed.')}
  const snapshot={id:row.id,title:row.title,owner:s.owner,companyKey:s.companyKey,realmId:s.realmId,environment:s.environment,revision:row.revision,reviewRevision:row.review_revision,reviewedAt:new Date().toISOString(),rows,notes:row.review_notes,comparison:row.comparison,excludedRows:row.excluded_rows,removedDocuments:row.removed_documents}
  await client.query(`UPDATE friday_document_reviews SET reviewed_snapshot=$6,updated_at=now() WHERE ${d.scopeWhere} AND id=$5`,[...args,JSON.stringify(snapshot)])
  await history(client,row,'reviewed',{reviewRevision:row.review_revision,comparisonId:row.comparison.id})
  return{reviewedAt:snapshot.reviewedAt}
 }))
 app.get(root+'/report.pdf',async(req,res)=>{
  try{
   const s=await context(req,res),row=await d.saved(s,req.params.id),snapshot=row.reviewed_snapshot
   if(!snapshot || snapshot.revision!==row.revision || snapshot.reviewRevision!==row.review_revision || snapshot.comparison.id!==row.comparison?.id)throw Error('Source review is not finalized or is stale. Save progress and mark reviewed first.')
   const bytes=await reviewedPdf(snapshot);res.setHeader('Content-Type','application/pdf');res.setHeader('Content-Disposition','attachment; filename="document-review.pdf"');return res.send(Buffer.from(bytes))
  }catch(e){return d.fail(res,e)}
 })
 app.get(root+'/source/:documentId',async(req,res)=>{
  try{
   const s=await context(req,res),row=await d.saved(s,req.params.id),id=req.params.documentId
   if(!validId(id) || (row.removed_documents || []).includes(id) || (id!==row.id && !row.extraction?.documents?.some((doc:any)=>doc.id===id)))throw Error('Source document is not part of this active private review.')
   // Trashing the original saved analysis must not break another analysis's retained source reference.
   const source=await d.saved(s,id,true);res.setHeader('Content-Type',source.mime);res.setHeader('Content-Disposition','inline; filename="source'+(source.mime==='application/pdf'?'.pdf':source.mime==='image/png'?'.png':'.jpg')+'"');return res.send(Buffer.from(source.source_base64,'base64'))
  }catch(e){return d.fail(res,e)}
 })
}
