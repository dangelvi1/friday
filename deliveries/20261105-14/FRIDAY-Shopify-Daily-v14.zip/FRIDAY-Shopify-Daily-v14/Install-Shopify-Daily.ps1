param([string]$ProjectPath = 'S:\AI\friday-ai')
$ErrorActionPreference = 'Stop'
$manifest = Get-Content (Join-Path $PSScriptRoot 'shopify-daily-manifest.json') -Raw | ConvertFrom-Json
if (!(Test-Path (Join-Path $ProjectPath 'server.ts'))) { throw "FRIDAY project not found at $ProjectPath" }
# Select an additive voice entry point for the actual installed version.
$mainTarget = Join-Path $ProjectPath 'src/main.ts'
if (!(Test-Path $mainTarget)) { throw 'Voice entry point missing. No files changed.' }
$mainHash = (Get-FileHash -LiteralPath $mainTarget -Algorithm SHA256).Hash.ToLowerInvariant()
$variantProperty = $manifest.mainVariants.PSObject.Properties[$mainHash]
if ($null -eq $variantProperty) { throw 'Installed voice source differs from supported v12/v13. No files changed. Keep current source and obtain a compatible patch.' }
$variant = $variantProperty.Value
$manifest.baselineSHA256.PSObject.Properties['src/main.ts'].Value = $mainHash
$manifest.packageSHA256.PSObject.Properties['src/main.ts'].Value = $variant.sha256
function Get-PackageSource([string]$Relative) {
  if ($Relative -eq 'src/main.ts') { return (Join-Path $PSScriptRoot $variant.source) }
  return (Join-Path $PSScriptRoot $Relative)
}
# Preconditions only: these unchanged files are never copied.
foreach ($entry in $manifest.requiredSHA256.PSObject.Properties) {
  $target = Join-Path $ProjectPath $entry.Name
  if (!(Test-Path $target) -or (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash -ne $entry.Value) { throw "Compatibility check failed: $($entry.Name). No project files changed. Obtain a patch based on the current installed source." }
}
foreach ($relative in $manifest.files) {
  if ($relative -match '(^[\\/]|\.\.|:)') { throw "Unsafe manifest path: $relative" }
  $source = Get-PackageSource $relative
  $target = Join-Path $ProjectPath $relative
  $packageHash = $manifest.packageSHA256.PSObject.Properties[$relative].Value
  if (!(Test-Path $source) -or (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash -ne $packageHash) { throw "Package validation failed: $relative" }
  $baseline = $manifest.baselineSHA256.PSObject.Properties[$relative].Value
  if ($null -ne $baseline) {
    if (!(Test-Path $target) -or (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash -ne $baseline) { throw "Installed file differs from the verified source selected for this update: $relative. No files changed. Keep this package separate and obtain a compatible update." }
  } elseif (Test-Path $target) { throw "New file already exists: $relative. No files changed." }
}
# Stop only the FRIDAY backend before running this installer; preserve other services.
$backup = Join-Path $ProjectPath ('backups\shopify-daily-v14-' + (Get-Date -Format 'yyyyMMdd-HHmmss-fff'))
New-Item -ItemType Directory -Path $backup -Force | Out-Null
foreach ($relative in $manifest.files) {
  $target = Join-Path $ProjectPath $relative
  if (Test-Path $target) {
    $saved = Join-Path $backup $relative
    New-Item -ItemType Directory -Path (Split-Path $saved) -Force | Out-Null
    Copy-Item -LiteralPath $target -Destination $saved
    $baseline = $manifest.baselineSHA256.PSObject.Properties[$relative].Value
    if ((Get-FileHash -LiteralPath $saved -Algorithm SHA256).Hash -ne $baseline) { throw "Backup verification failed: $relative. No project files changed." }
  }
}
$record = @{projectPath=$ProjectPath; files=$manifest.files; baselineSHA256=$manifest.baselineSHA256; packageSHA256=$manifest.packageSHA256}
$record | ConvertTo-Json -Depth 8 | Set-Content (Join-Path $backup 'restore-manifest.json') -Encoding UTF8
Copy-Item (Join-Path $PSScriptRoot 'Restore-Shopify-Daily.ps1') (Join-Path $backup 'Restore-Shopify-Daily.ps1')
try {
  # Recheck targets after backup to avoid overwriting an edit made during staging.
  foreach ($relative in $manifest.files) {
    $target = Join-Path $ProjectPath $relative
    $baseline = $manifest.baselineSHA256.PSObject.Properties[$relative].Value
    if ($null -ne $baseline) {
      if ((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash -ne $baseline) { throw "Target changed after backup: $relative" }
    } elseif (Test-Path $target) { throw "Target appeared after backup: $relative" }
  }
  $copied = @()
  foreach ($relative in $manifest.files) {
    $target = Join-Path $ProjectPath $relative
    New-Item -ItemType Directory -Path (Split-Path $target) -Force | Out-Null
    $copied += $relative
    Copy-Item -LiteralPath (Get-PackageSource $relative) -Destination $target -Force
    if ((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash -ne $manifest.packageSHA256.PSObject.Properties[$relative].Value) { throw "Installed file verification failed: $relative" }
  }
} catch {
  # Roll back only files this installation attempted to copy.
  foreach ($relative in $copied) {
    $saved = Join-Path $backup $relative; $target = Join-Path $ProjectPath $relative
    if (Test-Path $saved) { Copy-Item -LiteralPath $saved -Destination $target -Force }
    elseif (Test-Path $target) { Remove-Item -LiteralPath $target }
  }
  throw
}
Write-Host 'Shopify Daily + Voice + Photo Drafts version 14 installed. Installation made no external account changes.'
Write-Host "Verified backup: $backup"
Write-Host 'Restart npm run server, then hard-refresh the dashboard and close old review tabs.'
Write-Host 'Build, restart backend/dev, hard-refresh and reconnect voice. Verify the existing owner key privately in Daily ecommerce dashboard. Save nightly settings explicitly. No credentials, data, AGENTS or configuration were replaced.'
