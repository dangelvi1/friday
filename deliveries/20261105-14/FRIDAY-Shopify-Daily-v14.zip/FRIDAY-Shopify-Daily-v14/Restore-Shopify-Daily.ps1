$ErrorActionPreference = 'Stop'
$recordPath = Join-Path $PSScriptRoot 'restore-manifest.json'
if (!(Test-Path $recordPath)) { throw 'Run the backup-folder copy of this script with FRIDAY backend stopped.' }
$record = Get-Content $recordPath -Raw | ConvertFrom-Json
foreach ($relative in $record.files) {
  $target = Join-Path $record.projectPath $relative
  if (!(Test-Path $target) -or (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash -ne $record.packageSHA256.PSObject.Properties[$relative].Value) { throw "Installed file changed after update: $relative. Restore stopped before changing files." }
  $saved = Join-Path $PSScriptRoot $relative
  $baseline = $record.baselineSHA256.PSObject.Properties[$relative].Value
  if ($null -ne $baseline -and (!(Test-Path $saved) -or (Get-FileHash -LiteralPath $saved -Algorithm SHA256).Hash -ne $baseline)) { throw "Backup failed verification: $relative. No files changed." }
}
foreach ($relative in $record.files) {
  $target = Join-Path $record.projectPath $relative; $saved = Join-Path $PSScriptRoot $relative
  if (Test-Path $saved) { Copy-Item -LiteralPath $saved -Destination $target -Force }
  else { Remove-Item -LiteralPath $target }
}
Write-Host 'Application files restored. Restart FRIDAY and hard-refresh.'
Write-Host 'Private credentials, commerce reports, cost notes, uploaded photos and receipts remain. Disable nightly settings before rollback. Rollback does not undo approved Shopify SEO/product changes.'
