import test from 'node:test'
import assert from 'node:assert/strict'
import express from 'express'
import {PGlite} from '@electric-sql/pglite'
import {mkdtemp,mkdir,writeFile,rm} from 'node:fs/promises'
import {tmpdir} from 'node:os'
import {join} from 'node:path'
import {randomBytes,randomUUID,createHash} from 'node:crypto'
import {registerOwnerSessionRoutes} from '../auth/owner-session'
import {registerMarketingRoutes} from '../marketing/routes'
import {schemaSQL} from '../marketing/schema'
import {adsSchemaSQL} from '../marketing/ads/schema'
import {adsService} from '../marketing/ads/service'
import {adsRedirectForOrigin,LOCAL_ADS_REDIRECT,ADS_SCOPE,seal} from '../marketing/ads/google'
import {preset} from '../marketing/ads/plan'

test('callback allowlist accepts only the configured origin and exact HTTPS localhost Vite address',()=>{
 const c={redirect:'https://friday.example.invalid/marketing/google-ads/callback'}
 assert.equal(adsRedirectForOrigin(c,'https://friday.example.invalid'),c.redirect)
 assert.equal(adsRedirectForOrigin(c,'https://localhost:5173'),LOCAL_ADS_REDIRECT)
 for(const value of ['http://localhost:5173','https://localhost:5174','https://127.0.0.1:5173','https://localhost.evil.invalid:5173','https://friday.example.invalid.evil.invalid','https://other.example.invalid','https://localhost:5173/','null','not-a-url'])assert.throws(()=>adsRedirectForOrigin(c,value))
})

test('actual owner-authenticated callback routes bind local/public redirects, preserve migrated data and never exchange a mismatched request',async t=>{
 const cwd=process.cwd(),dir=await mkdtemp(join(tmpdir(),'friday-local-ads-v42-')),db=new PGlite(),legacySQL=adsSchemaSQL.replace(',redirect_uri text','').replace(/ALTER TABLE[^;]+;/,'');let server:any,auth:any
 const cfg:any={ready:true,missing:[],key:randomBytes(32),version:'v99',manager:'1111111111',clientId:'fixture',clientSecret:'fixture-secret',developerToken:'fixture-developer',redirect:'https://friday.example.invalid/marketing/google-ads/callback'}
 const calls:any[]=[],expected=new Map<string,string>(),pub='https://friday.example.invalid',local='https://localhost:5173'
 let queue=Promise.resolve();const query=async(sql:string,args?:any[])=>[schemaSQL,adsSchemaSQL,legacySQL].includes(sql)?(await db.exec(sql),{rows:[]}):db.query(sql,args);const lock=async()=>{const before=queue;let release!:()=>void;queue=new Promise(r=>release=r);await before;return release};const pool:any={query:async(sql:string,args?:any[])=>{const release=await lock();try{return await query(sql,args)}finally{release()}},connect:async()=>{const release=await lock();return{query,release}}}
 const send:any=async(url:string,options:any)=>{calls.push({url,options});if(url==='https://oauth2.googleapis.com/token'){const body=new URLSearchParams(options.body);assert.equal(body.get('redirect_uri'),expected.get(body.get('code')!));return Response.json({access_token:'SYNTHETIC-ACCESS',refresh_token:'SYNTHETIC-REFRESH',scope:ADS_SCOPE})}assert.match(url,/customers\/1111111111\/googleAds:search$/);return Response.json({results:[]})}
 try{
  process.chdir(dir);await mkdir('credentials');await writeFile('credentials/sandra-owner-access.json',JSON.stringify({salvador:'a'.repeat(64),dayanna:'b'.repeat(64)}));const app=express();app.use(express.json());server=app.listen(0,'127.0.0.1');await new Promise<void>(r=>server.once('listening',r));const base='http://127.0.0.1:'+server.address().port;auth=registerOwnerSessionRoutes(app,{allowedOrigins:[pub,local]});registerMarketingRoutes(app,pool,{ads:{config:()=>cfg,fetch:send}})
  const request=async(path:string,body:any,cookie:string|undefined,origin=local)=>fetch(base+path,{method:body===undefined?'GET':'POST',headers:{origin,'x-friday-session':'1','content-type':'application/json',...(cookie?{cookie}:{})},...(body===undefined?{}:{body:JSON.stringify(body)})})
  const login=async(origin:string,owner='salvador')=>{const r=await request('/session/owner/login',{owner,password:(owner==='salvador'?'a':'b').repeat(64)},undefined,origin);assert.equal(r.status,200);return r.headers.get('set-cookie')!.split(';')[0]}
  const localCookie=await login(local),pubCookie=await login(pub),wifeCookie=await login(local,'dayanna')
  const data=async(path:string,body?:any,cookie=localCookie,origin=local)=>{const r=await request(path,body,cookie,origin),d=await r.json();assert.equal(r.status,200,JSON.stringify(d));return d}
  await data('/marketing/initialize',{});const companies=(await data('/marketing/companies')).companies,nation=companies.find((x:any)=>x.profile.name.includes('Nationwide')),other=companies.find((x:any)=>x.id!==nation.id);assert.ok(nation)
  await db.exec(legacySQL);await pool.query('INSERT INTO aitan_studio.ads_version(singleton,version) VALUES(true,1)');const savedAuth=seal('KEEP-LEGACY-AUTH',nation.id,cfg.key),draftId=randomUUID();await pool.query('INSERT INTO aitan_studio.google_ads_connections(company_id,sealed_refresh,authorized_by) VALUES($1,$2,$3)',[nation.id,JSON.stringify(savedAuth),'salvador']);await pool.query('INSERT INTO aitan_studio.ad_drafts(id,company_id,request_id,request_hash,plan,created_by) VALUES($1,$2,$3,$4,$5,$6)',[draftId,nation.id,randomUUID(),'legacy',JSON.stringify(preset('2026-11-26')),'salvador']);const oldDigest=createHash('sha256').update('old-state').digest('hex');await pool.query('INSERT INTO aitan_studio.google_ads_oauth_states(digest,company_id,owner_name,session_id,expires_at) VALUES($1,$2,$3,$4,now()+interval \'10 minutes\')',[oldDigest,nation.id,'salvador','old-session'])
  await t.test('explicit additive upgrade retains credentials/drafts, cancels unbound pending logins and repeats safely',async()=>{
   assert.equal((await data('/marketing/ads/status')).initialized,false);assert.equal(calls.length,0);
   const failing={...pool,connect:async()=>{const c=await pool.connect();return{...c,query:async(sql:string,args?:any[])=>{if(sql.startsWith('UPDATE aitan_studio.google_ads_oauth_states SET cancelled_at=now() WHERE redirect_uri IS NULL'))throw Error('fixture migration failure');return c.query(sql,args)}}}};
   await assert.rejects(adsService(failing,{config:()=>cfg,fetch:send}).initialize('salvador'),/fixture migration failure/);assert.equal((await data('/marketing/ads/status')).initialized,false);assert.equal((await pool.query('SELECT cancelled_at FROM aitan_studio.google_ads_oauth_states WHERE digest=$1',[oldDigest])).rows[0].cancelled_at,null);assert.deepEqual((await pool.query('SELECT sealed_refresh FROM aitan_studio.google_ads_connections WHERE company_id=$1',[nation.id])).rows[0].sealed_refresh,savedAuth);
   const upgraded=await data('/marketing/ads/initialize',{});assert.match(upgraded.message,/updated/);assert.equal((await data('/marketing/ads/status')).initialized,true);assert.deepEqual((await pool.query('SELECT sealed_refresh FROM aitan_studio.google_ads_connections WHERE company_id=$1',[nation.id])).rows[0].sealed_refresh,savedAuth);assert.equal((await data('/marketing/companies/'+nation.id+'/ads')).drafts[0].id,draftId);assert.ok((await pool.query('SELECT cancelled_at FROM aitan_studio.google_ads_oauth_states WHERE digest=$1',[oldDigest])).rows[0].cancelled_at);assert.match((await data('/marketing/ads/initialize',{})).message,/already initialized/);assert.equal(calls.length,0)
  })
  for(const origin of [local,pub])await t.test('authorization from '+origin+' uses the exact same stored redirect at token exchange',async()=>{
   const cookie=origin===local?localCookie:pubCookie,start=await data('/marketing/companies/'+nation.id+'/google-ads/oauth/start',{},cookie,origin),url=new URL(start.url),state=url.searchParams.get('state')!,redirect=origin+'/marketing/google-ads/callback';assert.equal(url.searchParams.get('redirect_uri'),redirect);const row=(await pool.query('SELECT * FROM aitan_studio.google_ads_oauth_states WHERE digest=$1',[createHash('sha256').update(state).digest('hex')])).rows[0];assert.equal(row.redirect_uri,redirect);expected.set(origin,redirect);const done=await data('/marketing/google-ads/oauth/complete',{code:origin,state},cookie,origin);assert.equal(done.companyId,nation.id);assert.ok(!JSON.stringify(done).includes('SYNTHETIC'));assert.equal((await request('/marketing/google-ads/oauth/complete',{code:origin,state},cookie,origin)).status,409)
  })
  await t.test('local state cannot complete through public origin, another owner/session or client-supplied redirect',async()=>{
   const start=await data('/marketing/companies/'+other.id+'/google-ads/oauth/start',{}),state=new URL(start.url).searchParams.get('state')!,before=calls.length
   assert.equal((await request('/marketing/google-ads/oauth/complete',{code:'bad',state},pubCookie,pub)).status,409)
   assert.equal((await request('/marketing/google-ads/oauth/complete',{code:'bad',state},localCookie,pub)).status,401)
   assert.equal((await request('/marketing/google-ads/oauth/complete',{code:'bad',state},wifeCookie,local)).status,409)
   const nextCookie=await login(local);assert.equal((await request('/marketing/google-ads/oauth/complete',{code:'bad',state},nextCookie,local)).status,409);assert.equal(calls.length,before)
   const second=await data('/marketing/companies/'+other.id+'/google-ads/oauth/start',{redirect_uri:'https://evil.invalid/callback'},nextCookie),secondState=new URL(second.url).searchParams.get('state')!;assert.equal(new URL(second.url).searchParams.get('redirect_uri'),LOCAL_ADS_REDIRECT);expected.set('ignore-client-redirect',LOCAL_ADS_REDIRECT);await data('/marketing/google-ads/oauth/complete',{code:'ignore-client-redirect',state:secondState,redirect_uri:'https://evil.invalid/callback'},nextCookie)
  })
  await t.test('untrusted origins fail before creating a login and configured callback changes invalidate old states',async()=>{
   const service=adsService(pool,{config:()=>cfg,fetch:send}),before=calls.length;await assert.rejects(service.startOAuth('salvador','fixture-session',nation.id,'https://evil.invalid'),/configured domain/);assert.equal(calls.length,before)
   const start=await service.startOAuth('salvador','fixture-session',nation.id,pub),state=new URL(start.url).searchParams.get('state')!;cfg.redirect='https://changed.example.invalid/marketing/google-ads/callback';await assert.rejects(service.completeOAuth('salvador','fixture-session',{code:'bad',state},pub),/configured domain/);await assert.rejects(service.completeOAuth('salvador','fixture-session',{code:'bad',state},'https://changed.example.invalid'),/expired|changed owner/);assert.equal(calls.length,before);cfg.redirect=pub+'/marketing/google-ads/callback'
  })
 }finally{auth?.close();await new Promise<void>(r=>server?server.close(()=>r()):r());await db.close();process.chdir(cwd);await rm(dir,{recursive:true,force:true})}
})
