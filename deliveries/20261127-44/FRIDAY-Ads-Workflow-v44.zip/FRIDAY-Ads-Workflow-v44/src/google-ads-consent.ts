// Consent is granted only by a real local checkbox/button, never model/tool arguments.
const WINDOW_MS=15*60*1000
let busy=false,epoch=0,permissionEpoch=0,expiryTimer:ReturnType<typeof setTimeout>|null=null
let dismiss:(()=>void)|null=null,grant:{session:string;company:string;until:number;deadline:number}|null=null
const owner=()=>{const s=(window as any).FridayOwnerSession?.current();return s?.id&&s?.owner?String(s.id)+'\n'+String(s.owner):null}
const companySelect=()=>document.querySelector<HTMLSelectElement>('#mkCompany')
const selectedCompany=()=>companySelect()?.value??''
const companyName=(id:string)=>Array.from(companySelect()?.options||[]).find(o=>o.value===id)?.textContent||id
function changed(){document.dispatchEvent(new CustomEvent('friday-ads-sharing-changed'))}
export function stopAdsAiSharing(){permissionEpoch++;grant=null;if(expiryTimer)clearTimeout(expiryTimer);expiryTimer=null;dismiss?.();changed()}
export function refreshAdsAiSharing(){if(grant&&(grant.session!==owner()||(grant.until<=Date.now()||grant.deadline<=performance.now())||selectedCompany()!==grant.company))stopAdsAiSharing();else changed()}
function active(session:string,company:string){if(grant&&((grant.until<=Date.now()||grant.deadline<=performance.now())||grant.session!==session||grant.company!==company||selectedCompany()!==grant.company))stopAdsAiSharing();return !!grant&&grant.session===session&&grant.company===company&&grant.until>Date.now()&&grant.deadline>performance.now()}
if(typeof document!=='undefined'){
 document.addEventListener('friday-owner-session-changed',()=>{epoch++;stopAdsAiSharing()})
 document.addEventListener('change',event=>{if((event.target as HTMLElement)?.id==='mkCompany')refreshAdsAiSharing()})
}
export function mountAdsAiSharing(root:HTMLElement){
 root.innerHTML='<p data-ads-sharing-state role="status"></p><button type="button" data-ads-sharing-stop>Stop AI sharing</button>'
 const state=root.querySelector<HTMLElement>('[data-ads-sharing-state]')!,button=root.querySelector<HTMLButtonElement>('[data-ads-sharing-stop]')!
 const render=()=>{const valid=grant&&grant.session===owner()&&grant.company===selectedCompany()&&grant.until>Date.now()&&grant.deadline>performance.now();state.textContent=valid?'OpenAI Ads assistance allowed for '+companyName(grant!.company)+' until '+new Intl.DateTimeFormat('en-US',{hour:'numeric',minute:'2-digit',hour12:true,timeZone:'America/New_York'}).format(grant!.until)+' Eastern in this tab.':'OpenAI Ads assistance: off. Direct dashboard controls remain available.';button.disabled=!valid}
 button.onclick=()=>stopAdsAiSharing();document.addEventListener('friday-ads-sharing-changed',render);render()
}
const blocked=(status='ai_sharing_declined')=>({success:false,status,message:'No Google Ads tool results were shared by this request. Use Google Ads Manager directly in the dashboard. Do not automatically repeat this request or seek the same data through another tool.'})
export async function runGoogleAdsWithConsent(action:string,args:any,operation:()=>Promise<any>){
 if(busy)return blocked('ai_sharing_busy')
 busy=true
 try{
  await (window as any).FridayOwnerSession?.ensure()
  const session=owner(),generation=epoch,beforeCompany=selectedCompany(),company=args.companyId||beforeCompany
  if(!session)return blocked('owner_required')
  if(!company)return blocked('select_company_first')
  if(document.querySelector('dialog[open],[role=dialog][aria-modal=true]'))return blocked('finish_current_review')
  let windowGrant=active(session,company),allowed=windowGrant
  if(!allowed){
   const decision=await new Promise<'once'|'window'|null>(resolve=>{
    const dialog=document.createElement('dialog');dialog.id='fridayAdsAiConsent';dialog.setAttribute('aria-labelledby','adsConsentTitle');dialog.style.cssText='width:min(560px,calc(100vw - 40px));box-sizing:border-box;max-height:85dvh;overflow:auto;border:1px solid #b8cdc3;border-radius:14px;padding:24px;color:#23463c;background:white;font:15px/1.6 system-ui'
    dialog.innerHTML='<h2 id="adsConsentTitle">Allow Ads assistance with OpenAI?</h2><p>FRIDAY uses OpenAI to answer advertising questions and help with campaign planning. Tool results may include Google Ads account IDs and names, currency and time zone, campaign plans, keywords, ad copy, proposed budgets and targeting, and Keyword Planner search-volume, competition and bid estimates.</p><p>Authorization tokens, developer tokens and client secrets are excluded. Choose one request or allow this company’s Ads workflow for 15 minutes in this browser tab, including opening, editing, saving and researching drafts. You can stop sharing in Google Ads Manager. This does not launch ads or authorize spending.</p><p id="adsConsentContext"></p><p>Decline to use the dashboard directly. Declining does not disconnect Google or delete saved data. Information shared previously cannot be recalled.</p><label style="display:block;margin:16px 0"><input id="adsConsentCheck" type="checkbox"> I agree to send the described Ads results to OpenAI for the option I choose below.</label><div style="display:flex;flex-wrap:wrap;gap:12px"><button id="adsConsentDecline" type="button">Decline — use dashboard</button><button id="adsConsentAllow" type="button" disabled>Allow once</button><button id="adsConsentWorkflow" type="button" disabled>Allow this company for 15 minutes</button></div>'
    dialog.querySelector('#adsConsentContext')!.textContent='Company: '+companyName(company)+' · Requested action: '+action
    const check=dialog.querySelector<HTMLInputElement>('#adsConsentCheck')!,once=dialog.querySelector<HTMLButtonElement>('#adsConsentAllow')!,workflow=dialog.querySelector<HTMLButtonElement>('#adsConsentWorkflow')!
    let settled=false
    const finish=(value:'once'|'window'|null)=>{if(settled)return;settled=true;clearTimeout(timer);dismiss=null;dialog.remove();resolve(value)}
    const timer=setTimeout(()=>finish(null),300000);dismiss=()=>finish(null)
    check.onchange=()=>{once.disabled=workflow.disabled=!check.checked}
    once.onclick=event=>{if(event.isTrusted&&check.checked)finish('once')};workflow.onclick=event=>{if(event.isTrusted&&check.checked)finish('window')}
    dialog.querySelector<HTMLButtonElement>('#adsConsentDecline')!.onclick=()=>finish(null);dialog.addEventListener('cancel',event=>{event.preventDefault();finish(null)});dialog.addEventListener('close',()=>finish(null));document.body.append(dialog)
    try{dialog.showModal();dialog.querySelector<HTMLButtonElement>('#adsConsentDecline')!.focus()}catch{finish(null)}
   })
   if(!decision||epoch!==generation||owner()!==session||selectedCompany()!==beforeCompany)return blocked()
   allowed=true;windowGrant=decision==='window'
   if(windowGrant){grant={session,company,until:Date.now()+WINDOW_MS,deadline:performance.now()+WINDOW_MS};if(expiryTimer)clearTimeout(expiryTimer);expiryTimer=setTimeout(()=>stopAdsAiSharing(),WINDOW_MS);changed()}
  }
  if(!allowed)return blocked()
  const permission=permissionEpoch,result=await operation()
  if(epoch!==generation||owner()!==session||permissionEpoch!==permission||(windowGrant&&!active(session,company))||(companySelect()&&selectedCompany()!==company)){stopAdsAiSharing();return blocked('context_changed')}
  changed();if(action==='accounts'&&result?.success===true)return{success:true,status:'selection_required',message:'Accessible advertiser choices are displayed privately in Google Ads Manager. Select the intended client and verify it there; other client names and IDs are not returned to OpenAI under this company permission.'};return result
 }catch{return blocked('ai_sharing_failed')}finally{busy=false}
}
