param([string]$ProjectPath='S:\AI\friday-ai')
$ErrorActionPreference='Stop'
if(!(Test-Path -LiteralPath (Join-Path $ProjectPath 'server.ts'))){throw 'FRIDAY project not found. No configuration changed.'}
$comparisonTokenSecure=Read-Host 'Paste the approved AITAN API Center developer token privately (hidden input; never paste it in chat)' -AsSecureString
$comparisonTokenPtr=[IntPtr]::Zero
Push-Location -LiteralPath $ProjectPath
try{
 $comparisonTokenPtr=[Runtime.InteropServices.Marshal]::SecureStringToBSTR($comparisonTokenSecure)
 $comparisonTokenText=[Runtime.InteropServices.Marshal]::PtrToStringBSTR($comparisonTokenPtr)
 $comparisonCode=@'
import dotenv from 'dotenv';
dotenv.config({quiet:true});
let entered='';process.stdin.setEncoding('utf8');
for await(const part of process.stdin)entered+=part;
const configured=(process.env.FRIDAY_GOOGLE_ADS_DEVELOPER_TOKEN||'').trim();
console.log(!configured?'NOT_CONFIGURED':configured===entered.trim()?'MATCH':'DIFFERENT');
'@
 $comparisonTokenText | & node --input-type=module -e $comparisonCode
 if($LASTEXITCODE -ne 0){throw 'Private comparison failed. No credentials or configuration were changed.'}
}finally{
 if($comparisonTokenPtr -ne [IntPtr]::Zero){[Runtime.InteropServices.Marshal]::ZeroFreeBSTR($comparisonTokenPtr)}
 Remove-Variable comparisonTokenText -ErrorAction SilentlyContinue
 $comparisonTokenSecure.Dispose()
 Pop-Location
}
