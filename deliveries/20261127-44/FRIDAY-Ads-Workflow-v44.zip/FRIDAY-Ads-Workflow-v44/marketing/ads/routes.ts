import {randomBytes} from 'node:crypto'
import {adsService} from './service'
export function registerAdsRoutes(app:any,pool:any,endpoint:any,deps:any={}){const service=adsService(pool,deps)
 app.get('/marketing/google-ads/callback',(_q:any,r:any)=>{const nonce=randomBytes(18).toString('base64');r.set('Cache-Control','no-store');r.set('Referrer-Policy','no-referrer');r.set('Content-Security-Policy',`default-src 'none'; script-src 'nonce-${nonce}'; connect-src 'self'; base-uri 'none'; frame-ancestors 'none'`);r.type('html').send(`<!doctype html><html><head><title>FRIDAY Google Ads connection</title></head><body><h1>FRIDAY Google Ads authorization</h1><p id="state">Finishing authorization…</p><script nonce="${nonce}">(async()=>{const p=new URLSearchParams(location.search),code=p.get('code'),state=p.get('state');history.replaceState(null,'',location.pathname);if(!code||!state){document.getElementById('state').textContent='Authorization was cancelled or incomplete. Return to FRIDAY.';return}try{const r=await fetch('/marketing/google-ads/oauth/complete',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json','x-friday-session':'1'},body:JSON.stringify({code,state})}),d=await r.json();document.getElementById('state').textContent=d.message||d.error||'Check FRIDAY for the result.';if(r.ok&&d.success)window.opener?.postMessage({type:'friday-google-ads-authorized',companyId:d.companyId},location.origin)}catch{document.getElementById('state').textContent='Connection could not finish. Return to FRIDAY and inspect its connection status.'}})();</script></body></html>`)})
 app.get('/marketing/ads/drafts',endpoint(async(q:any,r:any)=>r.json(await service.reviewDrafts(typeof q.query.companyId==='string'?q.query.companyId:undefined))))
 app.get('/marketing/ads/status',endpoint(async(_q:any,r:any)=>r.json(await service.status())))
 app.post('/marketing/ads/initialize',endpoint(async(_q:any,r:any,o:string)=>r.json(await service.initialize(o))))
 app.get('/marketing/companies/:companyId/ads',endpoint(async(q:any,r:any)=>r.json(await service.list(q.params.companyId))))
 app.post('/marketing/companies/:companyId/ads/preset',endpoint(async(q:any,r:any,o:string)=>r.json(await service.preset(o,q.params.companyId,q.body))))
 app.get('/marketing/companies/:companyId/ads/:id',endpoint(async(q:any,r:any)=>r.json(await service.details(q.params.id,q.params.companyId))))
 app.post('/marketing/companies/:companyId/ads/:id',endpoint(async(q:any,r:any,o:string)=>r.json(await service.update(o,q.params.id,q.params.companyId,q.body))))
 app.post('/marketing/companies/:companyId/ads/:id/research',endpoint(async(q:any,r:any,o:string)=>r.json(await service.research(o,q.params.id,q.params.companyId,q.body))))
 app.get('/marketing/companies/:companyId/google-ads',endpoint(async(q:any,r:any)=>r.json(await service.accountStatus(q.params.companyId))))
 app.post('/marketing/companies/:companyId/google-ads/oauth/start',endpoint(async(q:any,r:any,o:string,s:any)=>r.json(await service.startOAuth(o,s.id,q.params.companyId,new URL(q.headers.origin||q.headers.referer).origin))))
 app.post('/marketing/google-ads/oauth/complete',endpoint(async(q:any,r:any,o:string,s:any)=>r.json(await service.completeOAuth(o,s.id,q.body,new URL(q.headers.origin||q.headers.referer).origin))))
 app.get('/marketing/companies/:companyId/google-ads/accounts',endpoint(async(q:any,r:any)=>r.json(await service.accounts(q.params.companyId))))
 app.post('/marketing/companies/:companyId/google-ads/select',endpoint(async(q:any,r:any,o:string)=>r.json(await service.selectAccount(o,q.params.companyId,q.body))))
 app.post('/marketing/companies/:companyId/google-ads/test',endpoint(async(q:any,r:any)=>r.json(await service.test(q.params.companyId))))
 app.post('/marketing/companies/:companyId/google-ads/disconnect',endpoint(async(q:any,r:any,o:string)=>r.json(await service.disconnect(o,q.params.companyId,q.body))))
 return service
}
