export const adsSchemaSQL=`
CREATE TABLE IF NOT EXISTS aitan_studio.ads_version(singleton boolean PRIMARY KEY DEFAULT true CHECK(singleton),version integer NOT NULL);
CREATE TABLE IF NOT EXISTS aitan_studio.ad_drafts(
 id uuid PRIMARY KEY,company_id uuid NOT NULL REFERENCES aitan_studio.companies(id),request_id uuid UNIQUE NOT NULL,request_hash text NOT NULL,
 plan jsonb NOT NULL,revision integer NOT NULL DEFAULT 0,status text NOT NULL DEFAULT 'draft' CHECK(status IN ('draft','reviewed')),
 evidence jsonb,created_by text NOT NULL CHECK(created_by IN ('salvador','dayanna')),created_at timestamptz NOT NULL DEFAULT now(),updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS aitan_studio.google_ads_connections(
 company_id uuid PRIMARY KEY REFERENCES aitan_studio.companies(id),sealed_refresh jsonb NOT NULL,
 revision integer NOT NULL DEFAULT 0,customer_id text UNIQUE,account_name text,currency text,time_zone text,last_verified_at timestamptz,
 authorized_by text NOT NULL CHECK(authorized_by IN ('salvador','dayanna')),updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS aitan_studio.google_ads_oauth_states(
 digest text PRIMARY KEY,company_id uuid NOT NULL REFERENCES aitan_studio.companies(id),owner_name text NOT NULL,session_id text NOT NULL,expires_at timestamptz NOT NULL,cancelled_at timestamptz,consumed_at timestamptz
);
`
