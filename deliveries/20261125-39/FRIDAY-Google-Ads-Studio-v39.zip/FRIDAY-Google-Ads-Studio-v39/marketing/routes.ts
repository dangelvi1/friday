import {registerAdsRoutes} from './ads/routes'
import {resolveOwnerSession} from '../auth/owner-session'
import {ZodError} from 'zod'
import {createMarketingService} from './service'
import {MarketingError} from './model'
// Only existing owner sessions. No legacy raw keys, customer/employee login or public intake.
export function registerMarketingRoutes(app:any,pool:any,deps:any={}){const service=createMarketingService(pool)
 const endpoint=(fn:any)=>async(req:any,res:any)=>{res.set('Cache-Control','no-store');const s=resolveOwnerSession(req);if(!s)return res.status(401).json({success:false,error:'Sign in to FRIDAY as Salvador or Dayanna.'});try{await fn(req,res,s.owner,s)}catch(e:any){const validation=e instanceof ZodError;res.status(validation?400:e instanceof MarketingError?e.status:503).json({success:false,error:validation?'Check the profile fields: '+e.issues.map(i=>i.path.join('.')+': '+i.message).slice(0,5).join('; '):e instanceof MarketingError?e.message:'Marketing request failed. Inputs retained. Check its saved status before retrying; no advertising mutation endpoint exists in this update.'})}}
 registerAdsRoutes(app,pool,endpoint,deps.ads||{})
 app.get('/marketing/status',endpoint(async(_q:any,r:any)=>r.json(await service.status())))
 app.post('/marketing/initialize',endpoint(async(_q:any,r:any,o:string)=>r.json(await service.initialize(o))))
 app.get('/marketing/companies',endpoint(async(_q:any,r:any)=>r.json(await service.list())))
 app.post('/marketing/companies',endpoint(async(q:any,r:any,o:string)=>r.json(await service.create(o,q.body))))
 app.get('/marketing/companies/:id',endpoint(async(q:any,r:any)=>r.json(await service.get(q.params.id))))
 app.post('/marketing/companies/:id',endpoint(async(q:any,r:any,o:string)=>r.json(await service.update(o,q.params.id,q.body))))
 app.post('/marketing/companies/:id/pause',endpoint(async(q:any,r:any,o:string)=>r.json(await service.pause(o,q.params.id,q.body?.expectedRevision))))
 app.get('/marketing/activity',endpoint(async(q:any,r:any)=>r.json(await service.activity(typeof q.query.companyId==='string'?q.query.companyId:undefined))))
 app.get('/marketing/backup',endpoint(async(_q:any,r:any)=>{r.set('Content-Disposition','attachment; filename="FRIDAY-AITAN-private-backup.json"');r.json(await service.backup())}))
 return service
}
