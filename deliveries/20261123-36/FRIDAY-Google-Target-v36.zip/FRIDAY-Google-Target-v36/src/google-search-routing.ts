type Target='this_computer'|'main_pc'
type Dependencies={local:(query:string)=>Promise<any>;main:(query:string)=>Promise<any>}

export async function routeGoogleSearch(value:unknown,target:Target|undefined,deps:Dependencies){
 if(target!==undefined&&target!=='this_computer'&&target!=='main_pc')return{success:false,status:'invalid_target',error:'Choose this_computer or main_pc.'}
 if(typeof value!=='string'||!value.trim()||value.length>500)return{success:false,status:'invalid_query',error:'Supply a Google search query of 1–500 characters.'}
 const query=value.trim(),selected=target||'this_computer'
 let result:any
 try{result=await(selected==='main_pc'?deps.main(query):deps.local(query))}
 catch{return failure(selected)}
 if(result?.success!==true)return failure(selected,result?.httpStatus)
 if(selected==='main_pc'){
  // The backend can land on consent or a challenge; opening it is not proof
  // that a usable results page or product evidence was obtained.
  let url:URL
  try{url=new URL(result.url)}catch{return{success:false,status:'unverified_page',target:selected,error:'The main PC did not return a verifiable Google search URL. No result reading is claimed.'}}
  if(url.protocol!=='https:'||!['www.google.com','google.com'].includes(url.hostname)||url.pathname!=='/search'||url.searchParams.get('q')!==query){
   return{success:false,status:'needs_browser_attention',target:selected,error:'The main-PC browser did not reach the requested Google results page. Check its visible window for consent or a challenge; no bypass or automatic retry was attempted.'}
  }
  return{success:true,status:'opened',target:selected,query,url:url.href,message:'Google search opened in the main FRIDAY PC browser. Results/prices have not been read or verified.'}
 }
 return{success:true,status:'opened',target:selected,query,computer:typeof result.computer==='string'?result.computer:'this computer',message:'Google search opened through this device’s Local Agent. Results/prices have not been read or verified.'}
}

function failure(target:Target,httpStatus?:number){
 return{success:false,status:target==='main_pc'?'main_pc_unavailable':'local_agent_unavailable',target,
  ...(httpStatus?{httpStatus}:{}),error:target==='main_pc'?
   (httpStatus===401||httpStatus===403?'FRIDAY denied the main-PC browser request. Check the existing owner/device session; no search was confirmed.':'The existing main-PC browser service failed or was unreachable. Check the FRIDAY server terminal; no search was confirmed.'):
   'The Local Agent at 127.0.0.1:8787 on this device is unreachable. On the main Windows PC, check its /health endpoint and browser local-network permission. On iPhone/iPad, use the Search Google link or explicitly request the main PC. No device fallback was attempted.'}
}
