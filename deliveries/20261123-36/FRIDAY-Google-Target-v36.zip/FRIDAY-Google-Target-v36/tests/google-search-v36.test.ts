import test from 'node:test'
import assert from 'node:assert/strict'
import {routeGoogleSearch} from '../src/google-search-routing'

test('Explicit main-PC Google request uses only the backend route and preserves literal query',async()=>{
 const query='Vans Bitter Chocolate & White size 9',calls:string[]=[]
 const result=await routeGoogleSearch(query,'main_pc',{local:async()=>assert.fail('No current-device agent call'),main:async value=>{calls.push(value);return{success:true,url:'https://www.google.com/search?q='+encodeURIComponent(value)}}})
 assert.deepEqual(calls,[query]);assert.equal(result.success,true);assert.equal(result.target,'main_pc');assert.match(result.message!,/not been read or verified/)
})

test('Default/current-device requests never fall back to the main PC',async()=>{
 let calls=0
 for(const target of [undefined,'this_computer'] as const){
  const result=await routeGoogleSearch('Fixture shoe',target,{local:async()=>{calls++;return null},main:async()=>assert.fail('No silent fallback')})
  assert.equal(result.status,'local_agent_unavailable');assert.equal(result.target,'this_computer');assert.match(result.error!,/127.0.0.1:8787/)
 }
 assert.equal(calls,2)
})

test('Local success and main failures stay distinct; no retry or cross-device action',async()=>{
 const result=await routeGoogleSearch('Fixture','this_computer',{local:async()=>({success:true,computer:'Fixture-PC'}),main:async()=>assert.fail('Wrong target')})
 assert.equal(result.success,true);assert.equal(result.computer,'Fixture-PC')
 for(const code of [401,403,500]){
  let calls=0
  const failed=await routeGoogleSearch('Fixture','main_pc',{local:async()=>assert.fail('No fallback'),main:async()=>{calls++;return{success:false,httpStatus:code}}})
  assert.equal(calls,1);assert.equal(failed.status,'main_pc_unavailable');assert.equal(failed.httpStatus,code)
 }
 const failed=await routeGoogleSearch('Fixture','main_pc',{local:async()=>assert.fail(),main:async()=>{throw Error('Network fixture')}})
 assert.equal(failed.success,false);assert.match(failed.error!,/server terminal/)
})

test('Challenge/consent/foreign/mismatched pages and invalid requests cannot report a completed search',async()=>{
 for(const url of ['https://www.google.com/sorry/index','https://consent.google.com/','https://example.com/search?q=Fixture','https://www.google.com/search?q=Different']){
  const result=await routeGoogleSearch('Fixture','main_pc',{local:async()=>assert.fail(),main:async()=>({success:true,url})})
  assert.equal(result.success,false);assert.equal(result.status,'needs_browser_attention')
 }
 for(const query of ['', ' '.repeat(3),'x'.repeat(501),null]){
  const result=await routeGoogleSearch(query,undefined,{local:async()=>assert.fail(),main:async()=>assert.fail()})
  assert.equal(result.status,'invalid_query')
 }
 const result=await routeGoogleSearch('Fixture','other' as any,{local:async()=>assert.fail(),main:async()=>assert.fail()});assert.equal(result.status,'invalid_target')
})
