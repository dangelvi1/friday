// START [QUICKBOOKS-DASH-21B] Company-scoped API banking review controller
(() => {
  async function readJson(response) {
    try {return await response.json()}
    catch {throw new Error(`Server returned an unreadable response (HTTP ${response.status}). Check the FRIDAY backend and public connection, then retry.`)}
  }
  const $ = id => document.getElementById(id)
  const state = {generation: 0, accountRequest: 0, accountsCompany: null, ledgerRequest: 0, ledger: [], analysis: [], input: [], source: '', filter: 'all', loadedScope: null, categoryHistory: null, teachingRevisions: [], scopeInfo: null, rules: [], notes: {}, selections: {}, savedRevision: null, savedActor: null, page: 1}
  const scope = () => ({companyKey: fridayQuickBooksState.companyKey, accountId: $('bankingAccountSelector').value})
  const key = selected => `${selected.companyKey}:${selected.accountId}`
  const current = (selected, generation) => generation === state.generation && key(selected) === key(scope())
  const escape = text => fridayEscapeHtml(String(text ?? ''))
  const money = amount => amount == null ? '—' : fridayMoney(amount)
  function showPanel(view) {
    const posted = view === 'posted'
    $('sandraPostedPanel').hidden = !posted; $('sandraCsvPanel').hidden = posted
    $('sandraPostedTab').setAttribute('aria-pressed', String(posted))
    $('sandraCsvTab').setAttribute('aria-pressed', String(!posted))
  }
  function feedback(text) {$('sandraBankStatus').textContent = text}
  function clearReview() {
    state.generation++; state.ledgerRequest++; state.analysis = []; state.ledger = []; state.input = []; state.loadedScope = null; state.categoryHistory = null; state.teachingRevisions = []; state.scopeInfo = null; state.rules = []; state.notes = {}; state.selections = {}; state.savedRevision = null; state.savedActor = null; state.page = 1; if ($('sandraSavedRules')) $('sandraSavedRules').innerHTML = ''
    $('sandraBankFile').value = ''; $('sandraScopeConfirmed').checked = false
    $('sandraAnalyzeButton').disabled = false
    $('sandraBankSearch').value = ''; $('sandraConfidenceFilter').value = 'exceptions'
    for (const id of ['bankMoneyIn','bankMoneyOut','bankNet','bankNeedsReview']) $(id).textContent = '—'
    $('bankingTypeSummary').textContent = ''
    $('bankingTableBody').innerHTML = '<tr><td colspan="7">Load posted accounting activity for this account.</td></tr>'
    for (const color of ['Green','Yellow','Red']) $('sandra' + color + 'Count').textContent = '—'
    feedback('Select a bank file for this company and account. Recommendations require owner review.')
    renderAnalysis()
    if (typeof clearLiveQuickBooksBankFeed === 'function') clearLiveQuickBooksBankFeed()
    cards()
  }
  function cards() {
    for (const id of ['sandraBankCards','sandraDashboardBankCards']) {
      const root = $(id); if (!root) continue
      root.innerHTML = ''
      for (const account of fridayBankAccounts) {
        const button = document.createElement('button'); button.type = 'button'
        button.className = 'sandra-account-card' + (String(account.id) === scope().accountId ? ' selected' : '')
        button.innerHTML = `<strong>${escape(account.name)}</strong><span>Bank balance</span><b>Not connected</b><span>QuickBooks posted balance</span><b>${money(account.currentBalance)}</b><span>Read bank feed separately to verify its balance and Pending count.</span>`
        button.addEventListener('click', async () => {
          $('bankingAccountSelector').value = String(account.id); clearReview()
          await openWorkspace('banking'); cards()
        })
        root.appendChild(button)
      }
      if (!fridayBankAccounts.length) root.textContent = 'No bank accounts loaded.'
    }
  }
  async function loadAccounts() {
    const companyKey = fridayQuickBooksState.companyKey
    if (!companyKey) return
    const request = ++state.accountRequest
    const companyChanged = state.accountsCompany !== companyKey
    const previous = companyChanged ? {} : Object.fromEntries(['expenseAccountSelector','bankingAccountSelector','reconcileAccountSelector'].map(id => [id, $(id)?.value]))
    if (companyChanged) {
      fridayBankAccounts = []; state.accountsCompany = companyKey; clearReview()
      for (const id of ['expenseAccountSelector','bankingAccountSelector','reconcileAccountSelector']) if ($(id)) $(id).innerHTML = '<option value="">Loading bank accounts…</option>'
    }
    try {
      const response = await fetch(`/quickbooks/accounts/${encodeURIComponent(companyKey)}?type=Bank`)
      const data = await readJson(response)
      if (request !== state.accountRequest || companyKey !== fridayQuickBooksState.companyKey) return
      if (!response.ok || !data.success) throw new Error('Could not load bank accounts.')
      fridayBankAccounts = data.accounts || []
      for (const id of ['expenseAccountSelector','bankingAccountSelector','reconcileAccountSelector']) {
        const select = $(id); if (!select) continue
        select.innerHTML = '<option value="">Select bank account</option>'
        for (const account of fridayBankAccounts) {
          const option = document.createElement('option'); option.value = String(account.id)
          option.textContent = `${account.name} — QBO posted ${money(account.currentBalance)}`; select.appendChild(option)
        }
        // Default from actual account data, never a hard-coded ID mapping.
        const preferred = fridayBankAccounts.find(account => /BOFA CONSTRUCTION\s*[-–—]\s*7015/i.test(account.name))
        select.value = fridayBankAccounts.some(account => String(account.id) === previous[id]) ? previous[id] : String((preferred || fridayBankAccounts[0])?.id || '')
      }
      cards(); await restoreDraft()
    } catch (error) {
      if (request !== state.accountRequest || companyKey !== fridayQuickBooksState.companyKey) return
      fridayLog(error.message); feedback(error.message)
      for (const id of ['expenseAccountSelector','bankingAccountSelector','reconcileAccountSelector']) if ($(id)) $(id).innerHTML = '<option value="">Bank accounts unavailable</option>'
    }
  }
  async function loadLedger() {
    showPanel('posted')
    const selected = scope(), generation = state.generation, request = ++state.ledgerRequest
    const month = $('bankingMonth').value
    if (!selected.companyKey || !selected.accountId || !/^\d{4}-\d{2}$/.test(month)) return fridayLog('Select an account and month first.')
    const [year, number] = month.split('-').map(Number)
    const endDate = `${month}-${new Date(Date.UTC(year, number, 0)).getUTCDate()}`
    $('bankingTypeSummary').textContent = 'Reading posted accounting activity through the API…'
    try {
      const params = new URLSearchParams({startDate: month + '-01', endDate})
      const response = await fetch(`/quickbooks/api-bank-review/${encodeURIComponent(selected.companyKey)}/${encodeURIComponent(selected.accountId)}?${params}`)
      const data = await readJson(response)
      if (!current(selected, generation) || request !== state.ledgerRequest || $('bankingMonth').value !== month) return
      if (!response.ok || !data.success || data.companyKey !== selected.companyKey || String(data.accountId) !== selected.accountId) throw new Error(data.error || 'Bank review scope did not match.')
      state.ledger = data.transactions
      $('bankMoneyIn').textContent = money(data.totals.moneyIn); $('bankMoneyOut').textContent = money(data.totals.moneyOut); $('bankNet').textContent = money(data.totals.net)
      $('bankNeedsReview').textContent = state.ledger.filter(row => !row.category || row.type === 'JournalEntry' || row.type === 'Transfer').length
      $('bankingTypeSummary').textContent = `${data.count} posted records · ${data.supportedEntities.length} supported transaction types · excludes the Pending bank feed · not a reconciliation`
      renderLedger(state.ledger)
      fridayLog(`${data.count} posted records read through the QuickBooks API.`)
    } catch (error) {
      if (!current(selected, generation) || request !== state.ledgerRequest) return
      state.ledger = []; renderLedger([])
      for (const id of ['bankMoneyIn','bankMoneyOut','bankNet','bankNeedsReview']) $(id).textContent = '—'
      $('bankingTypeSummary').textContent = error.message; fridayLog(error.message)
    }
  }
  function renderLedger(rows) {
    $('bankingTableBody').innerHTML = rows.length ? rows.map(row => `<tr><td>${escape(row.txnDate)}</td><td>${escape(row.type)}</td><td>${escape(row.name || '—')}</td><td>${escape(row.category || 'Needs review')}</td><td>${row.direction === 'in' ? 'Received' : 'Spent'}</td><td class="money">${money(row.amount)}</td><td><span class="status-pill">Posted in QBO</span></td></tr>`).join('') : '<tr><td colspan="7">No posted records loaded. This does not mean there are no Pending bank-feed transactions.</td></tr>'
  }
  function parseCsv(text) {
    const rows = []; let row = [], value = '', quoted = false
    text = text.replace(/^\uFEFF/, '')
    for (let i = 0; i < text.length; i++) {
      const char = text[i]
      if (char === '"') {if (quoted && text[i + 1] === '"') {value += '"'; i++} else if (quoted || !value) quoted = !quoted; else throw new Error('Unexpected quote in CSV.')}
      else if (char === ',' && !quoted) {row.push(value); value = ''}
      else if ((char === '\n' || char === '\r') && !quoted) {if (char === '\r' && text[i + 1] === '\n') i++; row.push(value); if (row.some(cell => cell.trim())) rows.push(row); row = []; value = ''}
      else value += char
    }
    if (quoted) throw new Error('CSV has an unclosed quoted field.')
    row.push(value); if (row.some(cell => cell.trim())) rows.push(row)
    return rows
  }
  function bankDate(text) {
    const value = String(text || '').trim()
    const match = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec(value)
    const iso = match ? `${match[3]}-${match[1].padStart(2,'0')}-${match[2].padStart(2,'0')}` : value
    if (!/^\d{4}-\d{2}-\d{2}$/.test(iso) || !Number.isFinite(Date.parse(iso + 'T00:00:00Z')) || new Date(iso + 'T00:00:00Z').toISOString().slice(0,10) !== iso) throw new Error(`Unreadable date: ${value}`)
    return iso
  }
  function amount(text) {
    const value = String(text ?? '').trim(); if (!value) return null
    const cleaned = value.replace(/^\((.+)\)$/, '-$1').replace(/^(-?)\$/, '$1')
    if (!/^-?(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d{1,2})?$/.test(cleaned)) throw new Error(`Unreadable amount: ${value}`)
    return Number(cleaned.replace(/,/g,''))
  }
  function importCsv(text) {
    const rows = parseCsv(text)
    if (!rows.length) throw new Error('CSV is empty.')
    const header = rows.shift().map(cell => cell.trim().toLowerCase())
    const index = names => header.findIndex(cell => names.includes(cell))
    const date = index(['date','transaction date','posting date']), description = index(['description','bank description','original description']), spent = index(['spent','debit','debits','withdrawal','withdrawals']), received = index(['received','credit','credits','deposit','deposits']), signed = index(['amount']), fromTo = index(['from/to','from / to','payee','name']), ref = index(['reference','reference number','check number'])
    if (date < 0 || description < 0 || (signed < 0 && (spent < 0 || received < 0))) throw new Error('CSV needs Date, Description, and Amount (negative spent / positive received), or both Spent and Received columns. Use a transaction-only export; statement totals and summary lines are rejected.')
    if (rows.length > 5000) throw new Error('Maximum 5,000 bank rows per analysis.')
    return rows.map((row, i) => {
      try {
        if (row.length !== header.length) throw new Error('Column count differs from the header.')
        let out = spent < 0 ? null : amount(row[spent]), incoming = received < 0 ? null : amount(row[received])
        if (spent < 0 && received < 0) {const value = amount(row[signed]); out = value < 0 ? -value : null; incoming = value > 0 ? value : null}
        if ((out != null && out < 0) || (incoming != null && incoming < 0) || ((out || 0) > 0) === ((incoming || 0) > 0)) throw new Error('Expected one nonzero Spent or Received amount.')
        if (!row[description].trim()) throw new Error('Description is missing.')
        return {date: bankDate(row[date]), description: row[description].trim(), spent: out, received: incoming, fromTo: fromTo < 0 ? '' : row[fromTo], referenceNumber: ref < 0 ? '' : row[ref]}
      } catch (error) {throw new Error(`CSV data row ${i + 1}: ${error.message} No rows were submitted.`)}
    })
  }
  async function analyze() {
    const selected = scope(), generation = state.generation, file = $('sandraBankFile').files[0]
    if (!selected.companyKey || !selected.accountId || !file) return feedback('Select the company, account, and bank CSV file first.')
    if (!$('sandraScopeConfirmed').checked) return feedback('Confirm that this file belongs to the displayed company and account.')
    if (file.size > 5 * 1024 * 1024) return feedback('Choose a CSV file smaller than 5 MB.')
    $('sandraAnalyzeButton').disabled = true
    try {
      await verifyScope(selected, generation)
      if (!current(selected, generation)) return
      const input = importCsv(await file.text())
      if (!input.length) throw new Error('No transaction rows found.')
      if (!current(selected, generation)) return
      feedback(`Analyzing ${input.length} bank rows against this account’s posted QuickBooks records…`)
      const response = await fetch(`/quickbooks/bank-feed-analysis/${encodeURIComponent(selected.companyKey)}/${encodeURIComponent(selected.accountId)}`, {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({...selected, scopeConfirmed:true, realmId:state.scopeInfo.realmId, environment:state.scopeInfo.environment, draftRules:state.rules, transactions:input})})
      const data = await readJson(response)
      if (!current(selected, generation)) return
      if (!response.ok || !data.success || data.companyKey !== selected.companyKey || String(data.accountId) !== selected.accountId || data.count !== input.length || data.transactions?.length !== input.length) throw new Error(data.error || 'Analysis scope or row count did not match.')
      state.input = input; state.analysis = data.transactions; state.source = file.name; state.loadedScope = selected; state.categoryHistory = data.categoryHistory; state.teachingRevisions = data.teachingRevisions || []; state.notes = {}; state.selections = {}; state.savedRevision = null; state.savedActor = null; state.page = 1; saveDraft(); $('sandraBankFile').value=''; $('sandraScopeConfirmed').checked=false
      for (const color of ['Green','Yellow','Red']) $('sandra' + color + 'Count').textContent = data.confidenceCounts[color.toUpperCase()]
      feedback(`${data.count} of ${input.length} file rows analyzed; all repeats retained. ${data.message} Category history: ${data.categoryHistory.postedPurchaseCount} posted purchases from ${data.categoryHistory.startDate} through ${data.categoryHistory.endDate}. File row count is not the QuickBooks Pending count.`)
      renderAnalysis()
    } catch (error) {
      if (!current(selected, generation)) return
      state.analysis = []; state.loadedScope = null; state.categoryHistory = null
      for (const color of ['Green','Yellow','Red']) $('sandra' + color + 'Count').textContent = '—'
      renderAnalysis(); feedback(error.message)
    } finally {if (current(selected, generation)) $('sandraAnalyzeButton').disabled = false}
  }
  const storageKey = info => `friday:sandra-draft:v2:${info.companyKey}:${info.accountId}:${info.environment}:${info.realmId}`
  async function verifyScope(selected, generation) {
    const response = await fetch(`/quickbooks/bank-review-scope/${encodeURIComponent(selected.companyKey)}/${encodeURIComponent(selected.accountId)}`)
    const data = await readJson(response)
    if (!current(selected,generation)) throw new Error('Selected company/account changed.')
    if (!response.ok || !data.success || data.companyKey !== selected.companyKey || String(data.accountId) !== selected.accountId || !data.realmId) throw new Error(data.error || 'Scope verification failed.')
    state.scopeInfo = data
    state.rules = data.rules || []
    try {
      const stored = JSON.parse(localStorage.getItem(storageKey(data)) || 'null')
      if (stored?.schemaVersion === 2 && stored.realmId === data.realmId && stored.companyKey === data.companyKey && stored.accountId === data.accountId && Array.isArray(stored.rules)) state.rules = stored.rules
    } catch {feedback('Saved draft is unreadable. No saved rules were applied.')}
    renderRules()
  }
  function saveDraft() {
    if (!state.scopeInfo || key(state.scopeInfo) !== key(scope())) return
    try {
      const prior = JSON.parse(localStorage.getItem(storageKey(state.scopeInfo)) || 'null')
      const keepPrior = !state.analysis.length && prior?.schemaVersion === 2
      localStorage.setItem(storageKey(state.scopeInfo), JSON.stringify({schemaVersion:2,...scope(),realmId:state.scopeInfo.realmId,environment:state.scopeInfo.environment,savedAt:new Date().toISOString(),source:keepPrior ? prior.source : state.source,rules:state.rules,notes:{},selections:{},input:keepPrior ? prior.input : state.input,transactions:keepPrior ? prior.transactions : state.analysis,categoryHistory:keepPrior ? prior.categoryHistory : state.categoryHistory,teachingRevisions:keepPrior ? prior.teachingRevisions : state.teachingRevisions,readOnly:true,executable:false}))
    } catch {feedback('Browser storage is unavailable/full. Download review JSON to keep this draft.')}
  }
  async function restoreDraft() {
    const selected = scope(), generation = state.generation
    if (!selected.companyKey || !selected.accountId) return
    try {
      await verifyScope(selected,generation)
      if (!current(selected,generation)) return
      const saved = JSON.parse(localStorage.getItem(storageKey(state.scopeInfo)) || 'null')
      if (!saved || saved.schemaVersion !== 2 || saved.companyKey !== selected.companyKey || saved.accountId !== selected.accountId || saved.realmId !== state.scopeInfo.realmId) return
      if (!Array.isArray(saved.transactions) || !Array.isArray(saved.input) || saved.transactions.length !== saved.input.length || saved.transactions.length > 5000) throw new Error('Saved draft failed validation.')
      if (!saved.transactions.every(r => r && Number.isInteger(r.ordinal) && typeof r.description === 'string' && typeof r.reason === 'string' && ['GREEN','YELLOW','RED'].includes(r.confidence) && Array.isArray(r.candidates))) throw new Error('Saved draft contains unreadable transaction rows.')
      // Restored evidence is a snapshot, never current QuickBooks approval.
      state.analysis = saved.transactions.map(row => ({...row,financialApproval:false,approvalRequired:true,executable:false}))
      state.input = saved.input; state.source = saved.source || ''; state.notes = {}; state.selections = {}; state.savedRevision = null; state.savedActor = null; state.loadedScope = selected; state.categoryHistory = saved.categoryHistory; state.teachingRevisions = saved.teachingRevisions || []; state.page = 1
      for (const color of ['Green','Yellow','Red']) $('sandra' + color + 'Count').textContent = state.analysis.filter(row => row.confidence === color.toUpperCase()).length
      renderAnalysis()
      feedback(`Saved draft restored (${saved.savedAt}). Posted evidence may be stale. Select the CSV again and reanalyze to refresh it; no financial approval is saved.`)
    } catch (e) {if (current(selected,generation)) feedback(e.message)}
  }
  function renderRules() {
    $('sandraSavedRules').innerHTML = state.rules.map((r,i) => `<tr><td>${escape(r.merchant)}</td><td>${escape(r.direction === 'in' ? 'Received' : 'Spent')}</td><td>${escape(r.category)}</td><td>${escape(r.purpose)}</td><td><button type="button" data-remove-rule="${i}">Remove draft rule</button></td></tr>`).join('')
  }
  async function addRule() {
    const selected = scope(), generation = state.generation
    try {
      if (!state.scopeInfo || key(state.scopeInfo) !== key(selected)) await verifyScope(selected,generation)
      if (!current(selected,generation)) return
      const rule = {merchant:$('sandraRuleMerchant').value.trim(),direction:$('sandraRuleDirection').value,category:$('sandraRuleCategory').value.trim(),purpose:$('sandraRulePurpose').value.trim()}
      if (rule.merchant.length < 4 || rule.merchant.length > 100 || !rule.category || rule.category.length > 150 || !rule.purpose || rule.purpose.length > 400) throw new Error('Enter a merchant (4–100 characters), category and purpose.')
      if (state.rules.length >= 100) throw new Error('Maximum 100 rules.')
      state.rules = state.rules.filter(r => !(r.merchant.toLowerCase() === rule.merchant.toLowerCase() && r.direction === rule.direction)); state.rules.push(rule)
      saveDraft(); renderRules(); feedback('Draft rule saved for this connected company and account. Reanalyze the CSV to apply it. No accounting approval was granted.')
    } catch(e) {feedback(e.message)}
  }
  function renderAnalysis() {
    const text = $('sandraBankSearch')?.value.toLowerCase() || '', confidence = $('sandraConfidenceFilter')?.value || 'all'
    const rows = state.analysis.filter(row => (confidence === 'all' || (confidence === 'exceptions' ? row.reviewStatus !== 'prepared' : confidence === 'prepared' ? row.reviewStatus === 'prepared' : row.confidence === confidence)) && `${row.description} ${row.fromTo} ${row.suggestedCategory || ''} ${row.reason}`.toLowerCase().includes(text))
    const pageSize = 300, pages = Math.max(1,Math.ceil(rows.length / pageSize))
    state.page = Math.min(state.page,pages)
    const visible = rows.slice((state.page - 1)*pageSize,state.page*pageSize)
    $('sandraVisibleCount').textContent = `${rows.length} filtered / ${state.analysis.length} analyzed · page ${state.page} of ${pages} · 300 per page`
    $('sandraPreviousPage').disabled = state.page <= 1; $('sandraNextPage').disabled = state.page >= pages
    const prepared = state.analysis.filter(r => r.reviewStatus === 'prepared').length
    $('sandraDraftSummary').textContent = `${prepared} prepared · ${state.analysis.length - prepared} exceptions · ${Object.keys(state.notes).length} purpose notes · 0 financial approvals. All rows retained.`
    $('sandraAnalysisBody').innerHTML = visible.length ? visible.map(row => `<tr><td>${escape(row.date)}<div class="sandra-reason">File row ${row.ordinal}</div></td><td>${escape(row.description)}<div class="sandra-reason">${escape(row.fromTo || '')}</div></td><td class="money">${money(row.spent)}</td><td class="money">${money(row.received)}</td><td><span class="sandra-${row.confidence.toLowerCase()}">${escape(row.confidence)}</span></td><td>${escape(row.suggestion)}${row.suggestedCategory ? `<div>${escape(row.suggestedCategory)}</div>` : ''}<div class="sandra-reason">${escape(row.reason)}</div>${row.candidates.length ? `<details><summary>${row.candidates.length} candidate(s)</summary>${row.candidates.map(candidate => `<p class="sandra-reason">${escape(candidate.type)} #${escape(candidate.id)} · ${escape(candidate.txnDate)} · ${money(candidate.amount)} · ${escape(candidate.name)} · ${escape(candidate.category)}<br>${escape(candidate.evidence || "")} · ${escape(candidate.dateEvidence || "")}<br>${escape((candidate.possibleCauses || []).join(" "))}<br><button type="button" data-select-candidate="${row.ordinal}" data-candidate-key="${escape(candidate.type+":"+candidate.id)}">${state.selections[row.ordinal]===candidate.type+":"+candidate.id?"Selected for private review":"Select for private review"}</button>${candidate.type==="Purchase"?`<button type="button" data-category-candidate="${escape(candidate.id)}">Review category change</button>`:""}</p>`).join('')}</details>` : ''}</td><td>${row.reviewStatus === 'prepared' ? 'Prepared draft' : 'Exception'}<div class="sandra-reason">Financial approval required</div>${state.notes[row.ordinal] ? `<div class="sandra-reason">Purpose note: ${escape(state.notes[row.ordinal])}</div>` : ''}<div class="sandra-reason">${escape((row.possibleCauses || []).join(" "))}</div>${state.selections[row.ordinal]?`<div>Private selection: ${escape(state.selections[row.ordinal])}</div><button type="button" data-clear-candidate="${row.ordinal}">Clear selection</button>`:""}<button type="button" data-purpose-note="${row.ordinal}">Add purpose note</button><button type="button" data-teach-row="${row.ordinal}">Teach this merchant</button></td></tr>`).join('') : '<tr><td colspan="7">Upload and analyze a bank file to see Sandra’s recommendations.</td></tr>'
    $('sandraExportButton').disabled = !state.analysis.length
  }
  function exportReview() {
    if (!state.loadedScope || key(state.loadedScope) !== key(scope())) return
    const blob = new Blob([JSON.stringify({schemaVersion:2,...state.loadedScope,realmId:state.scopeInfo?.realmId,environment:state.scopeInfo?.environment,rules:state.rules,teachingRevisions:state.teachingRevisions,reviewOwner:state.savedActor,privateReviewSavedRevision:state.savedRevision,purposeNotes:state.notes,privateSelections:state.selections,financialApproval:false,generatedAt:new Date().toISOString(),source:'uploaded-bank-file',sourceFile:state.source,readOnly:true,executable:false,count:state.analysis.length,categoryHistory:state.categoryHistory,transactions:state.analysis},null,2)],{type:'application/json'})
    const url = URL.createObjectURL(blob), anchor = document.createElement('a'); anchor.href = url; anchor.download = `sandra-review-${state.loadedScope.companyKey}-${state.loadedScope.accountId}.json`; anchor.click(); URL.revokeObjectURL(url)
  }
  async function serverReview(save) {
    const selected=scope(),generation=state.generation
    if(!state.loadedScope||key(state.loadedScope)!==key(selected)||!state.input.length)throw Error('Analyze a bank file for this account first.')
    if(location.protocol!=='https:'&&!['localhost','127.0.0.1','[::1]'].includes(location.hostname))throw Error('Use HTTPS or localhost for owner credentials.')
    const credential=$('sandraOwnerKey').value.trim()
    if(!/^[a-f0-9]{64}$/.test(credential))throw Error('Enter your owner credential in Sandra teaching first.')
    const options={headers:{'X-Sandra-Owner-Key':credential}}
    if(save){
      if(state.savedRevision==null)throw Error('Load the owner review once before saving; this checks for an existing revision.')
      options.method='POST';options.headers['Content-Type']='application/json'
      options.body=JSON.stringify({realmId:state.scopeInfo.realmId,environment:state.scopeInfo.environment,expectedRevision:state.savedRevision,expectedActor:state.savedActor,input:state.input,reviews:state.input.map((r,i)=>{const k=state.selections[i+1],split=k?.indexOf(':');return {ordinal:i+1,note:state.notes[i+1]||'',candidate:k?{type:k.slice(0,split),id:k.slice(split+1)}:null}})})
    }
    const response=await fetch(`/quickbooks/bank-review-notes/${encodeURIComponent(selected.companyKey)}/${encodeURIComponent(selected.accountId)}`,options),data=await readJson(response)
    if(!current(selected,generation))return
    if(!response.ok||!data.success)throw Error(data.error||'Private review request failed.')
    if(data.realmId!==state.scopeInfo.realmId||data.environment!==state.scopeInfo.environment)throw Error('Company connection changed; reload.')
    if(save&&state.savedActor!==data.actor)throw Error('Owner changed. Reload the owner review.')
    state.savedRevision=data.review?.revision||0;state.savedActor=data.actor
    if(!save&&data.review){
      if(JSON.stringify(data.review.input)!==JSON.stringify(state.input))throw Error('The saved review belongs to another bank file. Your current rows and notes were kept; saving will replace the previous private review after confirmation.')
      state.notes={};state.selections={}
      for(const r of data.review.reviews){if(r.note)state.notes[r.ordinal]=r.note;if(r.candidate){const row=state.analysis.find(x=>x.ordinal===r.ordinal);if(row?.candidates.some(c=>c.type===r.candidate.type&&c.id===r.candidate.id))state.selections[r.ordinal]=r.candidate.type+':'+r.candidate.id}}
      saveDraft();renderAnalysis()
    }
    feedback(save?'Owner-scoped review saved on your FRIDAY PC. QuickBooks was not changed.':data.review?'Saved owner review loaded; unavailable candidates were left unselected.':'No saved review for this owner/account. You can now save your current notes.')
  }
  window.sandraBankingApi = {loadAccounts, loadLedger, renderLedger, clearReview, cards, importCsv, revision: () => state.generation, getSelection:scope, getPostedRows:() => state.ledger}
  document.addEventListener('DOMContentLoaded', () => {
    const save=document.createElement('button'),load=document.createElement('button');save.type=load.type='button';save.textContent='Save owner review';load.textContent='Load owner review';save.id='sandraSaveOwnerReview';load.id='sandraLoadOwnerReview';$('sandraExportButton').after(load,save);load.addEventListener('click',()=>serverReview(false).catch(e=>feedback(e.message)));save.addEventListener('click',()=>{if(confirm('Save these private selections and notes for the current company, account and verified owner? This replaces the previous saved bank-file review. QuickBooks is unchanged.'))serverReview(true).catch(e=>feedback(e.message))});$('sandraOwnerKey').addEventListener('input',()=>{state.savedRevision=null;state.savedActor=null});
    $('sandraPostedTab').addEventListener('click', () => showPanel('posted'))
    $('sandraCsvTab').addEventListener('click', () => showPanel('csv'))
    $('sandraAnalyzeButton').addEventListener('click',analyze)
    $('sandraBankSearch').addEventListener('input',() => {state.page = 1; renderAnalysis()}); $('sandraConfidenceFilter').addEventListener('change',() => {state.page = 1; renderAnalysis()})
    $('sandraRestoreDraft').addEventListener('click',restoreDraft)
    $('sandraAddRule').addEventListener('click',addRule)
    $('sandraSavedRules').addEventListener('click',e => {const b = e.target.closest('[data-remove-rule]'); if (!b) return; state.rules.splice(Number(b.dataset.removeRule),1); saveDraft(); renderRules(); feedback('Draft rule removed. Reanalyze to refresh suggestions.')})
    $('sandraPreviousPage').addEventListener('click',() => {state.page--; renderAnalysis()})
    $('sandraNextPage').addEventListener('click',() => {state.page++; renderAnalysis()})
    $('sandraAnalysisBody').addEventListener('click',e => {const selected=e.target.closest('[data-select-candidate]');if(selected){state.selections[selected.dataset.selectCandidate]=selected.dataset.candidateKey;saveDraft();renderAnalysis();feedback('Private selection kept in this tab. Use Load owner review, then Save owner review to keep it on your PC. No QuickBooks matching or financial approval.');return}const clear=e.target.closest('[data-clear-candidate]');if(clear){delete state.selections[clear.dataset.clearCandidate];saveDraft();renderAnalysis();return}const category=e.target.closest('[data-category-candidate]');if(category){document.dispatchEvent(new CustomEvent('sandra-category-candidate',{detail:{purchaseId:category.dataset.categoryCandidate,scope:scope()}}));return}const teach=e.target.closest('[data-teach-row]'); if(teach){const row=state.analysis.find(r=>r.ordinal===Number(teach.dataset.teachRow)); if(row) document.dispatchEvent(new CustomEvent('sandra-teach-row',{detail:{row,scope:scope()}})); return} const b = e.target.closest('[data-purpose-note]'); if (!b) return; const note = prompt('Business purpose note (draft only; does not approve any QuickBooks action):',state.notes[b.dataset.purposeNote] || ''); if (note === null) return; if (note.trim()) state.notes[b.dataset.purposeNote] = note.trim().slice(0,1000); else delete state.notes[b.dataset.purposeNote]; saveDraft(); renderAnalysis()})
    $('sandraExportButton').addEventListener('click',exportReview)
    $('bankingAccountSelector').addEventListener('change',clearReview)
    $('bankingMonth').addEventListener('change', () => {clearReview(); showPanel('posted'); $('bankingTypeSummary').textContent = 'Read posted activity for the selected month.'; feedback('Month changed. The previous bank file and review were cleared. Choose a file for the selected month.')})
    $('sandraBankFile').addEventListener('change', () => {state.generation++; state.analysis = []; state.loadedScope = null; state.categoryHistory = null; $('sandraScopeConfirmed').checked = false; $('sandraAnalyzeButton').disabled = false; for (const color of ['Green','Yellow','Red']) $('sandra' + color + 'Count').textContent = '—'; renderAnalysis(); feedback('Confirm the account scope, then analyze this file.')})
    document.addEventListener('sandra-company-changed', () => {state.accountRequest++; state.accountsCompany = null; fridayBankAccounts = []; clearReview(); loadAccounts()})
    const observer = new MutationObserver(() => document.body.classList.toggle('sandra-banking-open', $('bankingWorkspace').classList.contains('active')))
    observer.observe($('bankingWorkspace'),{attributes:true,attributeFilter:['class']})
    if (fridayQuickBooksState.companyKey) loadAccounts()
  })
})()
// END [QUICKBOOKS-DASH-21B] Company-scoped API banking review controller
