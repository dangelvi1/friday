# FRIDAY Bank Review update — 20261014-3

For Salvador and Dayanna's existing PC-hosted app at `S:\AI\friday-ai`. Installs over the confirmed Document Analysis v2 installation. No hosting migration, new OAuth connection, credential replacement or separated Nationwide/Sara service change is included. Installing files does not change QuickBooks records.

## What changed

- Bank CSV candidates show the exact QuickBooks-versus-statement date offset and evidence. Equal amount/direction candidates remain within seven days; identity/reference evidence is still required for stronger confidence. Multiple candidates, shared candidates, repeated rows and sensitive transactions remain review items.
- Each candidate can be selected for private review. Notes/selections stay in the current tab until **Load owner review**, then **Save owner review**. These save on your own PC under the verified owner, company, actual realm, environment and bank account. Optimistic revision checks prevent stale overwrites. One current saved bank-file review is kept per owner/account; download review JSON before replacing it with a different file. Analysis snapshots/rules can still be restored from browser drafts, but private notes are not restored from unverified shared-browser storage. Export old browser drafts before installing if you need to retain their old notes. Selecting a candidate does not match a QuickBooks Pending item or approve an accounting change.
- Reconciliation now uses counted, paginated posted records and refuses partial reads. It handles eight supported transaction types and avoids counting a deposited Payment again. Exact-period totals use integer cents. Records within seven days outside the period are shown separately and excluded from totals. Missing balances stay unknown instead of becoming zero. Equal totals do not mean an official reconciliation is complete.
- Possible causes include transaction/posting dates, month boundaries, outstanding items, processing delays, fees, split/grouped amounts, duplicates, opening balances and excluded Pending/unsupported records. These are review possibilities, not a diagnosis of your real statement.
- Statement upload/list/file access now requires the existing verified owner. PDF signatures, CSV text, dates, exact two-decimal balances and safe paths are checked. Local writes are serialized and metadata is replaced atomically. Successful upload clears its form; failures keep it. Records remain scoped to their uploading owner. New records also retain connected realm/environment; legacy records have no historical realm proof and remain tied to their original owner/company/account. The local `reconciled` label is a private status, not a QuickBooks reconciliation.
- **Review statement rows** loads a saved CSV into Banking; confirm account and Analyze. PDF upload stores/displays the PDF for manual review and balance entry. **PDF transaction OCR is not implemented in this update.** Use a transaction-only bank CSV for row matching; statement headers/footers are not transaction rows.
- A Purchase candidate's **Review category change** opens Sandra teaching with its actual Purchase ID. The existing posted-category preview/approval/receipt flow is preserved. The preview displays the actual saved lesson's purpose, exclusions and questions. Free-text conditions require your transaction-specific judgment; merchant identity alone does not resolve them. Split/item/taxed/refund/foreign-currency expenses still require manual QuickBooks review. No broad automatic categorization is introduced.
- **Open in QuickBooks** buttons appear beside invoice/customer names in Sales, Customer 360, the invoice editor, customer results, customer reports and Document Analysis candidates where the actual ID is available. Invoice number `2020` can link to internal ID `71`; the number is never treated as the ID. Production links use your signed-in QuickBooks browser company, so verify the same company there. Sandbox/unknown-ID links are disabled or omitted. Embedded separated employee systems are unchanged.
- Existing multi-line invoice creation/editing remain intact, with existing services, rates, quantities, dates, terms, notes and line tax behavior. They now require a backend-verified owner and actual company scope rather than trusting an owner name in a request. **Review invoice deletion** adds a 15-minute snapshot preview, explicit confirmation, linked-payment/credit review when applicable, fresh revision checks and a durable receipt. Deletion is an accounting change. Submitted/uncertain deletes are blocked across new previews and both owners; inspect QuickBooks and the receipt instead of retrying. This preserves the existing invoice editor's scope, not every possible feature of the native QuickBooks editor.
- Natural conversational Realtime voice remains. Read navigation covers the dashboard sections, including Expenses, Sales, Customers, Banking and Chart of Accounts. Added customer/account searches, visible-ID customer opening, bank-account selection and YYYY-MM read filters. MONTH / CLAIM, JOB LOCATION / CARRIER and JOB NAME searches retain text/leading zeros and remain limited to loaded invoices. The existing pointer stays visible. Realtime `audio_interrupted` now sends Stop. Voice cannot approve financial writes, upload a file, enter an owner key or make an uncertain submission retry.

## Install

Stop only the FRIDAY backend and export any old Sandra browser drafts you need. Extract the ZIP under `S:\AI\Fixing-Files-Folder\FRIDAY-Bank-Review-Update-v3`. From any PowerShell folder:

```powershell
$packageRoot = 'S:\AI\Fixing-Files-Folder\FRIDAY-Bank-Review-Update-v3'
$installers = @(Get-ChildItem -LiteralPath $packageRoot -Filter 'Install-Bank-Review.ps1' -File -Recurse -ErrorAction Stop)
if ($installers.Count -ne 1) { throw 'Expected exactly one v3 installer in the extracted package folder.' }
$installer = $installers[0].FullName
Unblock-File -LiteralPath $installer
Unblock-File -LiteralPath (Join-Path (Split-Path $installer) 'Restore-Bank-Review.ps1')
& $installer -ProjectPath 'S:\AI\friday-ai'
```

This finds the actual extracted installer, including a nested package directory. It does not depend on your current `C:\Users\Salvador` folder or change execution policy. If your policy requires signed scripts after unblocking, use your existing administrator-approved signing process; no bypass is included.

The installer verifies all package hashes, unchanged prerequisites and installed baselines before copying; verifies timestamped backups; copies only listed application/test files; and rolls back attempted copies on failure. It refuses conflicts rather than overwriting local edits. Existing AGENTS.md, credentials, .env, certificates, uploads and databases are never copied over. Package.json/lock are unchanged; no new runtime dependencies.

Rebuild the existing voice frontend on your PC using its existing certificate/configuration, then restart your normal FRIDAY services:

```powershell
Set-Location -LiteralPath 'S:\AI\friday-ai'
npm run build
npm run server
```

If you normally run the frontend with Vite development mode, keep your existing frontend launch workflow instead. Hard-refresh the dashboard and voice home page, close old review tabs and open the conversational QuickBooks link again. Do not disable HTTPS/certificate verification.

Use **Verify owner** beside the company environment badge or the existing owner key field under Sandra teaching. The installer does not create/invent keys. If `credentials\sandra-owner-access.json` or private OAuth/database configuration is absent, restore your existing private setup locally; do not upload credentials to GitHub/chat.

## First real test — Nationwide / BOFA CONSTRUCTION – 7015

1. Select Nationwide and verify Production versus Sandbox. Select BOFA CONSTRUCTION – 7015 by its actual loaded account ID; do not assume a hard-coded ID.
2. Read posted activity for your statement month. Upload your statement in Statements, enter its exact dates/balances and click Reconcile. Review totals, possible causes and excluded boundary records. A failed read is an error, never a successful empty result.
3. For row comparison, use a transaction-only CSV with `Date,Description,Amount` (negative spent/positive received) or Date/Description/Spent/Received. Optional payee/reference fields help. From a saved CSV click **Review statement rows**, confirm the displayed company/account and Analyze. Verify at least one 1–2 day date difference, an unmatched amount, a repeated amount and multiple candidates against the original statement.
4. Add notes and select candidates. Load the owner review once to check its revision, then Save. Reload and verify persistence. Download review JSON before replacing the current saved file review. No QuickBooks records change during this sequence.
5. Test invoice/customer buttons against actual known records; verify the signed-in QuickBooks company and actual invoice number in the native view. Test invoice create/edit/delete first in a sandbox or with owner-approved test records. Read linked-payment warnings and receipts.
6. To test a posted category update, load teaching, choose an owner-approved category and select a single eligible Purchase candidate. Preview the exact before/after and review purpose, exclusions and reconciliation. Posted writes remain disabled unless your existing server configuration enables `SANDRA_ENABLE_POSTED_CATEGORY_WRITES=true`. After approving that live test, you may set this for only the backend PowerShell session:

```powershell
Set-Location -LiteralPath 'S:\AI\friday-ai'
$env:SANDRA_ENABLE_POSTED_CATEGORY_WRITES = 'true'
npm run server
```

This only enables the existing guarded posted-Purchase category path. It does not enable Pending-feed matching, official reconciliation or automatic approval. Restart with the flag removed/false to disable it. Do not submit uncertain actions again.

## Restore

Stop FRIDAY and run `Restore-Bank-Review.ps1` from the exact printed `backups\bank-review-v3-...` directory. It checks installed/backup hashes and refuses later-edited files. New private bank-review JSON and invoice receipts, statement uploads and existing PostgreSQL data are retained. Normal owner-controlled data backups remain separate from the application-file backup. Restoring older application code also restores its older authorization/statement access behavior; review your existing access controls before using it.

See AUDIT-AND-PLAN.md, VALIDATION.md and AGENTS-MERGE-PROPOSAL.md. No live OAuth, bank, customer, microphone or financial account was contacted for these automated checks.
