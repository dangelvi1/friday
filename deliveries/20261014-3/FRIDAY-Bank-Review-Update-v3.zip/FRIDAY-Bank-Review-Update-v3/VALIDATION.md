# Validation and limitations

Automated synthetic checks: 51 specific test cases (55 Node test entries including four parent tests) passed. These use fixture owner keys, isolated temporary data, pg-mem for teaching/review SQL, mocked QuickBooks/OCR responses, registered Express routes and actual Chromium. External account requests are intercepted; no live account is used.

Coverage includes one/two-day offsets, exact cents, repeated/shared/ambiguous candidates, complete reads over 1,000 records, incomplete-read rejection, boundary records excluded from balance totals, blank statement balances, scope/owner checks, atomic private saves and stale revisions, statement file validation/access, Sandra teaching and actual guarded single-line category execution/re-read/receipt, preserved multi-line create/update and SyncToken rejection, deletion preview/durable submission/uncertain-outcome blocking, dashboard controls and actual-ID links, all paired read navigation sections, company rejection, active Stop cancellation, bank account/month selection, CSV upload/offset display/private selection/server save, and the previous 34 Document Analysis regression cases.

Frontend TypeScript and targeted changed-backend TypeScript pass. JavaScript syntax checks pass. A standalone Vite production bundle build with configFile:false passes; it checks frontend compilation while leaving the actual PC TLS configuration untouched. The normal npm run build cloud configuration needs omitted Windows certificate paths, so its configured TLS/build workflow is not certified here. Existing large-bundle warning remains.

Windows PowerShell is unavailable in this Linux environment. Installer/restore scripts and the exact command were inspected; package/source hashes and archive structure were verified. **Actual Windows installation and rollback were not executed.** Baseline conflicts stop before any copy. Production PostgreSQL/advisory locks, real concurrent processes, OAuth refresh, bank-provider feeds, native QuickBooks deep links/tax/email/deletion effects, original statement data, Windows pointer/microphone and live conversation require owner-PC validation. pg-mem is not a substitute for production transaction/locking semantics.

New private JSON stores serialize writes within the single existing FRIDAY backend process. Invoice-delete claims also use exclusive durable files. Multi-process shared-drive deployment is not tested or introduced. Normal private-data backup/access controls remain the owner's existing workflow.

Optional reproduction on the owner PC (test-only dependency directory; no runtime package/lock edits):

```powershell
Set-Location -LiteralPath 'S:\AI\friday-ai'
npm install --prefix .test-tools --no-save --package-lock=false pg-mem
$env:FRIDAY_TEST_TOOLS = Join-Path (Get-Location) '.test-tools'
$env:FRIDAY_CHROMIUM_PATH = Join-Path $env:ProgramFiles 'Google\Chrome\Application\chrome.exe'
if (!(Test-Path -LiteralPath $env:FRIDAY_CHROMIUM_PATH)) { throw 'Set FRIDAY_CHROMIUM_PATH to your actual installed Chromium/Chrome executable before running browser tests.' }
node --import tsx --test tests/bank-workflows.test.ts tests/document-review.test.ts
```

Screenshots default to project .test-artifacts (synthetic only). Tests create isolated temporary fixture data and intercept server-side external requests; do not run against production DB data or substitute real credentials into fixtures. The repository's regular dependencies must already be installed.
