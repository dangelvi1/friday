// ============================================================
// FRIDAY QUICKBOOKS FEATURE MODULE
// FILE: S:\AI\friday-ai\quickbooks\invoice-create.ts
// PURPOSE: Small, focused QuickBooks route module.
// ============================================================

import type {
  Express,
} from 'express'

import {
  getValidQuickBooksConnection,
} from './connection'

import {
  runQuickBooksQuery,
} from './query'

import {
  getQuickBooksApiBaseUrl,
} from './quickbooks-auth'

export function registerQuickBooksInvoiceCreate(
  app:
    Express
) {

// START [QUICKBOOKS-25] Approved multi-line QuickBooks invoice creation + service date + per-line tax + optional send
// ACTION: REPLACE ENTIRE EXISTING QUICKBOOKS-25 BLOCK
// FILE: S:\AI\friday-ai\quickbooks\routes.ts
// PLACE: Below [QUICKBOOKS-24] Multi-line invoice draft preview
// PURPOSE:
// - Create QuickBooks invoices only after explicit approval
// - Support unlimited Product / Service lines
// - Support ServiceDate per invoice line
// - Support Description, Qty, Rate and Amount
// - Support taxable / non-taxable per invoice line
// - Preserve QuickBooks TaxCodeRef per line
// - Support invoice date, due date, email, memo and private note
// - Validate selected QuickBooks payment term
// - Send SalesTermRef on created invoices
// - Optionally email invoice after creation
// - Keep accounting write approval restricted to Salvador / Dayanna
// USERS: Salvador and Dayanna
// ============================================================

app.post(
  '/quickbooks/invoice-action/:companyKey',
  async (
    req,
    res
  ) => {
    try {

      const companyKey =
        String(
          req.params.companyKey ||
          ''
        )
          .trim()
          .toLowerCase()


      const approved =
        req.body?.approved ===
        true


      const approvedBy =
        String(
          req.body?.approvedBy ||
          ''
        )
          .trim()
          .toLowerCase()


      const action =
        String(
          req.body?.action ||
          ''
        )
          .trim()
          .toLowerCase()


      const customerId =
        String(
          req.body?.customerId ||
          ''
        )
          .trim()


      const txnDate =
        String(
          req.body?.txnDate ||
          ''
        )
          .trim()


      const dueDate =
        String(
          req.body?.dueDate ||
          ''
        )
          .trim()


      const termId =
        String(
          req.body?.termId ||
          ''
        )
          .trim()


      const docNumber =
        String(
          req.body?.docNumber ||
          ''
        )
          .trim()


      const billEmail =
        String(
          req.body?.billEmail ||
          ''
        )
          .trim()


      const customerMemo =
        String(
          req.body?.customerMemo ||
          ''
        )
          .trim()


      const privateNote =
        String(
          req.body?.privateNote ||
          ''
        )
          .trim()


      const inputLines =
        Array.isArray(
          req.body?.lines
        )
          ? req.body.lines
          : []


      // ============================================================
      // START [QUICKBOOKS-25A] Explicit invoice write approval gate
      // ============================================================

      if (!approved) {

        return res
          .status(403)
          .json({
            success:
              false,

            approvalRequired:
              true,

            error:
              'Explicit approval is required before creating or sending an invoice.',
          })
      }


      if (
        approvedBy !==
          'salvador' &&
        approvedBy !==
          'dayanna'
      ) {

        return res
          .status(403)
          .json({
            success:
              false,

            approvalRequired:
              true,

            error:
              'approvedBy must be Salvador or Dayanna.',
          })
      }


      if (
        action !==
          'create' &&
        action !==
          'create-and-send'
      ) {

        return res
          .status(400)
          .json({
            success:
              false,

            error:
              'action must be create or create-and-send.',
          })
      }

      // ============================================================
      // END [QUICKBOOKS-25A] Explicit invoice write approval gate
      // ============================================================


      if (!customerId) {

        return res
          .status(400)
          .json({
            success:
              false,

            error:
              'customerId is required.',
          })
      }


      if (
        inputLines.length ===
        0
      ) {

        return res
          .status(400)
          .json({
            success:
              false,

            error:
              'At least one invoice line is required.',
          })
      }


      if (
        action ===
          'create-and-send' &&
        !billEmail
      ) {

        return res
          .status(400)
          .json({
            success:
              false,

            error:
              'billEmail is required when action is create-and-send.',
          })
      }


      if (
        txnDate &&
        !/^\d{4}-\d{2}-\d{2}$/
          .test(
            txnDate
          )
      ) {

        return res
          .status(400)
          .json({
            success:
              false,

            error:
              'txnDate must use YYYY-MM-DD.',
          })
      }


      if (
        dueDate &&
        !/^\d{4}-\d{2}-\d{2}$/
          .test(
            dueDate
          )
      ) {

        return res
          .status(400)
          .json({
            success:
              false,

            error:
              'dueDate must use YYYY-MM-DD.',
          })
      }


      const connection =
        await getValidQuickBooksConnection(
          companyKey
        )
      if (res.locals.invoiceOwnerScope?.realmId !== String(connection.realm_id) || res.locals.invoiceOwnerScope?.environment !== connection.environment) {
        return res.status(409).json({success:false,error:'Connected company changed. Review the invoice again.'})
      }



      const baseUrl =
        getQuickBooksApiBaseUrl(
          connection.environment
        )


      // ============================================================
      // START [QUICKBOOKS-25B] QuickBooks entity query helper
      // ============================================================

      async function runQuickBooksQuery(
        query:
          string
      ) {

        const url =
          `${baseUrl}` +
          `/v3/company/` +
          `${encodeURIComponent(
            connection.realm_id
          )}` +
          `/query?query=` +
          `${encodeURIComponent(
            query
          )}`


        const response =
          await fetch(
            url,
            {
              method:
                'GET',

              headers: {
                Authorization:
                  `Bearer ${connection.access_token}`,

                Accept:
                  'application/json',
              },
            }
          )


        const data =
          await response.json()


        if (!response.ok) {

          throw new Error(
            JSON.stringify(
              data
            )
          )
        }


        return data
      }

      // ============================================================
      // END [QUICKBOOKS-25B] QuickBooks entity query helper
      // ============================================================


      const safeCustomerId =
        customerId
          .replace(
            /\\/g,
            '\\\\'
          )
          .replace(
            /'/g,
            "\\'"
          )


      const customerData =
        await runQuickBooksQuery(
          `SELECT * FROM Customer ` +
          `WHERE Id = '${safeCustomerId}' ` +
          `MAXRESULTS 1`
        )


      const customer =
        customerData
          ?.QueryResponse
          ?.Customer
          ?.[0] ||
        null


      if (!customer) {

        return res
          .status(404)
          .json({
            success:
              false,

            error:
              'Customer not found.',
          })
      }


      // ------------------------------------------------------------
      // VALIDATE PAYMENT TERM
      // ------------------------------------------------------------

      let paymentTerm:
        any =
        null


      if (termId) {

        const safeTermId =
          termId
            .replace(
              /\\/g,
              '\\\\'
            )
            .replace(
              /'/g,
              "\\'"
            )


        const termData =
          await runQuickBooksQuery(
            `SELECT * FROM Term ` +
            `WHERE Id = '${safeTermId}' ` +
            `MAXRESULTS 1`
          )


        paymentTerm =
          termData
            ?.QueryResponse
            ?.Term
            ?.[0] ||
          null


        if (!paymentTerm) {

          return res
            .status(404)
            .json({
              success:
                false,

              error:
                `QuickBooks payment term ${termId} was not found.`,
            })
        }


        if (
          paymentTerm.Active ===
          false
        ) {

          return res
            .status(400)
            .json({
              success:
                false,

              error:
                `QuickBooks payment term ${paymentTerm.Name || termId} is inactive.`,
            })
        }
      }



      // ------------------------------------------------------------
      // RE-CHECK CUSTOM INVOICE NUMBER IMMEDIATELY BEFORE WRITE
      // ------------------------------------------------------------

      if (docNumber) {
        const safeDocNumber =
          docNumber
            .replace(
              /\\/g,
              '\\\\'
            )
            .replace(
              /'/g,
              "\\'"
            )

        const invoiceNumberData =
          await runQuickBooksQuery(
            `SELECT * FROM Invoice ` +
            `WHERE DocNumber = '${safeDocNumber}' ` +
            `MAXRESULTS 1`
          )

        const existingInvoice =
          invoiceNumberData
            ?.QueryResponse
            ?.Invoice
            ?.[0] ||
          null

        if (existingInvoice) {
          return res
            .status(409)
            .json({
              success: false,
              stage: 'create',
              error:
                `Invoice number ${docNumber} already exists in QuickBooks. Use Auto or choose another number.`,
              duplicateDocNumber: true,
              existingInvoiceId:
                existingInvoice.Id ||
                null,
              existingDocNumber:
                existingInvoice.DocNumber ||
                docNumber,
            })
        }
      }


      // ============================================================
      // START [QUICKBOOKS-25C] Multi-line validation + SalesItemLineDetail builder
      // ============================================================

      const quickBooksLines:
        any[] =
        []


      const validatedLines:
        any[] =
        []


      let expectedSubtotal =
        0


      let expectedTaxableSubtotal =
        0


      for (
        let lineIndex = 0;
        lineIndex <
        inputLines.length;
        lineIndex += 1
      ) {

        const inputLine =
          inputLines[
            lineIndex
          ]


        const lineNumber =
          lineIndex +
          1


        const itemId =
          String(
            inputLine?.itemId ||
            ''
          )
            .trim()


        const description =
          String(
            inputLine?.description ||
            ''
          )
            .trim()


        const serviceDate =
          String(
            inputLine?.serviceDate ||
            ''
          )
            .trim()


        const quantity =
          Number(
            inputLine?.quantity ??
            1
          )


        const unitPrice =
          Number(
            inputLine?.unitPrice ??
            0
          )


        const taxable =
          inputLine?.taxable ===
          true


        const taxCodeId =
          String(
            inputLine?.taxCodeId ||
            ''
          )
            .trim()


        if (!itemId) {

          return res
            .status(400)
            .json({
              success:
                false,

              error:
                `Invoice line ${lineNumber} requires itemId.`,
            })
        }


        if (
          serviceDate &&
          !/^\d{4}-\d{2}-\d{2}$/
            .test(
              serviceDate
            )
        ) {

          return res
            .status(400)
            .json({
              success:
                false,

              error:
                `Invoice line ${lineNumber} has an invalid serviceDate. Expected YYYY-MM-DD.`,
            })
        }


        if (
          !Number.isFinite(
            quantity
          ) ||
          quantity <=
            0
        ) {

          return res
            .status(400)
            .json({
              success:
                false,

              error:
                `Invoice line ${lineNumber} has an invalid quantity.`,
            })
        }


        if (
          !Number.isFinite(
            unitPrice
          ) ||
          unitPrice <
            0
        ) {

          return res
            .status(400)
            .json({
              success:
                false,

            error:
                `Invoice line ${lineNumber} has an invalid unitPrice.`,
            })
        }


        const safeItemId =
          itemId
            .replace(
              /\\/g,
              '\\\\'
            )
            .replace(
              /'/g,
              "\\'"
            )


        const itemData =
          await runQuickBooksQuery(
            `SELECT * FROM Item ` +
            `WHERE Id = '${safeItemId}' ` +
            `MAXRESULTS 1`
          )


        const item =
          itemData
            ?.QueryResponse
            ?.Item
            ?.[0] ||
          null


        if (!item) {

          return res
            .status(404)
            .json({
              success:
                false,

              error:
                `QuickBooks item ${itemId} on invoice line ${lineNumber} was not found.`,
            })
        }


        const amount =
          Number(
            (
              quantity *
              unitPrice
            )
              .toFixed(
                2
              )
          )


        expectedSubtotal +=
          amount


        if (taxable) {

          expectedTaxableSubtotal +=
            amount
        }


        const salesItemLineDetail:
          any = {

          ItemRef: {
            value:
              String(
                item.Id
              ),

            name:
              item.Name ||
              undefined,
          },


          Qty:
            quantity,


          UnitPrice:
            unitPrice,
        }


        if (serviceDate) {

          salesItemLineDetail
            .ServiceDate =
              serviceDate
        }


        // QuickBooks US invoice lines require TAX / NON here.
        // Do not send the numeric TaxCode entity Id (for example "2")
        // in SalesItemLineDetail.TaxCodeRef.
        const quickBooksLineTaxCode =
          taxable
            ? 'TAX'
            : 'NON'


        salesItemLineDetail
          .TaxCodeRef = {
            value:
              quickBooksLineTaxCode,
          }


        const quickBooksLine =
          {

            DetailType:
              'SalesItemLineDetail',


            Amount:
              amount,


            Description:
              description ||
              item.Description ||
              item.Name ||
              undefined,


            SalesItemLineDetail:
              salesItemLineDetail,
          }


        quickBooksLines.push(
          quickBooksLine
        )


        validatedLines.push({

          lineNumber,


          serviceDate:
            serviceDate ||
            null,


          itemId:
            String(
              item.Id
            ),


          itemName:
            item.Name ||
            null,


          description:
            description ||
            item.Description ||
            item.Name ||
            null,


          quantity,


          unitPrice,


          amount,


          taxable,


          taxCodeId:
            taxCodeId ||
            null,
        })
      }


      expectedSubtotal =
        Number(
          expectedSubtotal
            .toFixed(
              2
            )
        )


      expectedTaxableSubtotal =
        Number(
          expectedTaxableSubtotal
            .toFixed(
              2
            )
        )

      // ============================================================
      // END [QUICKBOOKS-25C] Multi-line validation + SalesItemLineDetail builder
      // ============================================================


      // ============================================================
      // START [QUICKBOOKS-25D] Approved invoice payload builder
      // ============================================================

      const invoicePayload:
        any = {

        CustomerRef: {
          value:
            String(
              customer.Id
            ),

          name:
            customer.DisplayName ||
            undefined,
        },


        Line:
          quickBooksLines,
      }


      if (docNumber) {

        invoicePayload
          .DocNumber =
            docNumber
      }


      if (txnDate) {

        invoicePayload
          .TxnDate =
            txnDate
      }


      if (dueDate) {

        invoicePayload
          .DueDate =
            dueDate
      }


      if (
        paymentTerm &&
        termId
      ) {

        invoicePayload
          .SalesTermRef = {

            value:
              String(
                paymentTerm.Id ||
                termId
              ),

            name:
              paymentTerm.Name ||
              undefined,
          }
      }


      if (billEmail) {

        invoicePayload
          .BillEmail = {
            Address:
              billEmail,
          }
      }


      if (customerMemo) {

        invoicePayload
          .CustomerMemo = {
            value:
              customerMemo,
          }
      }


      if (privateNote) {

        invoicePayload
          .PrivateNote =
            privateNote
      }

      // ============================================================
      // END [QUICKBOOKS-25D] Approved invoice payload builder
      // ============================================================


      // ============================================================
      // START [QUICKBOOKS-25E] Create approved QuickBooks invoice
      // ============================================================

      const createUrl =
        `${baseUrl}` +
        `/v3/company/` +
        `${encodeURIComponent(
          connection.realm_id
        )}` +
        `/invoice`


      const createResponse =
        await fetch(
          createUrl,
          {
            method:
              'POST',

            headers: {
              Authorization:
                `Bearer ${connection.access_token}`,

              Accept:
                'application/json',

              'Content-Type':
                'application/json',
            },

            body:
              JSON.stringify(
                invoicePayload
              ),
          }
        )


      const createData =
        await createResponse.json()


      if (!createResponse.ok) {

        console.error(
          'QUICKBOOKS CREATE INVOICE ERROR:',
          createData
        )


        return res
          .status(
            createResponse.status
          )
          .json({
            success:
              false,

            stage:
              'create',

            error:
              'QuickBooks invoice creation failed.',

            details:
              createData,
          })
      }


      const createdInvoice =
        createData?.Invoice ||
        null


      if (
        !createdInvoice?.Id
      ) {

        throw new Error(
          'QuickBooks created the request but did not return an Invoice Id.'
        )
      }

      // ============================================================
      // END [QUICKBOOKS-25E] Create approved QuickBooks invoice
      // ============================================================


      // ============================================================
      // START [QUICKBOOKS-25F] Optional approved invoice email send
      // ============================================================

      let sendResult:
        any =
        null


      if (
        action ===
        'create-and-send'
      ) {

        const sendUrl =
          `${baseUrl}` +
          `/v3/company/` +
          `${encodeURIComponent(
            connection.realm_id
          )}` +
          `/invoice/` +
          `${encodeURIComponent(
            String(
              createdInvoice.Id
            )
          )}` +
          `/send?sendTo=` +
          `${encodeURIComponent(
            billEmail
          )}`


        const sendResponse =
          await fetch(
            sendUrl,
            {
              method:
                'POST',

              headers: {
                Authorization:
                  `Bearer ${connection.access_token}`,

                Accept:
                  'application/json',

                'Content-Type':
                  'application/octet-stream',
              },
            }
          )


        const sendData =
          await sendResponse.json()


        if (!sendResponse.ok) {

          console.error(
            'QUICKBOOKS SEND INVOICE ERROR:',
            sendData
          )


          return res
            .status(
              sendResponse.status
            )
            .json({
              success:
                false,

              stage:
                'send',

              invoiceCreated:
                true,

              invoiceId:
                createdInvoice.Id,

              docNumber:
                createdInvoice.DocNumber ||
                null,

              error:
                'Invoice was created successfully, but email sending failed.',

              details:
                sendData,
            })
        }


        sendResult = {
          sent:
            true,

          sentTo:
            billEmail,

          emailStatus:
            sendData
              ?.Invoice
              ?.EmailStatus ||
            null,

          deliveryInfo:
            sendData
              ?.Invoice
              ?.DeliveryInfo ||
            null,
        }
      }

      // ============================================================
      // END [QUICKBOOKS-25F] Optional approved invoice email send
      // ============================================================


      res.json({
        success:
          true,

        companyKey,

        companyName:
          connection.company_name,

        approved:
          true,

        approvedBy,

        action,

        result: {

          invoiceId:
            createdInvoice.Id,

          docNumber:
            createdInvoice.DocNumber ||
            null,

          requestedDocNumber:
            docNumber ||
            null,

          invoiceNumberMode:
            docNumber
              ? 'custom'
              : 'auto',

          customerId:
            createdInvoice
              ?.CustomerRef
              ?.value ||
            customerId,

          customerName:
            createdInvoice
              ?.CustomerRef
              ?.name ||
            customer.DisplayName ||
            null,

          lineCount:
            validatedLines.length,

          lines:
            validatedLines,

          expectedSubtotal,

          expectedTaxableSubtotal,

          quickBooksTotal:
            Number(
              createdInvoice.TotalAmt ||
              0
            ),

          balance:
            Number(
              createdInvoice.Balance ||
              0
            ),

          txnDate:
            createdInvoice.TxnDate ||
            txnDate ||
            null,

          dueDate:
            createdInvoice.DueDate ||
            dueDate ||
            null,

          termId:
            createdInvoice
              ?.SalesTermRef
              ?.value ||
            (
              paymentTerm
                ?.Id
                ? String(
                    paymentTerm.Id
                  )
                : null
            ),

          termName:
            createdInvoice
              ?.SalesTermRef
              ?.name ||
            paymentTerm
              ?.Name ||
            null,

          paymentTerm:
            (
              createdInvoice
                ?.SalesTermRef
                ?.value ||
              paymentTerm
                ?.Id
            )
              ? {
                  id:
                    String(
                      createdInvoice
                        ?.SalesTermRef
                        ?.value ||
                      paymentTerm
                        ?.Id ||
                      ''
                    ),

                  name:
                    createdInvoice
                      ?.SalesTermRef
                      ?.name ||
                    paymentTerm
                      ?.Name ||
                    null,

                  dueDays:
                    Number(
                      paymentTerm
                        ?.DueDays ??
                      0
                    ),
                }
              : null,

          emailStatus:
            createdInvoice.EmailStatus ||
            null,

          created:
            true,

          sent:
            action ===
            'create-and-send',

          sendResult,
        },
      })

    } catch (
      error:
        any
    ) {

      console.error(
        'QUICKBOOKS INVOICE ACTION ERROR:',
        error
      )


      res
        .status(500)
        .json({
          success:
            false,

          error:
            error?.message ||
            'Could not create or send QuickBooks invoice.',
        })
    }
  }
)

// ============================================================
// END [QUICKBOOKS-25] Approved multi-line QuickBooks invoice creation + service date + per-line tax + optional send

}
