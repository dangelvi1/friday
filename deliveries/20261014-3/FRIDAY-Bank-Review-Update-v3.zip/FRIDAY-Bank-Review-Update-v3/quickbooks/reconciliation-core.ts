import {validDate, type LedgerRow} from './bank-review-engine'

export function reconciliationInputs(companyKey: unknown, accountId: unknown, query: any) {
  if (typeof companyKey !== 'string' || !/^[a-z0-9-]{1,80}$/.test(companyKey) || typeof accountId !== 'string' || !/^\d{1,20}$/.test(accountId)) throw Error('Invalid company or account.')
  const {startDate, endDate} = query
  if (!validDate(startDate) || !validDate(endDate) || startDate > endDate || Date.parse(endDate) - Date.parse(startDate) > 366 * 86400000) throw Error('Choose valid statement dates within 366 days.')
  const balance = (v: unknown) => {
    if (typeof v !== 'string' || !/^-?\d+(?:\.\d{1,2})?$/.test(v) || !Number.isSafeInteger(Math.round(Number(v) * 100))) throw Error('Enter both statement balances, including zero when applicable, with at most two decimals.')
    return Number(v)
  }
  return {companyKey, accountId, startDate, endDate, startBalance: balance(query.statementStartBalance), endBalance: balance(query.statementEndBalance)}
}
export function offsetDate(date: string, days: number) {return new Date(Date.parse(date + 'T00:00:00Z') + days * 86400000).toISOString().slice(0, 10)}
export function reconciliationSummary(rows: LedgerRow[], startDate: string, endDate: string, startBalance: number, endBalance: number) {
  const transactions = rows.filter(r => r.txnDate >= startDate && r.txnDate <= endDate)
  const boundaryCandidates = rows.filter(r => r.txnDate < startDate || r.txnDate > endDate).map(r => ({...r, possibleCause: 'QuickBooks transaction date is outside the statement period. Check the actual statement posting date; do not automatically move or include this record.'}))
  const sum = (direction: string) => transactions.filter(r => r.direction === direction).reduce((n, r) => n + Math.round(r.amount * 100), 0)
  const incoming = sum('in'), outgoing = sum('out'), expected = Math.round(startBalance * 100) + incoming - outgoing
  const difference = Math.round(endBalance * 100) - expected
  return {transactions, boundaryCandidates, transactionCount: transactions.length, zeroActivityWarning: !transactions.length,
    quickBooksActivity: {moneyIn: incoming / 100, moneyOut: outgoing / 100, netActivity: (incoming - outgoing) / 100},
    reconciliation: {expectedEndingBalance: expected / 100, statementEndingBalance: endBalance, difference: difference / 100, appearsBalanced: difference === 0, officialReconciliation: false},
    possibleCauses: [
      ...(boundaryCandidates.length ? [`${boundaryCandidates.length} posted records lie within seven days outside the statement dates. A 1–2 day transaction/posting offset can cross a month boundary.`] : []),
      'Outstanding checks, deposits in transit, weekend/holiday processing and bank posting dates can differ from QuickBooks transaction dates.',
      'Fees, interest, missing or duplicate entries, grouped deposits, split payments or a different opening balance can explain a difference. These are possibilities, not confirmed causes.',
      'Supported posted records are counted and paginated. Pending bank-feed items and unsupported transaction types are excluded. Matching totals alone does not prove a completed reconciliation.'
    ]}
}
