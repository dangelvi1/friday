// START [SANDRA-LEARN-23] Owner-verified teaching and exact posted-category approvals
import type {Express} from 'express'
import {createHash,randomUUID} from 'node:crypto'
import {getValidQuickBooksConnection} from './connection'
import {runQuickBooksQuery,QuickBooksThrottleError} from './query'
import {getQuickBooksApiBaseUrl} from './quickbooks-auth'
import {authenticateSandraOwner,validateLesson,purchasePreview} from './sandra-learning-core'
import {ensureTeachingSchema,readLessons,saveLesson,lessonHistory,createProposal,getProposal,claimProposal,finishProposal,hasUncertainPurchase} from './sandra-learning-store'
const numberId=(x:unknown)=>{if(typeof x!=='string'||!/^\d{1,20}$/.test(x))throw new Error('Invalid accounting ID.');return x}
async function selected(req:any) {
 const companyKey=String(req.params.companyKey||'');if(!/^[a-z0-9-]{1,80}$/.test(companyKey))throw new Error('Invalid company.')
 const accountId=numberId(req.params.accountId),connection=await getValidQuickBooksConnection(companyKey)
 const scope={companyKey,accountId,realmId:String(connection.realm_id),environment:String(connection.environment)}
 if(req.body && req.method==='POST' && (req.body.realmId!==scope.realmId || req.body.environment!==scope.environment))throw new Error('SCOPE_CHANGED')
 const q=await runQuickBooksQuery(connection,`SELECT * FROM Account WHERE Id = '${accountId}'`)
 if(q?.QueryResponse?.Account?.[0]?.AccountType!=='Bank')throw new Error('Selected bank account not found.')
 return {scope,connection}
}
async function category(connection:any,id:string) {
 const d=await runQuickBooksQuery(connection,`SELECT * FROM Account WHERE Id = '${numberId(id)}'`)
 const a=d?.QueryResponse?.Account?.[0]
 if(!a?.Active || !['Expense','Other Expense','Cost of Goods Sold'].includes(a.AccountType))throw new Error('Select an active expense or cost-of-goods-sold account.')
 return a
}
async function purchase(connection:any,id:string) {
 const d=await runQuickBooksQuery(connection,`SELECT * FROM Purchase WHERE Id = '${numberId(id)}'`)
 return d?.QueryResponse?.Purchase?.[0]
}
function errorResponse(res:any,e:any) {
 if(e instanceof QuickBooksThrottleError){res.setHeader('Retry-After',String(e.retryAfterSeconds));return res.status(429).json({success:false,error:e.message})}
 const safe=String(e?.message||'')
 const status=safe==='OWNER_UNAUTHORIZED'?401:safe==='OWNER_SETUP_REQUIRED'?503:['STALE_LESSON','SCOPE_CHANGED'].includes(safe)?409:400
 return res.status(status).json({success:false,error: safe==='OWNER_UNAUTHORIZED'?'Enter a valid owner credential.':safe==='OWNER_SETUP_REQUIRED'?'Run Setup-Sandra-Owners.ps1 on the server first.':safe==='STALE_LESSON'?'Category teaching changed. Reload before saving.':safe==='SCOPE_CHANGED'?'Connected company changed. Reload teaching.':safe.startsWith('Invalid')||safe.startsWith('Select')||safe.startsWith('Only')||safe.includes('manual review')||safe.includes('already uses')||safe.includes('do not agree')||safe.includes('belong')||safe.includes('Maximum')||safe.includes('example')?safe:'The operation could not complete. No automatic retry was performed.'})
}
export function registerSandraLearning(app:Express) {
 const root='/quickbooks/sandra-teaching/:companyKey/:accountId'
 app.use(root,(_req,res,next)=>{res.setHeader('Cache-Control','no-store');next()})
 app.get(root,async(req,res)=>{try{
  const actor=authenticateSandraOwner(req),{scope,connection}=await selected(req)
  await ensureTeachingSchema()
  const count=await runQuickBooksQuery(connection,'SELECT COUNT(*) FROM Account WHERE Active = true')
  const expected=count?.QueryResponse?.totalCount;if(!Number.isSafeInteger(expected))throw new Error('Invalid account count.')
  const accounts:any[]=[];const ids=new Set<string>()
  for(let page=0;page<100;page++){
   const r=await runQuickBooksQuery(connection,`SELECT * FROM Account WHERE Active = true ORDERBY Name STARTPOSITION ${page*1000+1} MAXRESULTS 1000`)
   if(!r?.QueryResponse)throw new Error('Invalid account page.')
   const batch=r.QueryResponse.Account||[];if(!Array.isArray(batch))throw new Error('Invalid account page.')
   for(const a of batch){if(!a.Id||ids.has(String(a.Id)))throw new Error('Invalid account pagination.');ids.add(String(a.Id));accounts.push(a)}
   if(batch.length<1000)break
  }
  if(accounts.length!==expected)throw new Error('Invalid account count.')
  const categories=accounts.filter(a=>['Expense','Other Expense','Cost of Goods Sold'].includes(a.AccountType)).map(a=>({id:String(a.Id),name:a.FullyQualifiedName||a.Name,type:a.AccountType}))
  return res.json({success:true,...scope,actor,categories,lessons:await readLessons(scope),writesEnabled:process.env.SANDRA_ENABLE_POSTED_CATEGORY_WRITES==='true',pendingSupported:false})
 }catch(e){return errorResponse(res,e)}})
 app.post(root+'/category/:categoryId',async(req,res)=>{try{
  const actor=authenticateSandraOwner(req),definition=validateLesson(req.body),{scope,connection}=await selected(req)
  const account=await category(connection,String(req.params.categoryId));await ensureTeachingSchema()
  return res.json({success:true,lesson:await saveLesson(scope,account,definition,actor),quickBooksChanged:false})
 }catch(e){return errorResponse(res,e)}})
 app.get(root+'/history/:categoryId',async(req,res)=>{try{
  authenticateSandraOwner(req);const {scope}=await selected(req);await ensureTeachingSchema()
  return res.json({success:true,...scope,history:await lessonHistory(scope,numberId(req.params.categoryId))})
 }catch(e){return errorResponse(res,e)}})
 app.post(root+'/preview',async(req,res)=>{try{
  const actor=authenticateSandraOwner(req),{scope,connection}=await selected(req);await ensureTeachingSchema()
  const account=await category(connection,String(req.body.categoryId||''))
  const lesson=(await readLessons(scope,true)).find(l=>l.category_id===String(account.Id))
  if(!lesson)throw new Error('Select a category with owner-approved teaching first.')
  if(await hasUncertainPurchase(scope,String(req.body.purchaseId||'')))return res.status(409).json({success:false,error:'A previous update for this expense is submitted or uncertain. Inspect its receipt and QuickBooks before preparing another change.'})
  const preview=purchasePreview(await purchase(connection,String(req.body.purchaseId||'')),scope.accountId,account)
  const id=randomUUID(),digest=createHash('sha256').update(JSON.stringify({...scope,preview,lessonRevision:lesson.revision})).digest('hex')
  await createProposal(scope,id,preview,lesson.revision,digest,actor)
  const {payload,snapshotHash,...display}=preview
  return res.json({success:true,...scope,proposalId:id,digest,preview:display,teaching:{revision:lesson.revision,useFor:lesson.definition.useFor,notFor:lesson.definition.notFor,askWhen:lesson.definition.askWhen},expiresInSeconds:900,writesEnabled:process.env.SANDRA_ENABLE_POSTED_CATEGORY_WRITES==='true',message:'Exact posted expense only. Pending feed is unsupported. Confirm business purpose and reconciliation status before approval.'})
 }catch(e){return errorResponse(res,e)}})
 app.post(root+'/execute/:proposalId',async(req,res)=>{
 let context:any=null,claimed=false
 try{
  const actor=authenticateSandraOwner(req)
  if(process.env.SANDRA_ENABLE_POSTED_CATEGORY_WRITES!=='true')return res.status(403).json({success:false,error:'Posted accounting writes are disabled. Teaching and previews remain available.'})
  if(req.body?.approved!==true||req.body?.businessPurposeConfirmed!==true||req.body?.reconciliationReviewed!==true)throw new Error('Invalid approval confirmations.')
  const id=String(req.params.proposalId);if(!/^[a-f0-9-]{36}$/.test(id))throw new Error('Invalid proposal.')
  const {scope,connection}=await selected(req);context={scope,id}
  const proposal=await getProposal(scope,id)
  if(!proposal || proposal.digest!==req.body.digest || Date.now()-new Date(proposal.created_at).getTime()>900000) return res.status(409).json({success:false,error:'Preview expired or changed. Prepare a new preview.'})
  if(proposal.status==='applied')return res.json({success:true,status:'applied',result:proposal.result,replayed:true})
  if(proposal.status!=='prepared')return res.status(409).json({success:false,error:'This proposal was already submitted. Inspect its receipt and QuickBooks; do not retry it.'})
  const lesson=(await readLessons(scope,true)).find(l=>l.category_id===proposal.preview.newCategoryId)
  if(!lesson||lesson.revision!==proposal.lesson_revision)return res.status(409).json({success:false,error:'Teaching changed. Prepare a fresh preview.'})
  const fresh=purchasePreview(await purchase(connection,proposal.preview.purchaseId),scope.accountId,await category(connection,proposal.preview.newCategoryId))
  if(JSON.stringify(fresh)!==JSON.stringify(proposal.preview))return res.status(409).json({success:false,error:'The posted expense or category changed. Prepare a fresh preview.'})
  if(!await claimProposal(scope,id,actor,fresh.purchaseId))return res.status(409).json({success:false,error:'Proposal expired or already submitted.'})
  claimed=true
  // Exactly one request. No automatic retries on timeout, 429, errors or unknown outcomes.
  const url=`${getQuickBooksApiBaseUrl(connection.environment)}/v3/company/${encodeURIComponent(connection.realm_id)}/purchase?operation=update&requestid=${id}`
  const response=await fetch(url,{method:'POST',headers:{Authorization:`Bearer ${connection.access_token}`,'Content-Type':'application/json',Accept:'application/json'},body:JSON.stringify(fresh.payload),signal:AbortSignal.timeout(30000)})
  const data=await response.json();if(!response.ok||!data.Purchase)throw new Error('UNVERIFIED_WRITE')
  const actual=await purchase(connection,fresh.purchaseId)
  if(!actual||String(actual.AccountRef?.value)!==scope.accountId||Number(actual.TotalAmt)!==fresh.amount||actual.TxnDate!==fresh.date||actual.Line?.length!==1||String(actual.Line[0].AccountBasedExpenseLineDetail?.AccountRef?.value)!==fresh.newCategoryId)throw new Error('UNVERIFIED_WRITE')
  const before=JSON.parse(JSON.stringify(fresh.payload.Line[0])),after=JSON.parse(JSON.stringify(actual.Line[0]));delete before.AccountBasedExpenseLineDetail.AccountRef;delete after.AccountBasedExpenseLineDetail.AccountRef
  if(JSON.stringify(before)!==JSON.stringify(after))throw new Error('UNVERIFIED_WRITE')
  const result={purchaseId:fresh.purchaseId,newCategoryId:fresh.newCategoryId,syncToken:actual.SyncToken,verifiedAt:new Date().toISOString(),approvedBy:actor}
  await finishProposal(scope,id,'applied',result);return res.json({success:true,status:'applied',result})
 }catch(e){
  if(claimed&&context){try{await finishProposal(context.scope,context.id,'uncertain',{message:'Submitted; outcome requires manual verification. Never automatically retry.'})}catch{}return res.status(502).json({success:false,status:'uncertain',error:'The update was submitted but could not be fully verified. Check QuickBooks and the receipt before any further action.'})}
  return errorResponse(res,e)
 }
 })
 app.get(root+'/receipt/:proposalId',async(req,res)=>{try{
  authenticateSandraOwner(req);const {scope}=await selected(req);const id=String(req.params.proposalId);if(!/^[a-f0-9-]{36}$/.test(id))throw new Error('Invalid proposal.')
  const p=await getProposal(scope,id);if(!p)return res.status(404).json({success:false,error:'Receipt not found in this scope.'})
  const {payload,snapshotHash,...preview}=p.preview
  return res.json({success:true,...scope,receipt:{id:p.id,status:p.status,preview,createdBy:p.created_by,approvedBy:p.approved_by,createdAt:p.created_at,updatedAt:p.updated_at,result:p.result}})
 }catch(e){return errorResponse(res,e)}})
}
// END [SANDRA-LEARN-23] Owner-verified teaching and exact posted-category approvals
