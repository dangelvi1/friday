// START [SANDRA-BANK-21B] Paginated posted bank activity reader
import {runQuickBooksQuery} from './query'
import {validDate, type LedgerRow} from './bank-review-engine'
const entities = ['Payment', 'Deposit', 'Purchase', 'Transfer', 'BillPayment', 'JournalEntry', 'SalesReceipt', 'RefundReceipt'] as const
export async function readEntity(query: (sql: string) => Promise<any>, entity: string, where: string) {
  const counted = await query(`SELECT COUNT(*) FROM ${entity} WHERE ${where}`)
  const expected = counted?.QueryResponse?.totalCount
  if (!Number.isSafeInteger(expected) || expected < 0) throw new Error('QuickBooks did not provide a valid posted-record count.')
  const rows: any[] = []
  const seen = new Set<string>()
  for (let page = 0; page < 200; page++) {
    const data = await query(`SELECT * FROM ${entity} WHERE ${where} ORDERBY TxnDate STARTPOSITION ${page * 1000 + 1} MAXRESULTS 1000`)
    if (!data?.QueryResponse || typeof data.QueryResponse !== 'object') throw new Error('Missing QuickBooks query response.')
    const batch = data?.QueryResponse?.[entity]
    if (batch !== undefined && !Array.isArray(batch)) throw new Error('Invalid QuickBooks query response.')
    for (const row of batch || []) {
      if (!row.Id || seen.has(String(row.Id))) throw new Error('QuickBooks pagination repeated or omitted a record ID. Retry the read.')
      seen.add(String(row.Id)); rows.push(row)
    }
    if ((batch || []).length < 1000) {
      if (rows.length !== expected) throw new Error('Posted-record count changed or pagination was incomplete. Retry the read.')
      return rows
    }
  }
  throw new Error('QuickBooks pagination exceeded the review limit; choose a shorter period.')
}
export function normalizeLedger(data: Record<string, any[]>, accountId: string): LedgerRow[] {
  const rows: LedgerRow[] = []
  const depositedPayments = new Set<string>()
  for (const deposit of data.Deposit || []) for (const line of deposit.Line || []) for (const link of line.LinkedTxn || []) {
    if (link.TxnType === 'Payment') depositedPayments.add(String(link.TxnId))
  }
  function add(type: string, row: any, amount: number, direction: 'in' | 'out', category = '', suffix = '') {
    if (!validDate(row.TxnDate) || !/^\d+$/.test(String(row.Id)) || !Number.isFinite(amount) || amount < 0 || !Number.isSafeInteger(Math.round(amount*100)) || Math.abs(amount*100-Math.round(amount*100))>0.001) throw new Error('Invalid amount in posted QuickBooks data.')
    rows.push({id: String(row.Id) + suffix, type, txnDate: row.TxnDate, amount: Math.round(amount * 100) / 100, direction,
      name: row.EntityRef?.name || row.CustomerRef?.name || row.VendorRef?.name || '', category,
      referenceNumber: row.PaymentRefNum || row.DocNumber || ''})
  }
  for (const row of data.Payment || []) if (String(row.DepositToAccountRef?.value) === accountId && !depositedPayments.has(String(row.Id))) add('Payment', row, Number(row.TotalAmt), 'in', 'Customer payment')
  for (const row of data.Deposit || []) if (String(row.DepositToAccountRef?.value) === accountId) add('Deposit', row, Number(row.TotalAmt), 'in', 'Deposit')
  for (const row of data.Purchase || []) if (String(row.AccountRef?.value) === accountId) {
    const category = [...new Set((row.Line || []).map((line: any) => line.AccountBasedExpenseLineDetail?.AccountRef?.name || line.ItemBasedExpenseLineDetail?.ItemRef?.name).filter(Boolean))].join(', ')
    add('Purchase', row, Number(row.TotalAmt), row.Credit ? 'in' : 'out', category)
  }
  for (const row of data.Transfer || []) {
    if (String(row.FromAccountRef?.value) === accountId) add('Transfer', row, Number(row.Amount), 'out', row.ToAccountRef?.name || 'Transfer')
    if (String(row.ToAccountRef?.value) === accountId) add('Transfer', row, Number(row.Amount), 'in', row.FromAccountRef?.name || 'Transfer')
  }
  for (const row of data.BillPayment || []) if (String(row.CheckPayment?.BankAccountRef?.value || row.CreditCardPayment?.CCAccountRef?.value) === accountId) add('BillPayment', row, Number(row.TotalAmt), 'out', 'Bill payment')
  for (const row of data.SalesReceipt || []) if (String(row.DepositToAccountRef?.value) === accountId) add('SalesReceipt', row, Number(row.TotalAmt), 'in', 'Sales receipt')
  for (const row of data.RefundReceipt || []) if (String(row.DepositToAccountRef?.value) === accountId) add('RefundReceipt', row, Number(row.TotalAmt), 'out', 'Customer refund')
  for (const row of data.JournalEntry || []) {
    let debit = 0, credit = 0
    for (const line of row.Line || []) if (String(line.JournalEntryLineDetail?.AccountRef?.value) === accountId) {
      if (line.JournalEntryLineDetail.PostingType === 'Debit') debit += Number(line.Amount)
      else if (line.JournalEntryLineDetail.PostingType === 'Credit') credit += Number(line.Amount)
    }
    if (debit) add('JournalEntry', row, debit, 'in', 'Journal entry — owner review', ':debit')
    if (credit) add('JournalEntry', row, credit, 'out', 'Journal entry — owner review', ':credit')
  }
  return rows.sort((a, b) => b.txnDate.localeCompare(a.txnDate) || a.type.localeCompare(b.type) || a.id.localeCompare(b.id))
}
export async function loadPostedLedger(connection: any, accountId: string, startDate: string, endDate: string) {
  const query = (sql: string) => runQuickBooksQuery(connection, sql)
  const accountData = await query(`SELECT * FROM Account WHERE Id = '${accountId}'`)
  const account = accountData?.QueryResponse?.Account?.[0]
  if (!account || account.AccountType !== 'Bank') throw new Error('Selected bank account was not found in this QuickBooks company.')
  const where = `TxnDate >= '${startDate}' AND TxnDate <= '${endDate}'`
  const batches: any[][] = []
  for (const entity of entities) batches.push(await readEntity(query, entity, where))
  const data = Object.fromEntries(entities.map((entity, index) => [entity, batches[index]]))
  const transactions = normalizeLedger(data, accountId)
  const totals = {moneyIn: 0, moneyOut: 0, net: 0}
  for (const row of transactions) if (row.direction === 'in') totals.moneyIn += Math.round(row.amount * 100); else totals.moneyOut += Math.round(row.amount * 100)
  totals.net = totals.moneyIn - totals.moneyOut
  for (const key of ['moneyIn', 'moneyOut', 'net'] as const) totals[key] /= 100
  return {account: {id: String(account.Id), name: account.Name, postedBalance: account.CurrentBalance == null ? null : Number(account.CurrentBalance)}, transactions, totals,
    source: 'quickbooks-accounting-api', completeForSupportedEntities: true, supportedEntities: entities,
    limitations: ['Posted accounting records only; does not include the QuickBooks Pending bank-feed queue.', 'Not an official reconciliation or an exhaustive balance roll-forward; unsupported entity types are not included.', 'QuickBooks data can change during pagination; refresh before approving a future write.']}
}
// The account is verified by loadPostedLedger before this company-scoped history read.
export async function loadCategoryHistory(connection: any, accountId: string, beforeDate: string) {
  const startDate = new Date(Date.parse(beforeDate + 'T00:00:00Z') - 365 * 86400000).toISOString().slice(0, 10)
  const endDate = new Date(Date.parse(beforeDate + 'T00:00:00Z') - 86400000).toISOString().slice(0, 10)
  const purchases = await readEntity(sql => runQuickBooksQuery(connection, sql), 'Purchase', `TxnDate >= '${startDate}' AND TxnDate <= '${endDate}'`)
  const transactions = normalizeLedger({Purchase: purchases}, accountId)
  return {transactions, startDate, endDate}
}
// END [SANDRA-BANK-21B] Paginated posted bank activity reader
