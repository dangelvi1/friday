// START [SANDRA-BANK-21A] Read-only bank comparison and confidence engine
// No persistence, accounting writes, learned cross-company rules, or external sends.
export type LedgerRow = {
  id: string; type: string; txnDate: string; direction: 'in' | 'out';
  amount: number; name: string; category: string; referenceNumber: string;
}
export type FeedRow = {
  date: string; description: string; spent?: number | null; received?: number | null;
  fromTo?: string; referenceNumber?: string;
}
export function validDate(value: unknown): value is string {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false
  const date = new Date(value + 'T00:00:00Z')
  return Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === value
}
const normalize = (value: string) => value.toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim()
const cents = (value: number) => Math.round(value * 100)
const day = (value: string) => Date.parse(value + 'T00:00:00Z') / 86400000
export function validateFeed(input: unknown): FeedRow[] {
  if (!Array.isArray(input) || !input.length || input.length > 5000) throw new Error('Provide 1–5,000 bank rows.')
  return input.map((row, index) => {
    const label = `Bank row ${index + 1}`
    if (!row || !validDate(row.date)) throw new Error(`${label}: date must be YYYY-MM-DD.`)
    const spent = row.spent == null ? null : row.spent
    const received = row.received == null ? null : row.received
    for (const value of [spent, received]) {
      if (value !== null && (typeof value !== 'number' || !Number.isFinite(value) || value < 0 || value > 1e9 || Math.abs(value * 100 - Math.round(value * 100)) > 0.001)) {
        throw new Error(`${label}: amounts must be nonnegative numbers with at most two decimals.`)
      }
    }
    if ((Number(spent) > 0) === (Number(received) > 0)) throw new Error(`${label}: provide either Spent or Received, not both or neither.`)
    if (typeof row.description !== 'string' || !row.description.trim() || row.description.length > 2000) throw new Error(`${label}: description is required (maximum 2,000 characters).`)
    const field = (key: string) => typeof row[key] === 'string' ? row[key].slice(0, 500) : ''
    return {date: row.date, description: row.description, spent, received, fromTo: field('fromTo'), referenceNumber: field('referenceNumber')}
  })
}
// A vendor name in a payment memo is not evidence of recipient identity.
function payeeMatches(row: FeedRow, name: string) {
  const payee = normalize(name)
  if (payee.length < 5) return false
  const explicit = normalize(row.fromTo || '')
  if (explicit && !/^(select vendor|select customer)$/.test(explicit)) return explicit === payee
  const recipient = row.description.match(/^zelle\s+payment\s+(?:to|from)\s+(.+?)(?=\s+for\s+|\s+conf#|;|$)/i)
  if (recipient) return normalize(recipient[1]) === payee
  if (/\b(zelle|transfer)\b/i.test(row.description)) return false
  const merchant = normalize(row.description).replace(/^the /, '')
  const vendor = payee.replace(/^the /, '')
  return merchant === vendor || merchant.startsWith(vendor + ' ')
}
export function analyzeFeed(rows: FeedRow[], ledger: LedgerRow[], categoryHistory: LedgerRow[] = ledger) {
  const fingerprints = new Map<string, number>()
  const fingerprint = (row: FeedRow) => JSON.stringify([row.date, row.description, row.spent, row.received, row.fromTo, row.referenceNumber])
  for (const row of rows) fingerprints.set(fingerprint(row), (fingerprints.get(fingerprint(row)) || 0) + 1)
  const results = rows.map((row, ordinal) => {
    const direction = Number(row.spent) > 0 ? 'out' : 'in'
    const amount = Number(direction === 'out' ? row.spent : row.received)
    const text = normalize(`${row.description} ${row.fromTo || ''}`)
    const candidates = ledger.filter(item => item.direction === direction && cents(item.amount) === cents(amount) && Math.abs(day(item.txnDate) - day(row.date)) <= 7)
      .map(item => {
        const reference = normalize(row.referenceNumber || '')
        const referenceMatch = !!reference && !!item.referenceNumber && reference === normalize(item.referenceNumber)
        const payeeMatch = payeeMatches(row, item.name)
        const closeDate = Math.abs(day(item.txnDate) - day(row.date)) <= 3
        const dateOffsetDays = day(item.txnDate) - day(row.date)
        const dateEvidence = dateOffsetDays === 0 ? 'Same date' : `QuickBooks date is ${Math.abs(dateOffsetDays)} day(s) ${dateOffsetDays > 0 ? 'after' : 'before'} the statement row`
        return {...item, dateOffsetDays, dateEvidence, possibleCauses: dateOffsetDays ? ['Bank posting date versus transaction date; processing, weekends or holidays are possible causes. Verify the statement before selecting.'] : [], evidence: referenceMatch ? 'Same amount, direction, and reference' : payeeMatch ? 'Same amount, direction, and payee' : 'Same amount and direction; identity needs confirmation', strong: closeDate && (referenceMatch || payeeMatch)}
      })
    let confidence: 'GREEN' | 'YELLOW' | 'RED' = 'RED'
    let suggestion = 'Owner review'
    let reason = 'No reliable match or category history was found.'
    let suggestedCategory: string | null = null
    if (candidates.length) {
      confidence = candidates.length === 1 && candidates[0].strong ? 'GREEN' : candidates.length === 1 ? 'YELLOW' : 'RED'
      suggestion = candidates.length === 1 ? 'Possible existing QuickBooks match' : 'Multiple possible matches'
      reason = candidates.length === 1 ? candidates[0].evidence : 'Several QuickBooks records have the same amount and nearby dates.'
    } else if (direction === 'out' && !/\b(payroll|tax|irs|loan|mortgage|transfer|zelle)\b/.test(text)) {
      // History is supplied from this company/account only. No hard-coded vendor rules.
      const history = categoryHistory.filter(item => item.txnDate < row.date && item.type === 'Purchase' && item.direction === 'out' && item.category && payeeMatches(row, item.name))
      const categories = new Set(history.map(item => item.category))
      if (new Set(history.map(item => item.id)).size >= 3 && categories.size === 1 && !history[0].category.includes(', ')) {
        confidence = 'YELLOW'; suggestion = 'Category from account history'; suggestedCategory = history[0].category
        reason = `${history.length} posted purchases for this payee use this category. Confirm this purchase has the same purpose.`
      }
    }
    const duplicate = (fingerprints.get(fingerprint(row)) || 0) > 1
    const sensitive = /\b(payroll|tax|irs|loan|mortgage|transfer|zelle)\b/.test(text) || amount >= 5000 || candidates.some(item => item.type === 'JournalEntry' || item.type === 'Transfer')
    if (duplicate) {confidence = 'RED'; reason += ' Identical bank rows are retained; confirm whether they are legitimate repeats.'}
    if (sensitive) {confidence = 'RED'; reason += ' Sensitive transaction or amount at least $5,000 requires owner review.'}
    return {ordinal: ordinal + 1, ...row, amount, direction, confidence, suggestion, suggestedCategory, reason, possibleDuplicate: duplicate, candidates, possibleCauses: candidates.length ? ['Same amount alone does not identify a transaction. Check payee/reference, dates and whether another row uses this record.'] : ['No equal-amount, same-direction posted record within seven days. Check fees, split/grouped payments, Pending bank items, missing entries or an incorrect account.'], approvalRequired: true, executable: false}
  })
  // One posted record must not silently become the suggested match for two bank rows.
  const claims = new Map<string, number>()
  for (const row of results) for (const candidate of row.candidates) {
    const key = `${candidate.type}:${candidate.id}`
    claims.set(key, (claims.get(key) || 0) + 1)
  }
  for (const row of results) if (row.candidates.some(item => (claims.get(`${item.type}:${item.id}`) || 0) > 1)) {
    row.confidence = 'RED'; row.reason += ' A candidate is also proposed for another bank row; allocate it manually.'
  }
  return results.sort((a, b) => b.date.localeCompare(a.date) || a.ordinal - b.ordinal)
}
// END [SANDRA-BANK-21A] Read-only bank comparison and confidence engine
