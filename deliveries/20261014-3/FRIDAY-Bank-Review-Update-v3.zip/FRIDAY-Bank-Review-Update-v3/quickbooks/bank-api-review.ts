import {registerBankReviewNotes} from './bank-review-notes'
// START [SANDRA-BANK-21] Bank analysis routes and category teaching registration
import type {Express} from 'express'
import {registerSandraLearning} from './sandra-learning'
import {readLessons} from './sandra-learning-store'
import {applyTaughtCategories} from './sandra-learning-core'
import {getValidQuickBooksConnection} from './connection'
import {QuickBooksThrottleError, runQuickBooksQuery} from './query'
import {confirmedDraftRules, validateDraftRules, prepareDrafts} from './bank-draft-rules'
import {loadPostedLedger, loadCategoryHistory} from './bank-ledger-reader'
import {analyzeFeed, validDate, validateFeed} from './bank-review-engine'

function scope(companyKey: unknown, accountId: unknown) {
  if (typeof companyKey !== 'string' || !/^[a-z0-9-]{1,80}$/.test(companyKey) || typeof accountId !== 'string' || !/^\d{1,20}$/.test(accountId)) throw new Error('Invalid company or account.')
  return {companyKey, accountId}
}
function period(startDate: unknown, endDate: unknown) {
  if (!validDate(startDate) || !validDate(endDate) || startDate > endDate || Date.parse(endDate) - Date.parse(startDate) > 366 * 86400000) throw new Error('Select valid start/end dates within a 366-day period.')
  return {startDate, endDate}
}
export function registerQuickBooksApiBankReview(app: Express) {
  registerSandraLearning(app)
  registerBankReviewNotes(app)
  // Verifies the connected realm/account before a browser restores a saved draft.
  app.get('/quickbooks/bank-review-scope/:companyKey/:accountId', async (req, res) => {
    let selected: ReturnType<typeof scope>
    try {selected = scope(req.params.companyKey, req.params.accountId)} catch (e: any) {return res.status(400).json({success:false,error:e.message})}
    try {
      const connection = await getValidQuickBooksConnection(selected.companyKey)
      const data = await runQuickBooksQuery(connection, `SELECT * FROM Account WHERE Id = '${selected.accountId}'`)
      const account = data?.QueryResponse?.Account?.[0]
      if (!account || account.AccountType !== 'Bank') throw new Error('Bank account unavailable')
      return res.json({success:true,...selected,realmId:String(connection.realm_id),environment:String(connection.environment),accountName:account.Name,rules:confirmedDraftRules(selected.companyKey,selected.accountId,account.Name),readOnly:true,executable:false})
    } catch (e) {
      if (e instanceof QuickBooksThrottleError) {res.setHeader('Retry-After',String(e.retryAfterSeconds)); return res.status(429).json({success:false,error:e.message})}
      return res.status(502).json({success:false,error:'Could not verify the connected company and bank account.'})
    }
  })
  app.get('/quickbooks/api-bank-review/:companyKey/:accountId', async (req, res) => {
    let selected: ReturnType<typeof scope>, dates: ReturnType<typeof period>
    try {selected = scope(req.params.companyKey, req.params.accountId); dates = period(req.query.startDate, req.query.endDate)}
    catch (error: any) {return res.status(400).json({success: false, error: error.message})}
    try {
      const connection = await getValidQuickBooksConnection(selected.companyKey)
      const ledger = await loadPostedLedger(connection, selected.accountId, dates.startDate, dates.endDate)
      return res.json({success: true, ...selected, period: dates, readOnly: true, count: ledger.transactions.length, ...ledger})
    } catch (error) {
      if (error instanceof QuickBooksThrottleError) {
        res.setHeader('Retry-After', String(error.retryAfterSeconds))
        return res.status(429).json({success: false, error: error.message, retryAfterSeconds: error.retryAfterSeconds})
      }
      return res.status(502).json({success: false, error: 'Could not read all supported QuickBooks records. Check the connection and retry; no partial result was accepted.'})
    }
  })
  // POST carries bank rows for analysis; it performs GET queries only. Draft persistence is browser-local; no QuickBooks writes.
  app.post('/quickbooks/bank-feed-analysis/:companyKey/:accountId', async (req, res) => {
    let selected: ReturnType<typeof scope>, rows: ReturnType<typeof validateFeed>, customRules: ReturnType<typeof validateDraftRules>
    try {
      selected = scope(req.params.companyKey, req.params.accountId)
      if (req.body?.companyKey !== selected.companyKey || String(req.body?.accountId) !== selected.accountId || req.body?.scopeConfirmed !== true) throw new Error('Confirm the bank file belongs to this company and selected account.')
      rows = validateFeed(req.body?.transactions)
      customRules = validateDraftRules(req.body?.draftRules || [])
      const dates = rows.map(row => row.date).sort()
      period(dates[0], dates[dates.length - 1])
    } catch (error: any) {return res.status(400).json({success: false, error: error.message})}
    try {
      const sorted = rows.map(row => row.date).sort()
      const offsetDate = (date: string, delta: number) => new Date(Date.parse(date + 'T00:00:00Z') + delta * 86400000).toISOString().slice(0, 10)
      const connection = await getValidQuickBooksConnection(selected.companyKey)
      if (req.body?.realmId !== String(connection.realm_id) || req.body?.environment !== connection.environment) return res.status(409).json({success:false,error:'Connected QuickBooks company changed. Verify the scope again.'})
      const ledger = await loadPostedLedger(connection, selected.accountId, offsetDate(sorted[0], -7), offsetDate(sorted[sorted.length - 1], 7))
      const history = await loadCategoryHistory(connection, selected.accountId, sorted[0])
      const defaults = confirmedDraftRules(selected.companyKey, selected.accountId, ledger.account.name)
      const rules = req.body?.draftRules === undefined ? defaults : customRules
      const lessons = await readLessons({...selected,realmId:String(connection.realm_id),environment:String(connection.environment)},true)
      const transactions = applyTaughtCategories(prepareDrafts(analyzeFeed(rows, ledger.transactions, history.transactions), rules, selected.companyKey, selected.accountId, ledger.account.name),lessons)
      const categoryHistory = {startDate: history.startDate, endDate: history.endDate, postedPurchaseCount: history.transactions.length, companyKey: selected.companyKey, accountId: selected.accountId}
      const confidenceCounts = {GREEN: 0, YELLOW: 0, RED: 0}
      for (const row of transactions) confidenceCounts[row.confidence as keyof typeof confidenceCounts]++
      return res.json({success: true, ...selected, readOnly: true, source: 'uploaded-bank-file', account: ledger.account,
        realmId:String(connection.realm_id), environment:String(connection.environment), teachingRevisions:lessons.map(l => ({categoryId:l.category_id,revision:l.revision})), categoryHistory, count: transactions.length, inputCount: rows.length, confidenceCounts, transactions, approvalRequired: true, executable: false,
        limitations: ledger.limitations, message: 'Draft recommendations only. This does not change or match QuickBooks Pending items.'})
    } catch (error) {
      if (error instanceof QuickBooksThrottleError) {
        res.setHeader('Retry-After', String(error.retryAfterSeconds))
        return res.status(429).json({success: false, error: error.message, retryAfterSeconds: error.retryAfterSeconds})
      }
      return res.status(502).json({success: false, error: 'Bank analysis could not read all supported QuickBooks records. No changes were made.'})
    }
  })
}
// END [SANDRA-BANK-21] Bank analysis routes and category teaching registration
