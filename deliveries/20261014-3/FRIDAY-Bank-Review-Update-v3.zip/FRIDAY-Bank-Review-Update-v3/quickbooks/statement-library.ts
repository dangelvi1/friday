import {authenticateSandraOwner} from './sandra-learning-core'
import {getValidQuickBooksConnection} from './connection'
import {runQuickBooksQuery} from './query'
import {validDate} from './bank-review-engine'
// ============================================================
// FRIDAY / SANDRA QUICKBOOKS STATEMENT LIBRARY
// FILE: S:\AI\friday-ai\quickbooks\statement-library.ts
// PURPOSE:
// - Store uploaded bank / credit-card statements locally
// - Keep statements isolated by company and QuickBooks account
// - Provide statement metadata to Sandra reconciliation workspace
// - No accounting entries are created by this module
// ============================================================

import type { Express } from 'express'
import fs from 'node:fs/promises'
import path from 'node:path'
import crypto from 'node:crypto'

const root = () => path.resolve(process.cwd(), 'data', 'sandra-statements')

type StatementRecord = {
  realmId?: string
  environment?: string
  id: string
  companyKey: string
  accountId: string
  accountName: string | null
  statementStartDate: string | null
  statementEndDate: string | null
  beginningBalance: number | null
  endingBalance: number | null
  originalFileName: string
  storedFileName: string
  mimeType: string
  sizeBytes: number
  uploadedAt: string
  uploadedBy: string
  status: 'uploaded' | 'reviewed' | 'reconciled'
}

export function safePart(value: unknown) {
  const part=String(value ?? '').trim()
  if(!/^[a-zA-Z0-9_-]{1,120}$/.test(part)) throw Error('Invalid storage scope.')
  return part
}
export function statementBalance(value:unknown) {
  if(value===null||value===undefined||value==='')return null
  if(!/^-?\d+(?:\.\d{1,2})?$/.test(String(value))||!Number.isSafeInteger(Math.round(Number(value)*100)))throw Error('Balances require at most two decimals.')
  return Number(value)
}
function statementDates(start:any,end:any) {
  if(start!=null&&start!==''&&!validDate(start)||end!=null&&end!==''&&!validDate(end)||start&&end&&start>end)throw Error('Invalid statement dates.')
}
const writes=new Map<string,Promise<void>>()

function companyDir(companyKey: string) {
  return path.join(root(), safePart(companyKey))
}

function accountDir(companyKey: string, accountId: string) {
  return path.join(companyDir(companyKey), safePart(accountId))
}

function metadataPath(companyKey: string, accountId: string) {
  return path.join(accountDir(companyKey, accountId), 'statements.json')
}

async function readRecords(companyKey: string, accountId: string): Promise<StatementRecord[]> {
  try {
    const raw = await fs.readFile(metadataPath(companyKey, accountId), 'utf8')
    const parsed = JSON.parse(raw)
    return Array.isArray(parsed) ? parsed : []
  } catch (error: any) {
    if (error?.code === 'ENOENT') return []
    throw error
  }
}

async function writeRecords(companyKey: string, accountId: string, records: StatementRecord[]) {
  const dir = accountDir(companyKey, accountId)
  await fs.mkdir(dir, { recursive: true })
  const temporary=metadataPath(companyKey,accountId)+'.'+crypto.randomUUID()+'.tmp'
  await fs.writeFile(temporary, JSON.stringify(records, null, 2), 'utf8')
  await fs.rename(temporary,metadataPath(companyKey,accountId))
}

export function registerQuickBooksStatementLibrary(app: Express) {
  app.use('/quickbooks/statements/:companyKey/:accountId',async(req,res,next)=>{
    res.setHeader('Cache-Control','no-store')
    let actor:string
    try{actor=authenticateSandraOwner(req)}catch{return res.status(403).json({success:false,error:'Verified owner required for private statements.'})}
    const companyKey=String(req.params.companyKey),accountId=String(req.params.accountId)
    if(!/^[a-z0-9-]{1,80}$/.test(companyKey)||!/^\d{1,20}$/.test(accountId))return res.status(400).json({success:false,error:'Invalid company/account.'})
    try{
      const c=await getValidQuickBooksConnection(companyKey),data=await runQuickBooksQuery(c,`SELECT * FROM Account WHERE Id = '${accountId}'`)
      const account=data?.QueryResponse?.Account?.[0]
      if(!account||!['Bank','Credit Card'].includes(account.AccountType))throw Error('Statement account unavailable.')
      if(['POST','PATCH'].includes(req.method)&&(req.body?.realmId!==String(c.realm_id)||req.body?.environment!==c.environment))return res.status(409).json({success:false,error:'Company connection changed. Reload the statement form.'})
      res.locals.statementScope={actor,realmId:String(c.realm_id),environment:c.environment,accountName:account.Name}
      if(['POST','PATCH'].includes(req.method)){
        const key=companyKey+':'+accountId,prior=writes.get(key)||Promise.resolve()
        let release!:()=>void;const turn=new Promise<void>(r=>release=r),tail=prior.then(()=>turn);writes.set(key,tail)
        await prior
        let released=false;const done=()=>{if(released)return;released=true;release();if(writes.get(key)===tail)writes.delete(key)};res.once('finish',done);res.once('close',done)
      }
      next()
    }catch{return res.status(502).json({success:false,error:'Could not verify this company and statement account.'})}
  })
  const owns=(record:StatementRecord,res:any)=> record.uploadedBy.toLowerCase()===res.locals.statementScope.actor && (!record.realmId||record.realmId===res.locals.statementScope.realmId) && (!record.environment||record.environment===res.locals.statementScope.environment)

  app.get('/quickbooks/statements/:companyKey/:accountId', async (req, res) => {
    try {
      const companyKey = String(req.params.companyKey || '').trim().toLowerCase()
      const accountId = String(req.params.accountId || '').trim()
      const records = (await readRecords(companyKey, accountId)).filter(r=>owns(r,res))
      records.sort((a, b) => String(b.statementEndDate || b.uploadedAt).localeCompare(String(a.statementEndDate || a.uploadedAt)))
      res.json({ success: true, companyKey, accountId, statements: records })
    } catch (error: any) {
      res.status(500).json({ success: false, error: error?.message || 'Could not load statements.' })
    }
  })

  app.post('/quickbooks/statements/:companyKey/:accountId', async (req, res) => {
    try {
      const companyKey = String(req.params.companyKey || '').trim().toLowerCase()
      const accountId = String(req.params.accountId || '').trim()
      const {
        accountName = null,
        statementStartDate = null,
        statementEndDate = null,
        beginningBalance = null,
        endingBalance = null,
        originalFileName,
        mimeType = 'application/octet-stream',
        dataBase64,
        uploadedBy = 'salvador',
      } = req.body || {}

      if (!companyKey || !accountId || !originalFileName || !dataBase64) {
        return res.status(400).json({ success: false, error: 'companyKey, accountId, originalFileName and dataBase64 are required.' })
      }

      statementDates(statementStartDate,statementEndDate)
      const startBalance=statementBalance(beginningBalance),endBalance=statementBalance(endingBalance)
      if(typeof dataBase64!=='string'||dataBase64.length>36*1024*1024||! /^[A-Za-z0-9+/]*={0,2}$/.test(dataBase64)||dataBase64.length%4) return res.status(400).json({success:false,error:'Invalid statement file encoding.'})
      const bytes = Buffer.from(dataBase64, 'base64')
      const maxBytes = 25 * 1024 * 1024
      if (!bytes.length || bytes.length > maxBytes) {
        return res.status(400).json({ success: false, error: 'Statement must be between 1 byte and 25 MB.' })
      }

      const filename=path.basename(String(originalFileName)).slice(0,200)
      const extension=path.extname(filename).toLowerCase()
      if(!['.pdf','.csv'].includes(extension)||extension==='.pdf'&&!bytes.subarray(0,5).equals(Buffer.from('%PDF-'))||extension==='.csv'&&bytes.includes(0))return res.status(400).json({success:false,error:'Upload a valid PDF or text CSV statement.'})
      const id = crypto.randomUUID()
      const ext = path.extname(String(originalFileName)).slice(0, 12)
      const storedFileName = `${id}${ext}`
      const dir = accountDir(companyKey, accountId)
      await fs.mkdir(dir, { recursive: true })
      await fs.writeFile(path.join(dir, storedFileName), bytes)

      const record: StatementRecord = {
        id,
        companyKey,
        accountId,
        accountName: res.locals.statementScope.accountName,
        realmId:res.locals.statementScope.realmId,environment:res.locals.statementScope.environment,
        statementStartDate: statementStartDate ? String(statementStartDate) : null,
        statementEndDate: statementEndDate ? String(statementEndDate) : null,
        beginningBalance: startBalance,
        endingBalance: endBalance,
        originalFileName: filename,
        storedFileName,
        mimeType: extension==='.pdf'?'application/pdf':'text/csv',
        sizeBytes: bytes.length,
        uploadedAt: new Date().toISOString(),
        uploadedBy: res.locals.statementScope.actor,
        status: 'uploaded',
      }

      const records = await readRecords(companyKey, accountId)
      records.push(record)
      await writeRecords(companyKey, accountId, records)

      res.json({ success: true, statement: record })
    } catch (error: any) {
      res.status(500).json({ success: false, error: error?.message || 'Could not upload statement.' })
    }
  })

  app.get('/quickbooks/statements/:companyKey/:accountId/:statementId/file', async (req, res) => {
    try {
      const companyKey = String(req.params.companyKey || '').trim().toLowerCase()
      const accountId = String(req.params.accountId || '').trim()
      const statementId = String(req.params.statementId || '').trim()
      const records = await readRecords(companyKey, accountId)
      const record = records.find(x => x.id === statementId && owns(x,res))
      if (!record) return res.status(404).json({ success: false, error: 'Statement not found.' })
      if(path.basename(record.storedFileName)!==record.storedFileName)throw Error('Invalid stored statement path.')
      const filePath = path.join(accountDir(companyKey, accountId), record.storedFileName)
      const extension=path.extname(record.storedFileName).toLowerCase()
      res.type(extension==='.pdf'?'application/pdf':extension==='.csv'?'text/csv':'application/octet-stream')
      res.setHeader('X-Content-Type-Options','nosniff')
      res.setHeader('Content-Disposition', `inline; filename="${record.originalFileName.replace(/[^a-zA-Z0-9._-]/g,'_').slice(0,200)}"`)
      res.sendFile(filePath)
    } catch (error: any) {
      res.status(500).json({ success: false, error: error?.message || 'Could not open statement.' })
    }
  })

  app.patch('/quickbooks/statements/:companyKey/:accountId/:statementId', async (req, res) => {
    try {
      const companyKey = String(req.params.companyKey || '').trim().toLowerCase()
      const accountId = String(req.params.accountId || '').trim()
      const statementId = String(req.params.statementId || '').trim()
      const records = await readRecords(companyKey, accountId)
      const record = records.find(x => x.id === statementId && owns(x,res))
      if (!record) return res.status(404).json({ success: false, error: 'Statement not found.' })

      statementDates(req.body?.statementStartDate ?? record.statementStartDate,req.body?.statementEndDate ?? record.statementEndDate)
      const allowed = ['uploaded', 'reviewed', 'reconciled']
      if (req.body?.status && allowed.includes(String(req.body.status))) {
        record.status = String(req.body.status) as StatementRecord['status']
      }
      if (req.body?.statementStartDate !== undefined) record.statementStartDate = req.body.statementStartDate || null
      if (req.body?.statementEndDate !== undefined) record.statementEndDate = req.body.statementEndDate || null
      if (req.body?.beginningBalance !== undefined) record.beginningBalance = statementBalance(req.body.beginningBalance)
      if (req.body?.endingBalance !== undefined) record.endingBalance = statementBalance(req.body.endingBalance)

      await writeRecords(companyKey, accountId, records)
      res.json({ success: true, statement: record })
    } catch (error: any) {
      res.status(500).json({ success: false, error: error?.message || 'Could not update statement.' })
    }
  })
}
