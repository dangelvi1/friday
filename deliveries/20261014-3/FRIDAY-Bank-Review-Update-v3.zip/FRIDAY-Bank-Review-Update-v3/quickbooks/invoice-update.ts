// ============================================================
// FRIDAY QUICKBOOKS FEATURE MODULE
// FILE: S:\AI\friday-ai\quickbooks\invoice-update.ts
// PURPOSE: Small, focused QuickBooks route module.
// ============================================================

import type {
  Express,
} from 'express'

import {
  getValidQuickBooksConnection,
} from './connection'

import {
  getQuickBooksApiBaseUrl,
} from './quickbooks-auth'

export function registerQuickBooksInvoiceUpdate(
  app:
    Express
) {

// START [QUICKBOOKS-41] Editable invoice update + duplicate DocNumber check
// ACTION: ADD COMPLETE BLOCK
// FILE: S:\AI\friday-ai\quickbooks\routes.ts
// PLACE: Immediately after [QUICKBOOKS-25]
// PURPOSE:
// - Check whether a custom invoice number already exists in QuickBooks
// - Load-safe duplicate checks that can exclude the invoice being edited
// - Update an existing QuickBooks invoice with SyncToken protection
// - Support customer, DocNumber, terms, dates, email, notes and service lines
// - Preserve per-line ServiceDate and TAX / NON behavior
// - Require explicit Salvador / Dayanna approval before writing
// USERS: Salvador and Dayanna
// ============================================================


// ------------------------------------------------------------
// QUICKBOOKS QUERY HELPER FACTORY
// ------------------------------------------------------------

async function fridayQuickBooksInvoiceQuery(
  connection: any,
  query: string
) {
  const baseUrl =
    getQuickBooksApiBaseUrl(
      connection.environment
    )

  const url =
    `${baseUrl}` +
    `/v3/company/` +
    `${encodeURIComponent(
      connection.realm_id
    )}` +
    `/query?query=` +
    `${encodeURIComponent(
      query
    )}`

  const response =
    await fetch(
      url,
      {
        method:
          'GET',

        headers: {
          Authorization:
            `Bearer ${connection.access_token}`,

          Accept:
            'application/json',
        },
      }
    )

  const data =
    await response.json()

  if (!response.ok) {
    throw new Error(
      JSON.stringify(
        data
      )
    )
  }

  return data
}


// ------------------------------------------------------------
// CUSTOM INVOICE NUMBER CHECK
// ------------------------------------------------------------

app.get(
  '/quickbooks/invoice-number-check/:companyKey',
  async (
    req,
    res
  ) => {
    try {
      const companyKey =
        String(
          req.params.companyKey ||
          ''
        )
          .trim()
          .toLowerCase()

      const docNumber =
        String(
          req.query.docNumber ||
          ''
        )
          .trim()

      const excludeInvoiceId =
        String(
          req.query.excludeInvoiceId ||
          ''
        )
          .trim()

      if (!docNumber) {
        return res.json({
          success:
            true,

          exists:
            false,

          docNumber:
            null,

          invoice:
            null,
        })
      }

      const connection =
        await getValidQuickBooksConnection(
          companyKey
        )

      const safeDocNumber =
        docNumber
          .replace(
            /\\/g,
            '\\\\'
          )
          .replace(
            /'/g,
            "\\'"
          )

      const data =
        await fridayQuickBooksInvoiceQuery(
          connection,
          `SELECT * FROM Invoice ` +
          `WHERE DocNumber = '${safeDocNumber}' ` +
          `MAXRESULTS 10`
        )

      const invoices =
        data
          ?.QueryResponse
          ?.Invoice ||
        []

      const existingInvoice =
        invoices.find(
          (
            invoice:
              any
          ) =>
            String(
              invoice.Id ||
              ''
            ) !==
            excludeInvoiceId
        ) ||
        null

      res.json({
        success:
          true,

        companyKey,

        docNumber,

        exists:
          Boolean(
            existingInvoice
          ),

        invoice:
          existingInvoice
            ? {
                id:
                  existingInvoice.Id ||
                  null,

                docNumber:
                  existingInvoice.DocNumber ||
                  null,

                customerId:
                  existingInvoice
                    ?.CustomerRef
                    ?.value ||
                  null,

                customerName:
                  existingInvoice
                    ?.CustomerRef
                    ?.name ||
                  null,
              }
            : null,
      })

    } catch (
      error:
        any
    ) {
      console.error(
        'QUICKBOOKS INVOICE NUMBER CHECK ERROR:',
        error
      )

      res
        .status(500)
        .json({
          success:
            false,

          error:
            error?.message ||
            'Could not check invoice number.',
        })
    }
  }
)


// ------------------------------------------------------------
// UPDATE EXISTING INVOICE
// ------------------------------------------------------------

app.post(
  '/quickbooks/invoice-update/:companyKey/:invoiceId',
  async (
    req,
    res
  ) => {
    try {
      const companyKey =
        String(
          req.params.companyKey ||
          ''
        )
          .trim()
          .toLowerCase()

      const invoiceId =
        String(
          req.params.invoiceId ||
          ''
        )
          .trim()

      const approved =
        req.body?.approved ===
        true

      const approvedBy =
        String(
          req.body?.approvedBy ||
          ''
        )
          .trim()
          .toLowerCase()

      const syncToken =
        String(
          req.body?.syncToken ||
          ''
        )
          .trim()

      const customerId =
        String(
          req.body?.customerId ||
          ''
        )
          .trim()

      const docNumber =
        String(
          req.body?.docNumber ||
          ''
        )
          .trim()

      const termId =
        String(
          req.body?.termId ||
          ''
        )
          .trim()

      const txnDate =
        String(
          req.body?.txnDate ||
          ''
        )
          .trim()

      const dueDate =
        String(
          req.body?.dueDate ||
          ''
        )
          .trim()

      const billEmail =
        String(
          req.body?.billEmail ||
          ''
        )
          .trim()

      const customerMemo =
        String(
          req.body?.customerMemo ??
          ''
        )

      const privateNote =
        String(
          req.body?.privateNote ??
          ''
        )

      const inputLines =
        Array.isArray(
          req.body?.lines
        )
          ? req.body.lines
          : []


      // ----------------------------------------------------------
      // APPROVAL + BASIC VALIDATION
      // ----------------------------------------------------------

      if (!approved) {
        return res
          .status(403)
          .json({
            success:
              false,

            field:
              'approval',

            error:
              'Explicit approval is required before updating an invoice.',
          })
      }

      if (
        approvedBy !==
          'salvador' &&
        approvedBy !==
          'dayanna'
      ) {
        return res
          .status(403)
          .json({
            success:
              false,

            field:
              'approval',

            error:
              'approvedBy must be Salvador or Dayanna.',
          })
      }

      if (!invoiceId) {
        return res
          .status(400)
          .json({
            success:
              false,

            field:
              'invoice',

            error:
              'invoiceId is required.',
          })
      }

      if (!syncToken) {
        return res
          .status(400)
          .json({
            success:
              false,

            field:
              'invoice',

            error:
              'syncToken is required before updating an invoice.',
          })
      }

      if (!customerId) {
        return res
          .status(400)
          .json({
            success:
              false,

            field:
              'customerId',

            error:
              'Customer is required.',
          })
      }

      if (
        inputLines.length ===
        0
      ) {
        return res
          .status(400)
          .json({
            success:
              false,

            field:
              'lines',

            error:
              'At least one invoice line is required.',
          })
      }

      if (
        txnDate &&
        !/^\d{4}-\d{2}-\d{2}$/
          .test(
            txnDate
          )
      ) {
        return res
          .status(400)
          .json({
            success:
              false,

            field:
              'txnDate',

            error:
              'Invoice date must use YYYY-MM-DD.',
          })
      }

      if (
        dueDate &&
        !/^\d{4}-\d{2}-\d{2}$/
          .test(
            dueDate
          )
      ) {
        return res
          .status(400)
          .json({
            success:
              false,

            field:
              'dueDate',

            error:
              'Due date must use YYYY-MM-DD.',
          })
      }


      const connection =
        await getValidQuickBooksConnection(
          companyKey
        )
      if (res.locals.invoiceOwnerScope?.realmId !== String(connection.realm_id) || res.locals.invoiceOwnerScope?.environment !== connection.environment) {
        return res.status(409).json({success:false,error:'Connected company changed. Review the invoice again.'})
      }


      const baseUrl =
        getQuickBooksApiBaseUrl(
          connection.environment
        )


      // ----------------------------------------------------------
      // LOAD CURRENT QUICKBOOKS INVOICE
      // ----------------------------------------------------------

      const currentResponse =
        await fetch(
          `${baseUrl}/v3/company/${encodeURIComponent(
            connection.realm_id
          )}/invoice/${encodeURIComponent(
            invoiceId
          )}`,
          {
            headers: {
              Authorization:
                `Bearer ${connection.access_token}`,

              Accept:
                'application/json',
            },
          }
        )

      const currentData =
        await currentResponse.json()

      if (!currentResponse.ok) {
        return res
          .status(
            currentResponse.status
          )
          .json({
            success:
              false,

            field:
              'invoice',

            error:
              'Could not load the current QuickBooks invoice before updating.',

            details:
              currentData,
          })
      }

      const currentInvoice =
        currentData?.Invoice ||
        null

      if (!currentInvoice) {
        return res
          .status(404)
          .json({
            success:
              false,

            field:
              'invoice',

            error:
              'Invoice was not found.',
          })
      }


      // ----------------------------------------------------------
      // SYNCTOKEN PROTECTION
      // ----------------------------------------------------------

      const currentSyncToken =
        String(
          currentInvoice.SyncToken ||
          ''
        )

      if (
        currentSyncToken !==
        syncToken
      ) {
        return res
          .status(409)
          .json({
            success:
              false,

            field:
              'invoice',

            staleInvoice:
              true,

            currentSyncToken,

            error:
              'This invoice changed in QuickBooks after it was opened. Reload the invoice before saving your changes.',
          })
      }


      // ----------------------------------------------------------
      // DUPLICATE DOCNUMBER PROTECTION
      // ----------------------------------------------------------

      const finalDocNumber =
        docNumber ||
        String(
          currentInvoice.DocNumber ||
          ''
        )

      if (
        finalDocNumber
      ) {
        const safeDocNumber =
          finalDocNumber
            .replace(
              /\\/g,
              '\\\\'
            )
            .replace(
              /'/g,
              "\\'"
            )

        const duplicateData =
          await fridayQuickBooksInvoiceQuery(
            connection,
            `SELECT * FROM Invoice ` +
            `WHERE DocNumber = '${safeDocNumber}' ` +
            `MAXRESULTS 10`
          )

        const duplicates =
          duplicateData
            ?.QueryResponse
            ?.Invoice ||
          []

        const duplicateInvoice =
          duplicates.find(
            (
              invoice:
                any
            ) =>
              String(
                invoice.Id ||
                ''
              ) !==
              invoiceId
          ) ||
          null

        if (
          duplicateInvoice
        ) {
          return res
            .status(409)
            .json({
              success:
                false,

              field:
                'docNumber',

              duplicateDocNumber:
                true,

              existingInvoiceId:
                duplicateInvoice.Id ||
                null,

              existingDocNumber:
                duplicateInvoice.DocNumber ||
                finalDocNumber,

              error:
                `Invoice number ${finalDocNumber} already exists in QuickBooks. Use another number.`,
            })
        }
      }


      // ----------------------------------------------------------
      // VALIDATE CUSTOMER
      // ----------------------------------------------------------

      const safeCustomerId =
        customerId
          .replace(
            /\\/g,
            '\\\\'
          )
          .replace(
            /'/g,
            "\\'"
          )

      const customerData =
        await fridayQuickBooksInvoiceQuery(
          connection,
          `SELECT * FROM Customer ` +
          `WHERE Id = '${safeCustomerId}' ` +
          `MAXRESULTS 1`
        )

      const customer =
        customerData
          ?.QueryResponse
          ?.Customer
          ?.[0] ||
        null

      if (!customer) {
        return res
          .status(404)
          .json({
            success:
              false,

            field:
              'customerId',

            error:
              'Customer was not found in QuickBooks.',
          })
      }


      // ----------------------------------------------------------
      // VALIDATE PAYMENT TERM
      // ----------------------------------------------------------

      let paymentTerm:
        any =
        null

      if (
        termId
      ) {
        const safeTermId =
          termId
            .replace(
              /\\/g,
              '\\\\'
            )
            .replace(
              /'/g,
              "\\'"
            )

        const termData =
          await fridayQuickBooksInvoiceQuery(
            connection,
            `SELECT * FROM Term ` +
            `WHERE Id = '${safeTermId}' ` +
            `MAXRESULTS 1`
          )

        paymentTerm =
          termData
            ?.QueryResponse
            ?.Term
            ?.[0] ||
          null

        if (
          !paymentTerm ||
          paymentTerm.Active ===
            false
        ) {
          return res
            .status(400)
            .json({
              success:
                false,

              field:
                'termId',

              error:
                'Selected payment term is not valid in QuickBooks.',
            })
        }
      }


      // ----------------------------------------------------------
      // VALIDATE + BUILD SERVICE LINES
      // ----------------------------------------------------------

      const quickBooksLines:
        any[] =
        []

      const validatedLines:
        any[] =
        []

      let expectedSubtotal =
        0

      let expectedTaxableSubtotal =
        0

      for (
        let lineIndex = 0;
        lineIndex <
        inputLines.length;
        lineIndex += 1
      ) {
        const inputLine =
          inputLines[
            lineIndex
          ]

        const lineNumber =
          lineIndex +
          1

        const itemId =
          String(
            inputLine?.itemId ||
            ''
          )
            .trim()

        const description =
          String(
            inputLine?.description ||
            ''
          )
            .trim()

        const serviceDate =
          String(
            inputLine?.serviceDate ||
            ''
          )
            .trim()

        const quantity =
          Number(
            inputLine?.quantity ??
            1
          )

        const unitPrice =
          Number(
            inputLine?.unitPrice ??
            0
          )

        const taxable =
          inputLine?.taxable ===
          true

        if (!itemId) {
          return res
            .status(400)
            .json({
              success:
                false,

              field:
                `line-${lineNumber}-item`,

              lineNumber,

              error:
                `Invoice line ${lineNumber} requires a Product / Service.`,
            })
        }

        if (
          serviceDate &&
          !/^\d{4}-\d{2}-\d{2}$/
            .test(
              serviceDate
            )
        ) {
          return res
            .status(400)
            .json({
              success:
                false,

              field:
                `line-${lineNumber}-serviceDate`,

              lineNumber,

              error:
                `Invoice line ${lineNumber} has an invalid service date.`,
            })
        }

        if (
          !Number.isFinite(
            quantity
          ) ||
          quantity <=
            0
        ) {
          return res
            .status(400)
            .json({
              success:
                false,

              field:
                `line-${lineNumber}-quantity`,

              lineNumber,

              error:
                `Invoice line ${lineNumber} must have a quantity greater than zero.`,
            })
        }

        if (
          !Number.isFinite(
            unitPrice
          ) ||
          unitPrice <
            0
        ) {
          return res
            .status(400)
            .json({
              success:
                false,

              field:
                `line-${lineNumber}-rate`,

              lineNumber,

              error:
                `Invoice line ${lineNumber} has an invalid rate.`,
            })
        }

        const safeItemId =
          itemId
            .replace(
              /\\/g,
              '\\\\'
            )
            .replace(
              /'/g,
              "\\'"
            )

        const itemData =
          await fridayQuickBooksInvoiceQuery(
            connection,
            `SELECT * FROM Item ` +
            `WHERE Id = '${safeItemId}' ` +
            `MAXRESULTS 1`
          )

        const item =
          itemData
            ?.QueryResponse
            ?.Item
            ?.[0] ||
          null

        if (!item) {
          return res
            .status(404)
            .json({
              success:
                false,

              field:
                `line-${lineNumber}-item`,

              lineNumber,

              error:
                `QuickBooks Product / Service on line ${lineNumber} was not found.`,
            })
        }

        const amount =
          Number(
            (
              quantity *
              unitPrice
            )
              .toFixed(
                2
              )
          )

        expectedSubtotal +=
          amount

        if (
          taxable
        ) {
          expectedTaxableSubtotal +=
            amount
        }

        const salesItemLineDetail:
          any = {
          ItemRef: {
            value:
              String(
                item.Id
              ),

            name:
              item.Name ||
              undefined,
          },

          Qty:
            quantity,

          UnitPrice:
            unitPrice,

          TaxCodeRef: {
            value:
              taxable
                ? 'TAX'
                : 'NON',
          },
        }

        if (
          serviceDate
        ) {
          salesItemLineDetail
            .ServiceDate =
              serviceDate
        }

        quickBooksLines.push({
          DetailType:
            'SalesItemLineDetail',

          Amount:
            amount,

          Description:
            description ||
            item.Description ||
            item.Name ||
            undefined,

          SalesItemLineDetail:
            salesItemLineDetail,
        })

        validatedLines.push({
          lineNumber,

          serviceDate:
            serviceDate ||
            null,

          itemId:
            String(
              item.Id
            ),

          itemName:
            item.Name ||
            null,

          description:
            description ||
            item.Description ||
            item.Name ||
            null,

          quantity,

          unitPrice,

          amount,

          taxable,

          taxCode:
            taxable
              ? 'TAX'
              : 'NON',
        })
      }

      expectedSubtotal =
        Number(
          expectedSubtotal
            .toFixed(
              2
            )
        )

      expectedTaxableSubtotal =
        Number(
          expectedTaxableSubtotal
            .toFixed(
              2
            )
        )


      // ----------------------------------------------------------
      // BUILD SPARSE UPDATE PAYLOAD
      // ----------------------------------------------------------

      const updatePayload:
        any = {
        Id:
          invoiceId,

        SyncToken:
          currentSyncToken,

        sparse:
          true,

        CustomerRef: {
          value:
            String(
              customer.Id
            ),

          name:
            customer.DisplayName ||
            undefined,
        },

        Line:
          quickBooksLines,
      }

      if (
        finalDocNumber
      ) {
        updatePayload.DocNumber =
          finalDocNumber
      }

      if (
        txnDate
      ) {
        updatePayload.TxnDate =
          txnDate
      }

      if (
        dueDate
      ) {
        updatePayload.DueDate =
          dueDate
      }

      if (
        termId
      ) {
        updatePayload.SalesTermRef = {
          value:
            termId,

          name:
            paymentTerm?.Name ||
            undefined,
        }
      }

      if (
        billEmail
      ) {
        updatePayload.BillEmail = {
          Address:
            billEmail,
        }
      }

      updatePayload.CustomerMemo = {
        value:
          customerMemo,
      }

      updatePayload.PrivateNote =
        privateNote


      // ----------------------------------------------------------
      // UPDATE QUICKBOOKS
      // ----------------------------------------------------------

      const updateResponse =
        await fetch(
          `${baseUrl}/v3/company/${encodeURIComponent(
            connection.realm_id
          )}/invoice`,
          {
            method:
              'POST',

            headers: {
              Authorization:
                `Bearer ${connection.access_token}`,

              Accept:
                'application/json',

              'Content-Type':
                'application/json',
            },

            body:
              JSON.stringify(
                updatePayload
              ),
          }
        )

      const updateData =
        await updateResponse.json()

      if (
        !updateResponse.ok
      ) {
        console.error(
          'QUICKBOOKS UPDATE INVOICE ERROR:',
          updateData
        )

        return res
          .status(
            updateResponse.status
          )
          .json({
            success:
              false,

            field:
              'invoice',

            error:
              'QuickBooks invoice update failed.',

            details:
              updateData,
          })
      }

      const updatedInvoice =
        updateData?.Invoice ||
        null

      if (
        !updatedInvoice?.Id
      ) {
        throw new Error(
          'QuickBooks did not return the updated invoice.'
        )
      }

      res.json({
        success:
          true,

        companyKey,

        companyName:
          connection.company_name,

        environment:
          connection.environment,

        approved:
          true,

        approvedBy,

        result: {
          invoiceId:
            updatedInvoice.Id,

          syncToken:
            updatedInvoice.SyncToken ||
            null,

          docNumber:
            updatedInvoice.DocNumber ||
            finalDocNumber ||
            null,

          customerId:
            updatedInvoice
              ?.CustomerRef
              ?.value ||
            customerId,

          customerName:
            updatedInvoice
              ?.CustomerRef
              ?.name ||
            customer.DisplayName ||
            null,

          txnDate:
            updatedInvoice.TxnDate ||
            txnDate ||
            null,

          dueDate:
            updatedInvoice.DueDate ||
            dueDate ||
            null,

          termId:
            updatedInvoice
              ?.SalesTermRef
              ?.value ||
            termId ||
            null,

          termName:
            updatedInvoice
              ?.SalesTermRef
              ?.name ||
            paymentTerm?.Name ||
            null,

          expectedSubtotal,

          expectedTaxableSubtotal,

          totalAmount:
            Number(
              updatedInvoice.TotalAmt ||
              expectedSubtotal
            ),

          balance:
            Number(
              updatedInvoice.Balance ||
              0
            ),

          lineCount:
            validatedLines.length,

          lines:
            validatedLines,

          updated:
            true,
        },
      })

    } catch (
      error:
        any
    ) {
      console.error(
        'QUICKBOOKS INVOICE UPDATE ERROR:',
        error
      )

      res
        .status(500)
        .json({
          success:
            false,

          field:
            'invoice',

          error:
            error?.message ||
            'Could not update invoice.',
        })
    }
  }
)

// ============================================================
// END [QUICKBOOKS-41] Editable invoice update + duplicate DocNumber check

}
