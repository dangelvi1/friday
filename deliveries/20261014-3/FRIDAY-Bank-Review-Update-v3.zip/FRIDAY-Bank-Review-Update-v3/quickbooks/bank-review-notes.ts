import type {Express} from 'express'
import {createHash, randomUUID} from 'node:crypto'
import {mkdir, readFile, rename, writeFile} from 'node:fs/promises'
import {resolve, dirname} from 'node:path'
import {authenticateSandraOwner} from './sandra-learning-core'
import {getValidQuickBooksConnection} from './connection'
import {runQuickBooksQuery} from './query'
import {validateFeed} from './bank-review-engine'

const locks = new Map<string, Promise<unknown>>()
export function registerBankReviewNotes(app: Express) {
  app.all('/quickbooks/bank-review-notes/:companyKey/:accountId', async (req,res) => {
    res.setHeader('Cache-Control','no-store')
    if (!['GET','POST'].includes(req.method)) return res.sendStatus(405)
    let actor: string
    try {actor = authenticateSandraOwner(req)} catch {return res.status(403).json({success:false,error:'Verified owner credential required. No review was saved.'})}
    const companyKey=String(req.params.companyKey),accountId=String(req.params.accountId)
    if (!/^[a-z0-9-]{1,80}$/.test(companyKey)||!/^\d{1,20}$/.test(accountId)) return res.status(400).json({success:false,error:'Invalid company/account.'})
    try {
      const connection=await getValidQuickBooksConnection(companyKey)
      const scope={companyKey,accountId,realmId:String(connection.realm_id),environment:String(connection.environment),actor}
      const account=await runQuickBooksQuery(connection,`SELECT * FROM Account WHERE Id = '${accountId}'`)
      if(account?.QueryResponse?.Account?.[0]?.AccountType!=='Bank') throw Error('Selected bank account unavailable.')
      const scopeKey=createHash('sha256').update(JSON.stringify(scope)).digest('hex')
      const file=resolve(process.cwd(),'data','sandra-bank-reviews',scopeKey+'.json')
      const read=async()=>{try{return JSON.parse(await readFile(file,'utf8'))}catch(e:any){if(e.code==='ENOENT')return null;throw e}}
      if(req.method==='GET')return res.json({success:true,...scope,review:await read(),readOnly:true})
      if(req.body?.realmId!==scope.realmId||req.body?.environment!==scope.environment) return res.status(409).json({success:false,error:'Connected company changed. Reload the bank review.'})
      const input=validateFeed(req.body?.input)
      if(req.body?.expectedActor!==actor)return res.status(409).json({success:false,error:'Owner changed. Load this owner review before saving.'})
      const expectedRevision=req.body?.expectedRevision
      if(!Number.isSafeInteger(expectedRevision)||expectedRevision<0)throw Error('Invalid review revision.')
      const reviews=req.body?.reviews
      if(!Array.isArray(reviews)||reviews.length!==input.length)throw Error('Provide one private review per source row.')
      const seen=new Set<number>()
      const clean=reviews.map((r:any)=>{
        if(!Number.isSafeInteger(r.ordinal)||r.ordinal<1||r.ordinal>input.length||seen.has(r.ordinal)||typeof r.note!=='string'||r.note.length>1000)throw Error('Invalid review row or note.')
        seen.add(r.ordinal)
        const candidate=r.candidate==null?null:r.candidate
        if(candidate&&(!['Payment','Deposit','Purchase','Transfer','BillPayment','JournalEntry','SalesReceipt','RefundReceipt'].includes(candidate.type)||!/^\d+(?::(?:debit|credit))?$/.test(candidate.id)))throw Error('Invalid candidate reference.')
        return {ordinal:r.ordinal,note:r.note,candidate:candidate?{type:candidate.type,id:candidate.id}:null}
      })
      const prior=locks.get(file)||Promise.resolve()
      const task=prior.catch(()=>{}).then(async()=>{
        const old=await read()
        if((old?.revision||0)!==expectedRevision)return res.status(409).json({success:false,error:'This owner review changed in another tab. Load it before saving.'})
        const review={...scope,revision:expectedRevision+1,sourceHash:createHash('sha256').update(JSON.stringify(input)).digest('hex'),input,reviews:clean,savedAt:new Date().toISOString(),quickBooksChanged:false,candidateVerification:'Private selections only; refresh bank analysis to verify current QuickBooks evidence.'}
        await mkdir(dirname(file),{recursive:true})
        const temporary=file+'.'+randomUUID()+'.tmp'
        await writeFile(temporary,JSON.stringify(review,null,2),'utf8');await rename(temporary,file)
        return res.json({success:true,...scope,review})
      })
      locks.set(file,task)
      try {await task}finally{if(locks.get(file)===task)locks.delete(file)}
    }catch {if(!res.headersSent)res.status(400).json({success:false,error:'Could not validate or save the private bank review. Nothing was changed in QuickBooks.'})}
  })
}
