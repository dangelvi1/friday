import {loadPostedLedger, readEntity} from './bank-ledger-reader'
import {reconciliationInputs, reconciliationSummary, offsetDate} from './reconciliation-core'
import {validDate} from './bank-review-engine'
import {QuickBooksThrottleError} from './query'
// ============================================================
// FRIDAY QUICKBOOKS BANK RECONCILIATION
// FILE: S:\AI\friday-ai\quickbooks\bank-reconciliation.ts
// ============================================================

import type {
  Express,
} from 'express'

import {
  getValidQuickBooksConnection,
} from './connection'

import {
  runQuickBooksQuery,
} from './query'


export function registerQuickBooksBankReconciliation(
  app:
    Express
) {

  app.get('/quickbooks/reconcile-assistant/:companyKey/:accountId', async (req, res) => {
    let input: ReturnType<typeof reconciliationInputs>
    try {input = reconciliationInputs(req.params.companyKey, req.params.accountId, req.query)}
    catch (e: any) {return res.status(400).json({success:false,error:e.message})}
    try {
      const connection = await getValidQuickBooksConnection(input.companyKey)
      const ledger = await loadPostedLedger(connection, input.accountId, offsetDate(input.startDate,-7), offsetDate(input.endDate,7))
      const summary = reconciliationSummary(ledger.transactions,input.startDate,input.endDate,input.startBalance,input.endBalance)
      return res.json({success:true,companyKey:input.companyKey,companyName:connection.company_name,accountId:input.accountId,
        realmId:String(connection.realm_id),environment:connection.environment,account:ledger.account,
        period:{startDate:input.startDate,endDate:input.endDate},statement:{startBalance:input.startBalance,endBalance:input.endBalance},
        ...summary,supportedEntities:ledger.supportedEntities,limitations:ledger.limitations,readOnly:true})
    } catch (e) {
      if (e instanceof QuickBooksThrottleError) {res.setHeader('Retry-After',String(e.retryAfterSeconds));return res.status(429).json({success:false,error:e.message})}
      return res.status(502).json({success:false,error:'Could not read complete posted activity. No partial or balanced result was accepted. Check the QuickBooks connection and retry.'})
    }
  })

  // ============================================================
  // START [QUICKBOOKS-RECON-DIAGNOSTIC] ACCOUNT ACTIVITY DIAGNOSTIC
  // ============================================================

  app.get(
    '/quickbooks/account-diagnostic/:companyKey/:accountId',
    async (
      req,
      res
    ) => {
      try {
        const companyKey =
          String(
            req.params.companyKey ||
            ''
          )
            .trim()
            .toLowerCase()

        const accountId =
          String(
            req.params.accountId ||
            ''
          )
            .trim()

        const startDate =
          String(
            req.query.startDate ||
            ''
          )
            .trim()

        const endDate =
          String(
            req.query.endDate ||
            ''
          )
            .trim()

        if (
          !/^[a-z0-9-]{1,80}$/.test(companyKey) ||
          !/^\d{1,20}$/.test(accountId) ||
          !validDate(startDate) ||
          !validDate(endDate) || startDate > endDate || Date.parse(endDate)-Date.parse(startDate)>366*86400000
        ) {
          return res
            .status(400)
            .json({
              success: false,
              error:
                'companyKey, accountId, startDate and endDate are required.',
            })
        }

        const connection =
          await getValidQuickBooksConnection(
            companyKey
          )

        const accountData =
          await runQuickBooksQuery(
            connection,
            `SELECT * FROM Account WHERE Id = '${accountId}' MAXRESULTS 1`
          )

        const account =
          accountData
            ?.QueryResponse
            ?.Account?.[0] ||
          null

        if (!account) {
          return res
            .status(404)
            .json({
              success: false,
              error:
                `QuickBooks account ${accountId} was not found.`,
            })
        }

        const dateFilter =
          `TxnDate >= '${startDate}' AND TxnDate <= '${endDate}'`

        const entityNames = [
          'Payment',
          'Deposit',
          'Purchase',
          'Transfer',
          'BillPayment',
          'JournalEntry',
          'SalesReceipt',
          'RefundReceipt',
          'CreditMemo',
        ]

        async function safeQuery(
          entity:
            string
        ) {
          try {
            const rows = await readEntity(sql => runQuickBooksQuery(connection,sql),entity,dateFilter)
            const data: any = {QueryResponse:{[entity]:rows}}

            return {
              entity,
              ok: true,
              data,
              error: null,
            }
          } catch (
            error:
              any
          ) {
            return {
              entity,
              ok: false,
              data: {
                QueryResponse: {},
              },
              error:
                error?.message ||
                String(
                  error
                ),
            }
          }
        }

        function findAccountMatches(
          value:
            any,
          path =
            ''
        ):
          string[] {
          const matches:
            string[] =
            []

          if (
            value ===
              null ||
            value ===
              undefined
          ) {
            return matches
          }

          if (
            Array.isArray(
              value
            )
          ) {
            value.forEach(
              (
                item,
                index
              ) => {
                matches.push(
                  ...findAccountMatches(
                    item,
                    `${path}[${index}]`
                  )
                )
              }
            )

            return matches
          }

          if (
            typeof value !==
            'object'
          ) {
            return matches
          }

          for (
            const [
              key,
              child,
            ]
            of Object.entries(
              value
            )
          ) {
            const childPath =
              path
                ? `${path}.${key}`
                : key

            if (
              child &&
              typeof child ===
                'object' &&
              !Array.isArray(
                child
              ) &&
              String(
                (
                  child as
                  any
                ).value ||
                ''
              ) ===
                accountId
            ) {
              matches.push(
                childPath
              )
            }

            matches.push(
              ...findAccountMatches(
                child,
                childPath
              )
            )
          }

          return Array.from(
            new Set(
              matches
            )
          )
        }

        const queryResults =
          await Promise.all(
            entityNames.map(
              entity =>
                safeQuery(
                  entity
                )
            )
          )

        const results =
          queryResults.map(
            result => {
              const rows =
                result
                  .data
                  ?.QueryResponse
                  ?.[
                    result.entity
                  ] ||
                []

              const matched =
                rows
                  .map(
                    (
                      row:
                        any
                    ) => {
                      const paths =
                        findAccountMatches(
                          row
                        )

                      if (
                        paths.length ===
                        0
                      ) {
                        return null
                      }

                      return {
                        id:
                          row.Id ||
                          null,
                        txnDate:
                          row.TxnDate ||
                          null,
                        totalAmt:
                          Number(
                            row.TotalAmt ??
                            row.Amount ??
                            0
                          ),
                        paymentType:
                          row.PaymentType ||
                          null,
                        docNumber:
                          row.DocNumber ||
                          null,
                        privateNote:
                          row.PrivateNote ||
                          null,
                        entityName:
                          row
                            ?.EntityRef
                            ?.name ||
                          row
                            ?.CustomerRef
                            ?.name ||
                          row
                            ?.VendorRef
                            ?.name ||
                          null,
                        matchedAccountPaths:
                          paths,
                      }
                    }
                  )
                  .filter(
                    Boolean
                  )

              return {
                entity:
                  result.entity,
                querySucceeded:
                  result.ok,
                queryError:
                  result.error,
                totalRowsInPeriod:
                  rows.length,
                matchingRowsForAccount:
                  matched.length,
                sampleMatches:
                  matched.slice(
                    0,
                    10
                  ),
              }
            }
          )

        const totalMatchingRows =
          results.reduce(
            (
              total,
              result
            ) =>
              total +
              result.matchingRowsForAccount,
            0
          )

        res.json({
          success:
            true,
          companyKey,
          companyName:
            connection.company_name,
          account: {
            id:
              account.Id ||
              accountId,
            name:
              account
                .FullyQualifiedName ||
              account.Name ||
              null,
            accountNumber:
              account.AcctNum ||
              null,
            accountType:
              account.AccountType ||
              null,
            currentBalance:
              account.CurrentBalance ??
              null,
          },
          period: {
            startDate,
            endDate,
          },
          totalMatchingRows,
          results,
        })
      } catch (
        error:
          any
      ) {
        console.error(
          'QUICKBOOKS ACCOUNT DIAGNOSTIC ERROR:',
          error
        )

        res
          .status(500)
          .json({
            success:
              false,
            error:
              error?.message ||
              'Could not run QuickBooks account diagnostic.',
          })
      }
    }
  )

  // ============================================================
  // END [QUICKBOOKS-RECON-DIAGNOSTIC] ACCOUNT ACTIVITY DIAGNOSTIC
  // ============================================================
}
