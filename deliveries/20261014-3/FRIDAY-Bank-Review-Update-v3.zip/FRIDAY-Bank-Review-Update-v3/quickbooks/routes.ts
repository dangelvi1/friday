import {registerInvoiceOwnerActions} from './invoice-owner-actions'
import {registerDocumentAnalysis} from './document-analysis'
// ============================================================
// FRIDAY QUICKBOOKS ROUTE REGISTRY
// FILE: S:\AI\friday-ai\quickbooks\routes.ts
// PURPOSE:
// - Register small QuickBooks feature modules
// - Keep feature files easy to modify
// - Keep server.ts independent from QuickBooks internals
// ============================================================

import type {
  Express,
} from 'express'

import {
  registerQuickBooksAuthAndCompanies,
} from './auth-companies'

import {
  registerQuickBooksCustomers,
} from './customers'

import {
  registerQuickBooksInvoiceSearch,
} from './invoice-search'

import {
  registerQuickBooksInvoiceDetail,
} from './invoice-detail'

import {
  registerQuickBooksInvoiceDraft,
} from './invoice-draft'

import {
  registerQuickBooksInvoiceCreate,
} from './invoice-create'

import {
  registerQuickBooksInvoiceUpdate,
} from './invoice-update'

import {
  registerQuickBooksCatalog,
} from './catalog'

import {
  registerQuickBooksTermsCatalog,
} from './terms-catalog'

import {
  registerQuickBooksCustomerTermRead,
} from './customer-term-read'

import {
  registerQuickBooksCustomerTermUpdate,
} from './customer-term-update'

import {
  registerQuickBooksBankAccounts,
} from './bank-accounts'

import {
  registerQuickBooksBankTransactions,
} from './bank-transactions'

import {
  registerQuickBooksBankReview,
} from './bank-review'

import {
  registerQuickBooksBankCategorization,
} from './bank-categorization'

import {
  registerQuickBooksBankReconciliation,
} from './bank-reconciliation'

import {
  registerQuickBooksStatementLibrary,
} from './statement-library'

import {
  registerQuickBooksPaymentMatching,
} from './payment-matching'

import {
  registerQuickBooksPaymentRecord,
} from './payment-record'

import {
  registerQuickBooksVendorsAndExpenses,
} from './vendors-expenses'

import {
  registerQuickBooksArAgingReport,
} from './report-ar-aging'

import {
  registerQuickBooksMonthlySummaryReport,
} from './report-monthly-summary'

import {
  registerQuickBooksCollections,
} from './collections'

import {
  registerQuickBooksCommands,
  type FridayMessagingDependencies,
} from './commands'

import {
  registerQuickBooksPermissions,
} from './permissions'

import {
  registerSandraCollections,
} from './sandra-collections'

import {
  registerQuickBooksLiveBankFeed,
} from './live-bank-feed'

import {registerQuickBooksApiBankReview} from './bank-api-review'


export function registerQuickBooksRoutes(
  app:
    Express,
  messaging:
    FridayMessagingDependencies
) {
  registerQuickBooksAuthAndCompanies(app)
  registerQuickBooksCustomers(app)

  registerQuickBooksInvoiceSearch(app)
  registerQuickBooksInvoiceDetail(app)
  registerQuickBooksInvoiceDraft(app)
  registerInvoiceOwnerActions(app)
  registerQuickBooksInvoiceCreate(app)
  registerQuickBooksInvoiceUpdate(app)

  registerQuickBooksCatalog(app)

  registerQuickBooksTermsCatalog(app)
  registerQuickBooksCustomerTermRead(app)
  registerQuickBooksCustomerTermUpdate(app)

  registerQuickBooksBankAccounts(app)
  registerQuickBooksBankTransactions(app)
  registerQuickBooksBankReview(app)
  registerQuickBooksBankCategorization(app)
  registerQuickBooksBankReconciliation(app)
  registerQuickBooksStatementLibrary(app)
  registerQuickBooksLiveBankFeed(app)
  registerQuickBooksApiBankReview(app)
  registerDocumentAnalysis(app)

  registerQuickBooksPaymentMatching(app)
  registerQuickBooksPaymentRecord(app)

  registerQuickBooksVendorsAndExpenses(app)

  registerQuickBooksArAgingReport(app)
  registerQuickBooksMonthlySummaryReport(app)

  registerQuickBooksCollections(app)
  registerSandraCollections(app)

  registerQuickBooksCommands(
    app,
    messaging
  )

  registerQuickBooksPermissions(app)
}
