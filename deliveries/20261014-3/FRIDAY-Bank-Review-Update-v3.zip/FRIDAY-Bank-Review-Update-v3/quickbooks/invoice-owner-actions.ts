import type {Express} from 'express'
import {createHash, randomUUID} from 'node:crypto'
import {mkdir, readFile, writeFile} from 'node:fs/promises'
import {resolve} from 'node:path'
import {authenticateSandraOwner} from './sandra-learning-core'
import {getValidQuickBooksConnection} from './connection'
import {getQuickBooksApiBaseUrl} from './quickbooks-auth'

const hash=(v:unknown)=>createHash('sha256').update(JSON.stringify(v)).digest('hex')
const root=()=>resolve(process.cwd(),'data','invoice-owner-actions')
const file=(id:string)=>resolve(root(),id+'.json')
async function readInvoice(c:any,id:string){
  const r=await fetch(`${getQuickBooksApiBaseUrl(c.environment)}/v3/company/${encodeURIComponent(c.realm_id)}/invoice/${id}`,{headers:{Authorization:`Bearer ${c.access_token}`,Accept:'application/json'}})
  const d=await r.json() as any
  if(!r.ok||!d.Invoice)throw Error('Invoice unavailable. Refresh before approving.')
  return d.Invoice
}
export function registerInvoiceOwnerActions(app:Express){
  app.get('/quickbooks/invoice-owner-scope/:companyKey',async(req,res)=>{
    res.setHeader('Cache-Control','no-store')
    try{const actor=authenticateSandraOwner(req),companyKey=String(req.params.companyKey);if(!/^[a-z0-9-]{1,80}$/.test(companyKey))throw Error();const c=await getValidQuickBooksConnection(companyKey);res.json({success:true,actor,companyKey,companyName:c.company_name,realmId:String(c.realm_id),environment:c.environment})}catch{res.status(403).json({success:false,error:'Verified owner and connected company required.'})}
  })
  // Register before the existing full create/update handlers. A name in the body is not authentication.
  app.use(['/quickbooks/invoice-action/:companyKey','/quickbooks/invoice-update/:companyKey/:invoiceId'],async(req,res,next)=>{
    if(req.method!=='POST')return next()
    try{
      const actor=authenticateSandraOwner(req),c=await getValidQuickBooksConnection(String(req.params.companyKey))
      if(req.body?.approved!==true||String(req.body?.approvedBy).toLowerCase()!==actor||req.body?.realmId!==String(c.realm_id)||req.body?.environment!==c.environment) return res.status(409).json({success:false,error:'Owner approval or company scope changed. Review again.'})
      res.locals.invoiceOwnerScope={actor,realmId:String(c.realm_id),environment:c.environment};next()
    }catch{res.status(403).json({success:false,error:'Verified owner credential required for invoice changes.'})}
  })
  app.post('/quickbooks/invoice-delete/:companyKey/:invoiceId/:action',async(req,res)=>{
    try{
      const actor=authenticateSandraOwner(req),companyKey=String(req.params.companyKey),id=String(req.params.invoiceId),action=String(req.params.action)
      if(!/^[a-z0-9-]{1,80}$/.test(companyKey)||!/^\d{1,20}$/.test(id)||!['preview','execute','receipt'].includes(action))return res.status(400).json({success:false,error:'Invalid invoice request.'})
      const c=await getValidQuickBooksConnection(companyKey),scope={companyKey,invoiceId:id,actor,realmId:String(c.realm_id),environment:String(c.environment)}
      if(req.body?.realmId!==scope.realmId||req.body?.environment!==scope.environment)return res.status(409).json({success:false,error:'Connected company changed; review again.'})
      await mkdir(root(),{recursive:true})
      const claimFile=resolve(root(),hash({companyKey,invoiceId:id,realmId:scope.realmId,environment:scope.environment})+'.submitted')
      if(action==='preview'){
        try {const previous=await readFile(claimFile,'utf8');return res.status(409).json({success:false,error:'A deletion for this invoice was already submitted. Inspect its receipt and QuickBooks before further changes.',proposalId:previous})}catch(e:any){if(e.code!=='ENOENT')throw e}
        const invoice=await readInvoice(c,id)
        if(!Number.isFinite(Number(invoice.TotalAmt))||!Number.isFinite(Number(invoice.Balance)))throw Error('Invoice amounts unavailable.')
        if(!/^\d+$/.test(String(invoice.SyncToken)))throw Error('Missing invoice revision.')
        const proposal={...scope,proposalId:randomUUID(),snapshotHash:hash(invoice),syncToken:String(invoice.SyncToken),docNumber:invoice.DocNumber,customerName:invoice.CustomerRef?.name,total:invoice.TotalAmt,balance:invoice.Balance,linkedTransactions:(invoice.LinkedTxn||[]).map((x:any)=>({type:x.TxnType,id:x.TxnId})),dependenciesRequireReview:!!invoice.LinkedTxn?.length||Number(invoice.Balance)!==Number(invoice.TotalAmt),expiresAt:Date.now()+900000,status:'preview'}
        await writeFile(file(proposal.proposalId),JSON.stringify(proposal),{flag:'wx'})
        return res.json({success:true,...proposal})
      }
      const proposalId=req.body?.proposalId
      if(typeof proposalId!=='string'||! /^[a-f0-9-]{36}$/.test(proposalId))throw Error('Invalid proposal.')
      const proposal=JSON.parse(await readFile(file(proposalId),'utf8'))
      if(Object.entries(scope).some(([k,v])=>proposal[k]!==v))return res.status(403).json({success:false,error:'Proposal belongs to another company or owner.'})
      if(action==='receipt')return res.json({success:true,receipt:proposal})
      if(req.body?.approved!==true||req.body?.snapshotHash!==proposal.snapshotHash||proposal.expiresAt<Date.now()||proposal.status!=='preview')return res.status(409).json({success:false,error:'Approval is missing, expired or already submitted. Inspect the receipt; do not retry an uncertain deletion.'})
      if(proposal.dependenciesRequireReview && req.body?.dependenciesReviewed!==true)return res.status(409).json({success:false,error:'Review linked payments/credits and the invoice balance before deleting.'})
      const invoice=await readInvoice(c,id)
      if(hash(invoice)!==proposal.snapshotHash)return res.status(409).json({success:false,error:'Invoice changed after preview. Nothing was deleted; prepare a new preview.'})
      // Durable exclusive claim survives restarts. Never retry financial submission automatically.
      try{await writeFile(file(proposalId)+'.submitted',new Date().toISOString(),{flag:'wx'})}catch{return res.status(409).json({success:false,error:'Deletion was already submitted. Check its receipt and QuickBooks.'})}
      try{await writeFile(claimFile,proposalId,{flag:'wx'})}catch{return res.status(409).json({success:false,error:'A deletion for this invoice is already submitted. Check its receipt and QuickBooks.'})}
      proposal.status='uncertain';await writeFile(file(proposalId),JSON.stringify(proposal))
      try{
        const r=await fetch(`${getQuickBooksApiBaseUrl(c.environment)}/v3/company/${encodeURIComponent(c.realm_id)}/invoice?operation=delete&requestid=${proposalId}`,{method:'POST',headers:{Authorization:`Bearer ${c.access_token}`,Accept:'application/json','Content-Type':'application/json'},body:JSON.stringify({Id:id,SyncToken:proposal.syncToken}),signal:AbortSignal.timeout(30000)})
        const d=await r.json() as any
        if(!r.ok||String(d.Invoice?.Id)!==id||String(d.Invoice?.status).toLowerCase()!=='deleted')throw Error('Unverified delete response.')
        proposal.status='deleted';proposal.completedAt=new Date().toISOString();await writeFile(file(proposalId),JSON.stringify(proposal))
        return res.json({success:true,receipt:proposal})
      }catch{return res.status(502).json({success:false,error:'Deletion outcome is uncertain. Check the receipt and original QuickBooks invoice before doing anything else.',proposalId})}
    }catch{return res.status(400).json({success:false,error:'Could not validate the invoice action. Your form was kept. Check the owner setup and QuickBooks connection.'})}
  })
}
