$ErrorActionPreference = 'Stop'
$recordPath = Join-Path $PSScriptRoot 'restore-manifest.json'
if (!(Test-Path $recordPath)) { throw 'Stop Vite, then run the backup-folder copy of this script.' }
$record = Get-Content $recordPath -Raw | ConvertFrom-Json
foreach ($entry in $record.files) {
  $target = Join-Path $record.projectPath $entry.path
  $saved = Join-Path $PSScriptRoot $entry.path
  if (!(Test-Path $target) -or (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash -ne $entry.after) { throw "Installed file changed: $($entry.path). Restore stopped before changes." }
  if (!(Test-Path $saved) -or (Get-FileHash -LiteralPath $saved -Algorithm SHA256).Hash -ne $entry.before) { throw "Backup verification failed: $($entry.path). No files changed." }
}
foreach ($entry in $record.files) { Copy-Item -LiteralPath (Join-Path $PSScriptRoot $entry.path) -Destination (Join-Path $record.projectPath $entry.path) -Force }
Write-Host 'Verified Vite config restored. Restart npm run dev. Private data was not changed.'
