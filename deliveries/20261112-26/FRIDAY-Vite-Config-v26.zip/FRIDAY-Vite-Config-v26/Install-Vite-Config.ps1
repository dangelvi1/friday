param([string]$ProjectPath = 'S:\AI\friday-ai')
$ErrorActionPreference = 'Stop'
$manifest = Get-Content (Join-Path $PSScriptRoot 'vite-config-manifest.json') -Raw | ConvertFrom-Json
if (!(Test-Path (Join-Path $ProjectPath 'server.ts'))) { throw "FRIDAY project not found: $ProjectPath. No files changed." }
foreach ($entry in $manifest.requiredSHA256.PSObject.Properties) {
  $target = Join-Path $ProjectPath $entry.Name
  if (!(Test-Path $target) -or (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash -ne $entry.Value) { throw "Expected installed v25 dependency differs: $($entry.Name). No files changed." }
}
$active = @()
foreach ($entry in $manifest.files) {
  $relative = $entry.path
  if ($relative -match '(^[\\/]|\.\.|:)') { throw 'Unsafe package path.' }
  $source = Join-Path $PSScriptRoot $relative
  if (!(Test-Path $source) -or (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash -ne $entry.after) { throw "Package validation failed: $relative. No files changed." }
  $target = Join-Path $ProjectPath $relative
  if ($entry.optional -and !(Test-Path $target)) { continue }
  if (!(Test-Path $target) -or (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash -ne $entry.before) { throw "Installed file differs from verified v25: $relative. No files changed. Keep your edits and obtain a compatible patch." }
  $active += $entry
}
# Stop only the Vite/dev terminal before installation. The unchanged backend can stay running.
$backup = Join-Path $ProjectPath ('backups\vite-config-v26-' + (Get-Date -Format 'yyyyMMdd-HHmmss-fff'))
New-Item -ItemType Directory -Path $backup -Force | Out-Null
foreach ($entry in $active) {
  $saved = Join-Path $backup $entry.path
  New-Item -ItemType Directory -Path (Split-Path $saved) -Force | Out-Null
  Copy-Item -LiteralPath (Join-Path $ProjectPath $entry.path) -Destination $saved
  if ((Get-FileHash -LiteralPath $saved -Algorithm SHA256).Hash -ne $entry.before) { throw "Backup verification failed: $($entry.path). No project files changed." }
}
$record = @{projectPath=$ProjectPath; files=$active}
$record | ConvertTo-Json -Depth 8 | Set-Content (Join-Path $backup 'restore-manifest.json') -Encoding UTF8
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'Restore-Vite-Config.ps1') -Destination (Join-Path $backup 'Restore-Vite-Config.ps1')
$copied = @()
try {
  foreach ($entry in $active) {
    if ((Get-FileHash -LiteralPath (Join-Path $ProjectPath $entry.path) -Algorithm SHA256).Hash -ne $entry.before) { throw "File changed after backup: $($entry.path)" }
  }
  foreach ($entry in $active) {
    $copied += $entry
    $target = Join-Path $ProjectPath $entry.path
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot $entry.path) -Destination $target -Force
    if ((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash -ne $entry.after) { throw "Installed file verification failed: $($entry.path)" }
  }
} catch {
  foreach ($entry in $copied) { Copy-Item -LiteralPath (Join-Path $backup $entry.path) -Destination (Join-Path $ProjectPath $entry.path) -Force }
  throw
}
Write-Host 'FRIDAY Vite config v26 installed: explicit .ts import; existing device protection and TLS/proxy settings preserved.'
Write-Host "Verified backup: $backup"
Write-Host 'Restart npm run dev. No dependency reinstall or backend change is required.'
