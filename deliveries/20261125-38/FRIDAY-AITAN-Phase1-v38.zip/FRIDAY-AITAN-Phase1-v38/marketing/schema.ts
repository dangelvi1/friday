// Additive, transactional migration. Never alters existing FRIDAY tables.
export const schemaSQL=`
CREATE SCHEMA IF NOT EXISTS aitan_studio;
CREATE TABLE IF NOT EXISTS aitan_studio.version (singleton boolean PRIMARY KEY DEFAULT true CHECK(singleton), version integer NOT NULL);
CREATE TABLE IF NOT EXISTS aitan_studio.companies (
 id uuid PRIMARY KEY, request_id uuid UNIQUE NOT NULL, request_hash text NOT NULL,
 seed_key text UNIQUE, profile jsonb NOT NULL, active boolean NOT NULL DEFAULT true,
 revision integer NOT NULL DEFAULT 0 CHECK(revision>=0),
 created_by text NOT NULL CHECK(created_by IN ('salvador','dayanna')),
 created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS aitan_studio.activity (
 id uuid PRIMARY KEY, company_id uuid REFERENCES aitan_studio.companies(id),
 actor text NOT NULL CHECK(actor IN ('salvador','dayanna')), action text NOT NULL,
 revision integer, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS aitan_activity_company_time ON aitan_studio.activity(company_id,created_at DESC);
`
