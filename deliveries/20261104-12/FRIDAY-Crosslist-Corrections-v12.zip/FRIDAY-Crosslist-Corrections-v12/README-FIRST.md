# FRIDAY Crosslist Reviewed Corrections v12 — 20261104-12

Install over Crosslist Inspector v11 on Salvador/Dayanna's PC at S:\AI\friday-ai. Uses the actual app.crosslist.com/product/[UUID] editor, based on the owner-provided DOM inspections. Those inspections established separate Save/Post controls, Vinted marketplace checkbox, brand combobox, condition, color/color2, Next navigation, New without tags and the color palette including Navy. They did not prove live save behavior. Test one item first.

## Correction workflow

1. Existing private owner key and manual SALDANA SHOP workspace confirmation remain required. Open Crosslist in the dedicated FRIDAY Chrome tab, sign in yourself if needed and open one actual listing.
2. Manually select Vinted on the left to expose its color fields. FRIDAY preserves the current marketplace selection; it does not select additional posting destinations in the active editor.
3. Click Read current listing. Brand suggestions come from this item's DESCRIPTION, not the store/vendor name or a catalog-wide Vans default. Common known brands are suggested only when unambiguous. Negated/style-only/competing-brand evidence is rejected. An unfamiliar brand can be entered for review when the actual name occurs in the description; vague/ambiguous descriptions require manual review. Description evidence is shown in the before/after review.
4. View item photo. Only the current product photo is captured, not the full account page. In a connected voice session, the photo can be attached to FRIDAY for color analysis; owner already requested product-photo analysis. No photo goes to GitHub. UI users can review the displayed photo themselves. Colors are per item. The example Vans pair suggests Navy + White; it is not a default for other products.
5. Confirm the brand and primary/secondary colors, then Add/update this item in queue. Condition is New without tags, as the owner instructed. A secondary color may be blank only if already unset; clearing an existing native color requires its actual clear control to be verified and is not guessed. A voice-generated color proposal requires that item's actual photo to have been viewed in this browser snapshot.
6. For another item, use Next saved listing. It refuses to discard unsaved form edits. The main listing is not edited while building the queue. Up to 25 individually captured items may be queued. This is a bounded reviewed batch, not an unexamined whole-catalog operation. Duplicate item IDs update the existing queue entry.
7. Review and save queue shows exact before/after, per-description brand evidence, unchanged price and quantity. Approve once by click or live “Yes” to the specific save question / “Approve it”. Cancel dismisses that particular unsubmitted batch and retains queue notes. All items receive the same explicit New without tags instruction, but each brand/color choice remains separate.

## Save, verification and stop behavior

The backend rechecks exact owner session, actual product ID, captured form state and fresh saved source. It protects prices, size-related controls, quantities, leading-zero SKU, description, category, marketplace checkbox selections and photo references/order. Each dropdown is selected by its observed exact option label, not a captured generated option ID. The current item must expose the expected uniquely recognized controls. An already-open dropdown is handled. Missing/ambiguous fields/options stop the batch; no broad guessed selector fallback.

Only Brand, Condition, Primary color and Secondary color are changed. The workflow clicks the unique Save button, never Post, Bulk post, Delist or Delete. It checks fresh pages for persisted values and unchanged protected values before reporting saved. Verification pages reproduce the same marketplace checkbox view so Vinted-specific colors can be read; they are never saved or posted. A Save returning to the Crosslist dashboard is supported for the next queued item.

Private durable receipts/one-time revision claims are under credentials\commerce\crosslist\[owner]. Submitted or uncertain revisions are never automatically resubmitted. Any unexpected change, dropdown failure, validation problem or unverified persistence stops the remaining queue and reports that item's status. A partial dropdown edit can remain unsaved in the active form; inspect it. Do not clear claim files to retry. Use Check batch receipt or Recent batch receipts, including after a server restart.

Stop remaining saves works while the HTTP save operation runs. Live “stop/cancel” also requests stopping an active batch when no other owner review takes precedence. A Save already submitted may complete and be verified, then remaining items stop. Stop does not undo a completed save. Profile lock requests a stop and clears private UI state. Cancel/stop is not conditioned on another approval question.

## Boundaries

Current native Crosslist Save validation, account permissions and possible propagation to connected marketplace records still need a one-item live test. A distinct Post button does not prove all downstream save effects. FRIDAY does not call Shopify mutation APIs, change QuickBooks, upload/change photos, publish listings, bypass website challenges or synchronize inventory/orders in this update. It does not change category/size/shipping information to satisfy missing required fields. If Save is blocked by validation, inspect the actual error and complete those details yourself or provide the error for a later compatible change.

Fresh-page browser checks are optimistic; FRIDAY cannot lock Crosslist against simultaneous edits from other users or sessions. Do not edit the same queued items elsewhere during an approved batch. Do not treat “saved in Crosslist” as proof of marketplace publication, sales or stock synchronization. Unknown/uncertain colors and brand descriptions require human review; never invent item facts.

## Install from any PowerShell directory

Stop FRIDAY's backend and Vite process. Extract the ZIP under S:\AI\Fixing-Files-Folder\FRIDAY-Crosslist-Corrections-v12. Run:

```powershell
$packageRoot = 'S:\AI\Fixing-Files-Folder\FRIDAY-Crosslist-Corrections-v12'
$installers = @(Get-ChildItem -LiteralPath $packageRoot -Filter 'Install-Crosslist-Corrections.ps1' -File -Recurse -ErrorAction Stop)
if ($installers.Count -ne 1) { throw 'Expected exactly one installer. Check the extracted folder.' }
$installer = $installers[0].FullName
Unblock-File -LiteralPath $installer
Unblock-File -LiteralPath (Join-Path (Split-Path $installer) 'Restore-Crosslist-Corrections.ps1')
& $installer -ProjectPath 'S:\AI\friday-ai'
if (-not $?) { throw 'Installation failed. Do not continue.' }
Set-Location -LiteralPath 'S:\AI\friday-ai'
npm run build
if ($LASTEXITCODE -ne 0) { throw 'Build failed. Do not continue.' }
npm run server
```

In another terminal:

```powershell
Set-Location -LiteralPath 'S:\AI\friday-ai'
npm run dev
```

Ctrl+F5 at https://localhost:5173/ and reconnect voice. Open Crosslist dashboard setup. No dependency install, DB migration, OAuth reset, credential copying or TLS changes. Installer validates package/baseline/required hashes and backs up the seven listed app/test files before copying. It refuses incompatible installed source and preserves private data/configuration/Chrome profile/AGENTS.md. PowerShell reviewed but not executed in this Linux cloud; enforced signed-script policy is not overridden.

## First owner-PC test

- Start with ONE item. Verify owner and workspace, open its Crosslist editor and select Vinted. Save/discard unrelated existing unsaved edits yourself first; do not let a test discard them.
- Read current listing, View item photo, confirm the description-based brand. For the supplied Vans pair, use Vans / New without tags / Navy / White. Queue it and review the exact change. Approve once.
- Verify Crosslist's stored fields and the linked Shopify/marketplace records yourself to establish actual Save propagation. Price, size, quantity, photos and other values should remain unchanged. A successful cloud fixture is not proof of live account behavior.
- If a control/required field/save result is uncertain, use receipt and inspect the active browser. Send the exact result; do not repeatedly approve/resubmit. The existing read-only inspector remains available.
- After the single-item live behavior is confirmed, queue a small batch with each actual description/photo reviewed and test Stop. A voice workflow can capture → photo → propose that item's brand/colors → queue → Next saved listing → repeat → preview, then one owner decision for that specific batch.

## Restore

Stop FRIDAY. Run Restore-Crosslist-Corrections.ps1 from the printed backups\crosslist-corrections-v12-[timestamp] directory. Rebuild/restart both processes, hard-refresh and reconnect voice. Hash checks refuse later source edits. Private receipt/claim data remains. Code rollback does not undo saved Crosslist changes or a manually published listing. Existing AGENTS.md is not overwritten; the merge proposal is separate.
