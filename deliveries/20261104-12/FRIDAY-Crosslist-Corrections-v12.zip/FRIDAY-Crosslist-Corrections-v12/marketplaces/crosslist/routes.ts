import {createCrosslistEditor} from './editor'
import {CrosslistError} from './core'
export {CrosslistError} from './core'
import {randomUUID} from 'node:crypto'
import {authenticateSandraOwner} from '../../quickbooks/sandra-learning-core'
const ORIGIN='https://app.crosslist.com',DASHBOARD=ORIGIN+'/?tab=all'
// Inspection remains read-only. Explicit reviewed corrections live in editor.ts with owner-scoped receipts.
export function registerCrosslistInspectionRoutes(app:any,deps:{getBrowser?:()=>Promise<any>}={}){
 const tabs=new Map<string,any>(),running=new Set<string>()
 const editor=createCrosslistEditor(owner=>tabs.get(owner))
 const endpoint=(fn:any,parallel=false)=>async(req:any,res:any)=>{res.set('Cache-Control','no-store');let owner:string|undefined,acquired=false;try{owner=authenticateSandraOwner(req);if(!parallel&&running.has(owner))throw new CrosslistError('A Crosslist inspection is already running. Wait for it to finish.',409);if(!parallel){running.add(owner);acquired=true;}await fn(req,res,owner)}catch(e:any){const auth=/^OWNER_/.test(e.message);res.status(auth?401:e instanceof CrosslistError?e.status:500).json({success:false,error:auth?'Verify your existing Salvador or Dayanna owner key privately.':e instanceof CrosslistError?e.message:'Crosslist inspection could not complete. Inspect the listing and receipt before continuing; no automatic retry.'})}finally{if(owner&&acquired)running.delete(owner)}}
 app.get('/shopify/crosslist/status',endpoint(async(_req:any,res:any,owner:string)=>res.json({success:true,owner,readOnly:true,companyKey:'saldana-corp',url:DASHBOARD,editingEnabled:true})))
 app.post('/shopify/crosslist/open',endpoint(async(_req:any,res:any,owner:string)=>{if(!deps.getBrowser)throw new CrosslistError('FRIDAY browser connector is unavailable. Restart the updated backend.',503);let tab=tabs.get(owner);if(!tab||tab.page.isClosed()){const context=await deps.getBrowser();tab={page:await context.newPage(),id:randomUUID()};tabs.set(owner,tab)}await tab.page.goto(DASHBOARD,{waitUntil:'domcontentloaded',timeout:30000});await tab.page.bringToFront();res.json({success:true,sessionId:tab.id,url:DASHBOARD,readOnly:true,message:'Crosslist dashboard opened in a dedicated FRIDAY Chrome tab. Sign in yourself, verify your SALDANA SHOP workspace and choose a listing. Do not sign in to Vinted for this inspection.'})}))
 app.post('/shopify/crosslist/inspect',endpoint(async(req:any,res:any,owner:string)=>{
  if(req.body.verifiedWorkspace!=='saldana-corp')throw new CrosslistError('First check the signed-in Crosslist workspace contains your SALDANA SHOP inventory, then confirm it in FRIDAY.')
  const tab=tabs.get(owner);if(!tab||tab.page.isClosed())throw new CrosslistError('Open the dedicated Crosslist tab first.',409)
  const before=tab.page.url(),url=new URL(before);if(url.origin!==ORIGIN||url.username||url.password)throw new CrosslistError('The dedicated tab is outside app.crosslist.com. No page contents were inspected.',409)
  const result=await tab.page.evaluate(String.raw`(()=>{
   const visible=(e)=>{const r=e.getBoundingClientRect(),s=getComputedStyle(e);return r.width>0&&r.height>0&&s.visibility!=='hidden'&&s.display!=='none'},clean=(v,max=200)=>String(v||'').replace(/\s+/g,' ').trim().slice(0,max)
   if(Array.from(document.querySelectorAll('input[type=password]')).some(visible))return{loginRequired:true,message:'Sign in yourself in Chrome. Login fields were not inspected.'}
   const sensitive=/password|passcode|secret|token|cookie|authorization|email|login|credential|credit.card|payment|billing/i
   const labelOf=(e)=>{const associated=Array.from(e.labels||[]).map((l)=>clean(l.textContent)).join(' '),aria=clean(e.getAttribute('aria-label'));let labelled='';for(const id of (e.getAttribute('aria-labelledby')||'').split(/\s+/)){const label=document.getElementById(id);if(label)labelled+=' '+clean(label.textContent)}return clean(associated||aria||labelled||e.getAttribute('placeholder')||(e.tagName==='BUTTON'?e.textContent:''))}
   const controls=Array.from(document.querySelectorAll('input,select,textarea,button,[role="combobox"]')).filter(visible).map((e)=>{const label=labelOf(e),type=clean(e.type||''),name=clean(e.name||''),id=clean(e.id||''),testId=clean(e.getAttribute('data-testid')||'');if(['password','email','hidden'].includes(type)||sensitive.test([label,name,id,testId].join(' ')))return null;const field=/^(?:brand|condition|primary colou?r|secondary colou?r|title|quantity|size|price)(?:\s*[:*])?$/i.test(label);return{tag:e.tagName.toLowerCase(),type,name,id,testId,role:e.getAttribute('role')||'',label,disabled:!!e.disabled,...(field?{value:clean(e.value||e.getAttribute('aria-valuetext')||'',500)}:{}),...(e.tagName==='SELECT'&&field?{options:Array.from(e.options).map((o)=>({text:clean(o.textContent),value:clean(o.value),disabled:!!o.disabled})).slice(0,150)}:{})}}).filter(Boolean).slice(0,150)
   const options=Array.from(document.querySelectorAll('[role="option"]')).filter(visible).map((e)=>({text:clean(e.textContent),selected:e.getAttribute('aria-selected')==='true',id:clean(e.id),testId:clean(e.getAttribute('data-testid'))})).filter(o=>o.text&&!sensitive.test(o.text)).slice(0,100)
   const labels=Array.from(document.querySelectorAll('label')).filter(visible).map((e)=>({text:clean(e.textContent),for:clean(e.getAttribute('for'))})).filter(l=>l.text&&!sensitive.test(l.text)).slice(0,100)
   const headings=Array.from(document.querySelectorAll('h1,h2,h3')).filter(visible).map((e)=>clean(e.textContent)).filter(t=>t&&!sensitive.test(t)).slice(0,25)
   const links=Array.from(document.querySelectorAll('a[href]')).filter(visible).map((e)=>{try{const u=new URL(e.getAttribute('href'),location.href),text=clean(e.textContent);return u.origin===location.origin&&text&&!sensitive.test(text+' '+u.pathname)?{text,path:u.pathname}:null}catch{return null}}).filter(Boolean).slice(0,100)
   const photos=Array.from(document.querySelectorAll('main img,[role="dialog"] img')).filter(visible).map((e)=>{try{const u=new URL(e.currentSrc||e.src);if(u.protocol!=='https:')return null;return{alt:clean(e.alt),width:e.naturalWidth,height:e.naturalHeight}}catch{return null}}).filter(Boolean).slice(0,30)
   return{loginRequired:false,headings,labels,controls,visibleOptions:options,links,photoCount:photos.length,photos,message:'Observed visible controls only. Dropdowns were not opened automatically; open the target dropdown manually and inspect again to capture visible option labels. No listing was saved.'}
  })()`)
  if(tab.page.url()!==before)throw new CrosslistError('Crosslist navigated during inspection. Inspect the settled page again.',409)
  const safeURL=ORIGIN+url.pathname+(url.searchParams.get('tab')==='all'?'?tab=all':'')
  res.json({success:true,readOnly:true,sessionId:tab.id,url:safeURL,companyKey:'saldana-corp',workspaceVerification:'manually confirmed by owner; not automatic account verification',correctionPlan:{scope:'individually captured listings only',brand:'Determine per item from its description; never default all items to Vans or store name',condition:'New without tags',color:'Assess each product photo; current navy/white suggestion applies only to the shown item'},...result})
 }))
 const confirmed=(req:any)=>{if(req.body.verifiedWorkspace!=='saldana-corp')throw new CrosslistError('Confirm the signed-in SALDANA SHOP workspace first.')}
 app.get('/shopify/crosslist/batches',endpoint(async(_req:any,res:any,owner:string)=>res.json(await editor.history(owner)),true))
 app.post('/shopify/crosslist/current',endpoint(async(req:any,res:any,owner:string)=>{confirmed(req);res.json(await editor.capture(owner))}))
 app.post('/shopify/crosslist/photo',endpoint(async(req:any,res:any,owner:string)=>{confirmed(req);res.json(await editor.photo(owner))}))
 app.post('/shopify/crosslist/next',endpoint(async(req:any,res:any,owner:string)=>{confirmed(req);res.json(await editor.next(owner))}))
 app.post('/shopify/crosslist/batch/preview',endpoint(async(req:any,res:any,owner:string)=>{confirmed(req);res.json(await editor.preview(owner,req.body))}))
 app.post('/shopify/crosslist/batch/:id/apply',endpoint(async(req:any,res:any,owner:string)=>{confirmed(req);res.json(await editor.apply(owner,req.params.id,req.body.approved===true))}))
 app.post('/shopify/crosslist/batch/:id/stop',endpoint(async(req:any,res:any,owner:string)=>res.json(await editor.stop(owner,req.params.id)),true))
 app.get('/shopify/crosslist/batch/:id/receipt',endpoint(async(req:any,res:any,owner:string)=>res.json(await editor.receipt(owner,req.params.id)),true))

}
