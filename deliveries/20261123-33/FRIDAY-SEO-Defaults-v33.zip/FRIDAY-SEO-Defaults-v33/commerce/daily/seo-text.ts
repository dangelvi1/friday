// Plain SEO metadata is not HTML. Decode one layer of common, semicolon-ended
// entities only while preparing a proposal; do not alter saved Shopify values.
export function seoPlainText(text:string) {
  const named:Record<string,string>={amp:'&',quot:'"',apos:"'",lt:'<',gt:'>',nbsp:' '}
  return text.replace(/&(?:amp|quot|apos|lt|gt|nbsp|#\d{1,7}|#[xX][a-fA-F0-9]{1,6});/g,entity=>{
    const key=entity.slice(1,-1)
    if(key[0]!=='#')return named[key]??entity
    const hex=/^#[xX]/.test(key),point=Number.parseInt(key.slice(hex?2:1),hex?16:10)
    if(point<32||point>0x10ffff||point>=0xd800&&point<=0xdfff)return entity
    return String.fromCodePoint(point)
  })
}
