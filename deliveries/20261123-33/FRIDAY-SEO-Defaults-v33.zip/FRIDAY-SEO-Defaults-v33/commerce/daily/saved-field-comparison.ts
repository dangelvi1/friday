import {digest} from './core'

// Shopify decodes apostrophe entities in generated paragraph text. Recognize
// only that representation change. No fuzzy text, whitespace, markup, attribute,
// tag ordering, or pre-write concurrency comparison is relaxed.
function paragraphText(value: string): string | null {
  const parts = value.split(/(<[^>]*>)/)
  for (let i = 1; i < parts.length; i += 2) {
    // Generated proposals use plain paragraphs. Unrecognized HTML stays exact.
    if (!/^<\/?p>$/.test(parts[i])) return null
  }
  return JSON.stringify(parts.map((part, index) => index % 2 ? part :
    part.replace(/&(?:apos|#0*39|#[xX]0*27);/g, "'")))
}

export function savedFieldComparison(field: string, current: unknown, approved: unknown, productTitle?: string) {
  const exact = digest(current ?? null) === digest(approved ?? null)
  let normalized = false
  if (!exact && field === 'descriptionHtml' && typeof current === 'string' && typeof approved === 'string') {
    const a = paragraphText(current), b = paragraphText(approved)
    normalized = a !== null && b !== null && a === b
  }
  const defaultTitle = !exact && field === 'seoTitle' && current === null && typeof productTitle === 'string' && productTitle.length > 0 && approved === productTitle
  return {field, current, approved, ...(defaultTitle ? {effectiveCurrent:productTitle} : {}), matchesApproved: exact || normalized || defaultTitle,
    comparisonBasis: defaultTitle ? 'shopify_default_product_title' : normalized ? 'paragraph_text_apostrophe_entity' : 'exact'}
}

export function savedFieldMatches(field: string, current: unknown, approved: unknown, productTitle?: string) {
  return savedFieldComparison(field, current, approved, productTitle).matchesApproved
}
