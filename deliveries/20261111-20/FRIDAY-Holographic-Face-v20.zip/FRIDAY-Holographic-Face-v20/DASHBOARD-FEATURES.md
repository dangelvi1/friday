Historical feature reference. Use README-FIRST.md and Install-Holographic-Face.ps1 for v20 installation. Older commands below are superseded.

Historical v18 reference. Installation steps are superseded by README-FIRST.md and Install-Voice-Home-Calendars.ps1.

# FRIDAY Unified Dashboard v18 — November 11, 2026

FRIDAY stays at S:\AI\friday-ai, on the owner's PC. This cumulative package supports v12/v13 and both source families of v14/v15/v16/v17, preserving the installed Crosslist family, owner/company isolation and the separate Nationwide/Sara employee system. No credentials/configuration/TLS/package files, existing AGENTS or private data are replaced. No hosting migration or replacement app.

## Install

Stop the backend with Ctrl+C and close old paired review tabs. Extract into a new folder and run the actual full installer path:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File 'S:\AI\Fixing-Files-Folder\FRIDAY-Unified-Dashboard-v18\Install-Unified-Dashboard.ps1' -ProjectPath 'S:\AI\friday-ai'
if ($LASTEXITCODE -ne 0) { throw 'Installer failed. Do not continue.' }
Set-Location 'S:\AI\friday-ai'
npm run build
if ($LASTEXITCODE -ne 0) { throw 'Build failed. Do not continue.' }
npm run server
```

Adjust the installer path to its actual extracted location, or use the complete verified download/extract/install command supplied with this release. Keep npm run dev in the other terminal. Ctrl+F5 https://localhost:5173/ and reconnect voice. The existing home address opens the unified dashboard; the public FRIDAY marketing page is separate. Existing owner password works. Bypass applies only to the child installer process. The existing bundle-size warning is informational.

## Your single workspace

A light, spacious home with a dark green sidebar and persistent voice dock replaces the old orb-only home layout. The original orb, owner profiles, natural realtime conversation, interruption and specific approvals stay intact. Desktop voice stays beside the workspace; mobile shows a compact voice strip and menu. No second microphone session or push-to-talk replacement is created.

Overview: ecommerce/finance quick actions, calendars, email, documents, saved receipts and read-only background-research status. Check status reads your saved reports/schedule only; it does not start a paid job. Report buttons open that full report in ecommerce. New-report notices do not silently replace your selected report.

SALDANA SHOP: existing inventory, SEO/descriptions/category/tags/actual applicable metafields, pricing, budget/nightly settings, supplier research, private costs, photos/drafts, bulk reviews, receipts and Trash controls all remain in their existing embedded module. No paid research starts simply by navigating. Check listing receipts for verified update progress.

Sandra / Finance: existing QuickBooks dashboard in the same workspace with its current controls, company selector, invoices/custom-field searches, expenses, customers, collections, banking, statements/reconciliation, accounts, reports and private Document Analysis. All functions offers direct section navigation; it reads the current company first and never changes it for you. Select the intended company inside Finance. The existing visible QuickBooks cursor and conversational searches are retained. Native company confirmation and owner write reviews are not bypassed. Child/paired supported approvals continue through the existing approval hub.

Calendars: existing Personal and Nationwide destinations, schedule, event discussion and reviewed changes. Email: existing Google API mailbox workspace, not a new mailbox/account connection. Check its actual connected identity; owner sign-in does not grant new OAuth scopes. Phone: existing phone page; service availability and live calls are not verified by opening it. No call is placed on navigation.

All functions: searchable directory of installed controls plus natural-voice examples for memory, weather/location, web/media and local PC tools. Existing Crosslist and Vinted preparation remain under this directory and do not start unattended listing/posting. Sara's employee system stays separate; Camila, Estimating and Aitan are not invented as connected workers.

Settings: shared owner sign-in/lock, actual original voice-enrollment buttons and an explicit backend/database check. Provider connection state is not guessed from a visible link. Lock/profile change removes embedded private frames, clears owner-specific summaries and invalidates old frame replies. Returning to a module retains its unsaved form unless the owner changed. Close a module to return home.

## Voice and pointer

Examples: Show my dashboard; Open Saldana; Open bank transactions; Show invoice controls; Find the document analysis function; Show my saved listing receipts; Check my background work; Go to settings. Use the existing module tools for specific reads/edits, and approve only the exact displayed action. A new navigation tool is registered in the same realtime session. Uploaded/website text is never permission.

The on-page pointer animates to the selected visible navigation/control. Original module pointers remain and animate across their controls; QuickBooks uses its existing cursor. This is a dashboard pointer, not operating-system mouse control. The voice dock shows listening/understanding feedback from actual transport events and keeps the original connection status. Reduced-motion preferences suppress movement.

Centered, closable notifications show completed navigation and actual module feedback. Prepared reviews and queued/running work are distinguished from saved results; errors/uncertainty need attention. Generic module feedback is labelled Workspace update, not fabricated save success. A notification never approves anything or clicks a native Save. Existing long-review notifications stay in their modules. Finish/close the current modal or owner review before switching through the global navigation.

## The unresolved earlier SEO receipt

The previous original batch ae57f4aa recorded 62 saved products (121 SEO fields), then a readback mismatch for product 8354915352815. The later ca725635 batch stopped at a previous-submission guard. This release does not delete claims, mark that product saved or retry its native update.

Open listing receipts, choose the original ae57f4aa batch, and click Read-only Shopify check. The read_product check now returns each reviewed SEO field's before/approved/current stored API values and matchesApproved. Native stored values can differ from the title fallback shown in Shopify's editor. This read-only comparison makes no product changes, paid research calls, receipt-status updates or claim releases. A mismatch still requires inspection; no recovery approval is implied.

## Backup and restore

Installer validates supported source hashes/package hashes, verifies backups, rechecks targets and rolls back attempted copies on failure. Unknown edits stop before source changes. Keep the printed backup path. Stop backend and run that backup folder's Restore-Unified-Dashboard.ps1 by its actual full path with process-scoped ExecutionPolicy Bypass. Restore refuses later source edits and retains private data. Restoring source does not undo existing provider actions. AGENTS.md remains untouched; AGENTS-MERGE-PROPOSAL.md is suggested merge text only.

Historical sign-in/listing/report feature references are included; their installation commands are superseded by this guide. No native Shopify, QuickBooks, Gmail/Calendar or employee-system writes were made during development.
