# FRIDAY Holographic Face v20 — November 11, 2026

FRIDAY remains on your PC at S:\AI\friday-ai. This cumulative package supports v12/v13 and both source families of v14/v15/v16/v17/v18/v19. It preserves the installed Crosslist family, owner/company isolation, the separated Nationwide/Sara employee system and all earlier dashboard/calendar/receipt behavior. No existing AGENTS, private data, credentials, OAuth/TLS/Vite configuration or package files are replaced. No extra avatar provider account or service is required.

## Install

Stop backend with Ctrl+C and close old paired review tabs. Extract into a new folder and run the actual full installer path:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File 'S:\AI\Fixing-Files-Folder\FRIDAY-Holographic-Face-v20\Install-Holographic-Face.ps1' -ProjectPath 'S:\AI\friday-ai'
if ($LASTEXITCODE -ne 0) { throw 'Installer failed. Do not continue.' }
Set-Location 'S:\AI\friday-ai'
npm run build
if ($LASTEXITCODE -ne 0) { throw 'Build failed. Do not continue.' }
npm run server
```

Adjust the installer path to its extracted location, or use the complete verified download/extract/install command supplied with the release. Keep npm run dev in the other terminal. Ctrl+F5 FRIDAY and reconnect voice. ExecutionPolicy Bypass affects only the child installer process. Existing owner password works. The existing bundle warning is informational.

## The face is now a holographic mesh

The voice welcome uses a locally rendered, human-shaped 3D face mesh with cyan points/wireframe, moving eyelids/eyes, eyebrow/lip expression morphs, gentle head movement and a restrained holographic HUD. Amber hologram and the earlier digital portrait remain choices. This is a generic face, not a model of Salvador, Dayanna or another photographed person, and it does not access a camera or detect your emotions.

Its reply mouth/jaw movement follows actual assistant-output audio intensity with fast attack/release and silence gating. Listening, thinking and speaking states follow the existing realtime events; smiles/concern reflect interface feedback. The mouth closes on silence, stopped/paused output, interruption, owner lock or disconnect. This is audio-reactive mouth movement, not phoneme/word-perfect lip synchronization or a rendered full-body person.

No second realtime session, microphone permission, camera, avatar subscription or extra inference call is added. Normal FRIDAY conversation still uses your existing provider/runtime and normal costs. The original connect/disconnect button remains underneath the face, with the same owner sign-in, microphone and approval workflow.

## Test without connecting first

1. Open the voice home at https://localhost:5173/.
2. Leave the voice disconnected and click Silent expression preview.
3. Watch listening/thinking/speaking/closing mouth/blinking and a smile for about seven seconds. It is clearly labelled silent preview and starts no microphone, connection or provider request.
4. Try Face style: Blue hologram, Amber hologram or Digital portrait. Pause/Resume face animation is independent of voice playback. OS reduced-motion preferences keep the face still; change that device preference if you want motion.
5. Then click the face to connect the existing natural conversation. Ask a short question and watch its actual reply. Interrupt it normally; the face should stop speaking with that interruption.

If audio plays but this browser blocks the analysis context, use the displayed Enable speech animation button. This resumes the local analyser without connecting another microphone or altering playback. If unsupported, the voice still works and the face reports the limitation. Portrait and paused/static modes remain available.

While viewing the dashboard, appearance controls move to Settings → FRIDAY face & expressions. The original voice control/canvas moves between / and /dashboard without replacing the session or starting another stream. A visible control remains the original connection button; the animated pointer and centered notifications do not authorize actions.

Natural voice examples: Use the amber hologram; Use the blue hologram; Show your digital portrait; Pause your face animation; Resume your face animation. The new friday_avatar_control changes only cosmetic local appearance/motion or requests a disconnected silent preview. It cannot change business records, approve actions or bypass a calendar/invoice review.

## Local audio and resource handling

The renderer reads the existing assistant reply audio element supplied to the same realtime WebRTC transport. A small transient time-domain buffer is analysed in this browser only. Samples are not recorded, persisted or transmitted. The analyser is not connected to the speakers and never changes volume/playback or stops caller-owned tracks. The original SDK remains responsible for playing the response.

Portrait/pause/reduced-motion/background states disable analysis and animation. Owner changes, disconnect and page cleanup clear transient state; stale owner microphone access is checked before attaching the reply stream. Only cosmetic style/motion preferences are stored in browser local storage, without credentials or transcripts. A live voice connection must be disconnected before a silent preview; preview never interrupts it automatically.

Rendering uses Canvas/Web Audio without new npm dependencies or a camera detector. The generic canonical face geometry is adapted from Google MediaPipe under Apache License 2.0. Its source, modifications and complete license are included in public/licenses. No MediaPipe detector/runtime or learned face-recognition model is installed.

## Addresses and preserved controls

Hosting PC:
- Voice home: https://localhost:5173/
- Dashboard: https://localhost:5173/dashboard

Existing owner-confirmed Cloudflare hostname:
- Voice home: https://friday.dangelvi.com/
- Dashboard: https://friday.dangelvi.com/dashboard

Other devices must use the server's configured HTTPS address and their own owner sign-in/microphone permission. localhost means the device you are holding. The exact Cloudflare HTTPS origin remains explicitly accepted by the existing owner guard; no tunnel/DNS/Access/TLS change or verified public reachability is claimed. Physical microphone, actual model-output timing and phone/browser behavior require testing on the owner devices.

Both saved calendar cards, private document reviews, bulk listing suggestions/receipts, report Trash, the corrected unresolved-first Shopify diagnostic and company-scoped Finance navigation remain. No uncertain Shopify write is retried or claim removed. No calendar/accounting record, ad, order, purchase or employee data is changed by this release. Existing scheduled work still follows your saved settings.

## Backup and restore

Installer verifies supported source/package hashes, verifies backups, rechecks targets and rolls back attempted copies on failure. Unknown edits stop before source changes. Keep the printed backup path. Stop backend and run that backup folder's Restore-Holographic-Face.ps1 by its full path with process-scoped ExecutionPolicy Bypass. Restore refuses later source edits and preserves private runtime data. Restoring source does not undo provider actions. AGENTS.md remains untouched; AGENTS-MERGE-PROPOSAL.md is proposed merge text only.

Historical feature guides are included; their installation commands are superseded by this README and Install-Holographic-Face.ps1.
