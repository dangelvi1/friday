Historical v19 feature reference. Use README-FIRST.md and Install-Holographic-Face.ps1 for v20 installation.

# FRIDAY Voice Home & Calendars v19 — November 11, 2026

FRIDAY stays hosted on the owner's PC at S:\AI\friday-ai. This cumulative package supports v12/v13 and both source families of v14/v15/v16/v17/v18, preserving the installed Crosslist family, company/owner scope and the separate Nationwide/Sara employee system. No existing AGENTS, credentials, private runtime data, OAuth configuration, TLS/Vite configuration or package files are replaced. No hosting/tunnel migration.

## Install

Stop backend with Ctrl+C and close old paired review tabs. Extract into a new folder and run the actual full path:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File 'S:\AI\Fixing-Files-Folder\FRIDAY-Voice-Home-Calendars-v19\Install-Voice-Home-Calendars.ps1' -ProjectPath 'S:\AI\friday-ai'
if ($LASTEXITCODE -ne 0) { throw 'Installer failed. Do not continue.' }
Set-Location 'S:\AI\friday-ai'
npm run build
if ($LASTEXITCODE -ne 0) { throw 'Build failed. Do not continue.' }
npm run server
```

Adjust the installer path to its real extracted location, or use the complete verified download/extract/install command supplied with this release. Keep npm run dev in the other terminal. Ctrl+F5 and reconnect voice. Existing owner password works. ExecutionPolicy Bypass is confined to the child installer process. The existing bundle-size warning is informational.

## Two addresses, one assistant

On the hosting PC:
- Voice welcome: https://localhost:5173/
- Full dashboard: https://localhost:5173/dashboard

Through your existing Cloudflare hostname, confirmed by Salvador:
- Voice welcome: https://friday.dangelvi.com/
- Dashboard: https://friday.dangelvi.com/dashboard

The root now shows a generated digital woman's portrait in a calm private welcome screen. Click the portrait to connect/disconnect the original voice session. Listening/thinking/speaking halo states follow actual application/transport feedback and respect reduced-motion preferences. This is a still digital portrait with UI animation, not live facial tracking or mouth/lip synchronization. No new biometric identification or second microphone session is introduced.

Open dashboard / Voice home switches the app route in place, keeping the same original voice control, realtime connection, profile and module state. A separate direct visit to /dashboard opens the dashboard immediately. A new tab/device has its own browser session and microphone permissions; sign in there as the correct owner. Leaving a pending modal/owner review through app links or history is guarded. The portrait remains compact in the dashboard voice dock.

The interface adapts to desktop and mobile. localhost refers to the device you are holding, so use the Cloudflare hostname on a phone or another computer. The welcome footer includes the confirmed remote links and device guidance. This release adds exactly https://friday.dangelvi.com to owner sign-in's trusted origins, retaining strict origin-bound secure HttpOnly sessions, password checks, company scoping and rejection of HTTP/lookalike/unrelated domains. Existing explicitly configured origins remain. No wildcard Cloudflare origin or public credential is added.

Cloudflare DNS, tunnel/service routing, Access policies, TLS and actual external reachability remain your existing infrastructure. The cloud tool environment could not reach that hostname (outbound tunnel/proxy returned 403), so no remote success is claimed. The hostname must continue to serve the FRIDAY frontend with /dashboard reaching its normal frontend history fallback. If it shows a separate public marketing page, check the existing Cloudflare service target. Installing these files does not change Cloudflare. Existing frontend/API proxies and Google OAuth callbacks are preserved.

## Both main calendars at the top

Calendars now opens with two prominent cards: Personal and Nationwide office. Their names and native links come from this signed-in owner's actual saved calendar mappings. No mapping is guessed or replaced. Unknown/unconfigured destinations remain disabled and direct you to the existing connection/destination controls below.

Each card offers View upcoming events in FRIDAY and Open in Google Calendar for that exact saved calendar. Clicking View uses the displayed From/To range; when both are empty it fills the next seven days from now. A partial range is retained with an actionable error. Switching calendars only reads events, retains draft details, selects the destination and highlights the viewed card. Both card identities remain visible together; event schedules stay scoped to the chosen calendar instead of merging private and office data.

Discuss an actual event below, then use the existing modify/cancel workflow or its native Google link. The exact event/calendar/ETag owner controls and voice approval rules remain. Opening a card does not save, delete, cancel or edit events. Pending event reviews must be completed/cancelled before quick-switching. Owner lock clears private names, links and event context.

Voice examples: Open my calendars; Show my Personal calendar; Show my Nationwide calendar; Discuss the second event; Change its time to [time]. The existing google_calendar_control now supports quick_view with personal/nationwide and uses the same visible pointer/session, not a push-to-talk page. Actual write approvals remain in the existing workflow.

## Corrected unresolved-product diagnostics

The original ae57f4aa receipt recorded 62 successful products / 121 SEO fields and then an uncertain product 8354915352815. The prior diagnostic mistakenly selected the first product (8288690602223), so its matchesApproved:true only confirmed an already successful product. That did not resolve the later uncertainty.

Read-only Shopify check now selects the first unresolved result (uncertain, needs_review, rejected, blocked_before_write or conflict) and identifies the selection reason and receipt status. Other unresolved product IDs are listed. A completed receipt without unresolved results explicitly says it checked the first reviewed product. An inconsistent unresolved ID with no approved fields reports an error rather than silently checking an unrelated saved product.

After installing, open listing receipts, choose ae57f4aa, click Read-only Shopify check, then Copy diagnostics. Expect read_product.productId gid://shopify/Product/8354915352815 and selectionReason first_unresolved_product. The returned before/approved/current fields are current stored API values, not Shopify editor fallback titles. Inspect that comparison before any further action. No claims are removed, receipts marked saved, native changes retried or paid product research started by this check. The actual uncertain write remains unresolved until inspected.

## Preserved dashboard and approval behavior

The unified dashboard, natural conversation/interruptions, visible pointers, centered closable status notifications, report search/full refresh/Trash, existing bulk metadata review, pricing/scheduled-special limits and shared owner sign-in remain. Saved module drafts survive ordinary navigation; owner changes clear private state. Existing Vinted/Crosslist preparation remains manual/reviewed and no background publishing starts. Unverified Sara/Camila/Estimating/Aitan services are not presented as newly connected workers. QuickBooks records, ads, purchasing and employee data are not changed by this release.

## Backup and restore

Installer verifies supported baseline/package hashes before copying, verifies backups, rechecks targets and rolls back attempted copies on failure. Unknown edits stop before source changes. Keep the printed backup path. Stop backend, then run that backup folder's Restore-Voice-Home-Calendars.ps1 by its full path with process-scoped ExecutionPolicy Bypass. Restore refuses later source edits, restores prior app/origin-default behavior and preserves private data. Restoring source does not undo provider changes. Existing AGENTS.md is untouched; AGENTS-MERGE-PROPOSAL.md contains proposed merge text only.

Historical feature references are included; their installation commands are superseded by this guide. Live Windows/desktop, phone/physical microphone, real Calendar/OAuth changes, Shopify outcomes and Cloudflare reachability require owner-device testing. Development used provider fixtures for those business actions. The avatar is a generated artwork included as a local public asset.
