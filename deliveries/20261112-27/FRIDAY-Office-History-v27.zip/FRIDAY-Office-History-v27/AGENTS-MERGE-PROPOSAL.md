# Suggested merge only — do not replace AGENTS.md

- Office history/status/check_receipt are read-only voice actions. Use actual owner-bound task IDs from this workflow, not approval registry IDs. Recover missing lookups through owned history, never by redialing or guessing.
- Return the canonical office task ID/status after approval and distinguish prepared, scheduled, submission evidence, uncertainty and delivery. Poll existing tasks; never create another call to obtain a receipt.
- Keep exact owner approval, U.S. phone checks, company/contact scopes, Twilio signature/claim protections, Spanish courtesy and two-repeat limit.
- Persist spoken/typed questions, commands and replies privately. Expire unarchived chat and chat files after seven days; protect archived conversations. Preserve actual timestamps and the migration/unarchive grace period. Keep existing secrets protection, owner separation and failed-save feedback.
- Retention applies to chat records/files. Contacts/preferences, call receipts/claims, invoices, calendars, Sara employee data and other business records keep their existing rules. Source backup/rollback does not restore expired private data.
