param([string]$ProjectPath = 'S:\AI\friday-ai')
$ErrorActionPreference = 'Stop'
$manifest = Get-Content (Join-Path $PSScriptRoot 'office-history-manifest.json') -Raw | ConvertFrom-Json
if (!(Test-Path (Join-Path $ProjectPath 'server.ts'))) { throw "FRIDAY project not found at $ProjectPath" }
# Select a cumulative compatible package without installing discontinued Crosslist features.
$mainTarget = Join-Path $ProjectPath 'src/main.ts'
if (!(Test-Path $mainTarget)) { throw 'Voice entry point missing. No files changed.' }
$mainHash = (Get-FileHash -LiteralPath $mainTarget -Algorithm SHA256).Hash.ToLowerInvariant()
$selected = $manifest.profiles.PSObject.Properties[$mainHash]
if ($null -eq $selected) { throw 'Installed source differs from supported v25/v26. No files changed. Keep current source and obtain a compatible patch.' }
$selectedProfile = $selected.Value
foreach ($entry in $selectedProfile.requiredSHA256.PSObject.Properties) {
  $target = Join-Path $ProjectPath $entry.Name
  if (!(Test-Path $target) -or (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash -ne $entry.Value) { throw "Source family or dependency differs: $($entry.Name). No files changed." }
}
$manifest | Add-Member -NotePropertyName baselineSHA256 -NotePropertyValue $selectedProfile.baselineSHA256
foreach ($entry in $selectedProfile.sourceOverrides.PSObject.Properties) { $manifest.packageSHA256.PSObject.Properties[$entry.Name].Value = $entry.Value.sha256 }
# Preserve exact v25 or v26 config baselines while delivering the explicit import fix.
foreach ($entry in $manifest.compatibleBaselineSHA256.PSObject.Properties) {
  $target = Join-Path $ProjectPath $entry.Name
  if (!(Test-Path $target)) { continue }
  $actual = (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant()
  if ($entry.Value -notcontains $actual) { throw "Unexpected edited compatibility file: $($entry.Name). No files changed." }
  $manifest.baselineSHA256.PSObject.Properties[$entry.Name].Value = $actual
}
# Historical test files may be absent. Existing test edits are still protected by their expected hash.
foreach ($relative in $manifest.optionalExistingTests) { if (!(Test-Path (Join-Path $ProjectPath $relative))) { $manifest.baselineSHA256.PSObject.Properties[$relative].Value = $null } }
function Get-PackageSource([string]$Relative) {
  $override = $selectedProfile.sourceOverrides.PSObject.Properties[$Relative]
  if ($null -ne $override) { return (Join-Path $PSScriptRoot $override.Value.source) }
  return (Join-Path $PSScriptRoot $Relative)
}
# Preconditions only: these unchanged files are never copied.
foreach ($entry in $manifest.requiredSHA256.PSObject.Properties) {
  $target = Join-Path $ProjectPath $entry.Name
  if (!(Test-Path $target) -or (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash -ne $entry.Value) { throw "Compatibility check failed: $($entry.Name). No project files changed. Obtain a patch based on the current installed source." }
}
foreach ($relative in $manifest.files) {
  if ($relative -match '(^[\\/]|\.\.|:)') { throw "Unsafe manifest path: $relative" }
  $source = Get-PackageSource $relative
  $target = Join-Path $ProjectPath $relative
  $packageHash = $manifest.packageSHA256.PSObject.Properties[$relative].Value
  if (!(Test-Path $source) -or (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash -ne $packageHash) { throw "Package validation failed: $relative" }
  $baseline = $manifest.baselineSHA256.PSObject.Properties[$relative].Value
  if ($null -ne $baseline) {
    if (!(Test-Path $target) -or (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash -ne $baseline) { throw "Installed file differs from the verified source selected for this update: $relative. No files changed. Keep this package separate and obtain a compatible update." }
  } elseif (Test-Path $target) { throw "New file already exists: $relative. No files changed." }
}
# Stop only the FRIDAY backend before running this installer; preserve other services.
$backup = Join-Path $ProjectPath ('backups\office-history-v27-' + (Get-Date -Format 'yyyyMMdd-HHmmss-fff'))
New-Item -ItemType Directory -Path $backup -Force | Out-Null
foreach ($relative in $manifest.files) {
  $target = Join-Path $ProjectPath $relative
  if (Test-Path $target) {
    $saved = Join-Path $backup $relative
    New-Item -ItemType Directory -Path (Split-Path $saved) -Force | Out-Null
    Copy-Item -LiteralPath $target -Destination $saved
    $baseline = $manifest.baselineSHA256.PSObject.Properties[$relative].Value
    if ((Get-FileHash -LiteralPath $saved -Algorithm SHA256).Hash -ne $baseline) { throw "Backup verification failed: $relative. No project files changed." }
  }
}
$record = @{projectPath=$ProjectPath; files=$manifest.files; baselineSHA256=$manifest.baselineSHA256; packageSHA256=$manifest.packageSHA256}
$record | ConvertTo-Json -Depth 8 | Set-Content (Join-Path $backup 'restore-manifest.json') -Encoding UTF8
Copy-Item (Join-Path $PSScriptRoot 'Restore-Office-History.ps1') (Join-Path $backup 'Restore-Office-History.ps1')
try {
  # Recheck targets after backup to avoid overwriting an edit made during staging.
  foreach ($relative in $manifest.files) {
    $target = Join-Path $ProjectPath $relative
    $baseline = $manifest.baselineSHA256.PSObject.Properties[$relative].Value
    if ($null -ne $baseline) {
      if ((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash -ne $baseline) { throw "Target changed after backup: $relative" }
    } elseif (Test-Path $target) { throw "Target appeared after backup: $relative" }
  }
  $copied = @()
  foreach ($relative in $manifest.files) {
    $target = Join-Path $ProjectPath $relative
    New-Item -ItemType Directory -Path (Split-Path $target) -Force | Out-Null
    $copied += $relative
    Copy-Item -LiteralPath (Get-PackageSource $relative) -Destination $target -Force
    if ((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash -ne $manifest.packageSHA256.PSObject.Properties[$relative].Value) { throw "Installed file verification failed: $relative" }
  }
} catch {
  # Roll back only files this installation attempted to copy.
  foreach ($relative in $copied) {
    $saved = Join-Path $backup $relative; $target = Join-Path $ProjectPath $relative
    if (Test-Path $saved) { Copy-Item -LiteralPath $saved -Destination $target -Force }
    elseif (Test-Path $target) { Remove-Item -LiteralPath $target }
  }
  throw
}
Write-Host 'FRIDAY Office & History v27 installed. No new call, email or business change was submitted by installation.'
Write-Host "Verified source backup: $backup"
Write-Host 'Build, restart both servers and hard-refresh. Inspect the existing office task in history before any new call request.'
Write-Host 'Unarchived chat expires after seven days. Existing chats receive a seven-day grace period when the new schema first initializes. Archive conversations to keep them.'
Write-Host 'The source backup does not restore expired chat data. Existing approved office schedules and durable call/email claims are preserved.'
