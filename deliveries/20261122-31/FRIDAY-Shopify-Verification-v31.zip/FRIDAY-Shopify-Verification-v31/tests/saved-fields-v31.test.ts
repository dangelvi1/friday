import test from 'node:test'
import assert from 'node:assert/strict'
import {mkdtemp,rm,readFile} from 'node:fs/promises'
import {tmpdir} from 'node:os'
import {join} from 'node:path'
import {randomUUID} from 'node:crypto'
import {savedFieldComparison,savedFieldMatches} from '../commerce/daily/saved-field-comparison'
import {seoService} from '../commerce/daily/seo'
import {STORE} from '../commerce/daily/core'
import {atomic,jobFile,readJob,folder} from '../commerce/daily/storage'

test('Only apostrophe spelling in plain paragraph text is equivalent',()=>{
  for(const entity of ['&#39;','&#039;','&#x27;','&#X0027;','&apos;']) {
    const approved=`<p>O${entity}Brien shoes</p><p>Size: 9.</p>`
    const current="<p>O'Brien shoes</p><p>Size: 9.</p>"
    assert.equal(savedFieldComparison('descriptionHtml',current,approved).comparisonBasis,'paragraph_text_apostrophe_entity')
    assert.equal(savedFieldMatches('descriptionHtml',approved,current),true)
  }
  for(const [current,approved] of [
    ['<p>New text</p>','<p>Old text</p>'],
    ["<p>O'Brien  shoes</p>",'<p>O&#39;Brien shoes</p>'],
    ["<p>O'Brien shoes</p>",'<p>O&amp;#39;Brien shoes</p>'],
    ["<b>O'Brien</b>",'<p>O&#39;Brien</p>'],
    ["<p title=\"O'Brien\">text</p>",'<p title="O&#39;Brien">text</p>'],
    ["<script>O'Brien</script>",'<script>O&#39;Brien</script>'],
    ["<p>O'Brien</p>",'<p>&lt;p&gt;O&#39;Brien&lt;/p&gt;</p>'],
    ["<p><a title=\">O'Brien\">link</a></p>",'<p><a title=">O&#39;Brien">link</a></p>'],
    ["<p>O'Brien</p>",'<p>O&#39;Brien</p>\n']
  ]) assert.equal(savedFieldMatches('descriptionHtml',current,approved),false)
  assert.equal(savedFieldMatches('seoTitle',"O'Brien",'O&#39;Brien'),false)
  assert.equal(savedFieldMatches('tags',["O'Brien"],['O&#39;Brien']),false)
  assert.equal(savedFieldComparison('descriptionHtml','<p>Same</p>','<p>Same</p>').comparisonBasis,'exact')
})

test('Native readback and old-receipt verification retain guards and finish independent products',async t=>{
  const cwd=process.cwd(),dir=await mkdtemp(join(tmpdir(),'friday-v31-'))
  try {
    process.chdir(dir)
    const products=new Map<string,any>(),writes:any[]=[]
    const graphql=async(q:string,v:any={})=>{
      if(q.includes('Identity'))return{data:{shop:{id:STORE.id,myshopifyDomain:STORE.domain,currencyCode:'USD'}}}
      if(q.includes('CatalogReviewBases'))return{data:{nodes:v.ids.map((id:string)=>structuredClone(products.get(id)))}}
      if(q.includes('DailySeoProduct'))return{data:{product:structuredClone(products.get(v.id))}}
      if(q.includes('DailySeoUpdate')){
        writes.push(structuredClone(v.product));const p=products.get(v.product.id)
        p.descriptionHtml=v.product.descriptionHtml.replace(/&#39;/g,"'")
        if(p.title==='Different fixture')p.descriptionHtml='<p>Actually different text</p>'
        return{data:{productUpdate:{product:{id:p.id},userErrors:[]}}}
      }
      throw Error('Unexpected fixture query')
    }
    const service=seoService(graphql)
    async function make(titles:string[]){
      const id=randomUUID(),changes=titles.map((title,i)=>{
        const productId='gid://shopify/Product/'+(1000+products.size),base={id:productId,title,handle:'fixture-'+products.size,status:'ACTIVE',vendor:'Vans',descriptionHtml:'',seo:{title:null,description:null}}
        products.set(productId,base)
        return{id:productId.split('/').pop()+':descriptionHtml',productId,field:'descriptionHtml',before:'',after:'<p>O&#39;Brien shoes</p><p>Size: 9.</p>',supported:true}
      })
      await atomic(jobFile('salvador',id),{id,owner:'salvador',companyKey:STORE.companyKey,status:'completed',activity:[],report:{catalogRevision:0,audit:{products:changes.map(c=>({id:c.productId,sourceSEO:structuredClone(products.get(c.productId))}))},changes}})
      return{id,changes}
    }
    await t.test('entity-only readback saves; real difference retains uncertainty; later product saves',async()=>{
      const j=await make(['Normalized fixture','Different fixture','Later fixture'])
      const p=await service.preview('salvador',{reportId:j.id,changeIds:j.changes.map(c=>c.id)})
      const r=await service.execute('salvador',p.review.id,true)
      assert.equal(r.review.status,'completed_with_review')
      assert.deepEqual(r.review.results.map((r:any)=>r.status),['saved','uncertain','saved'])
      assert.equal(writes.length,3)
      assert.equal(r.review.results[0].comparisons[0].comparisonBasis,'paragraph_text_apostrophe_entity')
      assert.equal(r.review.results[1].writeAttempted,true)
      assert.equal(r.review.results[1].comparisons[0].current,'<p>Actually different text</p>')
      assert.equal(r.review.results[1].comparisons[0].matchesApproved,false)
      const report=await readJob('salvador',j.id)
      assert.ok(report.report.changes[0].appliedAt);assert.equal(report.report.changes[1].appliedAt,undefined);assert.ok(report.report.changes[2].appliedAt)
      const fresh=await service.preview('salvador',{reportId:j.id,changeIds:[j.changes[1].id]})
      assert.equal(fresh.review.status,'no_changes') // current differs from reviewed before; no overwrite
      assert.equal(writes.length,3)
    })
    await t.test('legacy uncertain entity-only receipt verifies locally without another write or guard deletion',async()=>{
      const j=await make(['Legacy fixture']),c=j.changes[0],id=randomUUID()
      products.get(c.productId).descriptionHtml=c.after.replace(/&#39;/g,"'")
      const path=join(folder('salvador'),'seo-reviews',id+'.json'),claim=join(folder('salvador'),'catalog-claims','retained-fixture.json')
      await atomic(claim,{reviewId:id})
      await atomic(path,{id,owner:'salvador',companyKey:STORE.companyKey,format:'catalog-v16',status:'needs_review',reportId:j.id,changes:j.changes,results:[{productId:c.productId,status:'uncertain',writeAttempted:true}],snapshots:{[c.productId]:{base:{...products.get(c.productId),descriptionHtml:''}}}})
      const before=writes.length,guard=await readFile(claim,'utf8'),r=await service.verifyCurrent('salvador',id)
      assert.equal(writes.length,before);assert.equal(r.review.status,'needs_review');assert.equal(r.review.results[0].status,'uncertain')
      assert.equal(r.verification.checks[0].status,'matches_approved')
      assert.equal(r.verification.checks[0].fields[0].comparisonBasis,'paragraph_text_apostrophe_entity')
      assert.ok((await readJob('salvador',j.id)).report.changes[0].appliedAt)
      assert.equal(await readFile(claim,'utf8'),guard)
      await assert.rejects(()=>service.verifyCurrent('dayanna',id),/not found/)
    })
    await t.test('preview recognizes already-matching entity spellings without requesting a new approval',async()=>{
      const j=await make(['Already matches fixture']),c=j.changes[0]
      products.get(c.productId).descriptionHtml=c.after.replace(/&#39;/g,"'")
      const before=writes.length,r=await service.preview('salvador',{reportId:j.id,changeIds:[c.id]})
      assert.equal(r.review.status,'no_changes');assert.match(r.review.excluded[0].reason,/Already matches/);assert.equal(writes.length,before)
    })
  } finally {process.chdir(cwd);await rm(dir,{recursive:true,force:true})}
})
