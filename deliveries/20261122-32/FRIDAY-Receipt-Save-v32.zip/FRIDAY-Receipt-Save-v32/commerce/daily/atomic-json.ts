import {mkdir,writeFile,rename,unlink} from 'node:fs/promises'
import {dirname} from 'node:path'
import {randomUUID} from 'node:crypto'

const waits = [50,100,200,400,800,1200] as const
const delay = (ms:number) => new Promise<void>(resolve=>setTimeout(resolve,ms))

// Retry only replacement of the already-written local temporary file. Never
// retry provider requests, unlink/truncate the destination, or bypass its ACLs.
export async function renameWithRetry(source:string,target:string,
  dependencies:{move?:(source:string,target:string)=>Promise<void>;wait?:(ms:number)=>Promise<void>}={}) {
  const move=dependencies.move||rename,wait=dependencies.wait||delay
  for(let attempt=0;;attempt++) {
    try {await move(source,target);return}
    catch(error:any) {
      if(!['EPERM','EACCES','EBUSY'].includes(error?.code)||attempt>=waits.length)throw error
      await wait(waits[attempt])
    }
  }
}

export function createAtomicWriter(replace:(source:string,target:string)=>Promise<void>=renameWithRetry) {
  return async(file:string,value:any)=>{
    await mkdir(dirname(file),{recursive:true,mode:0o700})
    const tmp=file+'.'+randomUUID()+'.tmp'
    try {
      await writeFile(tmp,JSON.stringify(value),{flag:'wx',mode:0o600})
      await replace(tmp,file)
    } finally {await unlink(tmp).catch(()=>{})}
  }
}
