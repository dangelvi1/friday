import test from 'node:test'
import assert from 'node:assert/strict'
import {mkdtemp,readFile,writeFile,readdir,rename,rm} from 'node:fs/promises'
import {tmpdir} from 'node:os'
import {join} from 'node:path'
import {createAtomicWriter,renameWithRetry} from '../commerce/daily/atomic-json'
import fs from 'node:fs/promises'
import {syncBuiltinESMExports} from 'node:module'
import {randomUUID} from 'node:crypto'
import {seoService} from '../commerce/daily/seo'
import {STORE} from '../commerce/daily/core'
import {atomic,jobFile} from '../commerce/daily/storage'

test('Temporary local replacement locks retry without damaging saved receipts',async t=>{
  const dir=await mkdtemp(join(tmpdir(),'friday-v32-')),file=join(dir,'receipt.json')
  try {
    for(const code of ['EPERM','EACCES','EBUSY'])await t.test(code+' retries the same staged file and preserves the old destination until replacement',async()=>{
      const old=JSON.stringify({status:'saved',verified:75}),next={status:'needs_review',verified:75}
      await writeFile(file,old);const waits:number[]=[],sources:string[]=[];let attempts=0
      const writer=createAtomicWriter((source,target)=>renameWithRetry(source,target,{
        move:async(a,b)=>{sources.push(a);assert.equal(b,file);assert.equal(await readFile(file,'utf8'),old);assert.deepEqual(JSON.parse(await readFile(a,'utf8')),next);if(attempts++<3)throw Object.assign(new Error('Locked fixture'),{code});await rename(a,b)},
        wait:async ms=>{waits.push(ms)}
      }))
      await writer(file,next);assert.equal(attempts,4);assert.equal(new Set(sources).size,1);assert.deepEqual(waits,[50,100,200]);assert.deepEqual(JSON.parse(await readFile(file,'utf8')),next);assert.deepEqual(await readdir(dir),['receipt.json'])
    })
    await t.test('permanent denial is bounded, rejects, keeps original bytes and cleans only temporary file',async()=>{
      await writeFile(file,'{"verified":75}');let attempts=0,totalWait=0
      const writer=createAtomicWriter((a,b)=>renameWithRetry(a,b,{move:async()=>{attempts++;throw Object.assign(new Error('Permanent lock fixture'),{code:'EPERM'})},wait:async ms=>{totalWait+=ms}}))
      await assert.rejects(()=>writer(file,{verified:76}),{code:'EPERM'});assert.equal(attempts,7);assert.equal(totalWait,2750);assert.equal(await readFile(file,'utf8'),'{"verified":75}');assert.deepEqual(await readdir(dir),['receipt.json'])
    })
    await t.test('unrelated errors are not retried and never delete the destination',async()=>{
      for(const code of ['ENOENT','ENOSPC','EIO']){
        let attempts=0
        const writer=createAtomicWriter((a,b)=>renameWithRetry(a,b,{move:async()=>{attempts++;throw Object.assign(new Error('Failure fixture'),{code})},wait:async()=>assert.fail('No wait expected')}))
        await assert.rejects(()=>writer(file,{changed:true}),{code});assert.equal(attempts,1);assert.equal(await readFile(file,'utf8'),'{"verified":75}');assert.deepEqual(await readdir(dir),['receipt.json'])
      }
    })
    await t.test('unserializable input never touches the destination',async()=>{
      const value:any={};value.self=value
      await assert.rejects(()=>createAtomicWriter()(file,value),/circular/i)
      assert.equal(await readFile(file,'utf8'),'{"verified":75}');assert.deepEqual(await readdir(dir),['receipt.json'])
    })
  }finally{await rm(dir,{recursive:true,force:true})}
})

test('A failed durable pre-submission save prevents Shopify dispatch and records a local-storage phase',async()=>{
  const cwd=process.cwd(),dir=await mkdtemp(join(tmpdir(),'friday-v32-dispatch-')),originalRename=fs.rename
  let attempts=0,writes=0
  try {
    process.chdir(dir)
    const id=randomUUID(),product={id:'gid://shopify/Product/123',title:'Fixture shoes',handle:'fixture',status:'ACTIVE',vendor:'Vans',descriptionHtml:'',seo:{title:null,description:null}}
    const c={id:'123:seoTitle',productId:product.id,field:'seoTitle',before:null,after:'Fixture SEO title',supported:true}
    await atomic(jobFile('salvador',id),{id,owner:'salvador',companyKey:STORE.companyKey,status:'completed',activity:[],report:{catalogRevision:0,audit:{products:[{id:product.id,sourceSEO:product}]},changes:[c]}})
    const service=seoService(async(q:string)=>{
      if(q.includes('Identity'))return{data:{shop:{id:STORE.id,myshopifyDomain:STORE.domain,currencyCode:'USD'}}}
      if(q.includes('CatalogReviewBases'))return{data:{nodes:[structuredClone(product)]}}
      if(q.includes('DailySeoProduct'))return{data:{product:structuredClone(product)}}
      if(q.includes('DailySeoUpdate')){writes++;throw Error('Must not dispatch')}
      throw Error('Unexpected fixture query')
    })
    const preview=await service.preview('salvador',{reportId:id,changeIds:[c.id]})
    fs.rename=async(a,b)=>{
      if(String(b).includes('seo-reviews')){
        const record=JSON.parse(await readFile(a,'utf8'))
        if(record.results?.some((r:any)=>r.writeAttempted)&&attempts<7){attempts++;throw Object.assign(new Error('Locked pre-submission fixture'),{code:'EPERM',syscall:'rename'})}
      }
      await originalRename(a,b)
    }
    syncBuiltinESMExports()
    const result=await service.execute('salvador',preview.review.id,true)
    assert.equal(attempts,7);assert.equal(writes,0);assert.equal(result.review.status,'needs_review')
    assert.equal(result.review.diagnostics.provider,'FRIDAY local storage')
    assert.equal(result.review.diagnostics.phase,'save_before_product_submission')
    assert.match(result.review.error,/FRIDAY local storage/)
  }finally{fs.rename=originalRename;syncBuiltinESMExports();process.chdir(cwd);await rm(dir,{recursive:true,force:true})}
})
