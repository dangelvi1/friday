import {readFile,stat} from 'node:fs/promises'
import {createHash} from 'node:crypto'
import {resolve} from 'node:path'
import {fileURLToPath,pathToFileURL} from 'node:url'
const enums=JSON.parse(await readFile(new URL('./google-reason-enums.json',import.meta.url),'utf8'))
const known=new Set([...Object.values(enums).flatMap(value=>Object.keys(value)),'SERVICE_DISABLED','ACCESS_TOKEN_SCOPE_INSUFFICIENT','ACCESS_TOKEN_EXPIRED','PROJECT_NOT_PERMITTED','PROJECT_NOT_FOUND'])
const statuses=new Set(['PERMISSION_DENIED','UNAUTHENTICATED','INVALID_ARGUMENT','RESOURCE_EXHAUSTED','FAILED_PRECONDITION','NOT_FOUND','INTERNAL','UNAVAILABLE'])
const categories=new Set(['authorizationError','authenticationError','headerError','requestError','quotaError'])
export function summarizeGoogleError(data,httpStatus){
 const error=data?.error,details=Array.isArray(error?.details)?error.details.slice(0,20):[],reasons=new Set(),types=new Set();let unrecognized=false
 const code=(value,category)=>{if(Number.isInteger(value)&&enums[category])value=Object.entries(enums[category]).find(([,n])=>n===value)?.[0];if(typeof value==='string'&&known.has(value))reasons.add(value);else if(value!==undefined)unrecognized=true}
 const entries=Array.isArray(error?.errors)?[...error.errors.slice(0,30)]:[]
 for(const detail of details){
  const type=String(detail?.['@type']||'');types.add(/google\.ads\.googleads\.v\d+\.errors\.GoogleAdsFailure$/.test(type)?'GoogleAdsFailure':/google\.rpc\.ErrorInfo$/.test(type)?'ErrorInfo':'Other')
  if(Array.isArray(detail?.errors))entries.push(...detail.errors.slice(0,30))
  if(detail?.reason!==undefined)code(detail.reason)
 }
 for(const entry of entries.slice(0,120))for(const category of categories)if(entry?.errorCode?.[category]!==undefined)code(entry.errorCode[category],category)
 const texts=[error?.message,...entries.slice(0,120).map(entry=>entry?.message)].filter(value=>typeof value==='string').map(value=>value.slice(0,20000)),classifications=new Set()
 const patterns={
  DEVELOPER_TOKEN_PROJECT_RESTRICTION:/developer token.{0,180}(not allowed|not permitted|prohibited).{0,100}project/i,
  DEVELOPER_TOKEN_TEST_ACCOUNT_RESTRICTION:/developer token.{0,160}(only.{0,60}test|not approved)/i,
  CLOUD_PROJECT_PRODUCTION_APPROVAL_REQUIRED:/project.{0,180}(only.{0,60}test|not approved.{0,60}production)/i,
  CLOUD_API_DISABLED:/(api|service).{0,160}(has not been used|is disabled|not enabled)/i,
  INSUFFICIENT_AUTHENTICATION_SCOPE:/insufficient.{0,60}(authentication|authorization)?.{0,30}scope/i,
  CALLER_PERMISSION_DENIED:/(caller|user).{0,100}(does not have|doesn't have|lacks).{0,30}permission/i,
  TERMS_ACCEPTANCE_REQUIRED:/(accept|sign).{0,80}terms of service/i
 }
 for(const text of texts){for(const [label,pattern]of Object.entries(patterns))if(pattern.test(text))classifications.add(label);for(const reason of known)if(new RegExp('\\b'+reason+'\\b').test(text))reasons.add(reason)}
 return{format:'FRIDAY_GOOGLE_ERROR_V1',httpStatus:Number.isInteger(httpStatus)?httpStatus:null,rpcStatus:statuses.has(error?.status)?error.status:'UNRECOGNIZED',reasonCodes:[...reasons].slice(0,12),messageClassifications:[...classifications].slice(0,8),detailTypes:[...types],unrecognizedCodePresent:unrecognized,detailsPresent:details.length>0}
}
async function limitedJson(response){
 const reader=response.body?.getReader();if(!reader)return null
 const chunks=[];let count=0
 try{while(true){const {done,value}=await reader.read();if(done)break;count+=value.byteLength;if(count>65536){void reader.cancel().catch(()=>{});return null}chunks.push(value)}const all=new Uint8Array(count);let offset=0;for(const chunk of chunks){all.set(chunk,offset);offset+=chunk.byteLength}return JSON.parse(new TextDecoder().decode(all))}catch{return null}finally{reader.releaseLock()}
}
export function installGoogleDiagnostic({fetch:original=globalThis.fetch,sink=value=>console.log(value),target=globalThis}={}){
 let logged=0
 const wrapped=async(...args)=>{
  const response=await original(...args)
  try{const input=args[0],url=new URL(typeof input==='string'?input:input instanceof URL?input.href:input.url)
   if(url.protocol==='https:'&&url.hostname==='googleads.googleapis.com'&&!response.ok&&logged<5){logged++;const data=await limitedJson(response.clone());sink('FRIDAY_GOOGLE_DIAG '+JSON.stringify(summarizeGoogleError(data,response.status)))}
  }catch{/* Diagnostics must not change the native response or expose raw exceptions. */}
  return response
 }
 target.fetch=wrapped
 return()=>{if(target.fetch===wrapped)target.fetch=original}
}
export async function startDiagnostic(project){
 const projectPath=resolve(project),serverPath=resolve(projectPath,'server.ts');await stat(serverPath);const module=await readFile(resolve(projectPath,'marketing/ads/google.ts'))
 process.chdir(projectPath)
 console.log('FRIDAY_GOOGLE_DIAG_READY '+JSON.stringify({googleAdsModuleSHA256:createHash('sha256').update(module).digest('hex'),reasonSource:'Official Google Ads Python SDK v26 authorization/authentication enums',maximumLoggedFailures:5}))
 installGoogleDiagnostic()
 await import(pathToFileURL(serverPath).href)
}
if(process.argv[1]&&resolve(process.argv[1]).toLowerCase()===fileURLToPath(import.meta.url).toLowerCase()){
 try{await startDiagnostic(process.argv[2]||'S:\AI\friday-ai')}catch{console.error('FRIDAY_GOOGLE_DIAG_START_FAILED: Check project path, stop the old backend and use the supplied launcher. Raw startup details are not printed.');process.exitCode=1}
}
