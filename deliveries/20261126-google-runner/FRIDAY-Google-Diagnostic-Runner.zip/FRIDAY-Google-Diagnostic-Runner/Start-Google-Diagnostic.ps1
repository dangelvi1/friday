param([string]$ProjectPath='S:\AI\friday-ai')
$ErrorActionPreference='Stop'
if(!(Test-Path -LiteralPath (Join-Path $ProjectPath 'server.ts'))){throw 'FRIDAY server.ts not found. No files changed.'}
if($env:OS -eq 'Windows_NT'){
 $listeners=@(Get-NetTCPConnection -LocalPort 3001 -State Listen -ErrorAction SilentlyContinue)
 if($listeners.Count){throw 'Port 3001 is already in use. Stop the existing FRIDAY backend with Ctrl+C first; this launcher will not kill processes.'}
}
Push-Location -LiteralPath $ProjectPath
try{
 Write-Host 'Temporary Google diagnostic backend. Leave the frontend running and make one NEW Google connection attempt.'
 Write-Host 'Copy only FRIDAY_GOOGLE_DIAG lines. Stop with Ctrl+C, then use npm.cmd run server normally.'
 & node --import tsx (Join-Path $PSScriptRoot 'google-diagnostic.mjs') $ProjectPath
 if($LASTEXITCODE -notin @(0,130,-1073741510)){throw 'Diagnostic backend exited with an error. The launcher did not edit FRIDAY source or configuration.'}
}finally{Pop-Location}
