# Validation

109 Node-reported test entries passed, zero failures/skips (97 specific cases and 12 parent entries), across voice approvals, Calendar, invoice fields, live bank feed, bank workflows and Document Analysis. The existing Document Analysis consent test now cancels the new explicit consent review and confirms selected files remain, rather than expecting a missing-checkbox error. No assertions were disabled.

```
FRIDAY_TEST_TOOLS=/workspace/scratch/friday-test-tools node --import tsx --test tests/voice-approvals.test.ts tests/calendar.test.ts tests/invoice-fields.test.ts tests/live-bank-feed.test.ts tests/bank-workflows.test.ts tests/document-review.test.ts
```

The pg-mem helper and /usr/bin/chromium are cloud-test facilities; they are not installed into the PC app or shipped as dependencies. Windows browser paths in the test harness may need adapting before rerunning there.

New tests exercise explicit/negative/quoted/blanket English/Spanish commands, actual WebRTC playback/transcription event shapes, incomplete/interrupted readbacks, item replay, expiry, changed review IDs/forms, exact production company confirmation, owner/profile clearing, multiple-review ambiguity and paired full-page confirmation. Actual Chromium exercises the shared approval registry/hub, real existing QuickBooks owner review JavaScript (preserving approvedBy/realm/environment), and the real Calendar panel's voice-dispatched preview/save clearing. Google/QuickBooks responses in those browser dispatch tests are synthetic; the existing registered backend route suites separately verify owner/company authorization, stale revisions and durable supported receipts.

Frontend TypeScript, JavaScript syntax checks and standalone Vite compilation pass; existing bundle-size warning remains. The standalone build uses configFile:false without replacing Windows TLS settings.

Live microphone recognition, WebRTC timing and OpenAI transcription availability, actual speaker identity, Windows installer/rollback execution, live Google/QuickBooks writes and office calendar visibility were not tested here. Salvador reported Calendar v6 works on his PC; this is user-reported prior behavior, not a new live voice-approval test. No private credential, microphone recording, uploaded customer document or live-account event/invoice is used or included in this package.
