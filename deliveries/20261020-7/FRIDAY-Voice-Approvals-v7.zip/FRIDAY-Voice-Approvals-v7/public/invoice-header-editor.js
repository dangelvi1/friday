// Header edits use a separate sparse, owner-approved save; invoice lines stay in the existing editor.
(() => {
 const labels={poReferenceNumber:'PO Reference no.',service:'SERVICE',monthClaim:'CLAIM / MONTH',jobLocationCarrier:'JOB LOCATION / CARRIER',jobName:'JOB NAME'}
 const $=id=>document.getElementById(id)
 let current=null,epoch=0
 function same(s){return s&&s===current&&s.companyKey===fridayQuickBooksState.companyKey&&String(fridayInvoiceEditState.invoice?.id)===s.id}
 function changed(s){return Object.fromEntries(Object.keys(labels).filter(k=>s.inputs[k]!==String(s.fields[k]??'')).map(k=>[k,s.inputs[k]]))}
 function notice(s,text,error=false){if(!same(s))return;const p=$('fridayInvoiceHeaderStatus');if(p)p.textContent=text;if(error)window.fridayReviewNotice?.('Invoice fields',text,true)}
 function buttonState(s){if(!same(s))return;$('fridayPreviewHeaderChanges').disabled=s.busy||s.blocked||!Object.keys(changed(s)).length;$('fridayHeaderReceipt').disabled=s.busy||!s.proposal;$('fridayRefreshHeaderFields').disabled=s.busy}
 async function confirmChanges(s,p){
  const dialog=document.createElement('dialog');dialog.className='friday-header-confirm';const form=document.createElement('form');form.method='dialog';const title=document.createElement('h3');title.textContent='Approve QuickBooks header changes';form.append(title);const scope=document.createElement('p');scope.textContent=`${p.companyKey} (${p.environment}) · Invoice #${p.docNumber} · Owner ${p.actor}`;form.append(scope)
  for(const change of p.review){const row=document.createElement('p');row.textContent=`${change.label}: ${change.before||'(blank)'} → ${change.after||'(blank)'}`;form.append(row)}
  const summary=document.createElement('p');summary.textContent='Only these invoice header values change. Amounts, dates, products/services, referral-fee lines and taxes are preserved.';form.append(summary)
  for(const [text,value] of [['Cancel','cancel'],['Approve and save in QuickBooks','approve']]){const button=document.createElement('button');button.textContent=text;button.value=value;form.append(button)}dialog.append(form);document.body.append(dialog);dialog.showModal()
  let unregister=()=>{};const snapshot=JSON.stringify(changed(s));if(window.FridayOwnerApprovals)unregister=window.FridayOwnerApprovals.register({element:dialog,title:title.textContent,summary:form.innerText,scope:p.companyKey,owner:p.actor,requiredSpokenCompany:p.environment==='production'?(fridayQuickBooksState.companyName||p.companyKey):null,snapshot:()=>({company:fridayQuickBooksState.companyKey,changes:changed(s),proposal:p.proposalId}),current:()=>same(s)&&JSON.stringify(changed(s))===snapshot,approve:()=>form.querySelector('button[value=approve]').click(),reject:()=>form.querySelector('button[value=cancel]').click()})
  return new Promise(resolve=>dialog.addEventListener('close',()=>{unregister();const approved=dialog.returnValue==='approve'&&same(s)&&JSON.stringify(changed(s))===snapshot;dialog.remove();resolve(approved)},{once:true}))
 }
 async function request(s,action,body){
  if(!same(s))throw Error('Invoice company changed. Reopen this invoice.')
  const r=await window.fridayInvoiceFieldRequest(`/quickbooks/invoice-fields/${encodeURIComponent(s.companyKey)}/${s.id}/${action}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}),d=await r.json()
  if(!same(s))throw Error('Invoice selection changed; response discarded.')
  if(!r.ok||!d.success){if(d.proposalId)s.proposal={...s.proposal,proposalId:d.proposalId};throw Error(d.error||'Header operation failed.')}
  return d
 }
 async function run(s,fn){if(!same(s)||s.busy)return;s.busy=true;buttonState(s);try{await fn()}catch(e){notice(s,e.message,true)}finally{if(same(s)){s.busy=false;buttonState(s)}}}
 function mount(){
  const invoice=fridayInvoiceEditState.invoice,body=$('fridayInvoiceEditBody');if(!invoice||!body)return
  if(current&&current.companyKey===fridayQuickBooksState.companyKey&&current.id===String(invoice.id)&&String(invoice.syncToken)!==current.syncToken)current=null
  if(!current||current.companyKey!==fridayQuickBooksState.companyKey||current.id!==String(invoice.id))current={companyKey:fridayQuickBooksState.companyKey,id:String(invoice.id),scope:invoice.readScope,syncToken:String(invoice.syncToken),fields:invoice,inputs:Object.fromEntries(Object.keys(labels).map(k=>[k,String(invoice[k]??'')])),proposal:null,busy:false,blocked:false}
  const s=current
  $('fridayInvoiceHeaderFields')?.remove();const pane=document.createElement('section');pane.id='fridayInvoiceHeaderFields';pane.className='friday-invoice-header-fields';const h=document.createElement('h3');h.textContent='Invoice reference fields';pane.append(h)
  const grid=document.createElement('div');grid.className='friday-invoice-header-grid'
  for(const [key,label] of Object.entries(labels)){const wrap=document.createElement('label');if(key==='poReferenceNumber')wrap.className='friday-invoice-header-po';wrap.append(document.createTextNode(label));const input=document.createElement('input');input.type='text';input.id='fridayInvoiceHeader_'+key;input.value=s.inputs[key];input.maxLength=500;input.autocomplete='off';const info=s.fields.fieldInfo?.[key];input.disabled=s.blocked||!info?.editable;input.placeholder=info?.status==='blank'?'Blank in QuickBooks':info?.status==='unavailable'?'Not returned by QuickBooks':'';input.title=info?.message||'';input.addEventListener('input',()=>{s.inputs[key]=input.value;s.proposal=null;buttonState(s)});wrap.append(input);const hint=document.createElement('small');hint.textContent=info?.message||'';wrap.append(hint);grid.append(wrap)}
  pane.append(grid)
  const lines=document.createElement('p');lines.className='friday-header-help';lines.textContent='Line products/services: '+((s.fields.lineServices||[]).join(' · ')||'No names returned')+'. These are separate from the SERVICE header.';pane.append(lines)
  const actions=document.createElement('div');actions.className='friday-header-actions';for(const [id,text] of [['fridayRefreshHeaderFields','Refresh from QuickBooks'],['fridayPreviewHeaderChanges','Review and save header changes'],['fridayHeaderReceipt','Check header receipt']]){const button=document.createElement('button');button.type='button';button.id=id;button.textContent=text;actions.append(button)}pane.append(actions)
  const status=document.createElement('p');status.id='fridayInvoiceHeaderStatus';status.setAttribute('role','status');status.textContent=s.blocked?'Invoice revision changed. Reopen the full invoice before editing; your other inputs were kept.':'Values read from QuickBooks. Missing or ambiguous text-field definitions cannot be edited by guessing.';pane.append(status);body.prepend(pane)
  $('fridayRefreshHeaderFields').addEventListener('click',()=>run(s,async()=>{
   if(Object.keys(changed(s)).length&&!confirm('Discard unsaved header changes and refresh these five fields? Other invoice edits stay in the editor.'))return
   const ticket=epoch,r=await fetch(`/quickbooks/invoice/${encodeURIComponent(s.companyKey)}/${s.id}`),d=await r.json()
   if(!same(s)||ticket!==epoch)return
   if(d.invoice?.readScope?.realmId!==s.scope?.realmId||d.invoice?.readScope?.environment!==s.scope?.environment)throw Error('QuickBooks connection changed. Reopen the invoice before refreshing headers.')
   if(!r.ok||!d.success||d.companyKey!==s.companyKey)throw Error(d.error||'Could not refresh invoice headers.')
   s.blocked=String(d.invoice.syncToken)!==String(fridayInvoiceEditState.invoice.syncToken);s.fields=d.invoice;s.inputs=Object.fromEntries(Object.keys(labels).map(k=>[k,String(d.invoice[k]??'')]));s.proposal=null;mount();document.dispatchEvent(new CustomEvent('friday-invoice-fields-refreshed',{detail:{companyKey:s.companyKey,invoiceId:s.id,fields:Object.fromEntries([...Object.keys(labels),'customFields','fieldInfo','lineServices'].map(k=>[k,d.invoice[k]]))}}));notice(s,s.blocked?'QuickBooks invoice revision changed. Reopen the invoice before editing; your other inputs were kept.':'Current QuickBooks header values refreshed.')
  }))
  $('fridayPreviewHeaderChanges').addEventListener('click',()=>run(s,async()=>{
   if(s.blocked)throw Error('Reopen the current invoice before editing.')
   const p=await request(s,'preview',{expectedSyncToken:s.syncToken,sourceScope:s.scope,changes:changed(s)});s.proposal=p
   if(!await confirmChanges(s,p))return
   notice(s,'Saving the approved header changes…')
   const result=await request(s,'execute',{proposalId:p.proposalId,snapshotHash:p.snapshotHash,approved:true})
   Object.assign(fridayInvoiceEditState.invoice,result.fields,{syncToken:result.syncToken});s.syncToken=result.syncToken;s.fields=fridayInvoiceEditState.invoice;s.inputs=Object.fromEntries(Object.keys(labels).map(k=>[k,String(s.fields[k]??'')]));mount()
   document.dispatchEvent(new CustomEvent('friday-invoice-fields-saved',{detail:{companyKey:s.companyKey,invoiceId:s.id,fields:result.fields}}));notice(s,'Header changes saved in QuickBooks and re-read successfully. Invoice amounts and lines were verified unchanged.')
  }))
  $('fridayHeaderReceipt').addEventListener('click',()=>run(s,async()=>{const d=await request(s,'receipt',{proposalId:s.proposal.proposalId});notice(s,'Header receipt: '+d.receipt.status+'. '+(d.receipt.status==='uncertain'?'Check the original QuickBooks invoice before any new submission.':''))}))
  buttonState(s)
 }
 const original=fridayRenderInvoiceEditor
 fridayRenderInvoiceEditor=function(...args){const r=original(...args);mount();return r}
 window.FridayInvoiceHeaderEditor={state:()=>same(current)&&$('fridayInvoiceEditOverlay')?.classList.contains('open')?{companyKey:current.companyKey,invoiceId:current.id,quickBooksValues:Object.fromEntries(Object.keys(labels).map(k=>[k,current.fields[k]??null])),draftValues:{...current.inputs},hasUnsavedChanges:!!Object.keys(changed(current)).length}:null}
 document.addEventListener('sandra-company-changed',()=>{epoch++;current=null;$('fridayInvoiceHeaderFields')?.remove();$('fridayInvoiceEditOverlay')?.classList.remove('open')})
})()
