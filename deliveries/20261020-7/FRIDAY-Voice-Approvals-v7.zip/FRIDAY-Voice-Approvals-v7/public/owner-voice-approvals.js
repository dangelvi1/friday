// Explicit application-owned reviews only. No scanning arbitrary buttons or trusting document instructions.
(() => {
 if(window.FridayOwnerApprovals)return
 const entries=new Map()
 const visible=e=>!!e?.isConnected&&!e.hidden&&!!(e.offsetWidth||e.offsetHeight||e.getClientRects().length)
 const notify=()=>document.dispatchEvent(new Event('friday-owner-approval-changed'))
 function register(options){
  const id=crypto.randomUUID(),version=crypto.randomUUID(),expiresAt=Math.min(options.expiresAt||Date.now()+900000,Date.now()+900000)
  const entry={...options,id,version,expiresAt,used:false};entries.set(id,entry);notify()
  return()=>{entries.delete(id);notify()}
 }
 function valid(e){try{return!e.used&&Date.now()<e.expiresAt&&visible(e.element)&&e.current()&&JSON.stringify(e.snapshot())===e.snapshotValue}catch{return false}}
 // Keep the snapshot function distinct from its immutable serialized value.
 function track(options){const snapshot=options.snapshot;return register({...options,snapshotValue:JSON.stringify(snapshot()),snapshot})}
 function list(){const result=[];for(const [id,e]of entries){if(!valid(e)){entries.delete(id);continue}result.push({id,version:e.version,title:e.title,summary:e.summary,scope:e.scope,owner:e.owner||'verified owner',requiredSpokenCompany:e.requiredSpokenCompany||null,expiresAt:e.expiresAt})}return result}
 async function act(id,version,decision,spokenCompany){
  const e=entries.get(id);if(!e||e.version!==version||!valid(e))throw Error('Approval expired, changed or closed. Inspect a fresh review; nothing was approved.')
  if(!['approve','reject'].includes(decision))throw Error('Choose approve or reject.')
  if(decision==='approve'&&e.requiredSpokenCompany&&normalize(spokenCompany)!==normalize(e.requiredSpokenCompany))throw Error('Say the full company name shown in this production review.')
  if(decision==='approve')await e.verify?.()
  if(!valid(e))throw Error('Review changed while verifying owner. Nothing was approved.')
  e.used=true;entries.delete(id);notify()
  if(decision==='reject'){await e.reject();return{success:true,status:'cancelled',saved:false}}
  const result=await e.approve();return result||{success:true,status:'approval_dispatched',completed:false,message:'Approval sent to the existing workflow. Inspect its actual result/receipt before claiming success or submitting again.'}
 }
 const normalize=s=>String(s||'').normalize('NFKD').replace(/\p{M}/gu,'').toLowerCase().replace(/&/g,' and ').replace(/[^\p{L}\p{N}]+/gu,' ').trim()
 async function confirm(options){
  const dialog=document.createElement('dialog');dialog.className='friday-owner-confirm';dialog.style.cssText='max-width:min(740px,90vw);max-height:85vh;border:1px solid #438364;border-radius:14px;padding:24px;background:white;color:#132b20;z-index:12000';const title=document.createElement('h2');title.textContent=options.title;const copy=document.createElement('pre');copy.style.cssText='white-space:pre-wrap;font:15px/1.5 system-ui;max-height:55vh;overflow:auto';copy.textContent=options.summary;const hint=document.createElement('p');hint.textContent='Review this action. You can approve or cancel by voice in your verified FRIDAY session, or use the buttons.';const no=document.createElement('button');no.textContent='Cancel';const yes=document.createElement('button');yes.textContent=options.approveLabel||'Approve';dialog.append(title,copy,hint,no,yes);document.body.append(dialog);dialog.showModal()
  return await new Promise(resolve=>{let unregister=()=>{},settled=false;function finish(approved){if(settled)return;settled=true;unregister();dialog.remove();resolve(approved)}
   no.onclick=()=>finish(false);yes.onclick=async()=>{try{await options.verify?.();if(!options.current())throw Error('Review changed.');finish(true)}catch(e){hint.textContent=e.message}}
   dialog.addEventListener('cancel',event=>{event.preventDefault();finish(false)})
   unregister=track({...options,element:dialog,approve:()=>finish(true),reject:()=>finish(false)})
  })
 }
 const clear=()=>{for(const e of entries.values())e.used=true;entries.clear();notify()}
 window.FridayOwnerApprovals={register:track,list,act,confirm,clear}
 document.addEventListener('sandra-company-changed',clear);window.addEventListener('pagehide',clear)
})()
