(() => {
 const room=new URLSearchParams(location.hash.slice(1)).get('friday-approval')
 if(!room||!/^[a-f0-9-]{36}$/.test(room)||!window.FridayOwnerApprovals)return
 window.fridayApprovalRoom=room
 const channel=new BroadcastChannel('friday-approvals-'+room),peer=crypto.randomUUID(),seen=new Set()
 channel.onmessage=async({data:m})=>{
  if(m?.kind==='query'){channel.postMessage({kind:'pending',query:m.query,peer,reviews:window.FridayOwnerApprovals.list()});return}
  if(m?.kind!=='decision'||m.peer!==peer||!['approve','reject'].includes(m.decision)||typeof m.id!=='string')return
  const reply=result=>channel.postMessage({kind:'decision-result',request:m.request,peer,result})
  if(seen.has(m.request))return reply({success:false,error:'Approval already dispatched. Inspect its result; no automatic retry.'});seen.add(m.request)
  try{reply(await window.FridayOwnerApprovals.act(m.id,m.version,m.decision,m.spokenCompany))}catch(e){reply({success:false,error:e.message})}
 }
 document.addEventListener('friday-owner-approval-changed',()=>channel.postMessage({kind:'changed',peer}))
 window.addEventListener('pagehide',()=>channel.close())
})()
