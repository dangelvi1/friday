// Adapt the existing invoice preparation approval. The final owner-authenticated invoice review remains required.
(() => {
 const original=openFridayApproval
 let clear=()=>{}
 openFridayApproval=function(approval){clear();const result=original(approval);if(approval.type!=='invoice'||!window.FridayOwnerApprovals)return result
  const p=fridayPendingApproval,overlay=document.getElementById('approvalOverlay'),company=fridayQuickBooksState.companyName
  clear=window.FridayOwnerApprovals.register({element:overlay,title:document.getElementById('approvalTitle').textContent,summary:document.getElementById('approvalDescription').textContent+'\n'+JSON.stringify(p.payload,null,2),scope:p.companyKeySnapshot,requiredSpokenCompany:p.environmentSnapshot==='production'?company:null,snapshot:()=>({pending:fridayPendingApproval,company:fridayQuickBooksState.companyKey,environment:fridayQuickBooksState.environment}),current:()=>fridayPendingApproval===p&&fridayApprovalCompanyMatches(p)&&overlay.classList.contains('open'),verify:async()=>{await window.fridayVerifyExistingOwner()},approve:()=>{if(p.environmentSnapshot==='production'){document.getElementById('productionCompanyConfirm').value=company;fridayUpdateProductionApprovalButton()}const button=document.getElementById('confirmApprovalButton');if(button.disabled)throw Error('Production company confirmation is required.');button.click()},reject:()=>closeFridayApproval()})
  return result
 }
 const close=closeFridayApproval;closeFridayApproval=function(){clear();return close()}
})()
