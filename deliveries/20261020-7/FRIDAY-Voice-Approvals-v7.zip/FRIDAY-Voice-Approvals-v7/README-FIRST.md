# FRIDAY Voice Approvals v7 — 20261020-7

For Salvador and Dayanna's existing FRIDAY at S:\AI\friday-ai. Requires the working Calendar v6 installation. Keeps the natural Realtime conversation, visible pointer/navigation, existing owner keys and backend/company approval guards. No account migration, dependencies, OAuth reset or data replacement.

## What changes

FRIDAY can show a supported pending approval, read it aloud, ask for a separate spoken approve/cancel command, and dispatch that command to the exact current review. It uses a reusable application-owned approval registry, not a scan/click of arbitrary buttons or document text.

Integrated flows:
- Calendar event creation: the existing centered event review and backend one-time receipt/duplicate protection.
- Invoice create/create-and-email, full invoice editor saves, header-only saves and invoice deletion, including the deletion dependencies shown in the review. Final owner-authenticated invoice reviews now use centered dialogs instead of native browser confirm boxes. Invoice preparation and final save can be separate stages; each stage requires its own fresh approval.
- Private Document Analysis: existing analysis/document/row deletion/restoration and final review confirmations, selected-file upload/AI extraction consent, source-row attestation and saved-original re-extraction consent. Both dashboard and paired full-page reviews use the same mechanism. Private review approvals never change QuickBooks.

Read and prepare still do not approve. Unknown/native dialogs, OS file pickers, owner credential entry, Google OAuth consent and unregistered/new workflows stay manual until explicitly integrated. The reusable registry is the standard for future protected reviews; this update is not blanket authority to approve future actions or an arbitrary website.

## Voice interaction

1. Verify your existing owner key once in Calendar or the relevant dashboard/private-file interface. Keys are typed into password fields, never spoken or supplied to the model.
2. Prepare/show the action. Ask “Friday, what needs my approval?” if necessary. FRIDAY uses owner_approval_control review to inspect the exact visible review, then reads its scope, changes, amounts/recipients and consequences aloud.
3. Wait until the readback finishes, then say “Friday, approve it,” “I approve,” or “Cancel it.” English and explicit Spanish variants such as “Apruébalo” are supported. A bare “yes,” instructions quoted inside files/emails/events, approval during an unfinished/interrupted readback, or a request to approve everything does not authorize anything.
4. For production QuickBooks, use the full company name shown, for example “Approve it for [the full company name].” FRIDAY should tell you the exact name. This preserves explicit company confirmation rather than guessing Nationwide/Robal aliases. Ampersand and spoken “and” normalize consistently.
5. Each changed/new review needs a new readback and fresh command. Changing owner/profile, company, form contents, closing/expiring the review or disconnecting invalidates the voice permission. If multiple reviews are open, select the intended one before confirming. Stopping cannot undo an action already submitted.

The gate uses fresh microphone input-transcription events in the existing authenticated session, matched to an actual pending review and audible WebRTC playback completion. Assistant output/model tool arguments cannot supply the confirmation. It tolerates a short transcription delay; if transcription is absent or late, nothing is approved and FRIDAY asks for a fresh confirmation. Input transcription uses gpt-4o-mini-transcribe through the existing OpenAI voice session; live availability/latency and recognition require PC testing.

Important identity limit: the current project has VOICE_RECOGNITION_ENABLED=false. This feature confirms speech within a manually verified owner session; it does not claim biometric speaker verification. Lock/disconnect when leaving the session unattended.

An approval_dispatched result means only that the existing workflow received authorization. FRIDAY must inspect its actual result/receipt before claiming the action succeeded. Calendar returns its verified creation receipt directly. Legacy full-invoice operations retain their existing backend behavior; this package does not invent new server-side idempotency for those operations. Never retry an uncertain financial or calendar write automatically.

## Install from any PowerShell location

Stop only the FRIDAY backend. Extract into S:\AI\Fixing-Files-Folder\FRIDAY-Voice-Approvals-v7, then run:

```powershell
$packageRoot = 'S:\AI\Fixing-Files-Folder\FRIDAY-Voice-Approvals-v7'
$installers = @(Get-ChildItem -LiteralPath $packageRoot -Filter 'Install-Voice-Approvals.ps1' -File -Recurse -ErrorAction Stop)
if ($installers.Count -ne 1) { throw 'Expected exactly one Install-Voice-Approvals.ps1. Check the extracted folder.' }
$installer = $installers[0].FullName
Unblock-File -LiteralPath $installer
Unblock-File -LiteralPath (Join-Path (Split-Path $installer) 'Restore-Voice-Approvals.ps1')
& $installer -ProjectPath 'S:\AI\friday-ai'
if (-not $?) { throw 'Installation failed. Do not continue.' }
Set-Location -LiteralPath 'S:\AI\friday-ai'
npm run build
if ($LASTEXITCODE -ne 0) { throw 'Build failed. Do not restart with an incomplete build.' }
npm run server
```

Restart the existing npm run dev process in its own terminal too. The installer checks package/source hashes and creates a verified timestamped backup before copying only listed files. If a baseline differs, stop and obtain a patch based on the installed source. It does not bypass an enforced Windows signing policy.

Your working https://localhost:5173/ voice page, FRIDAY_CALENDAR_REDIRECT_URI setting, private .env, Google Web/Desktop clients, Gmail files, Calendar tokens/mappings/receipts and all DB/upload data remain unchanged. No reconnect or Google consent is needed just for this update.

After restarting:
- Ctrl+F5 on the voice page. Close old QuickBooks/full-review tabs.
- Open QuickBooks using the existing “Open QuickBooks for conversational voice” link on the refreshed voice page. The link now also pairs owner approval messages. Both tabs must use the same browser profile/origin.
- Open a full-width Document Analysis review using its dashboard link; it carries the same private approval pairing. An old bookmark/unpaired review is not automatically controllable by voice.
- Verify owner in the relevant interface, prepare a real action you intend to review, let FRIDAY read it, then first test “Cancel it.” Confirm no write happened and the draft remains.
- Only then test voice approval of an event/invoice you actually intend to save. Check its native destination/receipt. No real event/invoice/file was changed during cloud testing.

## Backup / restore

The installer prints backups\voice-approvals-v7-[timestamp]. To restore, stop FRIDAY and run Restore-Voice-Approvals.ps1 from that backup directory. Rebuild, restart backend/dev and Ctrl+F5; close/reopen paired tabs. Restore verifies hashes and refuses to overwrite later edits. It restores application files only; Google/owner credentials, receipts, DB data and files remain. Code rollback cannot undo an already completed external write.

AGENTS-MERGE-PROPOSAL.md is a proposal; AGENTS.md is never overwritten. See VALIDATION.md for automated/live boundaries.
