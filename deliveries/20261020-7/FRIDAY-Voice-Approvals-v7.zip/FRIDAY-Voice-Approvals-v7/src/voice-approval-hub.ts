import {VoiceApprovalGate} from './voice-approval-gate'
const registry=()=> (window as any).FridayOwnerApprovals
export function createVoiceApprovalHub(room:string,onRemoteChange:()=>void){
 const gate=new VoiceApprovalGate(),channel=new BroadcastChannel('friday-approvals-'+room),queries=new Map<string,any[]>(),pending=new Map<string,{resolve:(v:any)=>void;timer:ReturnType<typeof setTimeout>}>()
 let current:any=null
 channel.onmessage=({data:m})=>{if(m?.kind==='changed'){onRemoteChange();return}if(m?.kind==='pending'&&queries.has(m.query)&&Array.isArray(m.reviews))queries.get(m.query)!.push(...m.reviews.map((r:any)=>({...r,peer:m.peer})));if(m?.kind==='decision-result'){const waiter=pending.get(m.request);if(waiter){clearTimeout(waiter.timer);pending.delete(m.request);waiter.resolve(m.result)}}}
 async function reviews(){const id=crypto.randomUUID(),rows=registry().list().map((r:any)=>({...r,peer:null}));queries.set(id,rows);channel.postMessage({kind:'query',query:id});await new Promise(r=>setTimeout(r,220));queries.delete(id);return rows}
 function reset(){gate.reset();current=null}
 async function execute(action:string,id?:string){
  if(action==='stop'){reset();return{success:true,message:'Voice approval stopped. A submitted action cannot be undone here.'}}
  if(action==='review'){
   const rows=await reviews();if(!rows.length){reset();return{success:false,error:'No supported approval is currently open. Prepare/show the action first; owner verification is still required.'}}
   const selected=id?rows.find((r:any)=>r.id===id):rows.length===1?rows[0]:null
   if(!selected){reset();return{success:false,error:'More than one approval is open. Ask which one and review its exact ID.',reviews:rows}}
   current=selected;gate.begin(selected)
   return{success:true,review:selected,message:'Read this review aloud, including scope, changes and consequences. Ask for a separate explicit command such as “Friday, approve it” or “Cancel it”. A bare yes is not approval.'}
  }
  if(!['approve','reject'].includes(action)||!id)throw Error('Use review, then approve/reject its actual ID.')
  if(current?.id!==id)throw Error('Inspect and read the current review before asking for voice approval.')
  const confirmation=await gate.waitAndConsume(id,action),r=confirmation.review;current=null
  const actual=(await reviews()).find((v:any)=>v.id===id&&v.version===r.version&&v.peer===r.peer)
  if(!actual)throw Error('Review changed or closed; the spoken confirmation was discarded.')
  if(!r.peer)return await registry().act(id,r.version,action,confirmation.spokenCompany)
  const request=crypto.randomUUID();return await new Promise(resolve=>{const timer=setTimeout(()=>{pending.delete(request);resolve({success:false,error:'Approval response timed out. Inspect the action/receipt; do not repeat it automatically.'})},25000);pending.set(request,{resolve,timer});channel.postMessage({kind:'decision',request,peer:r.peer,id,version:r.version,decision:action,spokenCompany:confirmation.spokenCompany})})
 }
 document.querySelectorAll('.profile').forEach(e=>e.addEventListener('click',()=>{reset();registry().clear()}))
 return{execute,reset,gate}
}
