// Speech is confirmation within an authenticated owner session, not biometric speaker identification.
export const normalizeApproval=(s:unknown)=>String(s||'').normalize('NFKD').replace(/\p{M}/gu,'').toLowerCase().replace(/&/g,' and ').replace(/[^\p{L}\p{N}]+/gu,' ').trim()
export function approvalCommand(text:string){
 const s=normalizeApproval(text).replace(/^friday /,'')
 if(/^(?:(?:no )?(?:cancel|reject)(?: it| that| this| this action| that action| this event| that event| this invoice| that invoice)?|stop|cancela(?:lo| eso| ese evento| esa factura)?|rechaza(?:lo| eso)?)$/.test(s))return{decision:'reject',company:''}
 const match=s.match(/^(?:(?:yes )?(?:i )?(?:approve|confirm)(?: it| that| this| this action| that action| this event| that event| this invoice| that invoice| this file| that file)?|(?:si )?(?:aprueba(?:lo| eso| ese evento| esa factura)?|confirma(?:lo| eso)?))(?: (?:for|para) (.+))?$/)
 return match?{decision:'approve',company:match[1]||''}:null
}
export class VoiceApprovalGate {
 private pending:any=null
 private reading=false
 private transcript=false
 private readyAt=0
 private audioId=''
 private audioTranscripts=new Set<string>()
 private speech:any=null
 private candidate:any=null
 private seen=new Set<string>()
 private clock:()=>number
 constructor(clock=()=>Date.now()){this.clock=clock}
 begin(review:any){this.reset();this.pending=review}
 reset(){this.pending=null;this.reading=false;this.transcript=false;this.readyAt=0;this.speech=null;this.candidate=null;this.audioId='';this.audioTranscripts.clear()}
 audioStart(id=''){if(this.pending&&!this.readyAt){this.reading=true;this.audioId=id;this.transcript=!!id&&this.audioTranscripts.has(id)}}
 audioTranscript(text:string,id=''){if(!this.pending||!text.trim())return;if(id)this.audioTranscripts.add(id);if(this.reading&&(!this.audioId||!id||this.audioId===id))this.transcript=true}
 audioStopped(id=''){if(this.reading&&this.transcript&&this.pending&&(!this.audioId||!id||this.audioId===id)){this.readyAt=this.clock();this.reading=false}}
 interrupted(){if(this.reading){this.reading=false;this.transcript=false;this.readyAt=0}}
 speechStarted(id:string){if(!id)return;this.speech={id,at:this.clock(),afterReadback:!!this.readyAt&&!this.reading};this.candidate=null}
 userTranscript(id:string,text:string){
  if(!this.pending||this.seen.has(id)||this.speech?.id!==id)return
  this.seen.add(id);if(this.seen.size>500)this.seen.delete(this.seen.values().next().value!)
  const command=approvalCommand(text)
  if(!command){this.reset();return}
  if(command.decision!=='reject'&&(!this.speech.afterReadback||this.speech.at<this.readyAt||this.clock()-this.readyAt>120000))return
  this.candidate={...command,at:this.clock(),id}
 }
 async waitAndConsume(id:string,decision:string){
  // Audio understanding can call a tool slightly before the asynchronous transcript completes.
  const deadline=this.clock()+1800,wallDeadline=Date.now()+1800
  while(this.pending?.id===id&&!this.candidate&&this.speech?.afterReadback&&this.clock()<deadline&&Date.now()<wallDeadline)await new Promise(r=>setTimeout(r,30))
  return this.consume(id,decision)
 }
 consume(id:string,decision:string){
  const p=this.pending,c=this.candidate
  if(!p||p.id!==id||!c||c.decision!==decision||this.clock()-c.at>20000||this.clock()>p.expiresAt)throw Error('No fresh explicit voice confirmation for this read-back review. Read the current review, then ask the owner to approve or cancel it.')
  if(decision==='approve'&&p.requiredSpokenCompany&&normalizeApproval(c.company)!==normalizeApproval(p.requiredSpokenCompany))throw Error('The production company must be spoken exactly as shown in the review.')
  this.reset();return{review:p,spokenCompany:c.company}
 }
}

export function handleApprovalTransportEvent(gate:VoiceApprovalGate,event:any){
 if(event.type==='output_audio_buffer.started')gate.audioStart(event.response_id||'')
 if(event.type==='output_audio_buffer.stopped')gate.audioStopped(event.response_id||'')
 if(event.type==='output_audio_buffer.cleared')gate.interrupted()
 if(event.type==='input_audio_buffer.speech_started')gate.speechStarted(event.item_id)
 if(event.type==='conversation.item.input_audio_transcription.completed')gate.userTranscript(event.item_id,event.transcript||'')
 if(event.type==='response.output_audio_transcript.done')gate.audioTranscript(event.transcript||'',event.response_id||'')
}
