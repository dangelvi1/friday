const {test}=require('node:test');const assert=require('node:assert/strict');const fs=require('node:fs/promises');const os=require('node:os');const path=require('node:path');const {checkGoogleCalendars}=require('./Check-Google-Calendars.cjs');
async function fixture(fn){const dir=await fs.mkdtemp(path.join(os.tmpdir(),'friday-calendar-check-'));try{await fs.writeFile(path.join(dir,'gmail-credentials.json'),JSON.stringify({installed:{client_id:'synthetic-client',client_secret:'synthetic-secret'}}));await fs.writeFile(path.join(dir,'gmail-token.json'),JSON.stringify({refresh_token:'synthetic-token',scope:'https://www.googleapis.com/auth/gmail.readonly'}));await fn(dir)}finally{await fs.rm(dir,{recursive:true,force:true})}}
function fake({gmailFailure=false,calendarFailure=false,repeated=false}={}) {
 let pages=0;
 return {
  auth:{OAuth2:class {setCredentials(){}}},
  gmail:()=>({users:{getProfile:async()=>{
   if(gmailFailure) throw {response:{status:401},secret:'synthetic-token'};
   return {data:{emailAddress:'salvador@example.test'}};
  }}}),
  calendar:()=>({calendarList:{list:async params=>{
   if(calendarFailure) throw {response:{status:403,data:{error:{errors:[{reason:'insufficientPermissions'}]}}},message:'synthetic-secret'};
   pages++;
   if(pages===1) return {data:{items:[{id:'private-id',summary:'Personal',accessRole:'owner',primary:true}],nextPageToken:'next'}};
   assert.equal(params.pageToken,'next');
   return {data:{items:[{id:'business-id',summary:'Nationwide',accessRole:'reader'}],...(repeated?{nextPageToken:'next'}:{})}};
  }}})
 };
}

test('complete scoped calendar pages; no event methods used; secrets and IDs suppressed',()=>fixture(async dir=>{const before=await fs.readFile(path.join(dir,'gmail-token.json'),'utf8');const r=await checkGoogleCalendars(dir,fake());assert.equal(r.gmail.status,'connected');assert.equal(r.gmail.accountHint,'sa***@example.test');assert.equal(r.calendar.completeRead,true);assert.equal(r.calendars.length,2);assert.equal(r.calendars[0].calendarRoleAllowsEdits,true);assert.equal(r.calendars[1].calendarRoleAllowsEdits,false);assert.equal(r.savedCalendarScopePresent,false);assert.doesNotMatch(JSON.stringify(r),/synthetic-secret|synthetic-token|private-id|business-id/);assert.equal(await fs.readFile(path.join(dir,'gmail-token.json'),'utf8'),before)}));
test('working Gmail is not reported as calendar connection; forbidden error redacted',()=>fixture(async dir=>{const r=await checkGoogleCalendars(dir,fake({calendarFailure:true}));assert.equal(r.gmail.status,'connected');assert.equal(r.calendar.status,'not verified');assert.equal(r.calendar.status=== 'connected',false);assert.equal(r.calendar.reason,'insufficientPermissions');assert.doesNotMatch(JSON.stringify(r),/synthetic-secret/)}));
test('Calendar listing is checked independently of Gmail profile scope',()=>fixture(async dir=>{const r=await checkGoogleCalendars(dir,fake({gmailFailure:true}));assert.equal(r.gmail.status,'not verified');assert.equal(r.calendar.completeRead,true);assert.doesNotMatch(JSON.stringify(r),/synthetic-token/)}));
test('repeated page fails closed without publishing partial calendar choices',()=>fixture(async dir=>{const r=await checkGoogleCalendars(dir,fake({repeated:true}));assert.equal(r.calendar.completeRead,false);assert.deepEqual(r.calendars,[])}));
test('missing private config returns safe instructions without invoking clients',async()=>{const r=await checkGoogleCalendars('/tmp/nonexistent-friday-google-private-config',fake());assert.match(r.configuration,/missing/);assert.equal(r.calendar.status,'not checked')});
