# FRIDAY Google Calendar connection check

Read-only diagnostic for the existing PC-hosted FRIDAY. Not a calendar integration installer. No application, config, token or database files are changed. No events are read, created, edited or deleted. No messages are sent. The existing saved OAuth token may refresh in memory as part of the read; this checker does not save it or request extra permissions.

Extract under S:\AI\Fixing-Files-Folder\FRIDAY-Calendar-Connection-Check, then run from any PowerShell location:

```powershell
$folder = 'S:\AI\Fixing-Files-Folder\FRIDAY-Calendar-Connection-Check'
$checks = @(Get-ChildItem -LiteralPath $folder -Filter 'Check-Google-Calendars.cjs' -File -Recurse -ErrorAction Stop)
if ($checks.Count -ne 1) { throw 'Expected exactly one calendar checker. Check the extracted folder.' }
node $checks[0].FullName 'S:\AI\friday-ai'
```

Uses the existing project's installed googleapis dependency and gmail-credentials.json / gmail-token.json. No npm install or server restart required. Never upload these private files. Output masks the connected Gmail address, lists accessible calendar names/roles/time zones, and reports Gmail and Calendar results separately. It does not print tokens, secrets, calendar IDs or event data. Calendar names may still be private; redact them before sharing if needed.

Interpretation:
- Gmail connected plus Calendar not verified means Gmail access alone has not established Calendar access. An old token may lack Calendar scope, the Calendar API may be disabled, or sharing may deny access. Output does not claim which cause without evidence.
- Calendar listing connected proves the saved Google authorization can list calendars at that time. It does not mean FRIDAY has calendar voice tools, or prove event read/write scopes. Owner/writer is an ACL role, distinct from OAuth scopes.
- The current source has Gmail tools but no registered Calendar API/voice tools. Its prompt describes calendar tools as future work. The sanitized cloud copy omits the private Google config, so no live connection was tested here.

Salvador confirmed the office uses a shared Google Calendar. The intended destinations are Personal and the existing Nationwide shared calendar, with explicit selection so personal items remain private.

Smallest compatible implementation:
1. Add a separate modular calendar service, retaining existing Gmail credentials/scopes and tools. Google Calendar requires its API and appropriate OAuth consent. Do not overwrite the working Gmail token to request Calendar permissions.
2. Owner-only connection/calendar selection maps Personal and Nationwide to actual account/calendar IDs. Shared Google Calendar can use one authorized account if it has office-calendar write access; another Google account needs a separately bound authorization. Outlook/365 requires its own Microsoft integration. Do not create a duplicate Nationwide calendar as a workaround.
3. Add read/list and owner-reviewed event creation tools to the existing Realtime conversation, with visible calendar/event preview and pointer. Confirm calendar, date, time zone and attendees before committing; ambiguous destination must be clarified. Use durable request receipts to avoid duplicate events after uncertain requests.
4. Write directly to the selected real shared calendar so existing authorized office users see the same event. Do not copy personal events into Nationwide or expose the personal calendar through Sara/employee access. Creating invites/sending updates remains explicitly approved.
5. Test timezone/DST/all-day dates, scope/isolation, ambiguous names, cancelled approval, partial calendar lists, stale changes and duplicate/uncertain submission. Then separately test owner-PC OAuth, actual calendar permissions, office visibility and microphone use.

Five automated synthetic checks passed. Run them with `node --test Check-Google-Calendars.test.cjs` from the extracted folder. Cloud validation covers synthetic clients only, including independent Gmail/Calendar failures, paginated listing, repeated-page rejection and suppression of raw credential-bearing errors. Live Google access requires running this checker on the owner PC.
