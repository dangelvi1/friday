'use strict';
// Read-only owner-PC diagnostic. No event reads/writes, file writes, OAuth consent or token logging.
const fs = require('node:fs/promises');
const path = require('node:path');
const {createRequire} = require('node:module');
function safeError(error) {
  const status = Number(error?.response?.status || error?.code);
  const reason = error?.response?.data?.error?.errors?.[0]?.reason;
  const message = status === 401 ? 'Saved authorization was rejected; reconnect through the approved OAuth flow.'
    : status === 403 ? 'Access denied: check Calendar API enablement, granted scopes and calendar sharing.'
    : status === 429 ? 'Google rate limit; check again later.'
    : status >= 500 ? 'Google service unavailable; check again later.'
    : 'Check network access and the saved Google authorization. No raw error details were printed.';
  return {httpStatus: Number.isFinite(status) ? status : null, reason: ['insufficientPermissions','accessNotConfigured','forbidden','authError','rateLimitExceeded'].includes(reason) ? reason : null, message};
}
function maskEmail(email) {
  if (typeof email !== 'string' || !email.includes('@')) return 'Not reported';
  const [name,domain] = email.split('@');
  return name.slice(0,2)+'***@'+domain;
}
async function checkGoogleCalendars(projectPath, suppliedGoogle) {
  projectPath = path.resolve(projectPath);
  const report = {mode:'READ ONLY — no events read or changed; no files changed',gmail:{status:'not checked'},calendar:{status:'not checked'},savedCalendarScopePresent:false,calendars:[]};
  let credentials,token;
  try {
    [credentials,token] = await Promise.all(['gmail-credentials.json','gmail-token.json'].map(name => fs.readFile(path.join(projectPath,name),'utf8').then(JSON.parse)));
  } catch {
    report.configuration = 'Saved Gmail credential/token files are missing, unreadable or invalid in the selected project folder. Do not upload them.';
    return report;
  }
  const key = credentials.web || credentials.installed;
  if (!key?.client_id || !key?.client_secret || !token.refresh_token) {
    report.configuration = 'Saved files lack the client settings or refresh token expected by the existing Gmail helper. Do not upload their contents.';
    return report;
  }
  const scopes = new Set(String(token.scope || '').split(/\s+/).filter(Boolean));
  report.savedCalendarScopePresent = [...scopes].some(scope => scope.startsWith('https://www.googleapis.com/auth/calendar'));
  report.savedScopeNote = 'Saved scope metadata is a hint, not proof of current access. Calendar listing below is the live read test. No event-write capability is tested.';
  let google,auth;
  try {
    google = suppliedGoogle || createRequire(path.join(projectPath,'package.json'))('googleapis').google;
    auth = new google.auth.OAuth2(key.client_id,key.client_secret,key.redirect_uris?.[0]);
    auth.setCredentials(Object.fromEntries(['access_token','refresh_token','scope','token_type','expiry_date'].filter(k => token[k] !== undefined).map(k => [k,token[k]])));
  } catch {
    report.configuration = 'Could not load the project Google API client. Run from the existing FRIDAY installation with its installed dependencies.';
    return report;
  }
  try {
    const response = await google.gmail({version:'v1',auth}).users.getProfile({userId:'me'},{timeout:15000,retry:false});
    report.gmail = {status:'connected',accountHint:maskEmail(response.data.emailAddress)};
  } catch(error) { report.gmail = {status:'not verified',...safeError(error)}; }
  try {
    const calendar = google.calendar({version:'v3',auth});
    const rows = [], seen = new Set();
    let pageToken;
    do {
      if (seen.size >= 100 || pageToken && seen.has(pageToken)) throw Error('Incomplete calendar listing');
      if (pageToken) seen.add(pageToken);
      const response = await calendar.calendarList.list({maxResults:250,showHidden:true,showDeleted:false,...(pageToken ? {pageToken} : {})},{timeout:15000,retry:false});
      if (!response.data || response.data.items !== undefined && !Array.isArray(response.data.items)) throw Error('Invalid listing');
      for (const item of response.data.items || []) {
        if (!item.id || !item.accessRole) throw Error('Incomplete calendar entry');
        rows.push({name:item.summaryOverride || item.summary || '(unnamed calendar)',primary:!!item.primary,accessRole:item.accessRole,calendarRoleAllowsEdits:['owner','writer'].includes(item.accessRole),timeZone:item.timeZone || 'not reported'});
      }
      pageToken = response.data.nextPageToken;
    } while(pageToken);
    report.calendar = {status:'calendar listing connected',completeRead:true,count:rows.length,permissionsNote:'Owner/writer role permits calendar edits, but this check does not prove the OAuth grant permits event writes. Reader/freeBusyReader cannot create events. Calendar names are for display; integration must bind selected calendar IDs, not guess from names.'};
    report.calendars = rows;
  } catch(error) {
    report.calendar = {status:'not verified',completeRead:false,...safeError(error)};
    report.calendars = [];
  }
  return report;
}
module.exports = {checkGoogleCalendars,safeError};
if (require.main === module) {
  checkGoogleCalendars(process.argv[2] || process.cwd()).then(report => console.log(JSON.stringify(report,null,2))).catch(() => {console.error('Diagnostic could not complete. No raw credential or error details were printed.');process.exitCode=1;});
}
