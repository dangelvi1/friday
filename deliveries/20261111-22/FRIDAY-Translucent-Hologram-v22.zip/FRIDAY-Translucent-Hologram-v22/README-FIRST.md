# FRIDAY v22 — Moving Hologram & Direct Calendars — November 11, 2026

Implements Salvador’s approved cyan/pink/violet translucent feminine front-facing design using original local artwork. Voice home now has a generous face panel and a responsive two-column welcome on desktop, stacked on phones. Click the same original face button to connect/disconnect and speak naturally. /dashboard remains the direct workspace address. No new microphone, realtime session, avatar account, dependency, camera or service is added.

## Install

Disconnect FRIDAY, stop the backend with Ctrl+C, and extract this ZIP into S:\AI\Fixing-Files-Folder. The ZIP contains its own FRIDAY-Translucent-Hologram-v22 folder. Do not extract it into a second folder with the same name. Run this full path (not a relative .\ command):

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File 'S:\AI\Fixing-Files-Folder\FRIDAY-Translucent-Hologram-v22\Install-Translucent-Hologram.ps1' -ProjectPath 'S:\AI\friday-ai'
if ($LASTEXITCODE -ne 0) { throw 'Installer failed. Do not continue.' }
Set-Location 'S:\AI\friday-ai'
npm run build
if ($LASTEXITCODE -ne 0) { throw 'Build failed. Do not continue.' }
npm run server
```

Keep npm run dev in the other terminal, hard-refresh https://localhost:5173/ with Ctrl+F5, close old review tabs, then reconnect. On your existing Cloudflare hostname use https://friday.dangelvi.com/ and /dashboard. No tunnel/DNS or credentials are changed. ExecutionPolicy Bypass affects the child installer process only. Existing owner password works.

## Calendar directly in your dashboard

Open /dashboard → Calendars. The saved Personal and Nationwide destinations are read into a direct calendar view, alongside the existing Google Calendar links. Choose Personal + Nationwide, Personal, or Nationwide. Use Month or Agenda, previous/next month, This month, and Refresh view. Phone-width screens initially use Agenda. Event labels retain their destination; times use the selected saved calendar time zone. All-day and overnight events keep correct day boundaries, including daylight-saving changes.

Opening Calendars reads the displayed month for the mapped destinations. The month view is refreshed on demand, not a continuous real-time subscription. Click an event to read/focus it in its exact original calendar, then use existing modify/cancel voice commands and reviews. Successful writes invalidate the displayed grid until refresh. Owner lock or mapping change clears private calendar results; failed/incomplete reads do not display partial combined data. Existing unsaved event drafts and Google links are retained. No Google iframe, extra login, public calendar sharing or new OAuth scope is required by this view.

Voice: “Show both my calendars for November” uses calendar_view with month YYYY-MM and viewDestination both; personal and nationwide are also accepted. Existing schedule questions, event creation/edit/cancellation, contextual approval and visible pointer remain.

## iPhone Chrome and other devices

Use https://friday.dangelvi.com/ for the voice face and https://friday.dangelvi.com/dashboard for the workspace. localhost on an iPhone refers to that phone, so do not use the PC’s localhost address there. Keep the PC, backend/dev server and existing Cloudflare tunnel running. Sign in with the existing owner password, tap the face and allow Chrome’s microphone permission. Safari is optional; it is not required by this update. On supported iOS versions use Chrome’s Share menu → Add to Home Screen if you want a shortcut.

Calendar and voice APIs use the same HTTPS app origin, so the phone does not need backend ports or secrets. No DNS/tunnel/port-forwarding changes are made by this package. Existing legacy PC-agent browser/media commands still target the PC-only loopback agent and are not claimed as newly working on a phone. Automated mobile viewport checks use Chromium; a live iPhone Chrome microphone/Cloudflare test still needs your device.

## House devices

See SMART-HOME-SETUP.md for the concrete connection plan covering WiZ, Hue, Lutron, Resideo/Honeywell, Ring cameras and Alarm, SmartThings appliances, and Govee. These integrations are not installed by this visual/calendar update. Home Assistant is separate from Echo Show/Alexa and must first be set up on the local network. The Ring Alarm route and individual model capabilities still need verification.

## What moves

The translucent face has blinking, subtle brow/lip/jaw deformation, gentle head motion, neural light pulses and an audio trace. Mouth movement follows the existing assistant reply audio; silence and interruption close it. This is stylized amplitude-reactive artwork, not generated video or phoneme-level facial synthesis. Classic and glamour mesh looks also remain available. No live-microphone or live-provider result is claimed by this release.

The approved Translucent woman look is selected when first opening this version, retaining the previous pause preference; an old Digital portrait style initially becomes Blue hologram to reveal the approved design. After a new cosmetic choice is saved, that choice persists on reload. Glamour woman, Classic hologram, amber color and Digital portrait remain selectable. The existing original portrait is still used for Digital portrait mode. Missing new artwork falls back to the local mesh; it must not break voice or open a microphone.

Voice commands: “Use the translucent hologram,” “Use the classic face,” “Pause face animation,” or “Open my dashboard.” Face controls are also in dashboard Settings. Silent expression preview is available while disconnected and starts no microphone or provider call. Pause, reduced motion, background/owner-lock lifecycle and local-only audio analysis remain. Appearance preferences contain version, look, style and paused only.

## Quick owner check

1. Hard-refresh voice home: the front-facing face appears. Try Silent expression preview while disconnected.
2. Start the original voice connection, sign in if needed, and ask a question. Check reply movement and interrupt it naturally.
3. Open /dashboard and return with Voice home: the same button/session remains; check phone-width layout too.
4. Pause animation and try reduced motion. The voice itself should continue normally.

## Compatibility, backup and restore

Cumulative package supports both voice families of v12–v21, preserves the installed Crosslist family, and rejects unknown source edits before copying. It validates package/baseline hashes, verifies backups, rechecks targets and rolls back attempted copies on failure. Keep the printed backup path. With the backend stopped, run that backup folder’s Restore-Translucent-Hologram.ps1 by its full path using process-scoped ExecutionPolicy Bypass. Restore refuses later source edits. AGENTS-MERGE-PROPOSAL.md is proposed text only; no existing AGENTS.md is overwritten.

This update changes appearance and adds a read-only calendar grid with a natural-voice display action. Existing approvals, private company/owner scope, Personal/Nationwide calendar cards, phone bridge, Document Analysis, Shopify receipts and all other modules are preserved. No call is placed and appointment calling/calendar handoff is not implemented by this visual release. No live accounting, calendar or Shopify records are read or changed for cloud validation. Installed calendar views use your already authorized Google connection when you open or refresh them. Earlier unresolved Shopify receipt guards are retained. Private configuration, package/TLS/Vite files and provider credentials are excluded.

Automated validation: frontend TypeScript; standalone Vite build; focused browser/audio, actual-dashboard and calendar suites (final counts in VALIDATION.md); package hashes, secret-pattern scan, and all 18 compatible source/verified-backup/guarded-restore models plus preserved v12 frontend typecheck. Synthetic Web Audio is used rather than a live microphone. Windows PowerShell execution and live owner-device audio/Cloudflare access remain local checks. Historical guides describe earlier features and are not proof of newly live-tested integrations.
