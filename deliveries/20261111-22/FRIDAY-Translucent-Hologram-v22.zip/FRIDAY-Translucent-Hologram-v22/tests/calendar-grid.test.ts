import test from 'node:test'
import assert from 'node:assert/strict'
import {calendarDay,calendarMonthRange,eventCalendarDays} from '../src/calendar-grid'
test('Calendar months use the saved calendar time zone across daylight saving and leap years',()=>{
 assert.deepEqual(calendarMonthRange('2026-11','America/New_York'),{from:'2026-11-01T04:00:00.000Z',to:'2026-12-01T05:00:00.000Z'})
 const march=calendarMonthRange('2026-03','America/New_York');assert.equal((Date.parse(march.to)-Date.parse(march.from))/3600000,31*24-1)
 assert.equal(calendarMonthRange('2028-02','UTC').to,'2028-03-01T00:00:00.000Z')
 assert.throws(()=>calendarMonthRange('2026-13','UTC'));assert.throws(()=>calendarMonthRange('2026-02','invalid-zone'))
})
test('All-day end dates are exclusive, multi-day events span cells, and timed events use calendar rather than browser dates',()=>{
 assert.deepEqual(eventCalendarDays({start:{date:'2026-11-11'},end:{date:'2026-11-13'}},'America/New_York','2026-11'),['2026-11-11','2026-11-12'])
 assert.deepEqual(eventCalendarDays({start:{dateTime:'2026-11-12T04:00:00Z'},end:{dateTime:'2026-11-12T05:00:00Z'}},'America/New_York','2026-11'),['2026-11-11'])
 assert.equal(calendarDay('2026-11-12T02:00:00Z','America/New_York'),'2026-11-11')
 assert.equal(eventCalendarDays({start:{date:'2028-02-01'},end:{date:'2028-03-01'}},'UTC','2028-02').length,29)
 assert.deepEqual(eventCalendarDays({status:'cancelled',start:{date:'2026-11-11'},end:{date:'2026-11-12'}},'UTC','2026-11'),[])
})
