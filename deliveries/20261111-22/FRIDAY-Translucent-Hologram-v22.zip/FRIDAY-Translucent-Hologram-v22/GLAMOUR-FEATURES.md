Historical v21 reference. Use README-FIRST.md for installation.

# FRIDAY Glamour Hologram v21 — November 11, 2026

Adds a clearly adult, late-20s-inspired Glamour woman appearance to the working hologram: softer/narrower jaw, refined cheeks/nose, fuller lip contours, softened brows, a warmer resting smile and shoulder-length holographic hair. Blue and amber colors, reply-audio mouth movement, blinking and expressions remain. Classic hologram preserves the earlier face. This is local cosmetic styling only; voice/personality, microphone, authentication and approvals are unchanged.

## Install

Disconnect FRIDAY and stop backend with Ctrl+C. Extract into a fresh folder, then run the actual full path:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File 'S:\AI\Fixing-Files-Folder\FRIDAY-Glamour-Hologram-v21\Install-Glamour-Hologram.ps1' -ProjectPath 'S:\AI\friday-ai'
if ($LASTEXITCODE -ne 0) { throw 'Installer failed. Do not continue.' }
Set-Location 'S:\AI\friday-ai'
npm run build
if ($LASTEXITCODE -ne 0) { throw 'Build failed. Do not continue.' }
npm run server
```

Use the actual extracted installer path or the complete verified download/extract/install command supplied with this release. Keep npm run dev in the other terminal, Ctrl+F5 https://localhost:5173/ and reconnect voice. ExecutionPolicy Bypass affects only the child installer process. Existing owner password works. The existing bundle warning is informational.

## Choose the look

On voice home, choose Face look → Glamour woman, then Face style → Blue hologram or Amber hologram. Glamour is the initial default if this browser has no saved look preference; existing color and pause preferences remain. Choose Classic hologram whenever you prefer the earlier face. Digital portrait retains its previous picture; the new look applies to the rendered holograms.

Silent expression preview is available while disconnected. It starts no microphone, voice session or provider request. Connect the existing face button for natural voice; the reply-audio mouth movement and interruption behavior remain. Pause/reduced motion/portrait fallback and Enable speech animation retain their existing functions. While in the dashboard, these controls remain in Settings → FRIDAY face & expressions.

Voice: Use the glamour hologram; Use the classic face; Use the amber hologram. The separate look parameter selects glamour/classic while preserving color and motion. These actions are cosmetic, not permission for any business change. The adult appearance is a fictional style, not a real person's face or biometric/age inference.

## Preserved behavior and compatibility

Cumulative update supports v12/v13 and both source families of v14/v15/v16/v17/v18/v19/v20. Preserves the installed Crosslist family, the original realtime session, exact reply audio element/analyser, owner/company isolation, all reviews and the separated Nationwide/Sara system. No new npm dependency, camera, avatar account, audio capture or inference request. Cosmetic browser preference now includes a validated look enum alongside color/pause; no secrets/transcripts/audio are stored.

Voice home and dashboard addresses remain https://localhost:5173/ and https://localhost:5173/dashboard, or the existing confirmed Cloudflare hostname https://friday.dangelvi.com/ and /dashboard on another device. No tunnel/DNS/OAuth changes or new public reachability claim. Personal/Nationwide calendar cards, report/receipt controls and prior safeguards remain. No private credentials/configuration/TLS/Vite/package files or AGENTS are replaced. No native Shopify/QuickBooks/Calendar action or uncertain-write retry is performed by this update.

## Backup and restore

Installer validates supported package/baseline hashes, verifies backups, rechecks targets and rolls back attempted copies on failure. Unknown edits stop before source changes. Keep the printed backup path. Stop backend and run that backup folder's Restore-Glamour-Hologram.ps1 by its full path with process-scoped ExecutionPolicy Bypass. Restore refuses later source edits and retains private data. AGENTS-MERGE-PROPOSAL.md is proposed text only. The generic mesh's original Apache license/provenance is retained in public/licenses.

Validation: the focused appearance/audio/actual-dashboard suites passed 21 reported entries, covering both looks, invalid-look rejection, real synthetic audio mouth movement and silence/interruption closing, playback/track preservation, classic/portrait fallback, reduced motion, cosmetic storage, original voice control and responsive dashboard behavior. Frontend TypeScript, standalone build and the compatible profile/package backup/restore models are recorded with delivery. Earlier broad regression history is in the historical feature guides and is not claimed as rerun for this cosmetic update. Windows installation and live owner-device voice timing remain local checks.
