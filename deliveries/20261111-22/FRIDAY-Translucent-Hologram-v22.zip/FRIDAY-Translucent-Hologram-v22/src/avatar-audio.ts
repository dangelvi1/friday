// Local, read-only analysis of the existing assistant output. Never creates a microphone stream,
// connects to the speakers, records samples, sends audio, or stops a caller-owned media track.
export function createReplyAnalyser(){
 let element:HTMLAudioElement|null=null,context:AudioContext|null=null,source:MediaStreamAudioSourceNode|null=null,analyser:AnalyserNode|null=null,stream:MediaStream|null=null,enabled=true,epoch=0,failed=false,unlocking:Promise<void>|null=null
 let samples:Float32Array<ArrayBuffer>=new Float32Array(512)
 function disconnectSource(){source?.disconnect();analyser?.disconnect();source=null;analyser=null;stream=null;samples.fill(0)}
 async function unlock(){if(!enabled)return;if(unlocking)return unlocking;const g=epoch;unlocking=(async()=>{try{if(!context){const Constructor=window.AudioContext||(window as any).webkitAudioContext;if(!Constructor)throw Error('Audio analysis unavailable');context=new Constructor()}if(context!.state==='suspended')await context!.resume();if(g!==epoch)return;failed=false}catch{if(g===epoch)failed=true}})().finally(()=>unlocking=null);return unlocking}
 function attach(audio:HTMLAudioElement|null){disconnectSource();element=audio;failed=false}
 function sample(){if(!enabled||!element||element.paused||element.muted||element.volume===0||context?.state!=='running')return 0;const current=element.srcObject;if(!(current instanceof MediaStream)||!current.getAudioTracks().some(t=>t.readyState==='live'&&t.enabled&&!t.muted)){disconnectSource();return 0}try{if(current!==stream){disconnectSource();source=context.createMediaStreamSource(current);analyser=context.createAnalyser();analyser.fftSize=512;analyser.smoothingTimeConstant=0;source.connect(analyser);stream=current}analyser!.getFloatTimeDomainData(samples);let sum=0;for(const x of samples)sum+=x*x;const rms=Math.sqrt(sum/samples.length);return Math.max(0,Math.min(1,(rms-.004)*7.5))}catch{failed=true;disconnectSource();return 0}}
 function clear(){epoch++;disconnectSource();element=null;failed=false;const old=context;context=null;unlocking=null;void old?.close().catch(()=>{})}
 function setEnabled(value:boolean){enabled=value;if(!value){disconnectSource();const old=context;context=null;epoch++;unlocking=null;void old?.close().catch(()=>{})}}
 return{unlock,attach,sample,clear,setEnabled,state:()=>({enabled,linked:!!stream&&context?.state==='running',available:!failed,contextState:context?.state||'not_started'}),destroy:clear}
}
