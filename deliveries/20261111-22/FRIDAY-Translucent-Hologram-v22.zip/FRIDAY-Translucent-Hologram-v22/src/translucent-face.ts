// Original local artwork. Small texture deformations use the existing reply audio.
type Pose={mouth:number;blink:number;brow:number;smile:number;yaw:number;pitch:number;tilt:number}
type Point={x:number;y:number}
const bell=(n:number,c:number,w:number)=>Math.exp(-(((n-c)/w)**2))
export function translucentPoint(u:number,v:number,pose:Pose){
 const lip=bell(u,.49,.10)*bell(v,.622,.038),jaw=bell(u,.49,.16)*bell(v,.69,.06)
 const eyes=bell(u,.39,.065)+bell(u,.61,.065),eye=eyes*bell(v,.41,.035),brow=eyes*bell(v,.35,.025)
 return{x:u,y:v+Math.tanh((v-.622)*120)*pose.mouth*.010*lip+pose.mouth*.005*jaw+(.41-v)*pose.blink*.96*eye-pose.brow*.006*brow-pose.smile*.006*bell(Math.abs(u-.49),.065,.03)*bell(v,.622,.027)}
}
function triangle(ctx:CanvasRenderingContext2D,image:HTMLImageElement,src:Point[],dst:Point[]){
 const sx1=src[1].x-src[0].x,sy1=src[1].y-src[0].y,sx2=src[2].x-src[0].x,sy2=src[2].y-src[0].y,den=sx1*sy2-sx2*sy1
 const dx1=dst[1].x-dst[0].x,dy1=dst[1].y-dst[0].y,dx2=dst[2].x-dst[0].x,dy2=dst[2].y-dst[0].y
 const a=(dx1*sy2-dx2*sy1)/den,b=(dy1*sy2-dy2*sy1)/den,c=(dx2*sx1-dx1*sx2)/den,d=(dy2*sx1-dy1*sx2)/den
 ctx.save();ctx.beginPath();const cx=(dst[0].x+dst[1].x+dst[2].x)/3,cy=(dst[0].y+dst[1].y+dst[2].y)/3
 for(let n=0;n<3;n++){const p=dst[n],radius=Math.hypot(p.x-cx,p.y-cy)||1,x=p.x+(p.x-cx)/radius*.8,y=p.y+(p.y-cy)/radius*.8;if(n)ctx.lineTo(x,y);else ctx.moveTo(x,y)}ctx.closePath();ctx.clip()
 ctx.transform(a,b,c,d,dst[0].x-a*src[0].x-c*src[0].y,dst[0].y-b*src[0].x-d*src[0].y);ctx.drawImage(image,0,0);ctx.restore()
}
export function drawTranslucentFace(ctx:CanvasRenderingContext2D,w:number,h:number,time:number,pose:Pose,moving:boolean,image:HTMLImageElement,amber=false,phase='idle'){
 ctx.clearRect(0,0,w,h);const size=Math.min(w,h)*.98,x=(w-size)/2,y=(h-size)/2+(moving?Math.sin(time*.55)*h*.003:0)
 ctx.save();ctx.translate(x+size/2,y+size/2);ctx.rotate(moving?pose.tilt+Math.sin(time*.34)*.004:0);ctx.scale(1+(moving?pose.yaw*.045:0),1+(moving?pose.pitch*.045:0));ctx.translate(-size/2,-size/2)
 if(amber)ctx.filter='hue-rotate(150deg)';ctx.drawImage(image,0,0,size,size)
 // Remesh small eye/brow and mouth patches, rather than the entire portrait.
 function patch(left:number,top:number,width:number,height:number){
  const cols=20,rows=16;ctx.save();ctx.beginPath();ctx.rect(left*size,top*size,width*size,height*size);ctx.clip();ctx.clearRect(left*size,top*size,width*size,height*size)
  const points=Array.from({length:rows+1},(_,j)=>Array.from({length:cols+1},(_,i)=>{const u=left+width*i/cols,v=top+height*j/rows,p=translucentPoint(u,v,pose),fade=Math.sin(i/cols*Math.PI)**2*Math.sin(j/rows*Math.PI)**2;return{src:{x:u*image.naturalWidth,y:v*image.naturalHeight},dst:{x:u*size,y:(v+(p.y-v)*fade)*size}}}))
  for(let j=0;j<rows;j++)for(let i=0;i<cols;i++){const a=points[j][i],b=points[j][i+1],c=points[j+1][i],d=points[j+1][i+1];triangle(ctx,image,[a.src,b.src,c.src],[a.dst,b.dst,c.dst]);triangle(ctx,image,[b.src,d.src,c.src],[b.dst,d.dst,c.dst])}ctx.restore()
 }
 if(moving&&(pose.blink>.001||pose.brow!==0))patch(.24,.29,.51,.22)
 if(moving&&(pose.mouth>.001||pose.smile>.1))patch(.30,.55,.39,.22)
 if(moving&&pose.mouth>.04){ctx.beginPath();ctx.ellipse(size*.49,size*.622,size*.061,size*.0045*pose.mouth,0,0,Math.PI*2);ctx.fillStyle=`rgba(4,16,35,${Math.min(.7,pose.mouth*.8)})`;ctx.fill()}
 ctx.restore()
 if(moving){ctx.save();ctx.globalCompositeOperation='screen';const nodes=[[.35,.22],[.5,.17],[.66,.29],[.32,.50],[.67,.58],[.51,.82]];for(let n=0;n<nodes.length;n++){const[a,b]=nodes[n],pulse=(1+Math.sin(time*1.5+n*1.7))/2;ctx.beginPath();ctx.arc(x+a*size,y+b*size,size*(.0015+pulse*.0015),0,Math.PI*2);ctx.fillStyle=n%2?`rgba(236,130,246,${pulse*.65})`:`rgba(139,239,255,${pulse*.7})`;ctx.fill()}ctx.restore()}
 ctx.save();ctx.strokeStyle=amber?'rgba(255,196,118,.65)':phase==='thinking'?'rgba(231,151,255,.7)':'rgba(115,225,255,.6)';ctx.lineWidth=1;ctx.beginPath();for(let n=0;n<=120;n++){const t=n/120,xx=w*(.18+.64*t),energy=.003+pose.mouth*.018+(phase==='listening'?.003:0),yy=h*.94+Math.sin(t*32+(moving?time*3:0))*Math.sin(t*Math.PI)*h*energy;if(n)ctx.lineTo(xx,yy);else ctx.moveTo(xx,yy)}ctx.stroke();ctx.restore()
}
