type Destination='personal'|'nationwide'
type Options={read:(destination:Destination,from:string,to:string)=>Promise<any>;select:(destination:Destination,id:string,from:string,to:string)=>Promise<any>;run:(fn:()=>Promise<any>)=>any;onLoaded?:()=>void}
export function calendarDay(value:string,timeZone:string){return new Intl.DateTimeFormat('en-CA',{timeZone,year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date(value))}
function midnight(day:string,zone:string){
 const target=Date.parse(day+'T00:00:00Z');let value=target
 for(let n=0;n<5;n++){const p=Object.fromEntries(new Intl.DateTimeFormat('en-CA',{timeZone:zone,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'}).formatToParts(new Date(value)).map(p=>[p.type,p.value]));const wall=Date.parse(`${p.year}-${p.month}-${p.day}T${p.hour}:${p.minute}:${p.second}Z`),next=value+target-wall;if(next===value)return new Date(value).toISOString();value=next}
 throw Error('Could not resolve this calendar month in its time zone.')
}
export function calendarMonthRange(month:string,zone:string){
 if(!/^\d{4}-(?:0[1-9]|1[0-2])$/.test(month)||Number(month.slice(0,4))<1900||Number(month.slice(0,4))>2100)throw Error('Choose a month between 1900 and 2100.')
 const [year,m]=month.split('-').map(Number),next=new Date(Date.UTC(year,m,1)).toISOString().slice(0,10)
 return{from:midnight(month+'-01',zone),to:midnight(next,zone)}
}
export function eventCalendarDays(event:any,zone:string,month:string){
 if(event.status==='cancelled')return[]
 const start=event.start?.date|| (event.start?.dateTime?calendarDay(event.start.dateTime,zone):''),end=event.end?.date?new Date(Date.parse(event.end.date+'T00:00:00Z')-86400000).toISOString().slice(0,10):event.end?.dateTime?calendarDay(new Date(Date.parse(event.end.dateTime)-1).toISOString(),zone):start
 if(!/^\d{4}-\d{2}-\d{2}$/.test(start)||!/^\d{4}-\d{2}-\d{2}$/.test(end))return[]
 const days:string[]=[];const [year,m]=month.split('-').map(Number),count=new Date(Date.UTC(year,m,0)).getUTCDate();for(let n=1;n<=count;n++){const day=month+'-'+String(n).padStart(2,'0');if(day>=start&&day<=end)days.push(day)}return days
}
export function createCalendarGrid(options:Options){
 const element=document.createElement('section');element.id='calendarDashboardView';element.className='calendar-dashboard-view'
 element.innerHTML=`<header><div><h3>Your calendar</h3><p id="calendarGridZone"></p></div></header><div class="calendar-grid-toolbar"><label>Show<select id="calendarGridDestination"><option value="both">Personal + Nationwide</option><option value="personal">Personal</option><option value="nationwide">Nationwide</option></select></label><label>Month<input id="calendarGridMonth" type="month" aria-label="Calendar month"></label><label>View<select id="calendarGridMode"><option value="month">Month</option><option value="agenda">Agenda</option></select></label><button id="calendarGridPrevious" aria-label="Previous month">←</button><button id="calendarGridToday">This month</button><button id="calendarGridNext" aria-label="Next month">→</button><button id="calendarGridRefresh">Refresh view</button></div><p id="calendarGridStatus" role="status">Sign in and save your calendar destinations to see events here.</p><div id="calendarGridContent"></div>`
 const $=<T extends HTMLElement=HTMLElement>(id:string)=>element.querySelector<T>('#'+id)!,month=$<HTMLInputElement>('calendarGridMonth'),destination=$<HTMLSelectElement>('calendarGridDestination'),mode=$<HTMLSelectElement>('calendarGridMode')
 let mapping:any=null,signature='',epoch=0,loading=false,results:any[]=[],loadedRange={from:'',to:''},loadedMonth='',zone='America/New_York'
 month.value=calendarDay(new Date().toISOString(),zone).slice(0,7);mode.value=matchMedia('(max-width:640px)').matches?'agenda':'month'
 function clear(){epoch++;results=[];loadedMonth='';$('calendarGridContent').replaceChildren()}
 function controls(){element.querySelectorAll<HTMLInputElement|HTMLButtonElement|HTMLSelectElement>('input,button,select').forEach(e=>e.disabled=loading||!(mapping?.personal?.id||mapping?.nationwide?.id))}
 function configure(next:any){
  const fresh=JSON.stringify(next||null);if(fresh!==signature){clear();mapping=next;signature=fresh;loading=false}
  const personal=!!mapping?.personal?.id,office=!!mapping?.nationwide?.id
  for(const o of destination.options)o.disabled=o.value==='both'?!(personal&&office):o.value==='personal'?!personal:!office
  if(destination.selectedOptions[0]?.disabled)destination.value=personal?'personal':office?'nationwide':'both'
  zone=mapping?.[destination.value==='nationwide'?'nationwide':'personal']?.timeZone||'America/New_York'
  $('calendarGridZone').textContent=mapping?'Times shown in '+zone:''
  if(!mapping)$('calendarGridStatus').textContent='Sign in and save your calendar destinations to see events here.'
  else if(!loadedMonth)$('calendarGridStatus').textContent='Choose a calendar and refresh the view. Nothing is changed by viewing it.'
  controls()
 }
 function eventButton(row:any){
  const ticket=epoch,b=document.createElement('button');b.className='calendar-grid-event calendar-grid-'+row.destination;b.dataset.gridEventId=row.event.id;b.dataset.gridDestination=row.destination
  let when='All day';if(row.event.start?.dateTime)when=new Intl.DateTimeFormat('en-US',{timeZone:zone,hour:'numeric',minute:'2-digit'}).format(new Date(row.event.start.dateTime))
  b.textContent=when+' · '+row.event.title;b.title=row.calendarName+' · '+b.textContent;b.setAttribute('aria-label',b.title)
  b.onclick=()=>options.run(async()=>{if(ticket!==epoch||!loadedMonth||loading)throw Error('Refresh this calendar view before choosing an event.');const result=await options.select(row.destination,row.event.id,loadedRange.from,loadedRange.to);element.querySelectorAll('[data-grid-event-id]').forEach(e=>e.classList.toggle('calendar-grid-selected',(e as HTMLElement).dataset.gridEventId===row.event.id&&(e as HTMLElement).dataset.gridDestination===row.destination));return result})
  return b
 }
 function render(){
  const area=$('calendarGridContent');area.replaceChildren();if(!loadedMonth)return
  const [year,m]=loadedMonth.split('-').map(Number),count=new Date(Date.UTC(year,m,0)).getUTCDate(),first=new Date(Date.UTC(year,m-1,1)).getUTCDay(),rows=results.flatMap(r=>r.events.map((event:any)=>({event,destination:r.destination,calendarName:r.calendarName})))
  const indexed=new Map<string,any[]>();for(const row of rows)for(const day of eventCalendarDays(row.event,zone,loadedMonth)){const entries=indexed.get(day)||[];entries.push(row);indexed.set(day,entries)}
  const heading=document.createElement('h4');heading.textContent=new Intl.DateTimeFormat('en-US',{timeZone:'UTC',year:'numeric',month:'long'}).format(new Date(loadedMonth+'-01T12:00:00Z'));area.append(heading)
  const legend=document.createElement('p');legend.className='calendar-grid-legend';legend.textContent=results.map(r=>r.calendarName+' ('+(r.destination==='personal'?'Personal':'Nationwide')+')').join(' · ');area.append(legend)
  const days=document.createElement('div');days.className=mode.value==='month'?'calendar-month-grid':'calendar-agenda-grid';area.append(days)
  if(mode.value==='month'){for(const label of ['Sun','Mon','Tue','Wed','Thu','Fri','Sat']){const h=document.createElement('div');h.className='calendar-weekday';h.textContent=label;days.append(h)}for(let n=0;n<first;n++){const blank=document.createElement('div');blank.className='calendar-day-empty';blank.setAttribute('aria-hidden','true');days.append(blank)}}
  const today=calendarDay(new Date().toISOString(),zone)
  for(let n=1;n<=count;n++){const day=loadedMonth+'-'+String(n).padStart(2,'0'),events=indexed.get(day)||[];if(mode.value==='agenda'&&!events.length)continue;const cell=document.createElement('section');cell.className='calendar-grid-day';cell.dataset.day=day;if(day===today)cell.classList.add('calendar-grid-today');const label=document.createElement('h5');label.textContent=mode.value==='month'?String(n):new Intl.DateTimeFormat('en-US',{timeZone:'UTC',weekday:'long',month:'short',day:'numeric'}).format(new Date(day+'T12:00:00Z'));cell.append(label);for(const row of events)cell.append(eventButton(row));days.append(cell)}
  if(!rows.some(row=>eventCalendarDays(row.event,zone,loadedMonth).length)){const p=document.createElement('p');p.textContent='No events in this month for the selected calendars.';area.append(p)}
 }
 async function load(){
  if(!mapping?.personal?.id&&!mapping?.nationwide?.id)return{success:true,status:'not_configured',message:'Save calendar destinations to see your calendar here.'}
  if(document.querySelector('#calendarApproval[open],#calendarEditApproval[open]'))throw Error('Finish or cancel the current event review before changing the calendar view.')
  const choice=destination.value,targets:Destination[]=choice==='both'?['personal','nationwide']:[choice as Destination];if(targets.some(d=>!mapping?.[d]?.id))throw Error('Choose a saved calendar destination.')
  zone=mapping[choice==='nationwide'?'nationwide':'personal']?.timeZone||'America/New_York';const range=calendarMonthRange(month.value,zone),requestedMonth=month.value,ticket=++epoch;loading=true;results=[];loadedMonth='';$('calendarGridContent').replaceChildren();$('calendarGridStatus').textContent='Reading your calendar…';$('calendarGridZone').textContent='Times shown in '+zone;controls()
  try{const read=await Promise.all(targets.map(d=>options.read(d,range.from,range.to)));if(ticket!==epoch)throw Error('Calendar view changed. Refresh it again.');if(read.some((r,i)=>r.completeRead!==true||r.destination!==targets[i]||!Array.isArray(r.events)))throw Error('Calendar read was incomplete. Refresh to try again.');results=read;loadedMonth=requestedMonth;loadedRange=range;render();$('calendarGridStatus').textContent='Calendar view updated · '+results.reduce((sum,r)=>sum+r.events.length,0)+' events. Select an event below to review changes.';options.onLoaded?.();return{success:true,month:loadedMonth,destinations:targets,eventCount:results.reduce((sum,r)=>sum+r.events.length,0)}}catch(e){if(ticket===epoch){results=[];$('calendarGridContent').replaceChildren();$('calendarGridStatus').textContent='Could not load this calendar view. Your existing event draft is retained.'}throw e}finally{if(ticket===epoch){loading=false;controls()}}
 }
 const refresh=()=>options.run(load);$('calendarGridRefresh').onclick=refresh;month.onchange=refresh;destination.onchange=refresh;mode.onchange=render
 function move(delta:number){const [y,m]=month.value.split('-').map(Number);month.value=new Date(Date.UTC(y,m-1+delta,1)).toISOString().slice(0,7);refresh()}
 $('calendarGridPrevious').onclick=()=>move(-1);$('calendarGridNext').onclick=()=>move(1);$('calendarGridToday').onclick=()=>{month.value=calendarDay(new Date().toISOString(),zone).slice(0,7);refresh()};configure(null)
 return{element,configure,load,clear:()=>{configure(null);clear()},invalidate(){clear();$('calendarGridStatus').textContent='Calendar changed. Refresh the view to see the latest events.'},setDestination(value:string){if(!['personal','nationwide','both'].includes(value))throw Error('Choose Personal, Nationwide or both.');destination.value=value},setMonth(value:string){calendarMonthRange(value,zone);month.value=value}}
}
