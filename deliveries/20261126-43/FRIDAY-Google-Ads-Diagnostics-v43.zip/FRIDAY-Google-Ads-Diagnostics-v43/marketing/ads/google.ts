import {randomBytes,createCipheriv,createDecipheriv} from 'node:crypto'
import {MarketingError} from '../model'
export const ADS_SCOPE='https://www.googleapis.com/auth/adwords'
export const LOCAL_ADS_REDIRECT='https://localhost:5173/marketing/google-ads/callback'
// Only the configured callback and the owner's exact local Vite origin are eligible.
export function adsRedirectForOrigin(config:any,origin:string){
 let canonical:string;try{canonical=new URL(origin).origin}catch{throw new MarketingError('Open FRIDAY at its configured domain or https://localhost:5173 before connecting.',409)}
 if(canonical!==origin)throw new MarketingError('Invalid Google Ads login origin.',409)
 const found=[config.redirect,LOCAL_ADS_REDIRECT].find(value=>typeof value==='string'&&new URL(value).origin===origin)
 if(!found)throw new MarketingError('Open FRIDAY at its configured domain or https://localhost:5173 before connecting.',409)
 return found
}
// Return only allowlisted provider reason codes and fixed guidance. Never provider messages/metadata.
const reasonGuidance:Record<string,string>={
 DEVELOPER_TOKEN_NOT_APPROVED:'The runtime developer token is not approved for this account. Confirm it is the same token whose access level you checked.',
 DEVELOPER_TOKEN_PROHIBITED:'Google rejected this developer-token and OAuth Cloud-project combination. Confirm both belong to the intended integration and check Google Ads API access restrictions.',
 DEVELOPER_TOKEN_INVALID:'The configured developer token is invalid. Compare it privately with the AITAN manager API Center.',
 DEVELOPER_TOKEN_NOT_ALLOWED:'Google did not permit this developer token for the requested operation. Check its API Center access.',
 PROJECT_DISABLED:'Google has disabled the OAuth Cloud project. Check its status and enabled APIs.',
 PROJECT_NOT_PERMITTED:'Google has not permitted this OAuth Cloud project for the requested API access. Check project and developer-token eligibility.',
 PROJECT_NOT_FOUND:'Google could not identify the OAuth Cloud project for this request. Check that FRIDAY uses the intended Web OAuth client.',
 USER_PERMISSION_DENIED:'The authorizing Google login lacks permission through the configured manager. Check that login in AITAN manager Access and security and the linked-client relationship.',
 CUSTOMER_NOT_ENABLED:'Google reports this Ads customer is not enabled. Check the manager/account activation and suspension status.',
 CUSTOMER_NOT_FOUND:'Google could not find an accessible requested Ads customer. Recheck the configured manager and account permissions.',
 NOT_ADS_USER:'The authorizing Google login is not an enabled Google Ads user. Use a login with access to the AITAN manager.',
 INCOMPLETE_SIGNUP:'Complete the Google Ads account signup before using its API.',
 MISSING_TOS:'Accept the applicable Google Ads terms in the Google Ads interface.',
 INVALID_LOGIN_CUSTOMER_ID:'Google rejected the login-customer-id manager header. Check the AITAN manager ID and its relationship to this advertiser.',
 LOGIN_CUSTOMER_ID_INVALID:'Google rejected the login-customer-id manager header. Check the AITAN manager ID and its relationship to this advertiser.',
 INVALID_USER_SELECTED_CUSTOMER:'The selected Ads customer is not valid for the authorizing login.',
 OAUTH_TOKEN_INVALID:'The Google authorization token is invalid. Start a fresh Google authorization using the intended account.',
 OAUTH_TOKEN_EXPIRED:'The Google authorization has expired. Reconnect with Google.',
 OAUTH_TOKEN_REVOKED:'Google authorization was revoked. Reconnect explicitly with the intended account.',
 OAUTH_TOKEN_SCOPE_INSUFFICIENT:'The authorization lacks the required AdWords scope. Check the OAuth client/project and reconnect.',
 SERVICE_DISABLED:'Google Ads API is disabled or unavailable for the OAuth client project actually used by this request. Check that exact project.',
 ACCESS_TOKEN_SCOPE_INSUFFICIENT:'The access token lacks the required Google Ads scope. Check the actual OAuth project/scope and reconnect.'
}
const oauthGuidance:Record<string,string>={invalid_client:'Google rejected the OAuth client credentials. Check the Client ID and secret privately.',invalid_grant:'Google rejected an expired, reused, revoked or mismatched authorization grant. Start a fresh login and keep its origin unchanged.',access_denied:'Google denied this authorization. Check the Google account and OAuth audience/access settings.',invalid_scope:'Google rejected the requested OAuth scope. Check the OAuth client project scope configuration.',unauthorized_client:'Google did not authorize this OAuth client for the requested flow. Confirm it is the intended Web application client.'}
export function googleFailureMessage(data:any){
 const error=data?.error,status=['UNAUTHENTICATED','PERMISSION_DENIED','INVALID_ARGUMENT','RESOURCE_EXHAUSTED','FAILED_PRECONDITION','NOT_FOUND','INTERNAL','UNAVAILABLE'].includes(error?.status)?error.status:null
 const reasons=new Set<string>()
 for(const detail of Array.isArray(error?.details)?error.details.slice(0,20):[]){
  if(/^type\.googleapis\.com\/google\.ads\.googleads\.v\d+\.errors\.GoogleAdsFailure$/.test(String(detail?.['@type']||''))){
   for(const entry of Array.isArray(detail.errors)?detail.errors.slice(0,30):[]){
    for(const kind of ['authorizationError','authenticationError','headerError','requestError','quotaError']){
     const code=entry?.errorCode?.[kind];if(typeof code==='string'&&Object.hasOwn(reasonGuidance,code))reasons.add(code)
    }
   }
  }
  if(detail?.['@type']==='type.googleapis.com/google.rpc.ErrorInfo'&&typeof detail.reason==='string'&&Object.hasOwn(reasonGuidance,detail.reason))reasons.add(detail.reason)
 }
 const oauth=typeof error==='string'&&Object.hasOwn(oauthGuidance,error)?error:null
 const codes=[...(status?[status]:[]),...Array.from(reasons).slice(0,3),...(oauth?[oauth]:[])]
 const guidance=[...Array.from(reasons).slice(0,3).map(code=>reasonGuidance[code]),...(oauth?[oauthGuidance[oauth]]:[])]
 return 'Google rejected the read-only connection request'+(codes.length?' ('+codes.join('; ')+')':'')+'. '+(guidance.length?guidance.join(' '):'Check account access, developer-token permission and private configuration.')
}
const vars=['CLIENT_ID','CLIENT_SECRET','DEVELOPER_TOKEN','API_VERSION','CREDENTIAL_KEY','REDIRECT_URI'] as const
export function googleConfig(){const missing=vars.filter(k=>!process.env['FRIDAY_GOOGLE_ADS_'+k]).map(k=>'FRIDAY_GOOGLE_ADS_'+k);if(missing.length)return{ready:false,missing};const key=Buffer.from(process.env.FRIDAY_GOOGLE_ADS_CREDENTIAL_KEY!,'base64'),version=process.env.FRIDAY_GOOGLE_ADS_API_VERSION!,redirect=process.env.FRIDAY_GOOGLE_ADS_REDIRECT_URI!;let u:URL;try{u=new URL(redirect)}catch{throw new MarketingError('Google Ads redirect configuration is invalid.')};if(key.length!==32||!/^[A-Za-z0-9+/]{43}=$/.test(process.env.FRIDAY_GOOGLE_ADS_CREDENTIAL_KEY!)||!/^v\d{1,3}$/.test(version)||u.protocol!=='https:'||u.username||u.password||u.search||u.hash||u.pathname!=='/marketing/google-ads/callback')throw new MarketingError('Configure a 32-byte base64 credential key, supported Google Ads API version and exact HTTPS callback privately.');const manager=(process.env.FRIDAY_GOOGLE_ADS_MANAGER_ID||'').replace(/-/g,'');if(manager&&!/^\d{10}$/.test(manager))throw new MarketingError('Configure the AITAN manager ID as ten digits.');return{ready:true,missing:[],key,version,redirect,manager,clientId:process.env.FRIDAY_GOOGLE_ADS_CLIENT_ID!,clientSecret:process.env.FRIDAY_GOOGLE_ADS_CLIENT_SECRET!,developerToken:process.env.FRIDAY_GOOGLE_ADS_DEVELOPER_TOKEN!}}
export function seal(refresh:string,company:string,key:Buffer){const iv=randomBytes(12),c=createCipheriv('aes-256-gcm',key,iv);c.setAAD(Buffer.from('friday-google-ads-v1:'+company));const cipher=Buffer.concat([c.update(refresh,'utf8'),c.final()]).toString('base64');return{iv:iv.toString('base64'),cipher,tag:c.getAuthTag().toString('base64')}}
export function unseal(value:any,company:string,key:Buffer){try{const d=createDecipheriv('aes-256-gcm',key,Buffer.from(value.iv,'base64'));d.setAAD(Buffer.from('friday-google-ads-v1:'+company));d.setAuthTag(Buffer.from(value.tag,'base64'));return Buffer.concat([d.update(Buffer.from(value.cipher,'base64')),d.final()]).toString('utf8')}catch{throw new MarketingError('Stored Google authorization cannot be decrypted with this server key. Preserve the original key or reconnect.',409)}}
export function googleClient(config:any,send:typeof fetch=fetch){
 async function read(url:string,options:any){let r:Response;try{r=await send(url,{...options,signal:AbortSignal.timeout(30000)})}catch{throw new MarketingError('Google connection timed out or is unreachable. No automatic retry or advertising write was made.',502)}let data:any;try{data=await r.json()}catch{throw new MarketingError('Google returned an unreadable response.',502)}if(!r.ok)throw new MarketingError(googleFailureMessage(data),502);return data}
 const token=(values:any)=>read('https://oauth2.googleapis.com/token',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({client_id:config.clientId,client_secret:config.clientSecret,...values})})
 async function refresh(value:string){const d=await token({grant_type:'refresh_token',refresh_token:value});if(typeof d.access_token!=='string'||!d.access_token)throw new MarketingError('Google did not return an access token.',502);return d.access_token}
 async function call(path:string,access:string,body?:any,manager=true){return read('https://googleads.googleapis.com/'+config.version+'/'+path,{method:body===undefined?'GET':'POST',headers:{Authorization:'Bearer '+access,'developer-token':config.developerToken,'Content-Type':'application/json',...(manager&&config.manager?{'login-customer-id':config.manager}:{})},...(body===undefined?{}:{body:JSON.stringify(body)})})}
 async function query(customer:string,access:string,query:string){if(!/^\d{10}$/.test(customer))throw new MarketingError('Invalid Google customer ID.');return call('customers/'+customer+'/googleAds:search',access,{query})}
 return{refresh,call,query,exchange:async(code:string)=>{const d=await token({grant_type:'authorization_code',code,redirect_uri:config.redirect});if(typeof d.refresh_token!=='string'||!d.refresh_token||!String(d.scope||'').split(' ').includes(ADS_SCOPE)||typeof d.access_token!=='string')throw new MarketingError('Google did not return the requested Ads scope and reusable authorization. Reconnect with consent.',502);return d},
 accounts:async(access:string)=>{if(config.manager){const d=await query(config.manager,access,'SELECT customer_client.client_customer, customer_client.descriptive_name, customer_client.manager, customer_client.status FROM customer_client WHERE customer_client.level <= 1');return(d.results||[]).filter((r:any)=>r.customerClient?.manager===false&&r.customerClient?.status==='ENABLED').map((r:any)=>({id:String(r.customerClient.clientCustomer||'').split('/').pop(),name:r.customerClient.descriptiveName||''})).filter((r:any)=>/^\d{10}$/.test(r.id))}const d=await call('customers:listAccessibleCustomers',access,undefined,false);return(d.resourceNames||[]).filter((n:any)=>typeof n==='string'&&/^customers\/\d{10}$/.test(n)).map((n:string)=>({id:n.split('/')[1],name:'Verify this account before assigning it'}))},
 account:async(id:string,access:string)=>{const d=await query(id,access,'SELECT customer.id, customer.descriptive_name, customer.currency_code, customer.time_zone, customer.manager FROM customer LIMIT 1'),c=d.results?.[0]?.customer;if(!c||String(c.id)!==id||c.manager!==false)throw new MarketingError('Select a real advertiser client account, not the AITAN manager account.',409);return{id,name:c.descriptiveName||'',currency:c.currencyCode,timeZone:c.timeZone}},
 ideas:async(id:string,access:string,terms:string[])=>{if(!/^\d{10}$/.test(id)||terms.length<1||terms.length>100)throw new MarketingError('Choose up to one hundred keyword seeds.');const geo=await call('geoTargetConstants:suggest',access,{locale:'en',countryCode:'US',locationNames:{names:['Manhattan, New York, United States']}}),candidate=(geo.geoTargetConstantSuggestions||[]).map((x:any)=>x.geoTargetConstant).find((g:any)=>g?.countryCode==='US'&&g?.status==='ENABLED'&&/^Manhattan$/i.test(g.name)&&/New York/.test(g.canonicalName||'')&&/geoTargetConstants\/\d+$/.test(g.resourceName));if(!candidate)throw new MarketingError('Google did not resolve a confirmed Manhattan target. No broader NYC target substituted.',409);const results:any[]=[],pages:string[]=[];for(let offset=0;offset<terms.length;offset+=20){const d=await call('customers/'+id+':generateKeywordIdeas',access,{keywordSeed:{keywords:terms.slice(offset,offset+20)},geoTargetConstants:[candidate.resourceName],language:'languageConstants/1000',keywordPlanNetwork:'GOOGLE_SEARCH',includeAdultKeywords:false,pageSize:100});results.push(...(d.results||[]));if(d.nextPageToken)pages.push(d.nextPageToken)}return{location:{name:candidate.name,canonicalName:candidate.canonicalName,resourceName:candidate.resourceName},ideas:results.slice(0,500).map((r:any)=>({text:r.text,averageMonthlySearches:r.keywordIdeaMetrics?.avgMonthlySearches??null,competition:r.keywordIdeaMetrics?.competition??null,lowTopOfPageBidMicros:r.keywordIdeaMetrics?.lowTopOfPageBidMicros??null,highTopOfPageBidMicros:r.keywordIdeaMetrics?.highTopOfPageBidMicros??null})),nextPageAvailable:pages.length>0,note:'Historical Keyword Planner estimates, not guaranteed leads, exact future CPC or complete local competitor coverage. First page per seed batch only. No campaign mutation was called.'}}
 }
}
