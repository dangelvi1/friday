import test from 'node:test'
import assert from 'node:assert/strict'
import {googleClient,googleFailureMessage} from '../marketing/ads/google'
const cfg:any={version:'v99',manager:'1111111111',clientId:'SYNTHETIC-CLIENT',clientSecret:'PRIVATE-CLIENT-SECRET',developerToken:'PRIVATE-DEVELOPER-TOKEN',redirect:'https://localhost:5173/marketing/google-ads/callback'}
const failure=(code:string,kind='authorizationError')=>({error:{status:'PERMISSION_DENIED',message:'PRIVATE-PROVIDER-MESSAGE',details:[{'@type':'type.googleapis.com/google.ads.googleads.v26.errors.GoogleAdsFailure',requestId:'PRIVATE-REQUEST-ID',errors:[{errorCode:{[kind]:code},message:'PRIVATE-ERROR-MESSAGE',location:{fieldPathElements:[{fieldName:'PRIVATE-FIELD'}]}}]},{'@type':'type.googleapis.com/google.rpc.ErrorInfo',reason:'PRIVATE-UNKNOWN-REASON',metadata:{consumer:'PRIVATE-PROJECT',token:'PRIVATE-TOKEN'}}]}})
for(const [code,hint] of [['USER_PERMISSION_DENIED','authorizing Google login'],['DEVELOPER_TOKEN_PROHIBITED','Cloud-project combination'],['DEVELOPER_TOKEN_NOT_APPROVED','same token'],['CUSTOMER_NOT_ENABLED','not enabled'],['PROJECT_NOT_PERMITTED','project']])test('real Google client exposes recognized '+code+' with fixed guidance and no raw data',async()=>{
 let calls=0;const send:any=async()=>{calls++;return Response.json(failure(code),{status:403})};const api=googleClient(cfg,send)
 await assert.rejects(api.accounts('PRIVATE-ACCESS-TOKEN'),(error:any)=>{assert.equal(error.status,502);assert.ok(error.message.includes(code));assert.ok(error.message.includes(hint));assert.ok(!error.message.includes('PRIVATE-'));assert.ok(error.message.length<1500);return true});assert.equal(calls,1)
})
test('actual Google ErrorInfo SERVICE_DISABLED is exposed without project metadata or raw explanation',async()=>{
 let calls=0;const api=googleClient(cfg,(async()=>{calls++;return Response.json({error:{status:'PERMISSION_DENIED',message:'PRIVATE-PROVIDER',details:[{'@type':'type.googleapis.com/google.rpc.ErrorInfo',reason:'SERVICE_DISABLED',domain:'googleapis.com',metadata:{service:'googleads.googleapis.com',consumer:'PRIVATE-CLOUD-PROJECT'}}]}},{status:403})}) as any)
 await assert.rejects(api.accounts('PRIVATE-ACCESS'),(error:any)=>{assert.match(error.message,/SERVICE_DISABLED/);assert.match(error.message,/project actually used/);assert.ok(!error.message.includes('PRIVATE-'));return true});assert.equal(calls,1)
})
test('unknown reason codes, messages, details and foreign payload types stay generic',()=>{
 for(const data of [failure('PRIVATE-UNKNOWN-CODE'),{error:{status:'PRIVATE-STATUS',message:'PRIVATE-MESSAGE',details:'PRIVATE-DETAIL'}},{error:{status:'PERMISSION_DENIED',details:[{'@type':'foreign.PrivateFailure',errors:[{errorCode:{authorizationError:'USER_PERMISSION_DENIED'}}],message:'PRIVATE-MESSAGE'}]}},null,{},'PRIVATE-RAW']){
  const value=googleFailureMessage(data);assert.ok(!value.includes('PRIVATE-'));assert.ok(!value.includes('USER_PERMISSION_DENIED'));assert.match(value,/Check account access/)
 }
})
test('recognized OAuth grant errors expose only fixed safe guidance and never raw descriptions',async()=>{
 const api=googleClient(cfg,(async()=>Response.json({error:'invalid_grant',error_description:'PRIVATE-CODE-OR-TOKEN',error_uri:'https://PRIVATE-URL.invalid'},{status:400})) as any)
 await assert.rejects(api.exchange('PRIVATE-AUTHORIZATION-CODE'),(error:any)=>{assert.match(error.message,/invalid_grant/);assert.match(error.message,/fresh login/);assert.ok(!error.message.includes('PRIVATE-'));return true})
})
test('multiple safe reasons are deduplicated and bounded without field paths or request IDs',()=>{
 const payload=failure('USER_PERMISSION_DENIED');const detail:any=payload.error.details[0];detail.errors=Array.from({length:100},()=>({errorCode:{authorizationError:'USER_PERMISSION_DENIED',authenticationError:'DEVELOPER_TOKEN_PROHIBITED',headerError:'INVALID_LOGIN_CUSTOMER_ID'},message:'PRIVATE-DETAIL'}));const value=googleFailureMessage(payload);assert.equal((value.match(/USER_PERMISSION_DENIED/g)||[]).length,1);assert.match(value,/INVALID_LOGIN_CUSTOMER_ID/);assert.ok(!value.includes('PRIVATE-'));assert.ok(value.length<1500)
})
test('network and unreadable failures retain generic handling and never retry',async()=>{
 for(const send of [async()=>{throw Error('PRIVATE-SOCKET-DETAIL')},async()=>new Response('PRIVATE-UNREADABLE',{status:503})]){
  let calls=0;const api=googleClient(cfg,(async(...args:any[])=>{calls++;return (send as any)(...args)}) as any);await assert.rejects(api.accounts('PRIVATE-ACCESS'),(error:any)=>{assert.ok(!error.message.includes('PRIVATE-'));return true});assert.equal(calls,1)
 }
})
