@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-Google-Ads-Diagnostics.ps1" -ProjectPath "S:\AI\friday-ai"
if errorlevel 1 (
 echo Installation stopped. Read the error and keep the source backup.
 pause
 exit /b 1
)
echo Restart FRIDAY, then initialize/update the Ads workspace once before connecting.
pause
