This is a historical feature reference. Use README-FIRST.md and Install-Unified-Dashboard.ps1 for v18 installation; older commands below are superseded.

# Owner sign-in reference

Use README-FIRST.md and Install-Commerce-Reports.ps1 for this release. Installation commands below are historical; only the sign-in/password guidance applies.

# Shared owner sign-in (included in v16)

Use this package’s README-FIRST.md for the v16 installation command.

## Sign in once

Choose Salvador or Dayanna and click Connect. The private sign-in screen appears before microphone/AI connection. Use your existing owner's key in the Password field. To choose an easier personal password, expand **First time: set or reset a personal password**, enter that existing owner key above, and enter/repeat your chosen 12–128-character password below. Only do this on FRIDAY's own screen; never send it to chat or speak it. A later sign-in uses the personal password. Existing owner keys remain available for recovery/reset and legacy API clients; no keys are regenerated or printed.

Calendar, Sandra teaching/private bank review, invoices/custom fields/statements, Document Analysis and ecommerce use the shared sign-in. Module password inputs/Verify owner buttons are hidden; existing connection checks/company/calendar/workspace selections still apply. Same-browser/same-origin paired tabs inherit an opaque HttpOnly cookie, not your key. Another browser/device/profile signs in separately. The installed desktop app shares a session only if it uses the same browser profile/origin; its native runtime was not available for verification. Current working https://localhost:5173 is the supported default. HTTPS LAN IP origins on the app ports are also supported; named/custom deployments require explicit FRIDAY_OWNER_ALLOWED_ORIGINS configuration, never invented by this update.

The session lasts at most eight hours, ends when FRIDAY is explicitly disconnected/locked, and is invalidated by backend restart, key rotation or password reset. After rotating an existing owner key, reset the personal password privately using the new key. Save unsaved notes/forms before disconnecting or switching owners; locking clears owner-private review state. Refresh/new tabs reuse an active session. Switching to the other owner's profile locks the old session and requires that owner's password. Say **Lock FRIDAY** or use the shared Lock button. Locking propagates to paired tabs and clears pending reviews/owner-private module state. A request already submitted may finish; check its receipt. No write is automatically replayed after login/expiry.

One sign-in does not approve accounting/calendar/product/file actions. FRIDAY still displays each specific review and accepts **yes / approve it / cancel it** by the existing voice gate. Production-company confirmation and all company/owner scopes remain. Passwords/keys are never voice inputs. The helper stores only salted scrypt password hashes in private credentials/friday-owner-passwords.json; session IDs stay server-side in memory and only an opaque HttpOnly/SameSite cookie reaches the browser. Passwords/keys/tokens are not put in browser storage, URLs or paired-tab messages. Failed logins are rate-limited. Provider/employee OAuth/webhooks are not intercepted by the new realtime sign-in gate; the separated Nationwide/Sara employee system is preserved.

