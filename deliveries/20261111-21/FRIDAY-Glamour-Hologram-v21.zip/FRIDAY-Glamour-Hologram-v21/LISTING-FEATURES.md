Historical feature reference. Use README-FIRST.md and Install-Glamour-Hologram.ps1 for v21 installation. Older commands below are superseded.

Historical feature reference. Use README-FIRST.md and Install-Holographic-Face.ps1 for v20 installation. Older commands below are superseded.

This is a historical feature reference. Use README-FIRST.md and Install-Voice-Home-Calendars.ps1 for v19 installation; older commands below are superseded.

This is a historical feature reference. Use README-FIRST.md and Install-Unified-Dashboard.ps1 for v18 installation; older commands below are superseded.

# Listing behavior retained from v16

Installation steps in this historical feature reference are superseded by README-FIRST.md and Install-Commerce-Reports.ps1.

# FRIDAY Listing Updates v16 — 2026-11-09

PC hosting remains S:\AI\friday-ai. Cumulative package supports installed v12/v13, both v14 variants and both v15 variants. It includes the shared owner sign-in and preserves the installed Crosslist source family, company separation and the Nationwide/Sara employee system. No provider/account credentials, TLS/Vite configuration, existing AGENTS, package files or private data are replaced.

## Install

Stop FRIDAY backend with Ctrl+C; close old review tabs. Extract into a new folder and run the actual full path:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File 'S:\AI\Fixing-Files-Folder\FRIDAY-Listing-Updates-v16\Install-Listing-Updates.ps1' -ProjectPath 'S:\AI\friday-ai'
if ($LASTEXITCODE -ne 0) { throw 'Installer failed. Do not continue.' }
Set-Location 'S:\AI\friday-ai'
npm run build
if ($LASTEXITCODE -ne 0) { throw 'Build failed. Do not continue.' }
npm run server
```

Keep `npm run dev` in the other terminal. Ctrl+F5 https://localhost:5173/, reconnect voice, close/reopen paired dashboard tabs. ExecutionPolicy Bypass applies only to the installer process. The large-bundle Vite warning remains informational. Existing personal owner password works; first-time setup with an existing owner key is explained in OWNER-SIGNIN-GUIDE.md. Never speak/send passwords or put them into chat.

## Accept all: changed behavior

The old implementation rejected more than 300 selected changes and let one stale product block the entire preview. The new review accepts up to 5,000 specific listing changes, reads products in chunks of 25, and separates ready fields from already-applied/stale/unavailable/dependent fields. Full before/after values remain visible. One concise voice review summarizes scope instead of sending thousands of rows into the conversation.

**Accept all supported changes → review** prepares every displayed supported, unapplied listing proposal. Review the ready/excluded counts and details, then say **Approve it** or **Cancel it** once. It is not blanket future approval. Accepted work runs in the backend with durable receipts; the dashboard polls verified progress. Stop can halt remaining writes; a submitted change may finish. Do not repeat an approval after a lost response—check its receipt. Unexpected product identity/status/selected-field changes are never overwritten. Proposal edits invalidate outstanding review work. A report display-refresh failure does not hide already verified saves. Opening older reports or editing fields no longer gets silently replaced by a nightly report; new report notices remain available.

## Fresh listing audit

Say **Audit my Shopify inventory again** after installation. Existing old reports retain SEO review support but do not contain the new category/metafield schema. The audit reads actual category, tags, product type, existing metafields, merchant definitions, available allowed choices/reference entries and category constraints where accessible. Missing permissions/config/schema/values stay unavailable; never invented.

Supported reviewed listing writes: SEO title, meta description, description, tags, actual taxonomy category and supported product/category metafields. Blank/short descriptions get original factual copy from existing titles/options; generated copy does not assert unseen materials, condition, authenticity or shipping promises. Existing tags are preserved in automatic proposals. Category refinement uses actual taxonomy options; category changes can affect tax classification. A category change with existing populated category attributes requires native dependency review. Apply a new category first and rerun the audit to discover its attributes rather than applying old category attributes blindly.

The editor offers friendly category/definition/allowed-value controls, editable confirmed text and missing-fact questions. Say **Show listing details for this product**, **Use this description**, **Set the material to Suede**, or **Use these tags**. FRIDAY saves a private proposal, then displays its before/after for the usual approval. Price/stock/SKU/variant structure and publishing are not part of Accept all listing fields.

Metafield writes use existing definitions, exact types, allowed enum/reference values and compareDigest checks. Supported types are single/multiline text, boolean, integer/decimal, lists of text and single/list metaobject references. No new definitions or metaobjects are invented/created. Unknown age, fit, care, material and other attributes require owner facts. Complex native types, missing category applicability, unavailable reference entries, or scopes require native Shopify setup/review; the current native value remains. Existing title/variant facts may generate a proposal only when they match a real allowed choice exactly.

## Pricing and a weekly special

Say **Analyse pricing for this product**. Reports show actual current variant prices/stock, linked public asking/sold-example evidence where available, a median only when comparable linked quotes exist, 5/10/15% test prices and contribution estimates only when costs are known. Example: $49.00 at 10% off is an estimated $44.10 item price before tax/shipping. Negative known margins remain negative; missing fees/shipping/costs do not become zero. There is no verified optimal-price or fast-sale guarantee.

A promotion is a **separate** owner review. Select exact variants, percentage, name and explicit future start/end dates (maximum 14 days). Voice can fill these for you: **Review a 10% special on these variants from November 16 to November 23, midnight Eastern**. Inspect the actual Eastern dates/UTC offsets and cost warnings before approving. Model suggestions are not permission to create an offer.

After one approval FRIDAY creates a native Shopify automatic percentage discount for those exact variants, with an end date and no order/product/shipping-discount combinations. It verifies the stored schedule/variant scope and exposes a native Shopify link. Shopify ends the offer even if FRIDAY is offline. This is one scheduled offer, not unattended weekly renewal. It applies at checkout; this update does not add theme sale badges or crossed-out product-page prices. Base prices/compare-at prices and inventory stay unchanged. Tax/shipping/rounding and other native discounts can affect final checkout totals. Shopify may choose another eligible promotion instead.

The connected app needs the relevant product/metafield/metaobject read/write permissions; promotions need discount permissions (including read/write_discounts as required by Shopify). Promotion preview checks the actual installed app scope before asking for approval. This package does not invent scopes, replace credentials or grant permissions. Restart FRIDAY after updating the app permissions to renew its server token. Native schema/scopes were not available for cloud verification. If creation is uncertain, the receipt keeps a unique FRIDAY title. Search that title in Shopify before any further action; never automatically recreate it. Cancel before approval creates nothing. A submitted/scheduled discount is inspected/managed through its native Shopify link; cancelling a review does not delete an existing offer.

## What this does not change

No QuickBooks invoices, employee system, ads, purchases, supplier orders, fulfillment/refunds, live product publication or theme publishing are changed by this update. Existing read-only research budgets/ZIP/nightly Eastern schedule, photos/draft creation and native voice navigation remain. Missing facts/configuration are questions or partial results. Research still uses the existing configured OpenAI service; normal API usage applies. This update adds no paid live cloud calls during its tests.

## Backup / restore

The installer selects the actual supported source by hash, verifies package/baseline hashes, verifies backups, rechecks targets and rolls back attempted copies on failure. Unknown installed edits stop safely before project changes. Keep the printed backup path. Stop backend and run the backup-folder Restore-Listing-Updates.ps1 by full path with process-scoped ExecutionPolicy Bypass. Restore refuses later source edits and removes only new app/test files; private credentials/password hashes/reports/photos/receipts remain. Restoring app files does not undo approved metadata edits or scheduled Shopify discounts. Inspect/delete an existing offer natively if needed before rollback. Existing AGENTS.md is not overwritten; AGENTS-MERGE-PROPOSAL.md is proposed text only.
