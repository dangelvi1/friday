@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-Ads-Analysis.ps1" -ProjectPath "S:\AI\friday-ai"
if errorlevel 1 (
 echo Installation stopped. Read the error; do not force through it.
 pause
 exit /b 1
)
pushd "S:\AI\friday-ai"
if errorlevel 1 exit /b 1
call npm.cmd run build
if errorlevel 1 (
 echo Build failed. Stop here and keep the verified backup.
 popd
 pause
 exit /b 1
)
popd
echo Build completed. Restart both servers, close old tabs and reconnect FRIDAY.
pause
