# Validation

Controlled local validation only, November 27, 2026. No owner Windows/iPhone installation or real Google/OpenAI/WordPress request was made.

- 65 focused reported Node tests/subtests passed: deterministic evidence audit, realized contribution math, unknown/zero and partial-data guards, client-specific intent isolation/revision checks, persistent PostgreSQL reports/outcomes, advertiser reassignment/race, source-citation filtering, charged-research reuse, actual authenticated Ads routes, existing safe diagnostics/local-public OAuth, and the actual consented SDK tool in both voice families.
- The real Chromium mobile dashboard flow covers loading/saving client rules, copying saved exclusions into the private form, preserving a separate plan Save, adding/editing lead outcomes, no horizontal overflow, and clearing private analysis/rules on owner reset. All Google/OpenAI native transports in tests use synthetic fixtures.
- 73 additional regression reported tests/subtests passed: existing company management, WordPress, owner sessions, dashboard chat and voice approvals.
- Total 138 reported entries across those non-overlapping suites (Node includes parent tests); overlapping reruns are not added to this count.
- Frontend type checks passed for both voice families; strict backend Ads type check passed. Production Vite bundle built with configFile:false in the test environment; existing >500KB chunk advisory remains. The owner's normal npm run build must still run after installation.
- 23 actual Linux PowerShell installer/rollback scenarios passed: v41/v42/v43/v44, both voice families, historical tests present/absent; baseline/payload verification, verified source backup, restored/new-file behavior; unknown source, collisions, modified payload, later edits and damaged backups stop safely. This is not a claim of an actual Windows test.

Credentials are configuration dependencies, not embedded in the package. External permissions, API support for the selected runtime version, actual landing-page behavior, conversion accuracy and real job margins require owner-side verification. There is no ad launch or spending endpoint.
