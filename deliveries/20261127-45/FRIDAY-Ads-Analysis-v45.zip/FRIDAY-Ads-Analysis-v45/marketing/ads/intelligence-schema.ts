export const intelligenceSQL=`
CREATE TABLE IF NOT EXISTS aitan_studio.ads_intent_policies(
 company_id uuid PRIMARY KEY REFERENCES aitan_studio.companies(id),value jsonb NOT NULL,revision integer NOT NULL DEFAULT 0,
 updated_by text NOT NULL CHECK(updated_by IN ('salvador','dayanna')),updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS aitan_studio.ads_intelligence_reports(
 id uuid PRIMARY KEY, company_id uuid NOT NULL REFERENCES aitan_studio.companies(id), draft_id uuid NOT NULL REFERENCES aitan_studio.ad_drafts(id),
 request_id uuid NOT NULL UNIQUE, kind text NOT NULL CHECK(kind IN ('web','performance')), status text NOT NULL CHECK(status IN ('running','completed','failed')),
 input jsonb NOT NULL, result jsonb, created_by text NOT NULL CHECK(created_by IN ('salvador','dayanna')), created_at timestamptz NOT NULL DEFAULT now(), completed_at timestamptz
);
CREATE INDEX IF NOT EXISTS ads_intelligence_company_date ON aitan_studio.ads_intelligence_reports(company_id,created_at DESC);
CREATE TABLE IF NOT EXISTS aitan_studio.ads_lead_outcomes(
 id uuid PRIMARY KEY, company_id uuid NOT NULL REFERENCES aitan_studio.companies(id), customer_id text NOT NULL, reference text NOT NULL,
 value jsonb NOT NULL, revision integer NOT NULL DEFAULT 0, updated_by text NOT NULL CHECK(updated_by IN ('salvador','dayanna')), updated_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE(company_id,customer_id,reference)
);`
