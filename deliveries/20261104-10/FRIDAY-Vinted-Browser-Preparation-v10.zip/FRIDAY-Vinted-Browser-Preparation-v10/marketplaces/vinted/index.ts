import type {MarketplaceAdapter} from '../types'
// Vinted US personal-account publishing is not connected. Do not infer API access from env keys.
export const VINTED_ADAPTER:MarketplaceAdapter={
 key:'vinted',displayName:'Vinted — US personal',mode:'assisted',
 async getConnectionStatus(){return{key:'vinted',displayName:'Vinted — US personal',mode:'assisted',configured:false,connected:false,notes:'Browser-assisted draft preparation is available in the FRIDAY voice page. Verify owner, read the complete SALDANA SHOP catalog, then inspect your actual Vinted form. Publishing, commercial-listing eligibility and inventory synchronization remain unverified; no API credentials are assumed.'}},
 async getRequiredFields(){return[
  {key:'title',label:'Title',required:true,sourcePriority:['shopify.title']},
  {key:'description',label:'Description',required:true,sourcePriority:['shopify.descriptionHtml','manual']},
  {key:'price',label:'Exact USD price',required:true,sourcePriority:['shopify.variant.price','manual']},
  {key:'images',label:'Actual item photos',required:true,sourcePriority:['shopify.images']},
  {key:'inventory',label:'Verified variant stock',required:true,sourcePriority:['shopify.variant.inventoryQuantity']},
  {key:'brand',label:'Brand confirmed from item',required:true,sourcePriority:['manual']},
  {key:'condition',label:'Actual condition',required:true,sourcePriority:['manual']},
  {key:'category',label:'Vinted category',required:true,sourcePriority:['manual']},
  {key:'size',label:'Actual size',required:true,sourcePriority:['shopify.variant.selectedOptions','manual']},
  {key:'sizingSystem',label:'Sizing system',required:true,sourcePriority:['manual']},
  {key:'shippingNotes',label:'Shipping details',required:true,sourcePriority:['manual']},
 ]}
}
