import {createHash} from 'node:crypto'
export const VINTED_SOURCE={companyKey:'saldana-corp',shopId:'gid://shopify/Shop/68917625071',shopDomain:'1d45b1-13.myshopify.com',storeName:'SALDANA SHOP',currency:'USD',market:'US',accountType:'personal',profile:'https://www.vinted.com/member/3174865142'} as const
export class VintedError extends Error{constructor(message:string,public status=400){super(message)}}
export const digest=(x:unknown)=>createHash('sha256').update(JSON.stringify(x)).digest('hex')
export function money(value:unknown){if(typeof value!=='string'||!/^\d{1,12}(?:\.\d{1,2})?$/.test(value))return null;const [a,b='']=value.split('.');return BigInt(a).toString()+'.'+b.padEnd(2,'0')}
const imageURL=(value:unknown)=>{try{const u=new URL(String(value));return u.protocol==='https:'&&!u.username&&!u.password?u.href:null}catch{return null}}
const variantFields='id title sku barcode price inventoryQuantity selectedOptions { name value } inventoryItem { tracked } image { url altText }'
const pageInfo='pageInfo { hasNextPage endCursor }'
function validatePage(page:any,seen:Set<string>,label:string){if(!page||!Array.isArray(page.nodes)||typeof page.pageInfo?.hasNextPage!=='boolean')throw new VintedError('Incomplete '+label+' page. Existing saved preparation was retained.',502);for(const n of page.nodes){if(!n?.id||seen.has(n.id))throw new VintedError('Missing or repeated '+label+' ID. No partial catalog saved.',502);seen.add(n.id)}return page.nodes}
async function pages(first:any,more:(cursor:string)=>Promise<any>,label:string){const rows:any[]=[],seen=new Set<string>(),cursors=new Set<string>();let page=first;for(let i=0;i<1000;i++){rows.push(...validatePage(page,seen,label));if(!page.pageInfo.hasNextPage)return rows;const cursor=page.pageInfo.endCursor;if(typeof cursor!=='string'||!cursor||cursors.has(cursor))throw new VintedError('Repeated or missing '+label+' cursor. No partial catalog saved.',502);cursors.add(cursor);page=await more(cursor)}throw new VintedError(label+' pagination exceeded its safety limit; no partial catalog saved.',502)}
function numberId(id:unknown,kind:string){const m=String(id).match(new RegExp('^gid://shopify/'+kind+'/(\\d+)$'));if(!m)throw new VintedError('Invalid Shopify '+kind+' ID.',502);return m[1]}
export async function readVintedCatalog(graphql:(query:string,variables?:any)=>Promise<any>,progress:(message:string)=>void=()=>{}){
 async function query(q:string,v:any={}){const r=await graphql(q,v);if(r?.errors?.length||!r?.data)throw new VintedError('Shopify catalog read failed. No partial catalog saved.',502);return r.data}
 const shop=(await query('query FridayVintedIdentity { shop { id name myshopifyDomain currencyCode } }')).shop
 if(shop?.id!==VINTED_SOURCE.shopId||shop?.myshopifyDomain!==VINTED_SOURCE.shopDomain||shop?.currencyCode!=='USD')throw new VintedError('Connected store/currency differs from the verified SALDANA SHOP. No other store was read.',409)
 const productQuery=`query FridayVintedProducts($after:String){ products(first:25,after:$after,query:"status:active"){ nodes { id title handle status vendor productType descriptionHtml onlineStoreUrl updatedAt variants(first:100){ nodes { ${variantFields} } ${pageInfo} } images(first:100){ nodes { id url altText } ${pageInfo} } } ${pageInfo} } }`
 const products=await pages((await query(productQuery)).products,async cursor=>(await query(productQuery,{after:cursor})).products,'products')
 const rows:any[]=[],variantIds=new Set<string>();let imageCount=0
 for(const p of products){progress('Reading '+p.title);const productId=numberId(p.id,'Product');if(p.status!=='ACTIVE')throw new VintedError('Shopify returned a non-active product during the active catalog read. Refresh again.',409)
  const variants=await pages(p.variants,async after=>{const d=await query(`query FridayVintedVariants($id:ID!,$after:String!){ product(id:$id){ id variants(first:100,after:$after){nodes{${variantFields}} ${pageInfo}} } }`,{id:p.id,after});if(d.product?.id!==p.id)throw new VintedError('Product identity changed during variant read.',409);return d.product.variants},'variants')
  const images=await pages(p.images,async after=>{const d=await query(`query FridayVintedImages($id:ID!,$after:String!){product(id:$id){id images(first:100,after:$after){nodes{id url altText} ${pageInfo}}}}`,{id:p.id,after});if(d.product?.id!==p.id)throw new VintedError('Product identity changed during image read.',409);return d.product.images},'images');imageCount+=images.length
  if(!variants.length)throw new VintedError('An active product had no readable variants; no partial catalog saved.',502)
  for(const v of variants){const variantId=numberId(v.id,'ProductVariant');if(variantIds.has(v.id))throw new VintedError('Variant appeared in multiple products; no partial catalog saved.',502);variantIds.add(v.id)
   const options=(v.selectedOptions||[]).map((o:any)=>({name:String(o.name),value:String(o.value)})),quantity=Number.isSafeInteger(v.inventoryQuantity)?v.inventoryQuantity:null
   const urls=[v.image?.url,...images.map((i:any)=>i.url)].map(imageURL).filter((x:any):x is string=>!!x)
   const source={productId:p.id,variantId:v.id,productTitle:String(p.title),variantTitle:String(v.title||''),handle:String(p.handle||''),vendor:String(p.vendor||''),productType:String(p.productType||''),descriptionHtml:String(p.descriptionHtml||''),sku:typeof v.sku==='string'?v.sku:'',barcode:typeof v.barcode==='string'?v.barcode:'',price:money(v.price),currency:'USD',quantity,tracked:v.inventoryItem?.tracked===true,options,images:[...new Set(urls)],updatedAt:p.updatedAt||null,url:`https://saldana.shop/products/${encodeURIComponent(String(p.handle||''))}`,adminUrl:`https://admin.shopify.com/store/1d45b1-13/products/${productId}`}
   rows.push({id:productId+'-'+variantId,source,sourceRevision:digest(source)})
  }
 }
 // Revalidate identity after paging so an account/config change cannot produce a completed snapshot.
 const finalShop=(await query('query FridayVintedIdentity { shop { id name myshopifyDomain currencyCode } }')).shop
 if(finalShop?.id!==shop.id||finalShop?.myshopifyDomain!==shop.myshopifyDomain||finalShop?.currencyCode!==shop.currencyCode)throw new VintedError('Shopify connection changed during catalog reading.',409)
 return{scope:VINTED_SOURCE,completeRead:true,importedAt:new Date().toISOString(),productCount:products.length,variantCount:rows.length,imageCount,rows}
}
