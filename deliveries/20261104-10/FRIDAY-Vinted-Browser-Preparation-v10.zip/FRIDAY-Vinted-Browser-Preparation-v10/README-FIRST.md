# FRIDAY Vinted Browser Preparation v10 — 20261104-10

For Salvador and Dayanna's existing FRIDAY at S:\AI\friday-ai, over Conversational Calendar v9. Shopify source is bound to the store Salvador verified: SALDANA SHOP, 1d45b1-13.myshopify.com, shop 68917625071, USD. Vinted destination is Salvador's US personal profile ending 3174865142. The owner reports owning all inventory. That statement is not used to infer condition, available variant stock or Vinted commercial-selling eligibility.

## What works in this update

- “Vinted listing preparation” opens a private full-width panel inside the existing conversational voice page. Existing voice, Calendar, QuickBooks, dashboard and pointer remain. Type the existing Salvador or Dayanna owner key privately; never speak it or send it in chat.
- Read all active Shopify products, every variant page and every image page, not the five-product connection sample. A wrong store/currency, missing/repeated IDs/cursors or failed page rejects the import. Previous saved notes remain until a complete read succeeds. No PostgreSQL migration or Commerce worker is needed for this workflow.
- Each size/variant has its own draft keyed by real product/variant IDs, including variants sharing SKU/title. Leading-zero SKU/barcodes, exact USD cents and unknown stock are preserved. Unknown stock never becomes one available item. A source vendor is a hint, not a confirmed brand. Condition, category and sizing system require actual owner review.
- Search saved drafts by title, SKU, barcode, brand and size. Choose 50/100/200/300 rows per page, inspect photos/native Shopify links, edit draft fields, save progress and mark complete notes reviewed. Failed/stale saves retain the form; successful saves reload the confirmed stored notes. Editing/source changes invalidate prior review. Removed active products remain as inactive notes, not publishable drafts. Refresh does not overwrite edits made during import.
- Open a dedicated Vinted Chrome tab using FRIDAY's existing persistent Chrome profile. This does not take over the bank-feed active tab or close other pages. Log in and handle verification yourself. Check that the signed-in account is Salvador's intended profile, then check the confirmation box before opening the new-item form. Account identity is manually confirmed by the owner, not automatically proven by FRIDAY.
- Inspect the real form's visible field names/labels/types without passwords, email fields, hidden fields, values or cookies. If title/description/price cannot be identified uniquely by supported observed input names, filling stops and asks for inspection. There are no blind selector guesses.
- A centered review shows exactly what title, description and USD price will be sent to Vinted. One “Yes” to that question, “Approve it”, or the Approve button fills those three fields. A visible FRIDAY marker highlights the browser field. Vinted may autosave these contents. The live draft revision, browser session, new-item URL and original field values are rechecked. Changed forms/reviews stop. Cancelling the review revokes it without filling the form. A repeated fill cannot automatically run twice in the same browser session. Partial/uncertain fills require inspecting the browser.

## Deliberate live-test boundary

This is the first browser-assisted preparation stage, not completed automatic cross-listing. It does not click Publish, upload photos, choose native Vinted category/condition/size/shipping controls, verify account eligibility, reserve/decrement stock, synchronize orders or keep Shopify/Vinted inventory synchronized. No Vinted API credentials are assumed or added. The Vinted marketplace summary now states assisted mode rather than implying that environment keys establish a connection.

The actual logged-in Vinted page, DOM, account permissions and US commercial-selling rules were not reachable from the cloud environment. Treat all eligibility/publishing claims as unverified. Inspect the form on the PC before extending browser automation. No workaround for login challenges or platform access restrictions is included. Do not interpret “notes reviewed” as “published”, “eligible” or “inventory synchronized”. Publishing remains manual; review marketplace eligibility and current stock before doing so. Do not run unattended bulk publishing from the generic browser tools.

## Install from any PowerShell directory

Stop FRIDAY's backend and Vite process. Extract the ZIP under S:\AI\Fixing-Files-Folder\FRIDAY-Vinted-Browser-Preparation-v10. Then run:

```powershell
$packageRoot = 'S:\AI\Fixing-Files-Folder\FRIDAY-Vinted-Browser-Preparation-v10'
$installers = @(Get-ChildItem -LiteralPath $packageRoot -Filter 'Install-Vinted-Browser.ps1' -File -Recurse -ErrorAction Stop)
if ($installers.Count -ne 1) { throw 'Expected exactly one installer. Check the extracted folder.' }
$installer = $installers[0].FullName
Unblock-File -LiteralPath $installer
Unblock-File -LiteralPath (Join-Path (Split-Path $installer) 'Restore-Vinted-Browser.ps1')
& $installer -ProjectPath 'S:\AI\friday-ai'
if (-not $?) { throw 'Installation failed. Do not continue.' }
Set-Location -LiteralPath 'S:\AI\friday-ai'
npm run build
if ($LASTEXITCODE -ne 0) { throw 'Build failed. Do not continue.' }
npm run server
```

In a second terminal:

```powershell
Set-Location -LiteralPath 'S:\AI\friday-ai'
npm run dev
```

Press Ctrl+F5 at https://localhost:5173/ and reconnect voice. No dependency installation, OAuth reset, credential copying or DB migration. The installer validates baseline/required/package hashes and creates a verified backup before copying only eleven listed app/test files. If an installed baseline differs, it stops without copying. It does not override a signed-script policy. The installer itself was reviewed but could not be run on Windows here.

## First PC test

1. Open Vinted listing preparation in the voice page and verify the owner key. Click Read all active Shopify products. Confirm the actual product/variant counts; the earlier response contained only five sample products.
2. Pick one owned item/size you intend to list. Inspect item photos and stock. Supply actual brand, condition, category, size system and shipping notes. Save progress, then Save notes as reviewed.
3. Open my Vinted profile. In the Chrome tab, log in yourself and verify the intended account. Return to FRIDAY and check the account confirmation box. Open new-item form, then Inspect form structure.
4. If the fields are recognized, click Review title / description / price fill, then say “Yes” to its save/fill question or “Approve it” once. Check all three values in Chrome. FRIDAY must not publish. If selectors are not recognized or the fill is partial, inspect the form and send the structure output rather than repeatedly approving/retrying. The output excludes field values and credentials.
5. Photos, category, condition, size and shipping are still manual. Once the real form is validated, the next patch can extend those interactions and define the owner-approved publishing/stock lifecycle. Do not assume inventory synchronization exists before it is implemented and tested.

Useful voice commands: “Open Vinted preparation”, “Read all my Shopify products for Vinted”, “Search my Vinted drafts for Vans”, “Show that size's draft”, “Open my Vinted profile”, “Inspect the Vinted form”, and “Prepare the Vinted form fill”. Pick an actual row when there are multiple sizes. Private notes are per owner, under credentials\commerce\vinted\[owner]\preparation.json. Keep that folder private; do not upload it to GitHub. Draft text can be copied locally with the Copy selected draft text button. No private product/photo export is published to GitHub.

## Restore

Stop FRIDAY, run Restore-Vinted-Browser.ps1 from the printed backups\vinted-browser-v10-[timestamp] directory, rebuild/restart both processes, hard-refresh and reconnect voice. The restore validates hashes and refuses later source edits. Private preparation notes and all existing credentials/data remain. Code rollback does not remove form contents already sent to Vinted or undo a manually published listing. Existing AGENTS.md is never overwritten; the included merge proposal is for review only.
