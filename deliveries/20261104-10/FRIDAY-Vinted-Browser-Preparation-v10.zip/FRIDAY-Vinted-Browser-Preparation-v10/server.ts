import {registerCalendarRoutes} from './calendar/routes'
import 'dotenv/config'
import express from 'express'
import cors from 'cors'
import {
  pool,
} from './db/pool'
import {
  chromium,
  BrowserContext,
  Page,
} from 'playwright'
import { spawn, execFile } from 'child_process'
import twilio from 'twilio'
import {
  twilioClient,
} from './phone/twilio-client'
import { createServer } from 'http'
import WebSocket, {
  WebSocketServer,
} from 'ws'

import {
  registerQuickBooksRoutes,
} from './quickbooks/routes'

import {
  registerGmailRoutes,
} from './gmail/routes'

import {
  registerCommerceRoutes,
} from './commerce/routes'

import {
  registerShopifyRoutes,
} from './shopify/routes'

import {
  registerMarketplaceRoutes,
} from './marketplaces/routes'



const app = express()

app.use(cors())

// ============================================================
// START [SERVER-BODY-LIMIT] LARGE REQUEST SUPPORT
// ============================================================

app.use(
  express.json({
    limit: '35mb',
  })
)

app.use(
  express.urlencoded({
    extended: true,
    limit: '35mb',
  })
)

// ============================================================
// END [SERVER-BODY-LIMIT] LARGE REQUEST SUPPORT
// ============================================================

// ============================================================
// START [PUBLIC-STATIC-01] SERVE PUBLIC FILES
// ============================================================

app.use(
  express.static(
    'public'
  )
)

// ============================================================
// END [PUBLIC-STATIC-01] SERVE PUBLIC FILES
// ============================================================

let browserContext: BrowserContext | null = null
let activePage: Page | null = null

async function createEmbedding(text: string): Promise<number[]> {
  const response = await fetch('https://api.openai.com/v1/embeddings', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model: 'text-embedding-3-small',
      input: text,
    }),
  })

  const data = await response.json()

  if (!response.ok) {
    console.error('Embedding error:', data)
    throw new Error('Failed to create embedding')
  }

  return data.data[0].embedding
}

function vectorToSql(vector: number[]) {
  return `[${vector.join(',')}]`
}

// ============================================================
// START [BROWSER-RECOVERY-01] RECOVER CLOSED BROWSER CONTEXT
// ACTION: REPLACE
// FILE: S:\AI\friday-ai\server.ts
// PLACE: Replace entire existing getBrowser() function
// PURPOSE: Recreate Chrome when closed and always return BrowserContext
// USERS: Salvador and Dayanna
// ============================================================

async function getBrowser(): Promise<BrowserContext> {
  let needsNewBrowser = false

  if (!browserContext) {
    needsNewBrowser = true
  } else {
    try {
      browserContext.pages()
    } catch {
      needsNewBrowser = true
    }
  }

  if (needsNewBrowser) {
    browserContext = null
    activePage = null

    browserContext = await chromium.launchPersistentContext(
      'S:\\AI\\friday-browser-profile',
      {
        channel: 'chrome',
        headless: false,
        viewport: null,
      }
    )

    browserContext.on('close', () => {
      browserContext = null
      activePage = null

      console.log(
        'FRIDAY central browser closed — context cleared'
      )
    })
  }

  if (!browserContext) {
    throw new Error(
      'FRIDAY browser could not be initialized'
    )
  }

  return browserContext
}

// ============================================================
// END [BROWSER-RECOVERY-01] RECOVER CLOSED BROWSER CONTEXT
// ============================================================


function pressMediaKey(
  key: 'playpause' | 'next' | 'previous' | 'stop'
) {
  const keyMap = {
    playpause: 179,
    next: 176,
    previous: 177,
    stop: 178,
  }

  const vk = keyMap[key]

  const command = `
Add-Type -TypeDefinition '
using System;
using System.Runtime.InteropServices;

public class MediaKeys {
    [DllImport("user32.dll")]
    public static extern void keybd_event(
        byte bVk,
        byte bScan,
        uint dwFlags,
        UIntPtr dwExtraInfo
    );
}
';

[MediaKeys]::keybd_event(${vk}, 0, 0, [UIntPtr]::Zero);
Start-Sleep -Milliseconds 100;
[MediaKeys]::keybd_event(${vk}, 0, 2, [UIntPtr]::Zero);
`

  execFile(
    'powershell.exe',
    [
      '-NoProfile',
      '-ExecutionPolicy',
      'Bypass',
      '-Command',
      command,
    ],
    {
      windowsHide: true,
    },
    (error, stdout, stderr) => {
      if (error) {
        console.error(
          'Media key PowerShell error:',
          error
        )
      }

      if (stderr) {
        console.error(
          'Media key stderr:',
          stderr
        )
      }

      if (!error) {
        console.log(
          `Media key sent: ${key}`
        )
      }
    }
  )
}

// ============================================================
// ============================================================

app.get('/health', async (_req, res) => {
  try {
    const result = await pool.query('SELECT NOW()')
    res.json({
      ok: true,
      database: 'connected',
      time: result.rows[0].now,
    })
  } catch (error) {
    console.error(error)
    res.status(500).json({
      ok: false,
      database: 'connection failed',
    })
  }
})

app.post('/memory', async (req, res) => {
  try {
    const {
      scope,
      category,
      title,
      content,
      importance = 5,
      source = 'conversation',
    } = req.body

    if (!scope || !content) {
      return res.status(400).json({
        error: 'scope and content are required',
      })
    }

    if (!['salvador', 'dayanna', 'shared'].includes(scope)) {
      return res.status(400).json({
        error: 'invalid memory scope',
      })
    }

    const userResult = await pool.query(
      `
      SELECT id
      FROM users
      WHERE LOWER(name) = $1
      LIMIT 1
      `,
      [scope]
    )

    const userId =
      userResult.rows.length > 0
        ? userResult.rows[0].id
        : null

    const embeddingText = [
      category,
      title,
      content,
    ]
      .filter(Boolean)
      .join('\n')

    const embedding = await createEmbedding(embeddingText)

    const result = await pool.query(
      `
      INSERT INTO memories (
        user_id,
        scope,
        category,
        title,
        content,
        importance,
        source,
        embedding
      )
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8::vector)
      RETURNING
        id,
        user_id,
        scope,
        category,
        title,
        content,
        importance,
        source,
        created_at
      `,
      [
        userId,
        scope,
        category ?? null,
        title ?? null,
        content,
        importance,
        source,
        vectorToSql(embedding),
      ]
    )

    res.json({
      success: true,
      memory: result.rows[0],
    })
  } catch (error) {
    console.error(error)

    res.status(500).json({
      error: 'failed to save memory',
    })
  }
})

app.get('/session', async (_req, res) => {
  try {
    const response = await fetch(
      'https://api.openai.com/v1/realtime/client_secrets',
      {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          session: {
            type: 'realtime',
            model: 'gpt-realtime-2.1',
          },
        }),
      }
    )

    const data = await response.json()

    if (!response.ok) {
      console.error(data)
      return res.status(response.status).json(data)
    }

    res.json(data)
  } catch (error) {
    console.error(error)
    res.status(500).json({
      error: 'failed to create realtime session',
    })
  }
})

app.get('/memory/search/:scope', async (req, res) => {
  try {
    const { scope } = req.params
    const query = String(req.query.q || '').trim()

    if (!['salvador', 'dayanna', 'shared'].includes(scope)) {
      return res.status(400).json({
        error: 'invalid memory scope',
      })
    }

    if (!query) {
      return res.status(400).json({
        error: 'search query is required',
      })
    }

    let scopes: string[]

    if (scope === 'salvador') {
      scopes = ['salvador', 'shared']
    } else if (scope === 'dayanna') {
      scopes = ['dayanna', 'shared']
    } else {
      scopes = ['shared']
    }

    // Break a natural-language question into useful search terms.
    const ignoredWords = new Set([
      'what',
      'which',
      'where',
      'when',
      'who',
      'why',
      'how',
      'kind',
      'does',
      'do',
      'did',
      'the',
      'and',
      'that',
      'this',
      'with',
      'about',
      'from',
      'have',
      'has',
      'had',
      'prefer',
      'preferred',
      'preference',
      'preferences',
      'remember',
      'salvador',
      'dayanna',
      'please',
      'tell',
      'me',
      'my',
      'our',
      'your',
      'you',
      'i',
      'a',
      'an',
      'is',
      'are',
      'of',
      'to',
      'for',
    ])

    let terms = query
      .toLowerCase()
      .replace(/[^\p{L}\p{N}\s]/gu, ' ')
      .split(/\s+/)
      .filter((word) => word.length >= 3 && !ignoredWords.has(word))

    // If filtering removed everything, use the original query.
    if (terms.length === 0) {
      terms = [query.toLowerCase()]
    }

    const result = await pool.query(
      `
      SELECT
        id,
        scope,
        category,
        title,
        content,
        importance,
        created_at
      FROM memories
      WHERE scope = ANY($1)
        AND EXISTS (
          SELECT 1
          FROM unnest($2::text[]) AS term
          WHERE
            COALESCE(content, '') ILIKE '%' || term || '%'
            OR COALESCE(title, '') ILIKE '%' || term || '%'
            OR COALESCE(category, '') ILIKE '%' || term || '%'
        )
      ORDER BY importance DESC, created_at DESC
      LIMIT 20
      `,
      [scopes, terms]
    )

    res.json(result.rows)
  } catch (error) {
    console.error(error)

    res.status(500).json({
      error: 'failed to search memories',
    })
  }
})

app.post('/memory/backfill', async (_req, res) => {
  try {
    const memories = await pool.query(`
      SELECT id, category, title, content
      FROM memories
      WHERE embedding IS NULL
      ORDER BY id
    `)

    let updated = 0

    for (const memory of memories.rows) {
      const text = [
        memory.category,
        memory.title,
        memory.content,
      ]
        .filter(Boolean)
        .join('\n')

      const embedding = await createEmbedding(text)

      await pool.query(
        `
        UPDATE memories
        SET embedding = $1::vector
        WHERE id = $2
        `,
        [vectorToSql(embedding), memory.id]
      )

      updated++
    }

    res.json({
      success: true,
      updated,
    })
  } catch (error) {
    console.error(error)

    res.status(500).json({
      error: 'memory backfill failed',
    })
  }
})

app.get('/reverse-geocode', async (req, res) => {
  try {
    const lat = req.query.lat
    const lon = req.query.lon

    if (!lat || !lon) {
      return res.status(400).json({
        error: 'Latitude and longitude are required',
      })
    }

    const response = await fetch(
      `https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${lat}&lon=${lon}`,
      {
        headers: {
          'User-Agent': 'FRIDAY-Personal-Assistant/1.0',
        },
      }
    )

    const data = await response.json()

    res.json({
      displayName: data.display_name,
      city:
        data.address?.city ||
        data.address?.town ||
        data.address?.village ||
        data.address?.municipality ||
        null,
      state: data.address?.state || null,
      country: data.address?.country || null,
      postcode: data.address?.postcode || null,
    })
  } catch (error) {
    console.error(error)

    res.status(500).json({
      error: 'Reverse geocoding failed',
    })
  }
})

app.get('/weather', async (req, res) => {
  try {
    const lat = req.query.lat
    const lon = req.query.lon

    if (!lat || !lon) {
      return res.status(400).json({
        error: 'Latitude and longitude are required',
      })
    }

    const url =
      `https://api.open-meteo.com/v1/forecast` +
      `?latitude=${lat}` +
      `&longitude=${lon}` +
      `&current=temperature_2m,apparent_temperature,precipitation,rain,weather_code,wind_speed_10m` +
      `&hourly=temperature_2m,precipitation_probability` +
      `&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max` +
      `&temperature_unit=fahrenheit` +
      `&wind_speed_unit=mph` +
      `&timezone=auto`

    const response = await fetch(url)

    if (!response.ok) {
      throw new Error(`Weather API error: ${response.status}`)
    }

    const data = await response.json()

    res.json(data)
  } catch (error) {
    console.error('Weather error:', error)

    res.status(500).json({
      error: 'Weather lookup failed',
    })
  }
})

app.get('/weather-location', async (req, res) => {
  try {
    const location = String(req.query.location || '').trim()

    if (!location) {
      return res.status(400).json({
        error: 'Location is required',
      })
    }

    // Find coordinates for the requested city/place
    const geoResponse = await fetch(
      `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(location)}&count=1&language=en&format=json`
    )

    if (!geoResponse.ok) {
      throw new Error(`Geocoding failed: ${geoResponse.status}`)
    }

    const geoData = await geoResponse.json()
    const place = geoData.results?.[0]

    if (!place) {
      return res.status(404).json({
        error: `Could not find location: ${location}`,
      })
    }

    const weatherUrl =
      `https://api.open-meteo.com/v1/forecast` +
      `?latitude=${place.latitude}` +
      `&longitude=${place.longitude}` +
      `&current=temperature_2m,apparent_temperature,precipitation,rain,weather_code,wind_speed_10m` +
      `&hourly=temperature_2m,precipitation_probability` +
      `&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max` +
      `&temperature_unit=fahrenheit` +
      `&wind_speed_unit=mph` +
      `&forecast_days=7` +
      `&timezone=auto`

    const weatherResponse = await fetch(weatherUrl)

    if (!weatherResponse.ok) {
      throw new Error(`Weather failed: ${weatherResponse.status}`)
    }

    const weather = await weatherResponse.json()

    res.json({
      location: {
        name: place.name,
        state: place.admin1 ?? null,
        country: place.country ?? null,
        latitude: place.latitude,
        longitude: place.longitude,
        timezone: place.timezone,
      },

      current: weather.current,
      currentUnits: weather.current_units,

      daily: weather.daily,
      dailyUnits: weather.daily_units,

      hourly: weather.hourly,
      hourlyUnits: weather.hourly_units,
    })
  } catch (error) {
    console.error('Location weather error:', error)

    res.status(500).json({
      error: 'Weather lookup failed',
    })
  }
})

app.post('/browser/open', async (req, res) => {
  try {
    let { url } = req.body

    if (!url) {
      return res.status(400).json({
        error: 'URL is required',
      })
    }

    if (!url.startsWith('http://') &&
        !url.startsWith('https://')) {
      url = `https://${url}`
    }

    const context = await getBrowser()

activePage = await context.newPage()

    await activePage.goto(url, {
      waitUntil: 'domcontentloaded',
    })

    res.json({
      success: true,
      url: activePage.url(),
      title: await activePage.title(),
    })
  } catch (error) {
    console.error('Browser open error:', error)

    res.status(500).json({
      error: 'Could not open website',
    })
  }
})

app.post('/browser/search', async (req, res) => {
  try {
    const { query } = req.body

    if (!query) {
      return res.status(400).json({
        error: 'Search query is required',
      })
    }

    const browser = await getBrowser()

    activePage = await browser.newPage()

    const searchUrl =
      `https://www.google.com/search?q=${encodeURIComponent(query)}`

    await activePage.goto(searchUrl, {
      waitUntil: 'domcontentloaded',
    })

    res.json({
      success: true,
      query,
      url: activePage.url(),
    })
  } catch (error) {
    console.error(error)

    res.status(500).json({
      error: 'Search failed',
    })
  }
})

app.post('/browser/site-search', async (req, res) => {
  try {
    const { query } = req.body

    if (!query) {
      return res.status(400).json({
        error: 'Search query is required',
      })
    }

    if (!activePage) {
      return res.status(400).json({
        error: 'No website is currently open',
      })
    }

    const searchBox = activePage.locator(
      [
        'input[type="search"]',
        'input[name*="search" i]',
        'input[placeholder*="search" i]',
        'input[aria-label*="search" i]',
      ].join(',')
    ).first()

    const found = await searchBox.count()

    if (!found) {
      return res.status(404).json({
        error: 'Could not find a search box on this page',
      })
    }

    await searchBox.fill(query)
    await searchBox.press('Enter')

    await activePage.waitForLoadState(
      'domcontentloaded'
    ).catch(() => {})

    res.json({
      success: true,
      query,
      url: activePage.url(),
      title: await activePage.title(),
    })
  } catch (error) {
    console.error('Site search error:', error)

    res.status(500).json({
      error: 'Website search failed',
    })
  }
})

app.post('/browser/homedepot-search', async (req, res) => {
  try {
    const { query } = req.body

    if (!query) {
      return res.status(400).json({
        error: 'Search query is required',
      })
    }

    const url =
      `https://www.homedepot.com/s/${encodeURIComponent(query)}`

    spawn(
      'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
      [url],
      {
        detached: true,
        stdio: 'ignore',
      }
    ).unref()

    res.json({
      success: true,
      query,
      url,
    })
  } catch (error) {
    console.error(error)

    res.status(500).json({
      error: 'Home Depot search failed',
    })
  }
})

app.get('/browser/page-state', async (_req, res) => {
  try {
    if (!activePage) {
      return res.status(400).json({
        error: 'No active browser page',
      })
    }

    const data = await activePage.evaluate(() => {
      const allElements = Array.from(
        document.querySelectorAll(
          'a, button, input, textarea, select'
        )
      )

      const elements = allElements
        .filter((el) => {
          const style = window.getComputedStyle(el)
          const rect = el.getBoundingClientRect()

          return (
            style.display !== 'none' &&
            style.visibility !== 'hidden' &&
            rect.width > 0 &&
            rect.height > 0
          )
        })
        .slice(0, 150)
        .map((el) => {
          const element = el as HTMLElement
          const input = el as HTMLInputElement

          return {
            tag: el.tagName.toLowerCase(),

            text:
              element.innerText?.trim() ||
              input.value ||
              '',

            ariaLabel:
              el.getAttribute('aria-label'),

            placeholder:
              el.getAttribute('placeholder'),

            name:
              el.getAttribute('name'),

            type:
              el.getAttribute('type'),

            href:
              el.getAttribute('href'),
          }
        })

      return {
        title: document.title,
        url: window.location.href,

        text:
          document.body.innerText
            .replace(/\s+/g, ' ')
            .slice(0, 12000),

        elements,
      }
    })

    res.json({
      success: true,
      ...data,
    })
  } catch (error) {
    console.error(
      'Page inspection error:',
      error
    )

    res.status(500).json({
      error: 'Could not inspect page',
    })
  }
})

app.post('/browser/click', async (req, res) => {
  try {
    const { text } = req.body

    if (!activePage) {
      return res.status(400).json({
        error: 'No active page',
      })
    }

    if (!text) {
      return res.status(400).json({
        error: 'Element text is required',
      })
    }

    const locator = activePage
      .getByText(text, { exact: false })
      .first()

    await locator.click()

    await activePage
      .waitForLoadState('domcontentloaded')
      .catch(() => {})

    res.json({
      success: true,
      url: activePage.url(),
      title: await activePage.title(),
    })
  } catch (error) {
    console.error('Browser click error:', error)

    res.status(500).json({
      error: 'Could not click element',
    })
  }
})

app.post('/browser/type', async (req, res) => {
  try {
    const { value, placeholder, ariaLabel } = req.body

    if (!activePage) {
      return res.status(400).json({
        error: 'No active page',
      })
    }

    let locator

    if (ariaLabel) {
      locator = activePage.getByLabel(
        ariaLabel,
        { exact: false }
      )
    } else if (placeholder) {
      locator = activePage.getByPlaceholder(
        placeholder,
        { exact: false }
      )
    } else {
      locator = activePage
        .locator(
          'input[type="search"], input[type="text"], textarea'
        )
        .first()
    }

    await locator.fill(value)

    res.json({
      success: true,
      value,
    })
  } catch (error) {
    console.error('Browser type error:', error)

    res.status(500).json({
      error: 'Could not type into element',
    })
  }
})

app.post('/browser/press-enter', async (_req, res) => {
  try {
    if (!activePage) {
      return res.status(400).json({
        error: 'No active page',
      })
    }

    await activePage.keyboard.press('Enter')

    await activePage
      .waitForLoadState('domcontentloaded')
      .catch(() => {})

    res.json({
      success: true,
      url: activePage.url(),
      title: await activePage.title(),
    })
  } catch (error) {
    console.error(error)

    res.status(500).json({
      error: 'Could not press Enter',
    })
  }
})

app.post('/browser/youtube-search', async (req, res) => {
  try {
    const { query, playFirst = false } = req.body

    if (!query) {
      return res.status(400).json({
        error: 'Search query required',
      })
    }

    const browser = await getBrowser()

    // Use Playwright only to find the video
    const searchPage = await browser.newPage()

    const searchUrl =
      `https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`

    await searchPage.goto(searchUrl, {
      waitUntil: 'domcontentloaded',
    })

    await searchPage.waitForSelector(
      'ytd-video-renderer a#video-title',
      {
        timeout: 15000,
      }
    )

    const firstVideo = searchPage
      .locator('ytd-video-renderer a#video-title')
      .first()

    const title =
      (await firstVideo.getAttribute('title')) ||
      (await firstVideo.innerText())

    const href =
      await firstVideo.getAttribute('href')

    if (!href) {
      throw new Error('Could not find YouTube video URL')
    }

    const videoUrl =
      href.startsWith('http')
        ? href
        : `https://www.youtube.com${href}`

    await searchPage.close()

    if (playFirst) {
      const chromePath =
        'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'

      spawn(
        chromePath,
        [videoUrl],
        {
          detached: true,
          stdio: 'ignore',
        }
      ).unref()
    }

    res.json({
      success: true,
      query,
      title,
      videoUrl,
      playing: playFirst,
    })
  } catch (error) {
    console.error('YouTube error:', error)

    res.status(500).json({
      error: 'YouTube search or playback failed',
    })
  }
})

app.post('/media/playpause', (_req, res) => {
  pressMediaKey('playpause')

  res.json({
    success: true,
    action: 'playpause',
  })
})

app.post('/media/next', (_req, res) => {
  pressMediaKey('next')

  res.json({
    success: true,
    action: 'next',
  })
})

app.post('/media/previous', (_req, res) => {
  pressMediaKey('previous')

  res.json({
    success: true,
    action: 'previous',
  })
})

app.post('/media/stop', (_req, res) => {
  pressMediaKey('stop')

  res.json({
    success: true,
    action: 'stop',
  })
})

// ============================================================
// START [PHONE-02] BROWSER VOICE TOKEN
// ACTION: ADD
// FILE: S:\AI\friday-ai\server.ts
// PLACE: Before app.listen(...)
// PURPOSE: Issue short-lived Twilio Voice token to FRIDAY browser
// USERS: Salvador and Dayanna
// ============================================================

app.get(
  '/phone/token',
  async (req, res) => {
    try {
      const {
        TWILIO_ACCOUNT_SID,
        TWILIO_API_KEY,
        TWILIO_API_SECRET,
        TWILIO_TWIML_APP_SID,
      } = process.env


      if (
        !TWILIO_ACCOUNT_SID ||
        !TWILIO_API_KEY ||
        !TWILIO_API_SECRET ||
        !TWILIO_TWIML_APP_SID
      ) {
        res.status(500).json({
          success: false,
          error:
            'Twilio browser credentials are not configured.',
        })

        return
      }


      const AccessToken =
        twilio.jwt.AccessToken

      const VoiceGrant =
        AccessToken.VoiceGrant


      const identity =
        String(
          req.query.identity ||
          'friday-browser'
        )


      const token =
        new AccessToken(
          TWILIO_ACCOUNT_SID,
          TWILIO_API_KEY,
          TWILIO_API_SECRET,
          {
            identity,
            ttl: 3600,
          }
        )


      const voiceGrant =
        new VoiceGrant({
          outgoingApplicationSid:
            TWILIO_TWIML_APP_SID,

          incomingAllow: true,
        })


      token.addGrant(
        voiceGrant
      )


      res.json({
        success: true,
        identity,
        token:
          token.toJwt(),
      })
    } catch (error) {
      console.error(
        'PHONE TOKEN ERROR:',
        error
      )

      res.status(500).json({
        success: false,
        error:
          String(error),
      })
    }
  }
)

// ============================================================
// END [PHONE-02] BROWSER VOICE TOKEN
// ============================================================

// ============================================================
// START [PHONE-03] TWILIO VOICE TWIML
// ACTION: REPLACE
// FILE: S:\AI\friday-ai\server.ts
// PLACE: Before app.listen(...)
// PURPOSE: Return TwiML instructions for FRIDAY browser calls
// USERS: Salvador and Dayanna
// ============================================================

app.post('/phone/twiml', (req, res) => {
  try {
    const response =
      new twilio.twiml.VoiceResponse()

    const conferenceName =
      String(
        req.body?.conference ??
        req.query?.conference ??
        'friday-test-conference'
      )

    const mode =
      String(
        req.body?.mode ??
        req.query?.mode ??
        'listen'
      )

    const dial =
      response.dial()

    dial.conference(
      {
        beep: 'false',

        muted:
          mode === 'listen',

        startConferenceOnEnter:
          true,

        endConferenceOnExit:
          false,
      },
      conferenceName
    )

    res
      .type('text/xml')
      .send(
        response.toString()
      )

  } catch (error) {
    console.error(
      'PHONE TWIML ERROR:',
      error
    )

    res
      .status(500)
      .send(
        'Unable to generate TwiML.'
      )
  }
})

// ============================================================
// END [PHONE-03] TWILIO VOICE TWIML
// ============================================================

// ============================================================
// START [PHONE-04] OUTBOUND CONFERENCE CALL
// ACTION: ADD
// FILE: S:\AI\friday-ai\server.ts
// PLACE: Before app.listen(...)
// PURPOSE: Call a phone number and place it into a FRIDAY conference
// USERS: Salvador and Dayanna
// ============================================================

app.post('/phone/call', async (req, res) => {
  try {
    const to =
      String(
        req.body?.to || ''
      ).trim()

    const conferenceName =
      String(
        req.body?.conference ||
        `friday-${Date.now()}`
      )

    if (!to) {
      res.status(400).json({
        success: false,
        error:
          'Destination phone number is required.',
      })

      return
    }

    const from =
      process.env.TWILIO_PHONE_NUMBER

    if (!from) {
      throw new Error(
        'TWILIO_PHONE_NUMBER is not configured.'
      )
    }

    const participant =
      await twilioClient
        .conferences(
          conferenceName
        )
        .participants
        .create({
  from,
  to,

  startConferenceOnEnter:
    true,

  endConferenceOnExit:
    false,

  beep:
    'false',

  earlyMedia:
    true,

  statusCallback:
    'https://friday.dangelvi.com/phone/call-status',

  statusCallbackMethod:
    'POST',

  statusCallbackEvent: [
    'initiated',
    'ringing',
    'answered',
    'completed',
  ],
})

    res.json({
      success: true,

      conference:
        conferenceName,

      callSid:
        participant.callSid,

      status:
        participant.status,
    })
  } catch (error) {
    console.error(
      'PHONE OUTBOUND CALL ERROR:',
      error
    )

    res.status(500).json({
      success: false,
      error:
        String(error),
    })
  }
})

// ============================================================
// END [PHONE-04] OUTBOUND CONFERENCE CALL
// ============================================================

// ============================================================
// START [PHONE-04B] OUTBOUND CALL STATUS CALLBACK
// ACTION: ADD
// FILE: S:\AI\friday-ai\server.ts
// PLACE: Before app.listen(...)
// PURPOSE: Log Twilio outbound call progress and failures
// USERS: Salvador and Dayanna
// ============================================================

app.post('/phone/call-status', (req, res) => {
  try {
    console.log(
      '=============================='
    )

    console.log(
      'FRIDAY PHONE STATUS'
    )

    console.log({
      callSid:
        req.body?.CallSid,

      callStatus:
        req.body?.CallStatus,

      from:
        req.body?.From,

      to:
        req.body?.To,

      timestamp:
        new Date().toISOString(),
    })

    console.log(
      'FULL TWILIO STATUS BODY:',
      req.body
    )

    console.log(
      '=============================='
    )

    res.sendStatus(200)
  } catch (error) {
    console.error(
      'PHONE STATUS CALLBACK ERROR:',
      error
    )

    res.sendStatus(500)
  }
})

// ============================================================
// END [PHONE-04B] OUTBOUND CALL STATUS CALLBACK
// ============================================================

// ============================================================
// START [PHONE-06] FRIDAY AI PHONE TWIML
// ACTION: ADD
// FILE: S:\AI\friday-ai\server.ts
// PLACE: Before server startup
// PURPOSE: Connect an answered phone call to FRIDAY live audio
// USERS: Salvador and Dayanna
// ============================================================

app.post('/phone/ai-twiml', (req, res) => {
  try {
    const publicBaseUrl =
      process.env.FRIDAY_PUBLIC_BASE_URL

    if (!publicBaseUrl) {
      throw new Error(
        'FRIDAY_PUBLIC_BASE_URL is not configured.'
      )
    }

    const websocketUrl =
      publicBaseUrl
        .replace(
          /^https:/i,
          'wss:'
        )
        .replace(
          /^http:/i,
          'ws:'
        ) +
      '/phone/media'

    const response =
      new twilio.twiml.VoiceResponse()

    const connect =
      response.connect()

    connect.stream({
      url: websocketUrl,
    })

    res
      .type('text/xml')
      .send(
        response.toString()
      )
  } catch (error) {
    console.error(
      'PHONE AI TWIML ERROR:',
      error
    )

    res
      .status(500)
      .send(
        'Unable to generate AI call TwiML.'
      )
  }
})

// ============================================================
// END [PHONE-06] FRIDAY AI PHONE TWIML
// ============================================================

// ============================================================
// START [PHONE-07] FRIDAY AI OUTBOUND TEST CALL
// ACTION: ADD
// FILE: S:\AI\friday-ai\server.ts
// PLACE: Before server startup
// PURPOSE: Call a phone number and connect FRIDAY directly
// USERS: Salvador and Dayanna
// ============================================================

app.post(
  '/phone/ai-call',
  async (req, res) => {
    try {
      const to =
        String(
          req.body?.to || ''
        ).trim()

      if (!to) {
        res.status(400).json({
          success: false,
          error:
            'Destination phone number is required.',
        })

        return
      }

      const from =
        process.env
          .TWILIO_PHONE_NUMBER

      const publicBaseUrl =
        process.env
          .FRIDAY_PUBLIC_BASE_URL

      if (!from) {
        throw new Error(
          'TWILIO_PHONE_NUMBER is not configured.'
        )
      }

      if (!publicBaseUrl) {
        throw new Error(
          'FRIDAY_PUBLIC_BASE_URL is not configured.'
        )
      }

      const call =
        await twilioClient
          .calls
          .create({
            to,
            from,

            url:
              `${publicBaseUrl}/phone/ai-twiml`,

            method:
              'POST',

            statusCallback:
              `${publicBaseUrl}/phone/call-status`,

            statusCallbackMethod:
              'POST',

            statusCallbackEvent: [
              'initiated',
              'ringing',
              'answered',
              'completed',
            ],
          })

      res.json({
        success: true,
        callSid:
          call.sid,
        status:
          call.status,
      })
    } catch (error) {
      console.error(
        'PHONE AI CALL ERROR:',
        error
      )

      res.status(500).json({
        success: false,
        error:
          String(error),
      })
    }
  }
)

// ============================================================
// END [PHONE-07] FRIDAY AI OUTBOUND TEST CALL
// ============================================================

// ============================================================
// START [PHONE-08] SHARED HTTP + WEBSOCKET SERVER
// ACTION: REPLACE
// FILE: S:\AI\friday-ai\server.ts
// PLACE: Replace the existing app.listen(...)
// PURPOSE: Run Express and Twilio Media Streams on port 3001
// USERS: Salvador and Dayanna
// ============================================================

const httpServer =
  createServer(app)

const phoneWss =
  new WebSocketServer({
    noServer: true,
  })


httpServer.on(
  'upgrade',
  (
    request,
    socket,
    head
  ) => {
    const pathname =
      new URL(
        request.url || '/',
        'http://localhost'
      ).pathname

    if (
      pathname !==
      '/phone/media'
    ) {
      socket.destroy()
      return
    }

    phoneWss.handleUpgrade(
      request,
      socket,
      head,
      ws => {
        phoneWss.emit(
          'connection',
          ws,
          request
        )
      }
    )
  }
)


phoneWss.on(
  'connection',
  twilioWs => {
    console.log(
      'FRIDAY PHONE MEDIA CONNECTED'
    )

    let streamSid =
      ''

    let openAiReady =
      false

    let initialGreetingSent =
      false


    const openAiWs =
      new WebSocket(
        'wss://api.openai.com/v1/realtime?model=gpt-realtime-2.1',
        {
          headers: {
            Authorization:
              `Bearer ${process.env.OPENAI_API_KEY}`,
          },
        }
      )


    openAiWs.on(
      'open',
      () => {
        console.log(
          'OPENAI PHONE REALTIME CONNECTED'
        )

        const sessionUpdate = {
          type:
            'session.update',

          session: {
            type:
              'realtime',

            model:
              'gpt-realtime-2.1',

            output_modalities: [
              'audio',
            ],

            instructions:
              `
You are FRIDAY, Salvador's AI assistant.

You are currently making a test phone call to simulate a restaurant reservation.

Important:
- Clearly identify yourself as an AI assistant calling on behalf of Salvador.
- Be natural, polite, concise, and professional.
- Ask for a dinner reservation for 2 people tomorrow at 7:00 PM.
- If 7:00 PM is unavailable, ask for availability between 6:00 PM and 8:00 PM.
- Select a reasonable available time within that range.
- Confirm the final date, time, party size, and reservation name as Salvador.
- Do not provide payment information.
- Do not agree to deposits, cancellation fees, or charges.
- If the other person asks for sensitive information, politely decline.
- Once the reservation is clearly confirmed, thank them and end naturally.
- For this test, the person answering is pretending to be the restaurant host.
              `.trim(),

            // ============================================================
// START [PHONE-08A] TWILIO COMPATIBLE AUDIO FORMAT
// ACTION: REPLACE
// FILE: S:\AI\friday-ai\server.ts
// PLACE: Inside the OpenAI session.update object in [PHONE-08]
// PURPOSE: Match Twilio G.711 μ-law audio with OpenAI Realtime
// USERS: Salvador and Dayanna
// ============================================================

audio: {
  input: {
    format: {
      type:
        'audio/pcmu',
    },

    turn_detection: {
      type:
        'semantic_vad',
    },
  },

  output: {
    format: {
      type:
        'audio/pcmu',
    },

    voice:
      'marin',
  },
},

// ============================================================
// END [PHONE-08A] TWILIO COMPATIBLE AUDIO FORMAT
// ============================================================
          },
        }

        openAiWs.send(
          JSON.stringify(
            sessionUpdate
          )
        )
      }
    )


    openAiWs.on(
      'message',
      data => {
        try {
          const event =
            JSON.parse(
              data.toString()
            )

          if (
            event.type ===
            'session.updated'
          ) {
            openAiReady =
              true

            console.log(
              'OPENAI PHONE SESSION READY'
            )

            if (
              !initialGreetingSent
            ) {
              initialGreetingSent =
                true

              openAiWs.send(
                JSON.stringify({
                  type:
                    'response.create',

                  response: {
                    instructions:
                      'Begin the call now. Introduce yourself as FRIDAY, an AI assistant calling on behalf of Salvador, and ask to make the restaurant reservation.',
                  },
                })
              )
            }

            return
          }


          if (
            event.type ===
            'response.output_audio.delta'
          ) {
            if (
              !streamSid ||
              twilioWs.readyState !==
                WebSocket.OPEN
            ) {
              return
            }

            twilioWs.send(
              JSON.stringify({
                event:
                  'media',

                streamSid,

                media: {
                  payload:
                    event.delta,
                },
              })
            )

            return
          }


          if (
            event.type ===
            'response.output_audio_transcript.delta'
          ) {
            process.stdout.write(
              event.delta || ''
            )

            return
          }


          if (
            event.type ===
            'error'
          ) {
            console.error(
              'OPENAI PHONE ERROR:',
              event
            )
          }
        } catch (error) {
          console.error(
            'OPENAI PHONE MESSAGE ERROR:',
            error
          )
        }
      }
    )


    openAiWs.on(
      'error',
      error => {
        console.error(
          'OPENAI PHONE WEBSOCKET ERROR:',
          error
        )
      }
    )


    twilioWs.on(
      'message',
      data => {
        try {
          const message =
            JSON.parse(
              data.toString()
            )


          if (
            message.event ===
            'start'
          ) {
            streamSid =
              message.start
                ?.streamSid ||
              message.streamSid ||
              ''

            console.log(
              'TWILIO STREAM STARTED:',
              streamSid
            )

            return
          }


          if (
            message.event ===
            'media'
          ) {
            if (
              !openAiReady ||
              openAiWs.readyState !==
                WebSocket.OPEN
            ) {
              return
            }

            const payload =
              message.media
                ?.payload

            if (!payload) {
              return
            }

            openAiWs.send(
              JSON.stringify({
                type:
                  'input_audio_buffer.append',

                audio:
                  payload,
              })
            )

            return
          }


          if (
            message.event ===
            'stop'
          ) {
            console.log(
              'TWILIO STREAM STOPPED'
            )

            if (
              openAiWs.readyState ===
              WebSocket.OPEN
            ) {
              openAiWs.close()
            }
          }
        } catch (error) {
          console.error(
            'TWILIO MEDIA MESSAGE ERROR:',
            error
          )
        }
      }
    )


    twilioWs.on(
      'close',
      () => {
        console.log(
          'FRIDAY PHONE MEDIA DISCONNECTED'
        )

        if (
          openAiWs.readyState ===
          WebSocket.OPEN
        ) {
          openAiWs.close()
        }
      }
    )
  }
)

// ============================================================

// ============================================================
// START [GLOBAL-MESSAGING-01] GLOBAL MESSAGE BEHAVIOR
// ACTION: REPLACE
// FILE: S:\AI\friday-ai\server.ts
// PLACE: Replace the complete existing [GLOBAL-MESSAGING-01] block
// PURPOSE: Global bilingual message behavior with UTF-8 / Spanish text hardening
// USERS: Salvador and Dayanna
// ============================================================

type FridayMessageMode =
  | 'exact'
  | 'improve'
  | 'generate'

type FridayMessageLanguage =
  | 'auto'
  | 'english'
  | 'spanish'

type FridayMessageTone =
  | 'professional'
  | 'friendly'
  | 'firm'
  | 'concise'
  | 'collections'
  | 'customer-service'
  | 'warm'
  | 'formal'


// ============================================================
// START [GLOBAL-MESSAGING-01A] TEXT REPAIR
// ACTION: ADD
// FILE: S:\AI\friday-ai\server.ts
// PLACE: Inside [GLOBAL-MESSAGING-01]
// PURPOSE: Repair common Spanish encoding corruption before intent analysis
// USERS: Salvador and Dayanna
// ============================================================

function repairFridayTextEncoding(
  value:
    string
) {
  let text =
    String(
      value ||
      ''
    )

  // Common UTF-8 interpreted as Windows-1252 / Latin-1.
  const replacements:
    Array<
      [
        string,
        string
      ]
    > = [
      ['Ã¡', 'á'],
      ['Ã©', 'é'],
      ['Ã­', 'í'],
      ['Ã³', 'ó'],
      ['Ãº', 'ú'],
      ['Ã±', 'ñ'],
      ['Ã', 'Á'],
      ['Ã‰', 'É'],
      ['Ã', 'Í'],
      ['Ã“', 'Ó'],
      ['Ãš', 'Ú'],
      ['Ã‘', 'Ñ'],
      ['Â¿', '¿'],
      ['Â¡', '¡'],
      ['â€™', "'"],
      ['â€œ', '"'],
      ['â€', '"'],
      ['â€“', '-'],
      ['â€”', '-'],
    ]

  for (
    const [
      broken,
      fixed,
    ]
    of replacements
  ) {
    text =
      text.split(
        broken
      )
        .join(
          fixed
        )
  }

  // Harden against replacement-character corruption seen in
  // Windows PowerShell tests.
  //
  // Example received:
  // "�qui�n debe m�s a Nationwide?"
  //
  // These targeted repairs recover common FRIDAY Spanish commands
  // without changing correctly encoded text.

  const corruptedPhraseRepairs:
    Array<
      [
        RegExp,
        string
      ]
    > = [
      [
        /�?qui�n/gi,
        'quien',
      ],
      [
        /m�s/gi,
        'mas',
      ],
      [
        /d�as/gi,
        'dias',
      ],
      [
        /factur�/gi,
        'factura',
      ],
      [
        /vencid�/gi,
        'vencida',
      ],
      [
        /pag�/gi,
        'pago',
      ],
      [
        /env�[ai]/gi,
        'envia',
      ],
      [
        /escr�b[ea]/gi,
        'escribe',
      ],
      [
        /muestr�me/gi,
        'muestrame',
      ],
    ]

  for (
    const [
      pattern,
      fixed,
    ]
    of corruptedPhraseRepairs
  ) {
    text =
      text.replace(
        pattern,
        fixed
      )
  }

  return text
}

// ============================================================
// END [GLOBAL-MESSAGING-01A] TEXT REPAIR
// ============================================================


// ============================================================
// START [GLOBAL-MESSAGING-01B] TEXT NORMALIZATION
// ACTION: MODIFY
// FILE: S:\AI\friday-ai\server.ts
// PLACE: Inside [GLOBAL-MESSAGING-01]
// PURPOSE: Normalize English, Spanish and Spanglish safely
// USERS: Salvador and Dayanna
// ============================================================

function normalizeFridayText(
  value:
    string
) {
  return repairFridayTextEncoding(
    value
  )
    .toLowerCase()
    .normalize(
      'NFD'
    )
    .replace(
      /[\u0300-\u036f]/g,
      ''
    )
    .replace(
      /[¿?¡!]/g,
      ' '
    )
    .replace(
      /\uFFFD/g,
      ' '
    )
    .replace(
      /\s+/g,
      ' '
    )
    .trim()
}

// ============================================================
// END [GLOBAL-MESSAGING-01B] TEXT NORMALIZATION
// ============================================================


function detectFridayLanguage(
  originalText:
    string
): FridayMessageLanguage {
  const text =
    normalizeFridayText(
      originalText
    )

  const spanishWords = [
    'que',
    'quien',
    'cuanto',
    'cuantos',
    'factura',
    'facturas',
    'cliente',
    'clientes',
    'pago',
    'pagos',
    'vencida',
    'vencido',
    'vencidas',
    'vencidos',
    'muestrame',
    'ensename',
    'busca',
    'crear',
    'crea',
    'enviar',
    'envia',
    'escribe',
    'escribelo',
    'mejora',
    'mejoralo',
    'recordatorio',
    'cobro',
    'debe',
    'deben',
    'gastos',
    'proveedor',
    'proveedores',
    'transaccion',
    'transacciones',
    'banco',
    'cuenta',
    'conciliar',
    'categoria',
    'categorizar',
    'mes',
    'este',
    'esta',
    'por',
    'para',
    'con',
    'del',
    'los',
    'las',
  ]

  const englishWords = [
    'show',
    'find',
    'create',
    'send',
    'write',
    'improve',
    'invoice',
    'invoices',
    'customer',
    'customers',
    'payment',
    'payments',
    'overdue',
    'expense',
    'expenses',
    'vendor',
    'vendors',
    'transaction',
    'transactions',
    'account',
    'bank',
    'reconcile',
    'category',
    'categorize',
    'month',
    'this',
    'the',
    'for',
    'with',
  ]

  let spanishScore =
    0

  let englishScore =
    0

  const words =
    new Set(
      text.split(
        /\s+/
      )
    )

  for (
    const word
    of spanishWords
  ) {
    if (
      words.has(
        word
      )
    ) {
      spanishScore +=
        1
    }
  }

  for (
    const word
    of englishWords
  ) {
    if (
      words.has(
        word
      )
    ) {
      englishScore +=
        1
    }
  }

  if (
    spanishScore >
    englishScore
  ) {
    return 'spanish'
  }

  if (
    englishScore >
    spanishScore
  ) {
    return 'english'
  }

  return 'auto'
}


function detectFridayMessageMode(
  originalText:
    string
): FridayMessageMode {
  const text =
    normalizeFridayText(
      originalText
    )

  const exactPhrases = [
    'exactly what i said',
    'use my exact words',
    'do not change it',
    'dont change it',
    'sin cambiarlo',
    'exactamente como lo dije',
    'usa mis palabras',
    'tal como lo dije',
  ]

  if (
    exactPhrases.some(
      phrase =>
        text.includes(
          phrase
        )
    )
  ) {
    return 'exact'
  }

  const improvePhrases = [
    'improve it',
    'improve this',
    'make it better',
    'make it professional',
    'more professional',
    'rewrite it',
    'mejoralo',
    'mejora esto',
    'hazlo mejor',
    'hazlo profesional',
    'mas profesional',
    'corrigelo',
  ]

  if (
    improvePhrases.some(
      phrase =>
        text.includes(
          phrase
        )
    )
  ) {
    return 'improve'
  }

  return 'generate'
}


function detectFridayMessageTone(
  originalText:
    string
): FridayMessageTone {
  const text =
    normalizeFridayText(
      originalText
    )

  if (
    text.includes(
      'collection'
    ) ||
    text.includes(
      'collections'
    ) ||
    text.includes(
      'cobranza'
    ) ||
    text.includes(
      'cobro'
    ) ||
    text.includes(
      'past due'
    ) ||
    text.includes(
      'overdue'
    ) ||
    text.includes(
      'vencid'
    )
  ) {
    return 'collections'
  }

  if (
    text.includes(
      'firm'
    ) ||
    text.includes(
      'firme'
    ) ||
    text.includes(
      'stronger'
    )
  ) {
    return 'firm'
  }

  if (
    text.includes(
      'friendly'
    ) ||
    text.includes(
      'amable'
    )
  ) {
    return 'friendly'
  }

  if (
    text.includes(
      'formal'
    )
  ) {
    return 'formal'
  }

  if (
    text.includes(
      'short'
    ) ||
    text.includes(
      'concise'
    ) ||
    text.includes(
      'corto'
    ) ||
    text.includes(
      'breve'
    )
  ) {
    return 'concise'
  }

  if (
    text.includes(
      'warm'
    ) ||
    text.includes(
      'calido'
    )
  ) {
    return 'warm'
  }

  if (
    text.includes(
      'customer service'
    ) ||
    text.includes(
      'servicio al cliente'
    )
  ) {
    return 'customer-service'
  }

  return 'professional'
}

// ============================================================
// END [GLOBAL-MESSAGING-01] GLOBAL MESSAGE BEHAVIOR
// ============================================================


// ============================================================
// START [GMAIL-MODULE-01] REGISTER GMAIL MODULE
// PURPOSE: Load all Gmail routes from gmail/routes.ts
// ============================================================

registerGmailRoutes(
  app
)

registerCalendarRoutes(app)

// ============================================================
// END [GMAIL-MODULE-01] REGISTER GMAIL MODULE
// ============================================================

// ============================================================
// START [QUICKBOOKS-MODULE-01] REGISTER QUICKBOOKS MODULE
// PURPOSE: Load all QuickBooks routes from quickbooks/routes.ts
// ============================================================

registerQuickBooksRoutes(
  app,
  {
    normalizeFridayText,
    detectFridayLanguage,
    detectFridayMessageMode,
    detectFridayMessageTone,
  }
)

registerCommerceRoutes(app)

registerShopifyRoutes(
  app,
  {getBrowser}
)

registerMarketplaceRoutes(
  app
)
// ============================================================
// END [QUICKBOOKS-MODULE-01] REGISTER QUICKBOOKS MODULE
// ============================================================

// ============================================================


// ============================================================

// ============================================================

// ============================================================


httpServer.listen(
  3001,
  '0.0.0.0',
  () => {
    console.log(
      'FRIDAY backend running on http://localhost:3001'
    )

    console.log(
      'FRIDAY phone WebSocket ready at /phone/media'
    )
  }
)

// ============================================================
// END [PHONE-08] SHARED HTTP + WEBSOCKET SERVER
// ============================================================
