export function researchStock(report:any,productId:string){
 const product=report?.owned?.find((p:any)=>p.id===productId)
 if(!product)return null
 return{title:product.title,variants:(product.variants||[]).map((v:any)=>({
  id:v.id,title:v.title,sku:v.sku,quantity:v.tracked===false?null:v.quantity??null,priceUSD:v.priceUSD??null,
  merchandiseUSD:v.merchandiseUSD??null,costBasis:v.costBasis||'Unknown cost source',
  estimatedContributionUSD:v.estimatedContributionUSD??null,missingCosts:v.missingCosts||[],
  promotionReady:v.tracked!==false&&Number.isSafeInteger(v.quantity)&&v.quantity>0&&v.estimatedContributionUSD!==null&&v.estimatedContributionUSD!==undefined&&Number(v.estimatedContributionUSD)>0&&!(v.missingCosts||[]).length
 }))}
}

export const googleProductSearch=(title:string)=>'https://www.google.com/search?q='+encodeURIComponent(title+' price buy')
