import test from 'node:test'
import assert from 'node:assert/strict'
import {directProductURL,quotedUSD} from '../commerce/daily/market-evidence'
import {buildResearch} from '../commerce/daily/research'
import {DEFAULTS} from '../commerce/daily/core'
import {researchStock,googleProductSearch} from '../src/research-stock'

test('Search and collection URLs never become exact product evidence',()=>{
 for(const url of [
  'https://shop.tiktok.com/us/k/oldskool-vans','https://www.amazon.com/s?k=Vans',
  'https://www.ebay.com/sch/i.html?_nkw=Vans','https://www.facebook.com/marketplace/search?q=Vans',
  'https://www.google.com/shopping/search?q=Vans','https://www.vans.com/shop/shoes-classics-old-skool',
  'https://example.com/collections/shoes','https://example.com/search?q=shoes'
 ])assert.equal(directProductURL(url),false,url)
 for(const url of ['https://shop.tiktok.com/us/pdp/exact-shoe/1234567890','https://www.amazon.com/dp/B012345678','https://www.ebay.com/itm/exact-shoe/123456789','https://www.facebook.com/marketplace/item/123456789','https://example.com/products/exact-shoe'])assert.equal(directProductURL(url),true,url)
 assert.equal(quotedUSD('Only $9.75 asking','97.50'),false);assert.equal(quotedUSD('USD 97.50 asking','97.50'),true);assert.equal(quotedUSD('No price here','0.00'),false)
})

test('The supplied general-page pattern cannot support price, fees, speed or a high-demand recommendation',()=>{
 const buy='https://www.vans.com/shop/shoes-classics-old-skool',sell='https://shop.tiktok.com/us/k/oldskool-vans',id='gid://shopify/Product/123'
 const raw={products:[{kind:'owned_inventory',existingProductId:id,title:'Fixture chocolate shoe',why:'High demand, sells fast!',offers:[{supplier:'Fixture source',url:buy,currency:'USD',variantMatch:'exact',quote:'$5.00',units:1,itemTotalUSD:'5.00',shippingUSD:'0.00',taxUSD:'0.00',otherUSD:'0.00'}],channels:[{name:'TikTok Shop',url:sell,currency:'USD',variantMatch:'exact',quote:'$97.50 asking',priceUSD:'97.50',priceBasis:'asking',sellingFeeUSD:'0.00',soldCount:100,windowDays:1,eligibility:'free shipping'}]}]}
 const result=buildResearch(raw,[{url:buy},{url:sell}],DEFAULTS,new Set([id,'gid://shopify/Product/456']))
 const p=result.products[0],c=p.channels[0];assert.equal(c.sourceLinked,true);assert.equal(c.comparablePrice,false);assert.equal(c.priceUSD,null);assert.equal(c.sellingFeeUSD,null);assert.equal(c.soldCount,null);assert.equal(c.priceBasis,'unknown');assert.ok(!c.eligibility.includes('free shipping'));assert.ok(!p.why.includes('High demand'));assert.equal(p.comparisons[0].estimatedProfitPerUnitUSD,null)
 assert.equal(result.coverage.returnedOwnedProducts,1);assert.equal(result.coverage.requestedOwnedProducts,2);assert.equal(result.coverage.ownedProductsWithComparablePrices,0);assert.equal(result.coverage.missingOwnedProductIds.length,1);assert.equal(result.coveredOwnedProducts,0);assert.deepEqual(result.adIdeas,[])
})

test('Direct quoted leads still require exact declared identity, source membership and USD',()=>{
 const url='https://example.com/products/exact-shoe'
 const build=(overrides:any={},sources:any[]=[{url}])=>buildResearch({products:[{kind:'new_opportunity',title:'Fixture',channels:[{name:'Fixture merchant',url,currency:'USD',variantMatch:'exact',quote:'$49.00 for the exact fixture shoe',priceUSD:'49.00',priceBasis:'asking',...overrides}]}]},sources,DEFAULTS,new Set()).products[0].channels[0]
 assert.equal(build().priceUSD,'49.00');assert.equal(build({soldCount:100,windowDays:1}).soldCount,null);assert.equal(build({soldCount:100,windowDays:1}).windowDays,null);assert.match(build().evidenceStatus,/AI-extracted/)
 for(const overrides of [{variantMatch:'unknown'},{variantMatch:'similar'},{currency:'other'},{quote:'$9.00'},{quote:''}])assert.equal(build(overrides).priceUSD,null)
 assert.equal(build({},[]).priceUSD,null)
})

test('Owned-stock facts use exact product ID and retain unknown costs and per-variant notes',()=>{
 const report={owned:[{id:'owned',title:'Fixture shoe',variants:[{id:'v1',title:'Size 9',sku:'00009',quantity:2,priceUSD:'49.00',merchandiseUSD:'20.00',costBasis:'Owner-private unit cost assumption',estimatedContributionUSD:null,missingCosts:['outboundShippingUSD']},{id:'v2',title:'Size 10',quantity:0,priceUSD:'49.00',merchandiseUSD:'20.00',estimatedContributionUSD:'15.00',missingCosts:[]}]}]}
 assert.equal(researchStock(report,'other'),null)
 const stock=researchStock(report,'owned')!;assert.equal(stock.variants[0].sku,'00009');assert.equal(stock.variants[0].estimatedContributionUSD,null);assert.equal(stock.variants[0].promotionReady,false);assert.equal(stock.variants[1].quantity,0);assert.equal(stock.variants[1].promotionReady,false)
})

test('Google discovery link preserves the literal public product name without executing page instructions',()=>{const title='Vans Chocolate & White / Size 9';const url=new URL(googleProductSearch(title));assert.equal(url.origin,'https://www.google.com');assert.equal(url.pathname,'/search');assert.equal(url.searchParams.get('q'),title+' price buy')})
