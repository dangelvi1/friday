$ErrorActionPreference = 'Stop'
$recordPath = Join-Path $PSScriptRoot 'restore-manifest.json'
if (!(Test-Path $recordPath)) { throw 'Run the backup-folder copy of this script with FRIDAY backend stopped.' }
$record = Get-Content $recordPath -Raw | ConvertFrom-Json
foreach ($relative in $record.files) {
  $target = Join-Path $record.projectPath $relative
  if (!(Test-Path $target) -or (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash -ne $record.packageSHA256.PSObject.Properties[$relative].Value) { throw "Installed file changed after update: $relative. Restore stopped before changing files." }
  $saved = Join-Path $PSScriptRoot $relative
  $baseline = $record.baselineSHA256.PSObject.Properties[$relative].Value
  if ($null -ne $baseline -and (!(Test-Path $saved) -or (Get-FileHash -LiteralPath $saved -Algorithm SHA256).Hash -ne $baseline)) { throw "Backup failed verification: $relative. No files changed." }
}
foreach ($relative in $record.files) {
  $target = Join-Path $record.projectPath $relative; $saved = Join-Path $PSScriptRoot $relative
  if (Test-Path $saved) { Copy-Item -LiteralPath $saved -Destination $target -Force }
  else { Remove-Item -LiteralPath $target }
}
# Verify restored bytes as well as the pre-restore backup checks.
foreach ($relative in $record.files) {
  $target = Join-Path $record.projectPath $relative
  $baseline = $record.baselineSHA256.PSObject.Properties[$relative].Value
  if ($null -ne $baseline) {
    if (!(Test-Path $target) -or (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash -ne $baseline) { throw "Restored file failed verification: $relative" }
  } elseif (Test-Path $target) { throw "New file was not removed: $relative" }
}
Write-Host 'Verified pre-v35 source restored. Build/restart both servers and hard-refresh.'
Write-Host 'Shopify records, receipt visibility/verification notes, claims and recovery journals were retained. Source restore does not undo native changes. Source backup does not replace a private-data backup.'
