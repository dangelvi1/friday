import {cents} from './core'

// Source-list membership proves a search returned a URL, not an exact item,
// price or sale. Accept only recognizable direct product/listing paths.
export function directProductURL(value:unknown){
 try{
  const u=new URL(String(value)),host=u.hostname.toLowerCase().replace(/^www\./,''),path=u.pathname
  if(!['http:','https:'].includes(u.protocol))return false
  if(/(?:^|\.)(?:tiktok\.com|shop\.tiktok\.com)$/.test(host))return /\/pdp\/(?:[^/]+\/)?\d+\/?$/.test(path)
  if(/(?:^|\.)amazon\.[a-z.]+$/.test(host))return /\/(?:dp|gp\/product)\/[a-zA-Z0-9]{10}(?:\/|$)/.test(path)
  if(/(?:^|\.)ebay\.[a-z.]+$/.test(host))return /\/itm\/(?:[^/]+\/)?\d+(?:\/|$)/.test(path)
  if(/(?:^|\.)facebook\.com$/.test(host))return /\/marketplace\/item\/\d+(?:\/|$)/.test(path)
  if(/(?:^|\.)google\.[a-z.]+$/.test(host))return false
  if(/(?:^|\/)(?:search|collections?|categor(?:y|ies)|catalog)(?:\/|$)/i.test(path)||['q','k','_nkw','search','query'].some(k=>u.searchParams.has(k)))return false
  return /\/(?:products?|items?|p|dp)\/[^/]+/i.test(path)
 }catch{return false}
}

export function quotedUSD(quote:unknown,value:unknown){
 const expected=cents(value)
 if(expected===null||typeof quote!=='string')return false
 return [...quote.matchAll(/(?:USD\s*|\$\s*)(\d[\d,]*(?:\.\d{1,2})?)(?![\d.])/g)].some(m=>cents(m[1].replaceAll(',',''))===expected)
}

export function marketEvidence(url:string|null,linked:boolean,match:unknown,currency:unknown,quote:unknown,price:unknown){
 const direct=directProductURL(url),identityExact=match==='exact',quoted=quotedUSD(quote,price)
 const comparable=linked&&direct&&identityExact&&currency==='USD'&&quoted
 return{directProductPage:direct,variantMatch:identityExact?'exact':match==='similar'?'similar':'unknown',comparablePrice:comparable,
  evidenceStatus:!linked?'URL not present in returned search evidence':!direct?'Search/collection/unrecognized page: discovery link only':!identityExact?'Exact model, color, size and condition not established':currency!=='USD'?'USD price not established':!quoted?'Quoted excerpt does not support this USD price':'AI-extracted exact-item price lead; independently verify variant, condition and delivered total'}
}
