import test from 'node:test'
import assert from 'node:assert/strict'
import {mkdtemp,rm,readFile,readdir} from 'node:fs/promises'
import {tmpdir} from 'node:os'
import {join} from 'node:path'
import {photoService,imageData} from '../commerce/daily/photo'
import {prepareProductImage} from '../commerce/daily/product-images'
import {atomic,folder,readJSON} from '../commerce/daily/storage'
const png='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aY1sAAAAASUVORK5CYII='
const prepared='data:image/png;base64,'+Buffer.concat([imageData(png).bytes,Buffer.from('synthetic-prepared-fixture')]).toString('base64')

test('Image-edit API sends only the supplied picture with constrained style and no automatic retry',async()=>{
 const fetchBefore=globalThis.fetch,keyBefore=process.env.OPENAI_API_KEY
 process.env.OPENAI_API_KEY='synthetic-image-key'
 let calls=0
 try{
  globalThis.fetch=async(url:any,options:any)=>{calls++;assert.equal(url,'https://api.openai.com/v1/images/edits');assert.ok(options.body instanceof FormData);assert.equal(options.body.get('n'),'1');assert.equal(options.body.get('output_format'),'png');assert.equal(options.body.get('image[]').type,'image/png');assert.match(options.body.get('prompt'),/Do not repair or hide wear/);assert.equal(options.headers.Authorization,'Bearer synthetic-image-key');return Response.json({data:[{b64_json:prepared.split(',')[1]}]})}
  const result=await prepareProductImage({bytes:new Uint8Array(imageData(png).bytes),mime:'image/png'},'clean_white');assert.equal(result,prepared);assert.equal(calls,1)
  globalThis.fetch=async()=>{calls++;return Response.json({error:{code:'fixture-denied'}},{status:403})}
  await assert.rejects(()=>prepareProductImage({bytes:new Uint8Array(imageData(png).bytes),mime:'image/png'},'soft_studio'),/HTTP 403/);assert.equal(calls,2)
 }finally{globalThis.fetch=fetchBefore;if(keyBefore===undefined)delete process.env.OPENAI_API_KEY;else process.env.OPENAI_API_KEY=keyBefore}
})

test('Prepared pictures stay owner-scoped, preserve originals, require explicit selection and invalidate old native reviews',async t=>{
 const cwd=process.cwd(),dir=await mkdtemp(join(tmpdir(),'friday-images-v37-'))
 let edits=0,fail=false,invalid=false
 try{
  process.chdir(dir)
  const service=photoService(async()=>{throw Error('No Shopify call allowed')},undefined,undefined,async(input,style)=>{edits++;assert.equal(input.mime,'image/png');assert.equal(Buffer.from(input.bytes).toString('base64'),png.split(',')[1]);assert.ok(['clean_white','soft_studio'].includes(style));if(fail)throw Error('Image provider fixture failed');return invalid?'data:image/png;base64,dW5rbm93bg==':prepared})
  const created=await service.create('salvador',{images:[png,png],notes:'Owner fixture shoe'}),id=created.draft.id,path=join(folder('salvador'),'photo-drafts',id,'draft.json')
  await t.test('preparing an image cannot silently replace originals or retain an old product approval',async()=>{
   const p=await readJSON(path);p.status='prepared';p.review={id:'old-review',revision:0};p.fields={title:'Owner confirmed title'};await atomic(path,p)
   const result=await service.imagePrepare('salvador',id,{expectedRevision:0,sourceIndex:1,style:'clean_white'});assert.equal(edits,1);assert.equal(result.draft.images[0].file,'0.bin');assert.equal(result.draft.images[1].file,'1.bin');assert.equal(result.draft.review,undefined);assert.equal(result.draft.fields.title,'Owner confirmed title')
   const assets=await service.imageAssets('salvador',id);assert.equal(assets.originals[1].image,png);assert.equal(assets.prepared[0].image,prepared);assert.equal(assets.prepared[0].selected,false)
   assert.equal((await service.execute('salvador',id,{approved:true,reviewId:'old-review'})).draft.status,'uploaded')
  })
  await t.test('another owner, stale revision and invalid index cannot trigger another paid edit',async()=>{
   await assert.rejects(()=>service.imageAssets('dayanna',id),/not found/)
   await assert.rejects(()=>service.imagePrepare('salvador',id,{expectedRevision:0,sourceIndex:1,style:'clean_white'}),/changed/)
   await assert.rejects(()=>service.imagePrepare('salvador',id,{expectedRevision:1,sourceIndex:9,style:'clean_white'}),/actual original/);assert.equal(edits,1)
  })
  await t.test('selecting a prepared copy affects only its source slot; original can be restored',async()=>{
   const p=await readJSON(path),asset=p.preparedImages[0]
   const selected=await service.imageSelect('salvador',id,{expectedRevision:1,preparedId:asset.id});assert.equal(selected.draft.images[0].file,'0.bin');assert.equal(selected.draft.images[1].preparedAssetId,asset.id)
   assert.equal((await service.images('salvador',id)).images[1],prepared);assert.equal((await service.imageAssets('salvador',id)).originals[1].image,png)
   const restored=await service.imageSelect('salvador',id,{expectedRevision:2,originalIndex:1});assert.equal(restored.draft.images[1].file,'1.bin');assert.equal((await service.images('salvador',id)).images[1],png)
   await assert.rejects(()=>service.imageSelect('salvador',id,{expectedRevision:3,preparedId:'foreign-id'}),/this owner draft/)
  })
  await t.test('failed/invalid image results preserve prior fields, images and revision',async()=>{
   const before=await readFile(path,'utf8');fail=true;await assert.rejects(()=>service.imagePrepare('salvador',id,{expectedRevision:3,sourceIndex:0,style:'soft_studio'}),/fixture failed/);fail=false
   invalid=true;await assert.rejects(()=>service.imagePrepare('salvador',id,{expectedRevision:3,sourceIndex:0,style:'soft_studio'}),/Invalid|match/);invalid=false
   assert.equal(await readFile(path,'utf8'),before);assert.equal((await readdir(join(folder('salvador'),'photo-drafts',id))).filter(s=>s.startsWith('prepared-')).length,1)
  })
  await t.test('stop aborts picture preparation and cannot select or publish a result',async()=>{
   let began!:()=>void;const started=new Promise<void>(resolve=>{began=resolve})
   const cancelled=photoService(async()=>{throw Error('No Shopify request')},undefined,undefined,async(_input,_style,signal)=>new Promise<string>((_resolve,reject)=>{began();signal!.addEventListener('abort',()=>reject(Error('cancelled image fixture')),{once:true})}))
   const draft=(await cancelled.create('salvador',{images:[png],notes:'Cancellation fixture'})).draft
   const pending=cancelled.imagePrepare('salvador',draft.id,{expectedRevision:0,sourceIndex:0,style:'clean_white'}),failed=assert.rejects(()=>pending,/cancelled image fixture/)
   await started;await cancelled.stop('salvador',draft.id);await failed
   const after=(await cancelled.get('salvador',draft.id)).draft;assert.equal(after.revision,0);assert.equal(after.preparedImages,undefined);assert.equal((await cancelled.images('salvador',draft.id)).images[0],png)
  })

  await t.test('name-only and submitted drafts cannot make new prepared listing images',async()=>{
   const named=await service.create('salvador',{images:[],notes:'Name-only fixture'}),before=edits
   await assert.rejects(()=>service.imagePrepare('salvador',named.draft.id,{expectedRevision:0,sourceIndex:0,style:'clean_white'}),/actual original/)
   const p=await readJSON(path);p.status='uncertain';await atomic(path,p);await assert.rejects(()=>service.imagePrepare('salvador',id,{expectedRevision:3,sourceIndex:0,style:'clean_white'}),/submitted/);assert.equal(edits,before)
  })
 }finally{process.chdir(cwd);await rm(dir,{recursive:true,force:true})}
})
