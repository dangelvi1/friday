import {DailyError} from './core'

export const PHOTO_STYLES=['clean_white','soft_studio'] as const
export type PhotoStyle=typeof PHOTO_STYLES[number]

export async function prepareProductImage(image:{bytes:Uint8Array;mime:string},style:PhotoStyle,signal?:AbortSignal){
 if(!PHOTO_STYLES.includes(style))throw new DailyError('Choose clean white or soft studio.')
 const key=process.env.OPENAI_API_KEY
 if(!key)throw new DailyError('Product photo preparation requires the existing OpenAI key on your PC. Original photos remain unchanged.',503)
 const form=new FormData()
 form.append('model',process.env.FRIDAY_COMMERCE_IMAGE_MODEL||'gpt-image-1')
 form.append('image[]',new Blob([new Uint8Array(image.bytes)],{type:image.mime}),'owner-product.'+(image.mime.split('/')[1]||'png'))
 form.append('n','1');form.append('size','1024x1024');form.append('quality','medium');form.append('input_fidelity','high');form.append('output_format','png')
 form.append('prompt','Prepare a polished ecommerce listing photograph from THIS exact owner-supplied product photograph. '+(style==='clean_white'?'Use a clean white background, balanced lighting and a subtle natural contact shadow.':'Use a neutral light-gray studio background, balanced soft lighting and a natural contact shadow.')+' Preserve the exact physical item, color, texture, shape, branding, labels, visible wear/damage and included accessories. Keep the whole product in frame. Do not invent angles, features, packaging, accessories, text, logos, claims or a different condition. Do not repair or hide wear. Improve background and photographic presentation only. Owner will compare the original and the prepared copy before selecting it.')
 const r=await fetch('https://api.openai.com/v1/images/edits',{method:'POST',headers:{Authorization:'Bearer '+key},body:form,signal:signal?AbortSignal.any([signal,AbortSignal.timeout(180000)]):AbortSignal.timeout(180000)})
 if(!r.ok)throw new DailyError('Product photo preparation returned HTTP '+r.status+'. Check image API availability on the PC. Original photos remain unchanged; no automatic retry.',502)
 const data=await r.json(),encoded=data?.data?.[0]?.b64_json
 if(typeof encoded!=='string'||!encoded)throw new DailyError('Image provider did not return a prepared picture. Original photos remain unchanged.',502)
 return'data:image/png;base64,'+encoded
}
