const words=(s:unknown)=>String(s||'').normalize('NFKD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^\p{L}\p{N}]+/gu,' ').trim().split(/\s+/).filter(Boolean)

export function selectCommerceProduct(report:any,args:{productId?:string;query?:string}={}){
 const products=report?.audit?.products||[]
 const terms=words(args.query),hasId=args.productId!==undefined,hasQuery=typeof args.query==='string'&&!!args.query.trim()
 const matches=hasId?products.filter((p:any)=>p.id===args.productId):terms.length?products.filter((p:any)=>{const name=new Set(words(p.title));return terms.every(t=>name.has(t))}):hasQuery?[]:products
 const status=matches.length===1?'selected':matches.length>1?'selection_required':hasId||hasQuery?'not_found':'selection_required'
 return{status,product:matches.length===1?matches[0]:null,candidates:matches.slice(0,10).map((p:any)=>({id:p.id,title:p.title})),totalMatches:matches.length,
  source:'saved_store_report',liveWebSearchPerformed:false,message:status==='not_found'?'No matching product in this saved store report. This does not establish whether matching listings exist online.':status==='selection_required'?'Choose one actual product ID or an unambiguous product name before focused research.':'Actual store product selected from this report.'}
}

export function savedProductPricing(report:any,args:{productId?:string;query?:string}={}){
 const selected=selectCommerceProduct(report,args)
 if(!selected.product)return{success:true,...selected,pricing:[]}
 const id=selected.product.id,owned=report?.owned?.find((p:any)=>p.id===id)
 const research=report?.research?.evidenceVersion===3?(report.research.products||[]).filter((p:any)=>p.existingProductId===id):[]
 return{success:true,...selected,pricing:(report?.pricing||[]).filter((p:any)=>p.productId===id),owned:owned||null,research,
  hasQualifiedMarketLeads:research.some((p:any)=>p.channels?.some((c:any)=>c.comparablePrice)),
  message:'Saved report data only; no live web search was performed. Missing exact-item leads do not prove online unavailability. Use research_product once when the owner requests fresh research; normal provider API usage applies. Unknown costs remain unknown.'}
}
