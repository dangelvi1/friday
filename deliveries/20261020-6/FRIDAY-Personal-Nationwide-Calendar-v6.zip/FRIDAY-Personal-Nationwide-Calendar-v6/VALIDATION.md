# Validation

Calendar tests use synthetic owners and fake Google API clients with real registered Express routes and actual headless Chromium. No Google/Gmail account is accessed, OAuth granted or live event created during these tests.

The Vite proxy is tested with a real loopback HTTP request through its configured Calendar route; the Windows TLS certificates are not loaded or validated by that test.

Calendar suite: 13 specific cases / 15 reported entries. Checks real dates and explicit destinations, IANA zones and DST gap/overlap offsets, exclusive all-day ends, calendar pagination/repeated-page rejection, receipt payload verification, verified backend owner isolation, browser-bound/single-use OAuth state and separate token files, distinct writable calendar mapping, stale account/mapping/revisions and revoked permissions, complete schedule reads, cancelled/unapproved reviews, one-time event creation without invites, durable lost-response recovery/duplicate blocking, and actual panel voice preparation/pointer, cancellation, failed-draft retention, success clearing and owner locking.

```
node --import tsx --test tests/calendar.test.ts
```

The suite uses the existing Playwright dependency and /usr/bin/chromium in the cloud. On Windows configure an available Playwright browser path in the test harness; the included runtime app does not require Chromium for Calendar APIs. Existing frontend/backend TypeScript checks and standalone Vite compilation are separate checks. Standalone build uses configFile:false to avoid the owner's Windows-only TLS certificate paths, without modifying vite.config.ts.

Combined result: 94 reported entries passed, zero failed/skipped (84 specific cases plus ten parent entries). Frontend/backend TypeScript checks passed; standalone Vite compilation passed with the existing bundle-size warning.

Combined regressions include Calendar, invoice custom fields, visible live-bank-feed UI, bank reconciliation/private notes/owner invoice workflows, and Document Analysis. Google API/OAuth behavior, native shared-calendar permissions, Google console redirect/consent setup, same-origin browser cookie routing on the owner domain, real event creation/office visibility, live microphone and Windows installer remain owner-PC validation. No automated result is a claim that the user's calendar is already connected.

No new dependencies, lockfile changes, credential/config replacements or AGENTS overwrites. No QuickBooks records change during installation or Calendar actions.
