# FRIDAY Personal / Nationwide Calendar v6

For Salvador and Dayanna's existing PC-hosted FRIDAY at S:\AI\friday-ai. Requires Invoice Fields v5. Preserves Gmail and the modular QuickBooks, Sandra, Document Analysis and natural Realtime conversation. No hosting, employee-service, database or dependency migration.

## What this adds

A Calendar button/panel on the existing FRIDAY voice home page, separate Google Calendar OAuth authorization per verified owner, explicitly selected Personal and Nationwide shared calendar destinations, complete schedule reads (ranges up to 32 days), and event drafting through the normal voice conversation with a visible pointer. A centered review shows the actual target calendar, title, start/end, time zone, location and notes. Only an owner's click on Approve submits creation. Cancellation/failure retains the draft. Verified success clears event entry fields.

This version creates single timed/all-day events and reads schedules. No attendee invitations, recurring event creation, event edits/deletion, calendar sharing changes or background sync jobs. Events are written to the existing real shared Nationwide calendar, so office users who already have access see the same event. Personal events are never copied into Nationwide. Sara/employee services receive no FRIDAY credential, token, calendar API route or private-data access.

The owner key must be entered in the panel using the existing Salvador/Dayanna owner key (same mechanism as the owner dashboard). Profile name or spoken identity alone is not authorization. Keys stay in page memory; Lock/profile change/reload clears access. Never say the key aloud or put it in chat. Each owner's Google authorization and calendar mapping is separate; both may independently select the same office calendar if permitted.

## 1. Install from any PowerShell location

Stop only the FRIDAY backend. Extract under S:\AI\Fixing-Files-Folder\FRIDAY-Personal-Nationwide-Calendar-v6, then run:

```powershell
$packageRoot = 'S:\AI\Fixing-Files-Folder\FRIDAY-Personal-Nationwide-Calendar-v6'
$installers = @(Get-ChildItem -LiteralPath $packageRoot -Filter 'Install-Calendar.ps1' -File -Recurse -ErrorAction Stop)
if ($installers.Count -ne 1) { throw 'Expected exactly one Install-Calendar.ps1. Check the extracted folder.' }
$installer = $installers[0].FullName
Unblock-File -LiteralPath $installer
Unblock-File -LiteralPath (Join-Path (Split-Path $installer) 'Restore-Calendar.ps1')
& $installer -ProjectPath 'S:\AI\friday-ai'
if (-not $?) { throw 'Installation failed. Do not continue.' }
Set-Location -LiteralPath 'S:\AI\friday-ai'
npm run build
if ($LASTEXITCODE -ne 0) { throw 'Build failed. Do not restart with an incomplete build.' }
npm run server
```

Installer locates/validates the project, verifies all package and expected installed-source hashes, creates a verified timestamped backup, and copies only seven listed application/test files. If a baseline differs, stop and obtain a compatible patch; never force replacement. No npm install needed. Unblock-File does not override an enforced signed-script policy. PowerShell execution has not been tested in this Linux cloud.

## 2. Google setup — required before connecting

Use the Google Cloud project for the Google OAuth client you intend to authorize. Enable Google Calendar API (Google Auth Platform alone is not enough). No credentials or Google console access were supplied in the sanitized cloud project; these steps must be performed on the owner PC/account.

Default authorized redirect URI, exact spelling:

```
https://friday.dangelvi.com/calendar/oauth/callback
```

For an existing **Web application** OAuth client, add that exact URI to its Authorized redirect URIs without deleting existing Gmail redirects. The existing gmail-credentials.json is read only to construct the separate Calendar client. The working gmail-token.json is never read, replaced, expanded or deleted by this Calendar module.

If the existing Gmail client is **Desktop**, or you prefer a separate client, create a **Web application** OAuth client in your own Google Cloud project, register the URI above, download its JSON directly to the owner PC and save it as:

```
S:\AI\friday-ai\credentials\calendar-client.json
```

That optional private client file takes precedence over gmail-credentials.json. Do not upload it to GitHub or chat. No secret values belong in this README or a support screenshot.

Configure the OAuth consent screen/test users as Google requires for your account. The requested scopes are calendar.calendarlist.readonly (list accessible calendars) and calendar.events (read/create events on authorized calendars, including the shared office calendar). Google consent must actually grant both. A Google external app in Testing can have short-lived refresh grants; complete the appropriate Google publishing/verification process for durable production use rather than replacing Gmail authorization.

Default URI assumes your existing friday.dangelvi.com route reaches this FRIDAY backend. Open the FRIDAY home page at that same HTTPS origin when connecting so the callback can verify its HttpOnly browser cookie. Don't start consent on localhost and return to another domain. An existing Cloudflare login may need to be completed in the same browser. The module does not migrate hosting or configure Cloudflare.

If using a different real FRIDAY origin, set FRIDAY_CALENDAR_REDIRECT_URI in your existing private environment to that origin plus /calendar/oauth/callback, register the exact URI in Google, restart, and open FRIDAY at that origin. HTTPS required except localhost/127.0.0.1. Do not post private environment files here.

## 3. Connect and select real calendars

1. Hard-refresh the existing FRIDAY home/voice page (Ctrl+F5). Click Open Personal / Nationwide Calendar.
2. Enter your existing owner key and click Verify owner. The panel displays the exact callback URI and whether Calendar authorization is saved.
3. Click Connect Google Calendar. In Google's tab, choose your intended Google account and grant the Calendar permissions. This action authorizes Calendar separately and leaves the Gmail token file unchanged. Confirm Google's page shows the client/project you control.
4. On success, return to FRIDAY and click Refresh calendars. If the shared calendar is absent, check Google Calendar sharing/subscription in your account. This module does not create a replacement calendar or grant itself sharing permissions.
5. Select your actual Personal calendar and existing Nationwide office calendar. Full IDs are visible in the owner-only dropdown to distinguish duplicate names. Owner/writer permission is required for both; reader calendars are visibly disabled. Save calendar destinations. They must be different calendars.
6. For Dayanna, lock/switch profile and verify with Dayanna's key, authorize her intended Google account, and choose her own destinations. No automatic cross-owner sharing occurs.

Do not revoke existing Gmail access to fix Calendar. Google's consent/cloud-console configuration cannot be completed from this cloud checkout.

## 4. First live test

Read schedules before approving any event. Try: “Friday, show my personal schedule for tomorrow,” and “Show Nationwide's calendar for tomorrow.” Clarify which destination whenever uncertain. Ask: “Prepare an office visit in Nationwide on [date], from [time] to [time], America/New_York.” FRIDAY prepares the centered review; nothing is saved until you click Approve. Verify the Google Calendar link and office visibility only for an event you actually intend to create. No test event was created in a real account here.

Timed requests require explicit ISO offsets matched to the selected IANA zone, including daylight saving. All-day end dates are exclusive: a one-day event starting 2026-10-21 ends 2026-10-22. Google may display a different local time on an office user's device according to their Calendar settings.

After an interrupted save, use Check last receipt. After reopening FRIDAY, use Load recent event receipts to recover the appropriate review. An uncertain request is never automatically retried. Persistent event IDs and exact-draft submission claims prevent the same reviewed request from creating duplicates. Inspect the original Google calendar if authorization/account changed before checking an older receipt. This version intentionally blocks resubmitting an identical event through a fresh review, even after success; intentional changes must be reviewed directly in Google Calendar.

## 5. Private storage / restore

Runtime-only private files are under credentials/calendar/: per-owner OAuth tokens and destination mappings, short-lived OAuth state, event receipts and duplicate-submission claims. These are never served from public/ and never included in this package. Exclude the entire credentials/ folder from Git/exports and retain its restrictive owner-PC permissions. Never remove uncertain receipts/claims simply to retry a request.

To restore: stop FRIDAY, run Restore-Calendar.ps1 from the backup directory printed during installation, rebuild and restart, then Ctrl+F5. Restore verifies hashes and refuses to overwrite later file edits. It restores only application files; Gmail files, Calendar authorizations/receipts, all databases and private uploads remain. Reverting code does not undo an event already created in Google Calendar; review it there if needed.

AGENTS-MERGE-PROPOSAL.md is a proposal only; AGENTS.md is not installed or overwritten. See VALIDATION.md for the distinction between automated and owner-PC tests.
