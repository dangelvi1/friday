import { defineConfig } from 'vite'
import fs from 'node:fs'

// ============================================================
// START [NETWORK-02] LOCAL HTTPS FOR FRIDAY
// ACTION: REPLACE FILE CONTENT
// FILE: S:\AI\friday-ai\vite.config.ts
// PLACE: Entire file
// PURPOSE: Enable HTTPS so microphone access works on local PCs
// USERS: Salvador and Dayanna
// ============================================================

export default defineConfig({
  server: {
    host: '0.0.0.0',
    port: 5173,
    allowedHosts: true,

    https: {
      key: fs.readFileSync(
        'S:/AI/friday-ai/certs/friday-local-key.pem'
      ),
      cert: fs.readFileSync(
        'S:/AI/friday-ai/certs/friday-local.pem'
      ),
    },

    proxy: {
      '/calendar': {
        target: 'http://127.0.0.1:3001',
        changeOrigin: true,
      },

      '/session': {
        target: 'http://127.0.0.1:3001',
        changeOrigin: true,
      },

      '/memory': {
        target: 'http://127.0.0.1:3001',
        changeOrigin: true,
      },

      '/memories': {
        target: 'http://127.0.0.1:3001',
        changeOrigin: true,
      },

      '/health': {
        target: 'http://127.0.0.1:3001',
        changeOrigin: true,
      },

      '/reverse-geocode': {
        target: 'http://127.0.0.1:3001',
        changeOrigin: true,
      },

      '/weather': {
        target: 'http://127.0.0.1:3001',
        changeOrigin: true,
      },

      '/weather-location': {
        target: 'http://127.0.0.1:3001',
        changeOrigin: true,
      },

      '/gmail-api': {
        target: 'http://127.0.0.1:3001',
        changeOrigin: true,
      },

      '/gmail-dashboard': {
        target: 'http://127.0.0.1:3001',
        changeOrigin: true,
      },

      '/browser': {
        target: 'http://127.0.0.1:3001',
        changeOrigin: true,
      },

      '/media': {
        target: 'http://127.0.0.1:3001',
        changeOrigin: true,
      },

      '/shopify': {
        target: 'http://127.0.0.1:3001',
        changeOrigin: true,
      },

      '/speaker': {
        target: 'http://127.0.0.1:8001',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/speaker/, ''),
      },

      '/quickbooks': {
        target: 'http://127.0.0.1:3001',
        changeOrigin: true,
        secure: false,
      },
    },
  },
})

// ============================================================
// END [NETWORK-02] LOCAL HTTPS FOR FRIDAY
// ============================================================