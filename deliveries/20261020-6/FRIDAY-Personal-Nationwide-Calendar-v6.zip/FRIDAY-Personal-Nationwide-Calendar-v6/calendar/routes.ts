import type {Express} from 'express'
import {google} from 'googleapis'
import {randomBytes,randomUUID} from 'node:crypto'
import {writeFile,mkdir,readdir} from 'node:fs/promises'
import {authenticateSandraOwner} from '../quickbooks/sandra-learning-core'
import {CalendarError,digest,privatePath,readPrivate,savePrivate,locked,destination,eventDraft,sameEvent,calendarPages} from './core'
import type {Owner} from './core'
const scopes=['https://www.googleapis.com/auth/calendar.calendarlist.readonly','https://www.googleapis.com/auth/calendar.events']
const options={timeout:20000,retry:false}
async function oauth(){
 let raw:any,c:any
 try{raw=await readPrivate(privatePath('..','calendar-client.json'))}catch(e:any){if(e.code!=='ENOENT')throw new CalendarError('Separate Calendar client configuration is unreadable; keep the file private.');try{raw=await readPrivate(process.cwd()+'/gmail-credentials.json')}catch{throw new CalendarError('Google client configuration is unavailable. Keep Gmail files private.')}}
 c=raw.web||raw.installed

 const redirect=process.env.FRIDAY_CALENDAR_REDIRECT_URI||'https://friday.dangelvi.com/calendar/oauth/callback'
 let url:URL;try{url=new URL(redirect)}catch{throw new CalendarError('Invalid Calendar redirect configuration.')}
 if(url.pathname!=='/calendar/oauth/callback'||url.search||url.hash||url.username||url.password||!(url.protocol==='https:'||url.protocol==='http:'&&['localhost','127.0.0.1'].includes(url.hostname)))throw new CalendarError('Use the exact /calendar/oauth/callback path on HTTPS (or local loopback HTTP).')
 if(!raw.web&&url.protocol==='https:')throw new CalendarError('A Desktop Google client cannot use this HTTPS callback. Create a Web application client and save its JSON as credentials/calendar-client.json; leave Gmail files unchanged.')
 if(!c?.client_id||!c?.client_secret)throw new CalendarError('Existing Google OAuth client settings are incomplete.')
 // Google enforces registered redirect URIs. Download a refreshed credentials file after adding this URI if using a web client.
 return{auth:new google.auth.OAuth2(c.client_id,c.client_secret,redirect),redirect}
}
async function connection(owner:Owner){try{return await readPrivate(privatePath(owner+'.json'))}catch{throw new CalendarError('Connect Google Calendar separately first; Gmail authorization remains unchanged.',409)}}
async function client(owner:Owner){const c=await connection(owner),{auth}=await oauth();auth.setCredentials(c.tokens);return{api:google.calendar({version:'v3',auth}),connection:c}}
async function mapping(owner:Owner){try{return await readPrivate(privatePath(owner+'-mapping.json'))}catch(e:any){if(e.code!=='ENOENT')throw new CalendarError('Stored calendar selection is unreadable. Keep the file and resolve it before saving new selections.');return{revision:'none',connectionId:null,personal:null,nationwide:null}}}
function publicProposal(p:any){return{id:p.id,eventId:p.eventId,destination:p.destination,calendarName:p.calendarName,payload:p.payload,timeZone:p.timeZone,allDay:p.allDay,status:p.status,expiresAt:p.expiresAt,htmlLink:p.htmlLink||null}}
function receiptPath(owner:Owner,id:string){if(!/^[a-f0-9-]{36}$/.test(id))throw new CalendarError('Invalid event review ID.');return privatePath('receipts',owner,id+'.json')}
export function registerCalendarRoutes(app:Express,dependencies:any={}){
 const getClient=dependencies.client||client,getOAuth=dependencies.oauth||oauth
 const endpoint=(fn:any)=>async(req:any,res:any)=>{res.setHeader('Cache-Control','no-store');try{let owner:Owner;try{owner=authenticateSandraOwner(req)}catch{throw new CalendarError('Verify Salvador or Dayanna with the existing owner key.',401)}await fn(req,res,owner)}catch(e:any){res.status(e instanceof CalendarError?e.status:400).json({success:false,error:e instanceof CalendarError?e.message:'Google Calendar request could not be verified. Check authorization, sharing and connectivity. No automatic write retry.'})}}
 app.get('/calendar/status',endpoint(async(_req:any,res:any,owner:Owner)=>{const m=await mapping(owner);let c:any=null;try{c=await connection(owner)}catch{}res.json({success:true,owner,connected:!!c,connectionId:c?.id||null,mapping:c&&m.connectionId===c.id?m:null,redirectUri:process.env.FRIDAY_CALENDAR_REDIRECT_URI||'https://friday.dangelvi.com/calendar/oauth/callback'})}))
 app.post('/calendar/oauth/start',endpoint(async(_req:any,res:any,owner:Owner)=>{
 const {auth,redirect}=await getOAuth();if(_req.headers.origin&&_req.headers.origin!==new URL(redirect).origin)throw new CalendarError('Open FRIDAY at '+new URL(redirect).origin+' before connecting, so the Google callback can verify this browser.');const state=randomBytes(32).toString('hex'),cookie=randomBytes(32).toString('hex');await savePrivate(privatePath('oauth',digest(state)+'.json'),{owner,cookieHash:digest(cookie),expiresAt:Date.now()+600000,status:'pending'})
 res.cookie('friday_calendar_oauth',cookie,{httpOnly:true,secure:redirect.startsWith('https:'),sameSite:'lax',path:'/calendar/oauth/callback',maxAge:600000})
 res.json({success:true,redirectUri:redirect,url:auth.generateAuthUrl({access_type:'offline',prompt:'consent select_account',scope:scopes,state,include_granted_scopes:false})})
 }))
 app.get('/calendar/oauth/callback',async(req,res)=>{
 res.setHeader('Cache-Control','no-store');res.setHeader('Referrer-Policy','no-referrer');res.setHeader('Content-Security-Policy',"default-src 'none'; style-src 'unsafe-inline'")
 try{
 const state=String(req.query.state||'');if(!/^[a-f0-9]{64}$/.test(state))throw Error('invalid')
 const file=privatePath('oauth',digest(state)+'.json');await locked(file,async()=>{
 const p=await readPrivate(file),cookie=String(req.headers.cookie||'').split(';').map(x=>x.trim()).find(x=>x.startsWith('friday_calendar_oauth='))?.slice('friday_calendar_oauth='.length)
 if(p.status!=='pending'||p.expiresAt<Date.now()||!cookie||digest(cookie)!==p.cookieHash||!['salvador','dayanna'].includes(p.owner))throw Error('invalid')
 p.status='consumed';await savePrivate(file,p)
 if(req.query.error||typeof req.query.code!=='string'||req.query.code.length>4096)throw Error('denied')
 const {auth}=await getOAuth(),response=await auth.getToken({code:req.query.code}),tokens=response.tokens
 if(!tokens.refresh_token||!scopes.every(s=>String(tokens.scope||'').split(' ').includes(s)))throw Error('incomplete')
 auth.setCredentials(tokens);const api=dependencies.callbackApi?dependencies.callbackApi(auth):google.calendar({version:'v3',auth});await calendarPages(api)
 await locked('owner:'+p.owner,()=>savePrivate(privatePath(p.owner+'.json'),{id:randomUUID(),connectedAt:new Date().toISOString(),tokens}))
 });res.clearCookie('friday_calendar_oauth',{path:'/calendar/oauth/callback'});res.type('html').send('<h1>Google Calendar connected</h1><p>Return to FRIDAY, refresh Calendar status, and select Personal and Nationwide. Gmail was not changed. You can close this tab.</p>')
 }catch{res.status(400).type('html').send('<h1>Calendar connection not completed</h1><p>Return to FRIDAY and start a new connection. Check Calendar API enablement, consent scopes and the registered redirect URI. Gmail was not changed. Do not share this callback URL.</p>')}
 })
 app.get('/calendar/calendars',endpoint(async(_req:any,res:any,owner:Owner)=>{const{api,connection:c}=await getClient(owner);res.json({success:true,owner,connectionId:c.id,calendars:await calendarPages(api),completeRead:true})}))
 app.post('/calendar/mapping',endpoint(async(req:any,res:any,owner:Owner)=>locked('owner:'+owner,async()=>{
 const{api,connection:c}=await getClient(owner),m=await mapping(owner)
 if(req.body.connectionId!==c.id||req.body.expectedRevision!==(m.connectionId===c.id?m.revision:'none'))throw new CalendarError('Connection or mapping changed. Refresh before selecting calendars.',409)
 const rows=await calendarPages(api),selected:any={}
 for(const target of ['personal','nationwide']){const row=rows.find((r:any)=>r.id===req.body[target]);if(!row?.writable)throw new CalendarError('Select an existing owner/writer calendar for each destination.');selected[target]=row}
 if(selected.personal.id===selected.nationwide.id)throw new CalendarError('Personal and Nationwide must be separate calendars.')
 const next={revision:randomUUID(),connectionId:c.id,...selected};await savePrivate(privatePath(owner+'-mapping.json'),next);res.json({success:true,mapping:next})
 })))
 async function selected(owner:Owner,target:any){const name=destination(target),{api,connection:c}=await getClient(owner),m=await mapping(owner);if(m.connectionId!==c.id||!m[name])throw new CalendarError('Select and save both calendar destinations for this Google connection first.',409);return{api,c,m,target:name,calendar:m[name]}}
 async function stillSelected(owner:Owner,s:any){const c=await connection(owner),m=await mapping(owner);if(c.id!==s.c.id||m.revision!==s.m.revision)throw new CalendarError('Google connection or calendar selection changed during the read. Results discarded; refresh first.',409)}
 app.post('/calendar/events/read',endpoint(async(req:any,res:any,owner:Owner)=>{
 const s=await selected(owner,req.body.destination),from=String(req.body.from||''),to=String(req.body.to||'')
 if(!/T.*(?:Z|[+-]\d{2}:\d{2})$/.test(from)||!Number.isFinite(Date.parse(from))||!/T.*(?:Z|[+-]\d{2}:\d{2})$/.test(to)||!Number.isFinite(Date.parse(to))||Date.parse(to)<=Date.parse(from)||Date.parse(to)-Date.parse(from)>32*86400000)throw new CalendarError('Choose an explicit timezone-aware range of up to 32 days.')
 const items:any[]=[],seen=new Set(),eventIds=new Set();let pageToken:string|undefined
 do{if(seen.size>=100||pageToken&&seen.has(pageToken))throw new CalendarError('Event listing repeated or exceeded its page limit. No partial results accepted.');if(pageToken)seen.add(pageToken)
 const r=await s.api.events.list({calendarId:s.calendar.id,timeMin:from,timeMax:to,singleEvents:true,orderBy:'startTime',maxResults:250,...(pageToken?{pageToken}:{})},options)
 if(!r.data||r.data.items!==undefined&&!Array.isArray(r.data.items))throw new CalendarError('Event listing incomplete.')
 for(const e of r.data.items||[]){if(!e.id||eventIds.has(e.id))throw new CalendarError('Repeated or missing event ID. No partial schedule accepted.');eventIds.add(e.id);items.push({id:e.id,title:e.summary||'(busy)',start:e.start,end:e.end,status:e.status,location:e.location||'',htmlLink:e.htmlLink||null})}
 pageToken=r.data.nextPageToken
 }while(pageToken)
 await stillSelected(owner,s);res.json({success:true,destination:s.target,calendarName:s.calendar.name,from,to,completeRead:true,events:items})
 }))
 app.post('/calendar/events/preview',endpoint(async(req:any,res:any,owner:Owner)=>{
 const draft=eventDraft(req.body),s=await selected(owner,draft.destination),rows=await calendarPages(s.api),row=rows.find((r:any)=>r.id===s.calendar.id);if(!row?.writable)throw new CalendarError('This calendar no longer permits creating events.')
 const id=randomUUID(),p={id,owner,connectionId:s.c.id,mappingRevision:s.m.revision,calendarId:s.calendar.id,calendarName:row.name,...draft,eventId:id.replaceAll('-',''),expiresAt:Date.now()+900000,status:'prepared'}
 await stillSelected(owner,s);await savePrivate(receiptPath(owner,id),p);res.json({success:true,review:publicProposal(p),message:'Prepared only. Review the calendar and event in FRIDAY and click Approve to create. No event has been saved.'})
 }))
 async function verifyReceipt(api:any,p:any){const r=await api.events.get({calendarId:p.calendarId,eventId:p.eventId},options);if(!sameEvent(r.data,p))throw new CalendarError('Event receipt differs from the reviewed draft. Inspect Google Calendar before proceeding.',409);p.status='created';p.htmlLink=r.data.htmlLink||null;p.verifiedAt=new Date().toISOString();await savePrivate(receiptPath(p.owner,p.id),p)}
 app.get('/calendar/reviews',endpoint(async(_req:any,res:any,owner:Owner)=>{
 let names:string[]=[];try{names=await readdir(privatePath('receipts',owner))}catch(e:any){if(e.code!=='ENOENT')throw e}
 const reviews=[];for(const name of names){if(!/^[a-f0-9-]{36}\.json$/.test(name))continue;const p=await readPrivate(privatePath('receipts',owner,name));if(p.owner===owner)reviews.push(p)}
 reviews.sort((a:any,b:any)=>b.expiresAt-a.expiresAt);res.json({success:true,reviews:reviews.slice(0,30).map(publicProposal),total:reviews.length,truncated:reviews.length>30})
 }))
 app.post('/calendar/events/:id/:action',endpoint(async(req:any,res:any,owner:Owner)=>locked('owner:'+owner,async()=>{
 if(!['approve','receipt'].includes(req.params.action))throw new CalendarError('Unsupported calendar action.')
 const p=await readPrivate(receiptPath(owner,req.params.id));if(p.owner!==owner)throw new CalendarError('Event review belongs to another owner.',403)
 if(req.params.action==='receipt'){const current=await getClient(owner);if(current.connection.id!==p.connectionId)throw new CalendarError('This receipt belongs to the earlier Google connection. Inspect its original calendar; no new copy was sent.',409);if(p.status==='uncertain')try{await verifyReceipt(current.api,p)}catch{}return res.json({success:true,review:publicProposal(p)})}
 const s=await selected(owner,p.destination)
 if(s.c.id!==p.connectionId||s.m.revision!==p.mappingRevision||s.calendar.id!==p.calendarId)throw new CalendarError('Calendar selection or account changed. Recheck the original calendar before creating a new review.',409)
 if(p.status==='created')return res.json({success:true,review:publicProposal(p)})
 if(p.status!=='prepared'||p.expiresAt<Date.now()||req.body.approved!==true)throw new CalendarError('Review expired, not approved or already submitted. Inspect the receipt; do not retry creation.',409)
 const rows=await calendarPages(s.api);if(!rows.find((r:any)=>r.id===p.calendarId)?.writable)throw new CalendarError('Calendar write access changed.')
 // A durable fingerprint prevents an uncertain request being resubmitted through a fresh preview.
 const fingerprint=digest({owner,connectionId:p.connectionId,calendarId:p.calendarId,payload:p.payload});const claim=privatePath('claims',fingerprint+'.json');await mkdir(privatePath('claims'),{recursive:true,mode:0o700})
 try{await writeFile(claim,JSON.stringify({reviewId:p.id,eventId:p.eventId}),{flag:'wx',mode:0o600})}catch{throw new CalendarError('An identical event was already submitted. Check its receipt and Google Calendar; no duplicate was sent.',409)}
 p.status='uncertain';await savePrivate(receiptPath(owner,p.id),p)
 try{await s.api.events.insert({calendarId:p.calendarId,sendUpdates:'none',requestBody:{...p.payload,id:p.eventId,extendedProperties:{private:{fridayRequestId:p.id}},attendees:[]}},options);await verifyReceipt(s.api,p)}catch{throw new CalendarError('Creation outcome is uncertain. Keep the draft, check its receipt and Google Calendar. Do not submit another copy.',502)}
 res.json({success:true,review:publicProposal(p)})
 })))
}
