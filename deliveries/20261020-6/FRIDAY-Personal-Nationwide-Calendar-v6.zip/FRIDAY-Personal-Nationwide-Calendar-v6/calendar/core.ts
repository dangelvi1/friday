import {createHash,randomUUID} from 'node:crypto'
import {mkdir,readFile,rename,writeFile} from 'node:fs/promises'
import {resolve,dirname} from 'node:path'
export type Owner='salvador'|'dayanna'
export type Destination='personal'|'nationwide'
export class CalendarError extends Error {constructor(message:string,public status=400){super(message)}}
export const digest=(value:unknown)=>createHash('sha256').update(JSON.stringify(value)).digest('hex')
export const privatePath=(...parts:string[])=>resolve(process.cwd(),'credentials','calendar',...parts)
export async function readPrivate(file:string){return JSON.parse(await readFile(file,'utf8'))}
export async function savePrivate(file:string,value:unknown){await mkdir(dirname(file),{recursive:true,mode:0o700});const temp=file+'.'+randomUUID()+'.tmp';await writeFile(temp,JSON.stringify(value),{mode:0o600,flag:'wx'});await rename(temp,file)}
const locks=new Map<string,Promise<unknown>>()
export async function locked<T>(key:string,fn:()=>Promise<T>):Promise<T>{const previous=locks.get(key)||Promise.resolve();const pending=previous.catch(()=>{}).then(fn);locks.set(key,pending);try{return await pending}finally{if(locks.get(key)===pending)locks.delete(key)}}
export function destination(value:unknown):Destination{if(value!=='personal'&&value!=='nationwide')throw new CalendarError('Choose Personal or Nationwide explicitly.');return value}
export function text(value:unknown,label:string,max:number,required=false){if(typeof value!=='string'||value.length>max||/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(value)||required&&!value.trim())throw new CalendarError(`Provide valid ${label}.`);return value.trim()}
function validDate(value:string){if(!/^\d{4}-\d{2}-\d{2}$/.test(value))return false;const d=new Date(value+'T00:00:00Z');return Number.isFinite(+d)&&d.toISOString().slice(0,10)===value}
export function eventDraft(body:any){
 const target=destination(body?.destination),summary=text(body?.title,'title',200,true),description=text(body?.description??'','description',4000),location=text(body?.location??'','location',500),zone=text(body?.timeZone,'IANA time zone',80,true)
 try{new Intl.DateTimeFormat('en',{timeZone:zone}).format()}catch{throw new CalendarError('Provide a valid IANA time zone, such as America/New_York.')}
 if(typeof body?.allDay!=='boolean')throw new CalendarError('Choose timed or all-day explicitly.')
 const start=text(body?.start,'start',50,true),end=text(body?.end,'end',50,true)
 if(body.allDay){if(!validDate(start)||!validDate(end)||end<=start)throw new CalendarError('All-day start/end must be real dates; the end date is exclusive and after the start.')}
 else {
  const pattern=/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:Z|[+-]\d{2}:\d{2})$/
  if(!pattern.test(start)||!pattern.test(end)||!Number.isFinite(Date.parse(start))||!Number.isFinite(Date.parse(end))||Date.parse(end)<=Date.parse(start))throw new CalendarError('Use explicit ISO date-times with UTC offsets and end after start.')
  for(const value of [start,end]){
   if(!validDate(value.slice(0,10)))throw new CalendarError('The event date is invalid.')
   // Validate the offset and wall clock against the chosen zone, including DST gaps/overlaps.
   const parts=new Intl.DateTimeFormat('en-CA',{timeZone:zone,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'}).formatToParts(new Date(value));const p=Object.fromEntries(parts.map(x=>[x.type,x.value]));const wall=`${p.year}-${p.month}-${p.day}T${p.hour}:${p.minute}:${p.second}`
   if(wall!==value.slice(0,19))throw new CalendarError('Time/offset does not match the selected zone. Confirm the date, time and daylight-saving offset.')
  }
 }
 return{destination:target,payload:{summary,description,location,start:body.allDay?{date:start}:{dateTime:start,timeZone:zone},end:body.allDay?{date:end}:{dateTime:end,timeZone:zone}},timeZone:zone,allDay:body.allDay}
}
export function sameEvent(event:any,proposal:any){
 const p=proposal.payload
 const when=(a:any,b:any)=>b.date?a?.date===b.date:Date.parse(a?.dateTime)===Date.parse(b.dateTime)&&a?.timeZone===b.timeZone
 return event?.id===proposal.eventId&&event.status!=='cancelled'&&event.extendedProperties?.private?.fridayRequestId===proposal.id&&event.summary===p.summary&&(event.description||'')===p.description&&(event.location||'')===p.location&&when(event.start,p.start)&&when(event.end,p.end)&&!(event.attendees?.length)
}
export async function calendarPages(client:any){const rows:any[]=[],ids=new Set(),tokens=new Set();let pageToken:string|undefined;do{
 if(tokens.size>=100||pageToken&&tokens.has(pageToken))throw new CalendarError('Calendar listing was incomplete or repeated. No partial list accepted.');if(pageToken)tokens.add(pageToken)
 const response=await client.calendarList.list({maxResults:250,showHidden:true,showDeleted:false,...(pageToken?{pageToken}:{})},{timeout:20000,retry:false})
 if(!response.data||response.data.items!==undefined&&!Array.isArray(response.data.items))throw new CalendarError('Invalid calendar page.')
 for(const c of response.data.items||[]){if(!c.id||!c.accessRole||ids.has(c.id))throw new CalendarError('Calendar listing contains missing or repeated IDs.');ids.add(c.id);rows.push({id:String(c.id),name:String(c.summaryOverride||c.summary||'(unnamed)'),role:c.accessRole,timeZone:c.timeZone||null,primary:!!c.primary,writable:['owner','writer'].includes(c.accessRole)})}pageToken=response.data.nextPageToken
 }while(pageToken);return rows}
