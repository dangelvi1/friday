import {mkdir,writeFile} from 'node:fs/promises'
import {join} from 'node:path'
import {digest} from './core'
import {folder,readJSON} from './storage'
// Permanent records are never removed. Recovery is allowed only through a new
// exclusive journal entry when the previous exact submission durably says false.
export async function reserveCatalogWrite(owner:any,productId:string,rows:any[],reviewId:string,loadOwned:(owner:any,id:string)=>Promise<any>){
 const hash=digest({productId,fields:rows.map(c=>({field:c.field,before:c.before,after:c.after}))}),dir=join(folder(owner),'catalog-claims'),path=join(dir,hash+'.json')
 await mkdir(dir,{recursive:true,mode:0o700})
 try{await writeFile(path,JSON.stringify({reviewId,createdAt:Date.now()}),{flag:'wx',mode:0o600});return{allowed:true,recoveredFrom:null}}catch(e:any){if(e.code!=='EEXIST')throw e}
 let record:any;try{record=await readJSON(path)}catch{return{allowed:false,relatedReceiptId:null,reason:'The existing submission record cannot be inspected. No repeat was attempted.'}}
 const seen=new Set<string>()
 for(let depth=0;depth<20;depth++){
  const priorId=record?.reviewId
  if(typeof priorId!=='string'||seen.has(priorId)||priorId===reviewId)return{allowed:false,relatedReceiptId:null,reason:'A submission is already reserved or its history is ambiguous. No repeat was attempted.'}
  seen.add(priorId)
  let prior:any;try{prior=await loadOwned(owner,priorId)}catch{return{allowed:false,relatedReceiptId:null,reason:'The earlier owned receipt is unavailable. No repeat was attempted.'}}
  const selected=rows.map(c=>(prior.changes||[]).find((x:any)=>x.id===c.id&&x.productId===productId&&x.field===c.field&&digest(x.before??null)===digest(c.before??null)&&digest(x.after??null)===digest(c.after??null)))
  const ids=new Set(rows.map(c=>c.id)),results=(prior.results||[]).filter((r:any)=>r.productId===productId&&(r.changeIds||[]).some((id:string)=>ids.has(id)))
  const proof=prior.format==='catalog-v16'&&!['prepared','queued','running'].includes(prior.status)&&selected.every(Boolean)&&results.length>0&&results.every((r:any)=>r.writeAttempted===false&&['blocked_before_write','stopped before submission'].includes(r.status))&&new Set(results.flatMap((r:any)=>r.changeIds||[])).size===ids.size&&[...ids].every(id=>results.some((r:any)=>(r.changeIds||[]).includes(id)))
  if(!proof||results.some((r:any)=>r.relatedReceiptId))return{allowed:false,relatedReceiptId:priorId,reason:'This exact write has an earlier submitted or uncertain record. No repeat was attempted; inspect its receipt.'}
  const recoveryDir=join(folder(owner),'catalog-recoveries');await mkdir(recoveryDir,{recursive:true,mode:0o700});const recoveryPath=join(recoveryDir,hash+'-'+priorId+'.json')
  try{await writeFile(recoveryPath,JSON.stringify({reviewId,recoveryOf:priorId,createdAt:Date.now(),basis:'Exact prior receipt has writeAttempted false; fresh owner approval and current values checked.'}),{flag:'wx',mode:0o600});return{allowed:true,recoveredFrom:priorId}}catch(e:any){if(e.code!=='EEXIST')throw e}
  try{record=await readJSON(recoveryPath)}catch{return{allowed:false,relatedReceiptId:priorId,reason:'Recovery history cannot be inspected. No repeat was attempted.'}}
 }
 return{allowed:false,relatedReceiptId:null,reason:'Submission history exceeded its inspection limit. No repeat was attempted.'}
}
