// Presentation only: this module can scroll/point. It never clicks or submits.
let lastExplicit=0
function shown(e:HTMLElement){const w=e.ownerDocument.defaultView;if(!w||!e.isConnected||!e.getClientRects().length)return false;const s=w.getComputedStyle(e);return s.display!=='none'&&s.visibility!=='hidden'}
function visibleModal(d:Document){return Array.from(d.querySelectorAll<HTMLElement>('dialog[open],[role=dialog][aria-modal=true],#approvalOverlay')).find(shown)||null}
export function revealResult(target:HTMLElement|null,point?:((e:HTMLElement)=>void),explicit=true){
 if(!target||!shown(target))return false
 const d=target.ownerDocument,w=d.defaultView!,modal=visibleModal(d)
 if(modal&&!modal.contains(target))return false
 if(target.getBoundingClientRect().height>w.innerHeight*.8&&!target.matches('pre,textarea')){const first=target.querySelector<HTMLElement>('h1,h2,h3,h4,thead,tr,article')||target.firstElementChild as HTMLElement|null;if(first&&shown(first)&&first.getBoundingClientRect().height<w.innerHeight*.8)target=first}
 let top=12,bottom=w.innerHeight-12,left=0,right=w.innerWidth
 for(let parent=target.parentElement;parent;parent=parent.parentElement){const style=w.getComputedStyle(parent);if(/auto|scroll|hidden|clip/.test(style.overflowY)){const b=parent.getBoundingClientRect();top=Math.max(top,b.top+12);bottom=Math.min(bottom,b.bottom-12)}if(/auto|scroll|hidden|clip/.test(style.overflowX)){const b=parent.getBoundingClientRect();left=Math.max(left,b.left);right=Math.min(right,b.right)}}
 const r=target.getBoundingClientRect();if(r.top<top||r.bottom>bottom||r.left<left||r.right>right)target.scrollIntoView({block:'center',inline:'nearest',behavior:'instant'})
 if(explicit){lastExplicit=Date.now();d.dispatchEvent(new CustomEvent('friday-result-revealed'))}
 if(point)point(target)
 else{const existing=d.querySelector('[data-friday-result-pointer]');existing?.remove();const pointer=d.createElement('span'),box=target.getBoundingClientRect();pointer.dataset.fridayResultPointer='';pointer.textContent='➤';pointer.setAttribute('aria-hidden','true');pointer.style.cssText=`position:fixed;pointer-events:none;z-index:2147483647;color:#169d9a;font:28px system-ui;left:${Math.max(2,box.left-15)}px;top:${Math.max(5,Math.min(w.innerHeight-30,box.top+12))}px`;const parent=modal&&modal.contains(target)?modal:d.body;parent.append(pointer);w.setTimeout(()=>pointer.remove(),1600)}
 return true
}
const resultSelectors=['[data-friday-result]','#scMetricDetails','#scProductPrint','.sc-products .sc-product','#dcBatchOutcome','#dcHistoryRows','#dcResearch','#dcOwned','#dcChanges','#dcPricing','#dcListingInfo','#dpResult','#calendarEvents','#calendarReceipt','#phoneResearchResults','#phoneCurrent','#phoneTranscriptText','#officeResult','[data-log]','#fdJobs','#fdFunctionGrid','#fdHealthStatus','tbody tr','tbody','[role="alert"]','[role="status"]','div[id*="result" i]','section[id*="result" i]']
const busyText=/^(loading|reading|checking|searching|working|applying|queued|preparing|verifying|analysing|analyzing|saving)\b/i
const ignored='#fdCursor,[data-friday-result-pointer],#fdToast,#fdMessage,.fd-assistant,#fdVoiceControls'
export function createDashboardReveal(root:HTMLElement,point:(e:HTMLElement)=>void){
 type Context={arm:()=>void;result:(preferred?:HTMLElement|null)=>void;finish:(preferred?:HTMLElement|null)=>void;destroy:()=>void}
 const contexts=new Map<Document,Context>()
 function attach(d:Document):Context{
  if(contexts.has(d))return contexts.get(d)!
  const w=d.defaultView!;let intentUntil=0,origin:Element|null=null,editing:Element|null=null,timer:any
  const arm=()=>{intentUntil=Date.now()+180000;origin=d.activeElement;editing=null}
  const cancel=()=>{intentUntil=0;clearTimeout(timer)}
  function result(preferred?:HTMLElement|null){
   if(Date.now()>intentUntil||Date.now()-lastExplicit<800)return
   const active=d.activeElement;if(active&&active!==origin&&active.matches('input,textarea,select,[contenteditable=true]'))return
   const modal=visibleModal(d),scope=modal||(d===document?root.querySelector<HTMLElement>('[data-fd-module]:not([hidden])')||root.querySelector<HTMLElement>('.fd-view:not([hidden])')||root:d.body)
   const display=(e:HTMLElement)=>{if(!shown(e)||!e.textContent?.trim()||busyText.test(e.textContent.trim())||!scope.contains(e))return false;const target=e.matches('[data-log]')?e.lastElementChild as HTMLElement||e:e;if(revealResult(target,d===document?point:undefined,false)){cancel();return true}return false}
   if(preferred){display(preferred);return}
   for(const selector of resultSelectors)for(const candidate of scope.querySelectorAll<HTMLElement>(selector))if(display(candidate))return
  }
  const click=(e:Event)=>{if((e.target as Element)?.closest('button,a,[role=button]'))arm()}
  const key=(e:KeyboardEvent)=>{if(e.key==='Enter')arm();else if((e.target as Element)?.matches('input,textarea,select,[contenteditable=true]')){editing=e.target as Element;cancel()}}
  const observer=new MutationObserver(records=>{
   if(Date.now()>intentUntil)return
   let candidate:HTMLElement|null=null,priority=-1
   for(const r of records){const e=r.target.nodeType===3?r.target.parentElement:r.target as Element;if(!e||e.closest(ignored))continue
    const candidates=[e.closest<HTMLElement>(resultSelectors.join(',')),...Array.from(r.addedNodes).filter(n=>n.nodeType===1).map(n=>n as HTMLElement).flatMap(n=>[n.matches(resultSelectors.join(','))?n:null,n.querySelector<HTMLElement>(resultSelectors.join(','))])]
    for(const target of candidates){if(!target||target.closest(ignored)||!shown(target))continue;const rank=target.getAttribute('role')==='status'?0:target.getAttribute('role')==='alert'?2:1;if(rank>=priority){priority=rank;candidate=target}}
   }
   if(candidate){clearTimeout(timer);const target=candidate;timer=w.setTimeout(()=>result(target),100)}
  })
  observer.observe(d===document?root:d.body,{childList:true,characterData:true,subtree:true});d.addEventListener('click',click,true);d.addEventListener('keydown',key,true);d.addEventListener('wheel',cancel,{passive:true});d.addEventListener('touchstart',cancel,{passive:true});d.addEventListener('friday-result-revealed',cancel);d.addEventListener('friday-owner-session-changed',cancel)
  const context:Context={arm,result,finish(preferred){if(editing===d.activeElement)return;if(Date.now()>intentUntil)arm();clearTimeout(timer);timer=w.setTimeout(()=>result(preferred),120)},destroy(){cancel();editing=null;origin=null;observer.disconnect();d.removeEventListener('click',click,true);d.removeEventListener('keydown',key,true);d.removeEventListener('wheel',cancel);d.removeEventListener('touchstart',cancel);d.removeEventListener('friday-result-revealed',cancel);d.removeEventListener('friday-owner-session-changed',cancel)}}
  contexts.set(d,context);return context
 }
 attach(document)
 return{attach,completed(label='',data:any={}){
  if(/office task update|appearance|background/i.test(label)||Date.now()-lastExplicit<800)return
  const frame=Array.from(root.querySelectorAll<HTMLIFrameElement>('iframe')).find(f=>shown(f))
  if(frame){try{attach(frame.contentDocument!).finish()}catch{ /* Another origin is never inspected. */ }return}
  const selector=/restaurant/i.test(label)?'#phoneResearchResults':/phone/i.test(label)?'#phoneCurrent':/calendar/i.test(label)?(data.events?'#calendarEvents':data.review||data.event?'#calendarReceipt':'#calendarStatus'):/chat/i.test(label)?'[data-log]':null
  attach(document).finish(selector?root.querySelector<HTMLElement>(selector):null)
 },reset(){lastExplicit=0;for(const c of contexts.values())c.destroy();contexts.clear();attach(document)},destroy(){for(const c of contexts.values())c.destroy();contexts.clear()}}
}
